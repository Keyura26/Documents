sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ui5/PartDash/model/models",
	"sap/m/MessageBox",
	'sap/ui/model/json/JSONModel',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (UIComponent, Device, models, MessageBox, JSONModel, Filter, FilterOperator) {
	"use strict";
	let oBusyInd = new sap.m.BusyDialog();
	let busy = function (sText) {
		if (sText) {
			oBusyInd.setBusyIndicatorDelay(0);
			oBusyInd.setText(sText);
		}
		oBusyInd.open();
	};
	let notBusy = function () {
		oBusyInd.close();
	};
	return UIComponent.extend("ui5.PartDash.Component", {

		metadata: {
			"async": true,
			"interfaces": ["sap.ui.core.IAsyncContentCreation"],
			"manifest": "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			var oModel = new sap.ui.model.json.JSONModel();
			sap.ui.getCore().setModel(oModel, "viewData");
			this.setModel(oModel, "viewData");

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			this.getModel("device").setProperty("/SystemData", this.getModel("device").getData().system);
			// this.getModel("device").setProperty("/OrientationData", this.getModel("device").getData().orientation);

			this._deferredPersonaDataLoaded = $.Deferred();
			// this.getEmail(this._deferredPersonaDataLoaded);

			// var controller = this;
			var that = this;
			this._deferredPersonaDataLoaded.done(function () {
				that.getRouter().initialize();
			});
			// this.fnGetUserInfo().then(function () {
			// 	// this._FetchCustomerEmail();
			// 	this._deferredPersonaDataLoaded.resolve();
			// }.bind(this))

			// this.fnGetUserInfo(this._deferredPersonaDataLoaded);
			this.fnGetUserInfo();
			if (sap.ui.getCore()._appLoaded) {
				sap.ui.getCore()._appLoaded.resolve();
			}
		},

		//get oData model
		/*_getODataModel: function (oModel) {
			return this.getOwnerComponent().getModel(oModel);
		},*/
    
		// SOC This model gets Email of the logged in user
		
		fnGetUserInfo: function (odefObj) {

			var /*oModel = this.getView().getModel("viewData"),*/
				oServiceModel = this.getModel("SSVModel"),
				sPath = "/Ets_GetEmail";
			// var oModel = this.getModel("Z_MANAGE_SOL_Q_GP_SRV_EMAIL");
			var oEmailModel = this.getModel("EmailModel");
			   busy();
			// return new Promise(function (oResolve, oReject) {

			var mParameters = {
				method: "GET",
				// filters: [new Filter('Email', 'EQ', 'hiteshgujrathi.uat11@yopmail.com')],
				// urlParameters: {
				// 	$expand: 'userData/tierMapping,userData/userDetails,userData/userDetails/brTypeSet'
				// 		//$filter:'Email eq "hiteshgujrathi.uat11@yopmail.com"'
				// },
				success: jQuery.proxy(function (oData) {
					notBusy();
					// try {
					//oModel.setProperty("/Persona", oData.results[0].Persona);
					//oModel.setProperty("/EmailId", oData.results[0].Email);
					// this._loadPersonaData(oData.results[0].Email);

					var personaEmailModel = new JSONModel({
						"email": oData.results[0].Email,
						"aSoldto": []

					});
					personaEmailModel.getProperty("/aSoldto").push({
						"Soldto": "1001810197"
					});
					personaEmailModel.getProperty("/aSoldto").push({
						"Soldto": "1013160652"
						// 1001763858
					});
					sap.ui.getCore().setModel(personaEmailModel, 'personaEmailModel');
					this._deferredPersonaDataLoaded.resolve(personaEmailModel.oData);
					// this._deferredPersonaDataLoaded.resolve();
					//odefObj.resolve();
					// oResolve();
					// } catch (e) {
					//this._deferredPersonaDataLoaded.reject();
					//odefObj.reject();
					// oResolve();
					// }

				}, this),

				error: jQuery.proxy(function (oError) {
					// oResolve();
					//this._deferredPersonaDataLoaded.reject();
					//odefObj.reject();
				}, this)

			};

			oEmailModel.read(sPath, mParameters);
			// }.bind(this))
		},
    
		// EOC This model gets Email of the logged in user
	
	// getEmailAndDefaultURLs: function (odeferred) {
		// 	var controller = this,
		// 		aModel = this.getModel("viewData");

		// 	if (aModel.getProperty("/Persona") && aModel.getProperty("/EmailId")) {
		// 		odeferred.resolve();
		// 		return;
		// 	} else {
		// 		var __sBatchGroupId__ = Math.random().toString(36).slice(2).toUpperCase(),
		// 			oModel = this.getModel("SSVModel"),
		// 			sPath1 = "/Ets_GetEmail",
		// 			sPath2 = "/Ets_defaultUrls",
		// 			aFilters = [];
		// 		if (this.fnGetParamExistsInURI("imp")) {
		// 			var impValue = this.fnGetParamIdFrmURI("imp"),
		// 				decryptedImpValue = this.fnGetDecryptedParamIDs(impValue);
		// 			aFilters.push(new sap.ui.model.Filter("Email", "EQ", decryptedImpValue));
		// 		}

		// 		var mParameters = {
		// 			method: "GET",
		// 			filters: aFilters,
		// 			groupId: __sBatchGroupId__,
		// 			urlParameters: {
		// 				$expand: "userData/tierMapping,userData/userDetails,userData/userDetails/brTypeSet"
		// 			},
		// 			success: jQuery.proxy(function (oData) {

		// 				try {
		// 					aModel.setProperty("/Persona", oData.results[0].Persona);
		// 					aModel.setProperty("/EmailId", oData.results[0].Email);
		// 					aModel.setProperty("/dateFormat", oData.results[0].dateFormat);
		// 					aModel.setProperty("/userData", oData.results[0].userData);
		// 				} catch (e) { }

		// 			}, this),
		// 			error: jQuery.proxy(function (oError) {
		// 				odeferred.reject();
		// 			}, this)
		// 		};

		// 		oModel.read(sPath1, mParameters);

		// 		var mParameters2 = {
		// 			method: "GET",
		// 			groupId: __sBatchGroupId__,
		// 			success: jQuery.proxy(function (oData) {

		// 				try {
		// 					aModel.setProperty("/OrderURL", oData.results[1].osvorderurl);
		// 					aModel.setProperty("/PunchOutData_Details/osvorderurl", oData.results[1].osvorderurl); // ACHOPRADELOI RAMP-1458 2023/10/25
		// 					aModel.setProperty("/PunchOutData_Full/results/0/osvorderurl", oData.results[1].osvorderurl); // ACHOPRADELOI RAMP-1458 2023/10/25
		// 				} catch (e) {
		// 					aModel.setProperty("/OrderURL", "");
		// 				}

		// 				try {
		// 					aModel.setProperty("/DefaultURL", oData.results[0].osvdefaulturl);
		// 					aModel.setProperty("/PunchOutData_Details/osvdefaulturl", oData.results[0].osvdefaulturl); // ACHOPRADELOI RAMP-1458 2023/10/25
		// 					aModel.setProperty("/PunchOutData_Full/results/0/osvdefaulturl", oData.results[0].osvdefaulturl); // ACHOPRADELOI RAMP-1458 2023/10/25
		// 				} catch (e) {
		// 					aModel.setProperty("/DefaultURL", "");
		// 				}

		// 				/*SOC EAGLE BADH SOME4028A 2021/08/26*/
		// 				try {
		// 					aModel.setProperty("/SFDCCaseWebformURL", oData.results[2].sfdccaseurl);
		// 					aModel.setProperty("/PunchOutData_Details/sfdccaseurl", oData.results[2].sfdccaseurl); // ACHOPRADELOI RAMP-1458 2023/10/25
		// 					aModel.setProperty("/PunchOutData_Full/results/0/sfdccaseurl", oData.results[2].sfdccaseurl); // ACHOPRADELOI RAMP-1458 2023/10/25
		// 				} catch (e) {
		// 					aModel.setProperty("/SFDCCaseWebformURL", "");
		// 				}
		// 				odeferred.resolve();
		// 			}, this),
		// 			error: jQuery.proxy(function (oError) {
		// 				odeferred.reject();
		// 			}, this)
		// 		};

		// 		oModel.read(sPath2, mParameters2);

		// 		var mParameters3 = {
		// 			groupId: __sBatchGroupId__,
		// 			success: jQuery.proxy(function (oData) { }, this),
		// 			error: jQuery.proxy(function (oError) {
		// 				odeferred.reject();
		// 			}, this)
		// 		};
		// 		oModel.submitChanges(mParameters3);
		// 	}
		// },

		fnGetParamExistsInURI: function (param) {
			var __bOpptyExistsInURI = false;
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null && __oURIParam.get(param) !== "") {
					__bOpptyExistsInURI = true;
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null && __aStartUpParameter[param] !== "") {
							__bOpptyExistsInURI = true;
						}
					}
				}
			} catch (err) {

			}
			return __bOpptyExistsInURI;
		},
		// getEmail: function (odeferred) {
		// 	var controller = this;

		// 	//R1.8 TSINHADELOIT Performance - Avoid Duplicate Call - Add check condition if Email exists in Persona Model.
		// 	if (controller.getModel("viewData").getProperty("/Persona") && controller.getModel("viewData").getProperty("/EmailId")) {
		// 		odeferred.resolve();
		// 		return;
		// 	} else {
		// 		var path = "/Ets_GetEmail";
		// 		var oGlobalBusyDialog = new sap.m.BusyDialog();
		// 		oGlobalBusyDialog.open();
		// 		var oModel = this.getModel("Z_MANAGE_SOL_Q_GP_SRV_EMAIL");

		// 		return new Promise(function (oResolve, oReject) { //jmezadeloitte add promise in case persona is undefined PHOENIX-12601 17.06.2021

		// 			if (sap.ushell !== undefined) {
		// 				var sUSERID = sap.ushell.Container.getService("UserInfo").getUser().getId();
		// 				oModel.aUrlParams.push("CacheGroup=1");
		// 				oModel.aUrlParams.push("sId=" + btoa(sUSERID));
		// 			}

		// 			oModel.read(
		// 				path, {
		// 					urlParameters: {
		// 						"$format": "json"
		// 					},
		// 					success: function (oData, response) {
		// 						oGlobalBusyDialog.close();
		// 						if (controller.getModel("viewData").getProperty("/Persona") === undefined || controller.getModel("viewData").getProperty(
		// 								"/Persona") === "") {
		// 							controller.getModel("viewData").setProperty("/EmailId", oData.results[0].Email);
		// 							// that._loadPersonaData(oData.results[0].Email);
		// 							controller.getModel("viewData").setProperty("/isAdmin", oData.results[0].isAdmin); //AKADAM11DEC2021 SILVERPEAK 4277 CPN Change
		// 							controller.getModel("viewData").setProperty("/Persona", oData.results[0].Persona); //Defect 8672 AKADAM18JAN2021
		// 							controller.getModel("viewData").setProperty("/ArubaAdminFlag", oData.results[0].Custflag);

		// 							if (oData.results[0].Persona === "" && (__bDVEEnabled || __bITEEnabled)) { // ACHOPRADELOI INC2475093 2023/06/08
		// 								//SALES_OPS SALES_REP Reseller Distributor
		// 								controller.getModel("viewData").setProperty("/Persona", "SALES_OPS");
		// 							}
		// 							/*SOC BADH ASQ 3.0-SIMULATE WITH DIFFERENT PERSONA 2022/11/07*/
		// 							try {
		// 								var aStartUpParameter = controller.getComponentData().startupParameters;
		// 								if (aStartUpParameter["i_pers"]) {
		// 									controller.getModel("viewData").setProperty("/Persona", atob(decodeURIComponent(aStartUpParameter["i_pers"][0])));
		// 								}
		// 								if (aStartUpParameter["i_lang"]) {
		// 									sap.ui.getCore().getConfiguration().setLanguage(aStartUpParameter["i_lang"][0], decodeURIComponent(aStartUpParameter[
		// 										"i_lang"][0]));
		// 								}
		// 							} catch (err) {

		// 							}
		// 							/*EOC BADH ASQ 3.0-SIMULATE WITH DIFFERENT PERSONA 2022/11/07*/
		// 						}
		// 						odeferred.resolve();
		// 						oResolve("OK");
		// 					},
		// 					error: function (error) {
		// 						odeferred.reject();
		// 						oGlobalBusyDialog.close();
		// 					}
		// 				});S
		// 		});
		// 	}
		// },

		// _FetchCustomerEmail: function () {
		// 	busy("Loading");
		// 	let that = this;
		// 	$.ajax({
		// 		type: 'Get',
		// 		url: '/sap/bc/zutils/zui_email',
		// 		success: function (sData) {
		// 			// let sEmail = sData.split(",")[0];
		// 			let sEmail = "muktesh.mohan@hpe.com"
		// 				// that.sCountryCode = sData.split(",")[1] === undefined ? "" : sData.split(",")[1];
		// 			that._loadPersonaData(sEmail);
		// 		},
		// 		error: function (oError) {
		// 			notBusy();
		// 			console.log(oError);
		// 		}
		// 	});
		// },
		// _loadPersonaData: function (sEmail) {
		// 	let that = this;
		// 	let oPayload = {
		// 		// "customerEmail": sEmail, 
		// 		"customerEmail": "AAAAAAAAAAAAAAAAAAAAAJTyyR5md1Z4zcoiu3gCmTn8GAtzCJZz92MytwNR3qwL", // comment before deployment
		// 		"NV_TO_SALES_AREA": [],
		// 		"NV_TO_PURCHASE_AGREEMENT": []
		// 	};
		// 	let srvMainModel = this.getModel("QQModel");
		// 	srvMainModel.create("/ES_CUSTOMER",
		// 		oPayload, {
		// 			success: function (oData) {
		// 				if (oData.customerOrderBlockStatus === "") {
		// 					notBusy();
		// 					var personaModel = new JSONModel({
		// 						// "email": oData.customerEmail,
		// 						"aSoldto": []
		// 					});
		// 					personaModel.getProperty("/aSoldto").push({
		// 						"Soldto": oData.customerId
		// 					});
		// 					personaModel.getProperty("/aSoldto").push({
		// 						"Soldto": "1001763858"
		// 					});
		// 					// personaModel.getProperty("/aSoldto").push({
		// 					// 	"Soldto": "1001810196"
		// 					// });
		// 					// personaModel.getProperty("/aSoldto").push({
		// 					// 	"Soldto": "1001810199"
		// 					// });
		// 					//personaModel.setData(oData);
		// 					sap.ui.getCore().setModel(personaModel, 'personaModel');
		// 					that._deferredPersonaDataLoaded.resolve(oData);

		// 				} else {
		// 					notBusy();
		// 					let sMsg = oData.customerOrderBlockMessage;
		// 					//sMsg = "Hewlett Packard Enterprise (HPE) regrets to inform you that we are unable to act on your recent request. As a US company, HPE is required to comply with the Global trade laws sanctions and embargoes of the US and EU and those of other national governments where HPE does business, which may restrict or prohibit the conduct of business with certain persons, companies, organizations and countries or territories. To learn more about the identities of the persons, companies, organizations and countries that are subject to US trade controls, sanctions and embargoes, you may wish to contact the nearest US or EU member Embassy or Consulate or retrieve more information from the internet about EU (http://eeas.europa.eu/cfsp/sanctions/consol-list/index_en.htm) and US (https://www.treasury.gov/resource-center/sanctions/SDN-List/Pages/conso lidated.aspx) trade restrictions";
		// 					that._ErrorMsg(sMsg);
		// 				}
		// 			},
		// 			error: function (oError) {
		// 				notBusy();
		// 				let sMsg = JSON.parse(oError.responseText).error.message.value;
		// 				that._ErrorMsg(sMsg);
		// 			}
		// 		});
		// },
		_ErrorMsg: function (sMsg, fnAction) {
			MessageBox.show(
				sMsg, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: "Error",
				onClose: function (oAction) {
					window.open("https://www.HPE.com", "_self")
				}
			});
		}
	});
});