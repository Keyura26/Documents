sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			// if (oModel.getData().system.tablet && oModel.getData().system.desktop && oModel.getData().system.combi) {
			// 	oModel.getData().system.tablet = false;
			// }
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		}

	};
});