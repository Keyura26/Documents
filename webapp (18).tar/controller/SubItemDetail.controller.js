sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"ui5/PartDash/controller/BaseController",
	"ui5/PartDash/utils/formatter"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, UIComponent, Fragment, JSONModel, BaseController, formatter) {
		"use strict";
		// formatter:formatter,
		//Busy Indicator
		var __controller__,
			_sProviderContract,
			DisplayAVCDetails,
			sContract;
		var busy = function () {
			__controller__.getView().setBusyIndicatorDelay(0);
			__controller__.getView().setBusy(true);
		};

		var notBusy = function () {
			__controller__.getView().setBusy(false);
		};

		return BaseController.extend("ui5.PartDash.controller.SubItemDetail", {
			_formatter: formatter,

			onInit: function () {
				__controller__ = this;
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.getRoute("SubItemDetail").attachPatternMatched(this._onSubItemDetailMatched, this);
			},
			onChangeRenew: function (e) {
				let action = e.mParameters.state;
				let sText = "";
				if (action == true)
					sText = "Enable Auto Renewal";
				else
					sText = "Disable Auto Renewal"
				var contractActionModel = new sap.ui.model.json.JSONModel();
				contractActionModel.setData({
					"providerContract": sContract,
					"action": "B",
					"notes": "",
					"return": ""
				});

				if (!this._oAutoRenewDialog) {
					this._oAutoRenewDialog = new sap.m.Dialog({
						type: sap.m.DialogType.Message,
						title: sText,
						content: [
							new sap.m.CheckBox({
								text: "{i18n>xtxt.Main.Subscription.AutoRenewAgree}",
								select: function (_oEvent) {
									var bSelected = _oEvent.getParameter("selected");
									this._oAutoRenewDialog.getBeginButton().setEnabled(bSelected);
								}.bind(this)
							}).addStyleClass("sapUiTinyMarginBeginEnd"),
							new sap.m.Link({
								text: "{i18n>xtxt.Main.Subscription.AutoRenewTerms}",
								textAlign: "Center",
								press: function (_oEvent) { }.bind(this)
							})
						],
						beginButton: new sap.m.Button({
							type: sap.m.ButtonType.Emphasized,
							text: "{i18n>xtxt.Main.Subscription.Submit}",
							enabled: false,
							press: function () {
								var _oRequestData = this._oAutoRenewDialog.getModel("contractActionModel").getData(),
									oModel = this.getOwnerComponent().getModel("SSVModel");
								// this._subscriptionDialog.setBusy(true);
								// this._subscriptionDialog.setBusyIndicatorDelay(0);
								this.__openBusyDialog();
								oModel.create("/Ets_contractAction", _oRequestData, {
									method: "POST",
									success: function (oData, oResponse) {
										this.__closeBusyDialog();
										sap.m.MessageToast.show(oData.return);
										var _oViewModel = this.getView().getModel("viewData"),
											_sOrderNumber = _oViewModel.getProperty("/ContractDetailsOrderNumber");
										_sProviderContract = _oViewModel.getProperty("/ProviderContract");
										this.__fnGetProviderContractDetails(_sOrderNumber, _sProviderContract);
									}.bind(this),
									error: function (error) {
										this._subscriptionDialog.setBusy(false);
										sap.m.MessageBox.show(
											error.statusText, {
											icon: sap.m.MessageBox.Icon.ERROR,
											title: "Service Error",
											actions: [sap.m.MessageBox.Action.OK]
										});
										// this.byId("switch").setState(!this.byId("switch").getState());
									}.bind(this)
								});

								this._oAutoRenewDialog.close();
							}.bind(this)
						}).addStyleClass("homeBtn"),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								this._oAutoRenewDialog.close();
								// this.byId("switch").setState(!this.byId("switch").getState());
							}.bind(this)
						}).addStyleClass("homeBtn")
					});
					this.getView().addDependent(this._oAutoRenewDialog, this);
				}
				this._oAutoRenewDialog.setModel(contractActionModel, "contractActionModel");
				this._oAutoRenewDialog.setTitle(sText);
				this._oAutoRenewDialog.getContent()[0].setSelected(false);
				this._oAutoRenewDialog.getBeginButton().setEnabled(false);
				this._oAutoRenewDialog.open();
			},
			onPressDetails: function (oEvent) {

				var oButton = oEvent.getSource(),
					oView = this.getView();

				// create popover
				if (!this._pPopover) {
					this._pPopover = Fragment.load({
						id: oView.getId(),
						name: "ui5.PartDash.fragments.productDetails",
						controller: this
					}).then(function (_pPopover) {
						this._pPopover = _pPopover;
						oView.addDependent(_pPopover);
						this._pPopover.openBy(oEvent.getSource());
						// this.loadTableData();
						// return oPopover;
					}.bind(this));
				} else {
					this._pPopover.openBy(oEvent.getSource());
					// this.loadTableData();
				}

				// this._pPopover.then(function (oPopover) {
				// 	oPopover.openBy(oButton);
				// });
			},
			onViewInvoices: function () {
				this._getInvoices();

				if (!this._oDialog) {
					this._oDialog = sap.ui.xmlfragment("ui5.PartDash.fragments.Invoices", this);
				}

				this.getView().addDependent(this._oDialog);
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
				this._oDialog.open();
			},
			_getODataModel: function () {
				return this.getOwnerComponent().getModel("SSVModel");
			},
			onDownload: function (oEvent) {

				// TSINHADELOIT 5/4 - BOC
				// var sInvoice = oEvent.getSource().getBindingContext("viewData").getObject().Invoice;
				// TSINHADELOIT 5/4 - EOC
				//Line number 124 commented by SSAMRIDHI to accomodate INC0656338 changes
				var sInvoice = oEvent.getSource().getBindingContext("viewData").getObject().EncryptionKey; // ACHOPRADELOI RAMP-1007 2023/07/06
				var sPath = "/zcdoc-manager-billing/Ets_getInvoice(contract='',invoiceID='" + sInvoice + "',multi='Y')/$value"; // ACHOPRADELOI RAMP-1007 2023/07/06
				this.myWindow = window.open(sPath, "_blank");
			},

			//on Download All Invoices
			onDownloadAllInvoices: function (oEvent) {

				var ProviderContract = this.getView().getModel("viewData").getProperty("/ContractDetails/EncryptionKeyPC"); // ACHOPRADELOI RAMP-1007 2023/07/06
				var sPath = "/zcdoc-manager-billing/Ets_getInvoice(contract='" + ProviderContract + // ACHOPRADELOI RAMP-1007 2023/07/06
					"',multi='X',invoiceID='')/$value";
				this.myWindow = window.open(sPath, "_blank");
			},
			onContractActionBtnPress: function (oEvent) {
				var oButton = oEvent.getSource();
				this.byId("contractActionSheet").openBy(oButton);

				// 	var oView = this.getView(),
				// 		oSourceControl = oEvent.getSource();

				// 	if (!this._actionPopover) {
				// 		this._actionPopover = Fragment.load({
				// 			id: oView.getId(),
				// 			name: "ui5.PartDash.fragments.contractActions"
				// 		}).then(function (oPopover) {
				// 			oView.addDependent(oPopover);
				// 			return oPopover;
				// 		});
				// 	}

				// 	this._actionPopover.then(function (oPopover) {
				// 		oPopover.openBy(oSourceControl);
				// 	});
			},
			onClose: function () {

				this._oDialog.close();
				this._oDialog.destroy();
				this._oDialog = null;

			},
			_getInvoices: function () {

				var oModel = this.getView().getModel("viewData");
				var ProviderContract = this.getView().getModel("viewData").getProperty("/ProviderContract");

				oModel.setProperty("/Invoices", []);

				// this.getView().setBusy(true);
				var f = [];
				f.push(new sap.ui.model.Filter("Contract", "EQ", ProviderContract));
				var oServiceModel = this._getODataModel();

				var sPath = "/Ets_invoiceDetails";

				var mParameters = {
					method: "GET",
					filters: f,
					success: jQuery.proxy(function (oData) {

						// this.getView().setBusy(false);
						oModel.setProperty("/Invoices", oData.results);

						// the below functioanlity is used to set the download all buttton hide/visible

						if (oData.results.length === 0) {
							oModel.setProperty("/InvoiceDownloadAllBtnVis", false);

						}

						if (oData.results.length !== 0) {
							for (var b = 0; b <= oData.results.length; b++) {

								if (oData.results[b].Flag === "X") {
									oModel.setProperty("/InvoiceDownloadAllBtnVis", true);
									break;
								} else {

									oModel.setProperty("/InvoiceDownloadAllBtnVis", false);
								}
							}

						}

					}, this),
					error: jQuery.proxy(function (oError) {
						// this.getView().setBusy(false);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);
			},
			onPressDetailsAVC: function (oEvent) {
				var oButton = oEvent.getSource(),
					oView = this.getView();

				// create popover
				// if (!this.oAVCFragment) {
				if (!this._APopover) {
					this._APopover = Fragment.load({
						id: oView.getId(),
						name: "ui5.PartDash.fragments.AVCDetails",
						controller: this
					}).then(function (oPopover) {
						this._APopover = oPopover;
						oView.addDependent(this._APopover);
						// this.addFormElements();
						// this.clearFormElements();
						// this._APopover.openBy(oEvent.getSource());
						// this._APopover.attachAfterOpen(this.addFormElements(), this);
						// this._APopover.attachAfterOpen(function () {
						this.__PrepareAVCModelData().then(function () {
							this.addFormElements();
							// this.addFormElements1();
							this._APopover.openBy(oEvent.getSource());
						}.bind(this));

						// }.bind(this));
						// {


						// }.bind(this));
						this._APopover.attachAfterClose(function () {
							var oForm = this.byId("dynamicForm");
							if (oForm) {
								oForm.destroyContent();
								// this.getView().getModel("AVCDetailsModel").setProperty("/DisplayAVC", "");
							}
							this._APopover.destroy();
							this._APopover = null;
							// this.getView().getModel("AVCDetailsModel").setProperty("/DisplayAVC", "")
						}.bind(this));
						// this._APopover.openBy(oEvent.getSource());
						// this.addFormElements();

						// return oPopover;
					}.bind(this));
				}
				// }
				else {
					// this.clearFormElements();
					this.__PrepareAVCModelData().then(function () {
						// this.addFormElements();
						// this.addFormElements1();
						this._APopover.openBy(oEvent.getSource());
					}.bind(this));

				}
			},
			// clearFormElements: function () {
			// 	var oForm = this.byId("dynamicForm");
			// 	if (oForm) {
			// 		oForm.destroyContent();
			// 	}
			// },
			addFormElements1: function () {
				var oAVCDetailsModel = this.getView().getModel("AVCDetailsModel"),
					oSimpleForm = this.getView().byId("dynamicForm"),
					DisplayAVCDetails = oAVCDetailsModel.getProperty("/DisplayAVC");

				// const fields = caseModel.getProperty('/INPUT_FIELDS');
				// const form = this.getCustomFieldEditForm();
				const formDelimiter = new sap.ui.core.Title('', {});
				// const formDelimiter2 = new sap.ui.core.Title('form-delimiter2', {});
				const leftFormContainer = [formDelimiter];
				const rightFormContainer = [formDelimiter];

				DisplayAVCDetails.forEach((field, index) => {
					var oLabel = new sap.m.Label({
						text: field.title
					});
					var oText = new sap.m.Text({
						text: field.titleValue
					});
					// const { title, titleValue } = { oLabel, oText };
					//   this._editableCustomFieldFormElementFactory(field, dataPath);
					if (index <= 5) {
						leftFormContainer.push(oLabel);
						leftFormContainer.push(oText);
					} else {
						rightFormContainer.push(oLabel);
						rightFormContainer.push(oText);
					}
				});
				const elementsToAdd = [...leftFormContainer, ...rightFormContainer];
				elementsToAdd.forEach(
					(el) => oSimpleForm.addContent(el));
			},

			addFormElements: function () {

				var oAVCDetailsModel = this.getView().getModel("AVCDetailsModel"),
					oSimpleForm = this.getView().byId("dynamicForm"),
					oAVCPopover = this.getView().byId("AVCPopover");
				// if (oAVCDetailsModel.getProperty("/DisplayAVC") === "") {
				DisplayAVCDetails = oAVCDetailsModel.getProperty("/DisplayAVC");
				// DisplayAVCDetails.forEach(function (item, idx) {
				// 	// if(idx === 0 || idx === 6){
				// 	// 	var oTitle = new sap.ui.core.Title({
				// 	// 		text : ""
				// 	// 	})
				// 	// 	oSimpleForm.addContent(oTitle) ;
				// 	// }
				// 	var oLabel = new sap.m.Label({
				// 		text: item.title
				// 	});
				// 	var oText = new sap.m.Text({
				// 		text: item.titleValue
				// 	});
				// 	var oTitle = new sap.ui.core.Title({
				// 		text: ""
				// 	});
				// 	if (idx === 0 || idx === 6 || idx === 13) {
				// 		oSimpleForm.addContent(oTitle);
				// 		oSimpleForm.addContent(oLabel);
				// 		oSimpleForm.addContent(oText);
				// 		// oSimpleForm.addContent(oTitle);
				// 	}

				// 	oSimpleForm.addContent(oLabel);
				// 	oSimpleForm.addContent(oText);

				// 	// oSimpleForm.addContent(oTitle);
				// })
				if (DisplayAVCDetails.length > 12 && DisplayAVCDetails.length <= 18) {
					oSimpleForm.setMaxContainerCols(3);
					oSimpleForm.setColumnsXL(3);
					oSimpleForm.setColumnsM(3);
					oSimpleForm.setColumnsL(3);
					// oAVCPopover.setContentWidth("max-width");
					// oAVCPopover.setContentWidth("110%");
					if (sap.ui.Device.system.phone) {
						let phnsize = sap.ui.Device.resize.width * 9 / 10;
						oAVCPopover.setContentWidth(`${phnsize}px`);
					} else {
						oAVCPopover.setContentWidth("110%");
					}
					oAVCPopover.setContentHeight("auto");
					// 53%
				}
				else if (DisplayAVCDetails.length > 6 && DisplayAVCDetails.length <= 12) {
					// oAVCPopover.setContentWidth("50%");
					// oAVCPopover.setContentHeight("40%");
					oSimpleForm.setMaxContainerCols(2);
					oSimpleForm.setColumnsXL(2);
					oSimpleForm.setColumnsM(2);
					oSimpleForm.setColumnsL(2);
					// oAVCPopover.setContentWidth("max-width");
					// oSimpleForm.setColumnsL(2);
					if (sap.ui.Device.system.phone) {
						let phnsize = sap.ui.Device.resize.width * 9 / 10;
						oAVCPopover.setContentWidth(`${phnsize}px`);
					} else {
						oAVCPopover.setContentWidth("53%");
					}

					oAVCPopover.setContentHeight("auto");
				} else if (DisplayAVCDetails.length > 0 && DisplayAVCDetails.length <= 6) {
					// oAVCPopover.setContentWidth("40%");
					// oAVCPopover.setContentHeight("50%");
					oSimpleForm.setMaxContainerCols(1);
					oSimpleForm.setColumnsXL(1);
					oSimpleForm.setColumnsM(1);
					oSimpleForm.setColumnsL(1);
					// oAVCPopover.setContentWidth("auto");
					// oSimpleForm.setWidth("auto");
					// oSimpleForm.setLabelSpanS(6);
					// oSimpleForm.setLabelSpanM(6);
					// oSimpleForm.setLabelSpanL(6);
					if (sap.ui.Device.system.phone) {
						let phnsize = sap.ui.Device.resize.width * 9 / 10;
						oAVCPopover.setContentWidth(`${phnsize}px`);
					} else {
						oAVCPopover.setContentWidth("25%");
					}
					oAVCPopover.setContentHeight("auto");
				}
				DisplayAVCDetails.forEach(function (item, idx) {
					// if(idx === 0 || idx === 6){
					// 	var oTitle = new sap.ui.core.Title({
					// 		text : ""
					// 	})
					// 	oSimpleForm.addContent(oTitle) ;
					// }
					var oLabel = new sap.m.Label({
						text: item.title
						// width: "auto"
						// wrapping: true
					});
					var oText = new sap.m.Text({
						text: item.titleValue
					});
					var oTitle = new sap.ui.core.Title({
						text: ""
					});

					// TitleWrapper.addStyleClass("notitle")
					// oTitle.addStyleClass("notitle");
					if (idx === 6 || idx === 12) {
						// oSimpleForm.addContent(new sap.ui.core.InvisibleText({ text: "" }));
						oSimpleForm.addContent(oTitle);
						// oSimpleForm.addContent(oLabel);
						// oSimpleForm.addContent(oText);
						// oSimpleForm.addContent(oTitle);
					}

					oSimpleForm.addContent(oLabel);
					oSimpleForm.addContent(oText);
					// oSimpleForm.addContent(oTitle);
				})



			},
			__fnSetAVCDetails: function (AVCDetailsModel) {

				// var oAVCDetailsModel = this.getView().getModel("AVCDetailsModel"),
				var aChars = AVCDetailsModel.getProperty("/AssignedValues"),
					flagTerm,
					flagTermDesc,
					termValue,
					termDesc,
					odisplayAVCDet = [];
				aChars.forEach(function (Item, Idx) {
					var visibility = !Item.IsHidden,
						name = Item.Name,
						description = Item.Description,
						value,
						assignedValues = Item.AssignedValues.results;
					if (!(assignedValues.length > 0)) {
						value = "";
					} else {
						if (name === "CS_TERM") {
							flagTerm = true;
							termValue = aChars[Idx].AssignedValues.results[0].TechnicalValue;
						} else {
							value = aChars[Idx].AssignedValues.results[0].Description;
						}
					}
					if (name === "CS_TERM_UOM") {
						flagTermDesc = true;
						termDesc = aChars[Idx].AssignedValues.results[0].Description
					}
					if (flagTerm && flagTermDesc && visibility) {
						flagTermDesc = false;
						flagTerm = false;
						odisplayAVCDet.push({
							title: "Term",
							titleValue: termValue + " " + termDesc
						});
					}
					if (visibility && name !== "CS_TERM_UOM" && name !== "CS_TERM") {
						odisplayAVCDet.push({
							title: description,
							titleValue: value
						});
					}

				});
				AVCDetailsModel.setProperty("/DisplayAVC", odisplayAVCDet);

				// var oDispalyAVC = oAVCDetailsModel.getproperty("/DisplayAVC");
				// if (oDispalyAVC) {
				// 	resolve();
				// } else {
				// 	setTimeout(resolve, 100);
				// }
				// })
			},

			__PrepareAVCModelData: function () {
				return new Promise(function (resolve, reject) {
					var oAVCDetailsModel = this.getView().getModel("AVCDetailsModel");
					// this.__AVCConfigDetails();
					// poll the model to ensure property is set
					var CheckInterval = setInterval(function () {
						if (oAVCDetailsModel.getProperty("/DisplayAVC")) {
							clearInterval(CheckInterval);
							resolve();
						}
					}, 50);
				}.bind(this));
			},
			//SOC This method loads the time slices associated with contract number
			
			__fnGetHistoricalTimeSlices: function (_sProviderContract) {
				var oModel = this.getView().getModel("viewData");
				var that = this;
				var _sOrderNumber = "";
				var f = [];
				var oServiceModel = this.getView().getModel("SSVModel");
				var sPath = "/Ets_contractTimeSlice";
				// this.__openBusyDialog(sPath);
				f.push(new sap.ui.model.Filter("providerContract", "EQ", _sProviderContract));
				
				let deviceModel = this.getView().getModel("device").getProperty("/SystemData").phone;
				var ConHistoryControl;
				if (!deviceModel) {
					ConHistoryControl = this.getView().byId("	");
				} else {
					ConHistoryControl = this.getView().byId("idContractHisPhone");
				}
				var _oReadOptions = {};
				_oReadOptions["oModel"] = this.getView().getModel("SSVModel");
				_oReadOptions["sPath"] = sPath;
				// _oReadOptions["isAbsolutePath"] = true;
				_oReadOptions["oControl"] = ConHistoryControl;
				// _oReadOptions["oControlM"] = this.getView().byId("ProductDetails");
				_oReadOptions["bGlobalBusy"] = false;
				_oReadOptions["oFilters"] = [new sap.ui.model.Filter(f, true)];
				_oReadOptions["oURIParameters"] = {
					"$format": "json"
					// "$expand": "conHead_conItem,conHead_conPart"
				};
				_oReadOptions["fnSuccess"] = function (oData, oResponse) {
					console.log(oData);
					var timeSliceStart, timeSliceEnd, timeSlice, historicalTimeSlice = [],
						timeSlicePayload, timeSliceStartPayload, timeSliceEndPayload, historicalForPayload = [];
					oData.results.forEach(function (data) {
						if (data.TimeSliceStartDate !== undefined && data.TimeSliceStartDate !== null && data.TimeSliceStartDate !== "") {
							// var format = this.getView().getModel("viewData").getProperty("/DateFormat");
							var format = "dd/mm/yyyy";
							timeSliceStart = formatter.dynamicFormatDate(data.TimeSliceStartDate, true, format);
							timeSliceStartPayload = formatter.dynamicFormatDate(data.TimeSliceStartDate, true, undefined, true);
						}

						if (data.TimeSliceEndDate !== undefined && data.TimeSliceEndDate !== null && data.TimeSliceEndDate !== "") {
							// var format = this.getView().getModel("viewData").getProperty("/DateFormat");
							var format = "dd/mm/yyyy";
							timeSliceEnd = formatter.dynamicFormatDate(data.TimeSliceEndDate, true, format);
							timeSliceEndPayload = formatter.dynamicFormatDate(data.TimeSliceEndDate, true, undefined, true);
						}

						timeSlice = timeSliceStart + " - " + timeSliceEnd;
						timeSlicePayload = timeSliceStartPayload + " - " + timeSliceEndPayload;

						historicalTimeSlice.push({
							"timeSlice": timeSlice
						});

						historicalForPayload.push({
							"timeSlice": timeSlicePayload
						});
					}.bind(that));
					oModel.setProperty("/historicalTimeSlice", historicalTimeSlice);
					oModel.setProperty("/historicalForPayload", historicalForPayload);

				}.bind(this);
				this.__readODataOperation(_oReadOptions);
			},
						
			//EOC This method loads the time slices associated with contract number

			onChangeHistoricalTimeSlice: function (oEvent) {
				var oViewModel = this.getView().getModel("viewData"),
					_sOrderNumber = "",
					_sProviderContract = oViewModel.getProperty("/ProviderContract"),
					timesliceStart, timeSliceEnd, timeSlice = [];
				timeSlice = oEvent.getSource().getSelectedKey().split(" - ");
				var timeSlicePayload = oViewModel.getProperty("/historicalForPayload")[oEvent.getSource().getSelectedIndex()]["timeSlice"].split(
					" - ");
				timesliceStart = this.convertStringToTimestamp(timeSlicePayload[0]);
				timeSliceEnd = this.convertStringToTimestamp(timeSlicePayload[1]);
				this.__fnGetProviderContractDetails(_sOrderNumber, _sProviderContract, timesliceStart, timeSliceEnd);
			},
			convertStringToTimestamp: function (dateTimeString) {
				// Split the string into date and time parts
				var parts = dateTimeString.split(' '),
					datePart = parts[0],
					timePart = parts[1],

					// Split the date into year, month, and day
					dateParts = datePart.split('-'),
					year = parseInt(dateParts[0], 10),
					month = parseInt(dateParts[1], 10) - 1, // Months are zero-based in JavaScript
					day = parseInt(dateParts[2], 10),

					// Split the time into hours, minutes, and seconds
					timeParts = timePart.split(':'),
					hours = parseInt(timeParts[0], 10),
					minutes = parseInt(timeParts[1], 10),
					seconds = parseInt(timeParts[2], 10),

					// Create a new Date object in UTC
					date = new Date(Date.UTC(year, month, day, hours, minutes, seconds));

				// Return the timestamp in milliseconds
				return date.getTime();
			},
			__fnGetProviderContractDetails: function (_sOrderNumber, _sProviderContract, timeSliceStart, timeSliceEnd) {
				// busy();
				let partnerFilter = [];
				let path = "/Ets_contractHeadDetail";
				let panel1 = this.getView().byId("1");
				partnerFilter.push(new sap.ui.model.Filter("providerContract", "EQ", sContract));
				if (timeSliceStart !== undefined && timeSliceStart !== null && timeSliceStart !== "") {
					partnerFilter.push(new sap.ui.model.Filter("timeslicestartdate", "EQ", timeSliceStart));
				}
				if (timeSliceEnd !== undefined && timeSliceEnd !== null && timeSliceEnd !== "") {
					partnerFilter.push(new sap.ui.model.Filter("timeslicenddate", "EQ", timeSliceEnd));
				}
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC");
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				// this.__openBusyDialog(path);
				// oModel.read(path, {
				// 	method: "GET",
				// 	urlParameters: {
				// 		$format: "json",
				// 		$expand: "conHead_conItem,conHead_conPart"
				// 	},
				// 	filters: partnerFilter,
				// 	success: function (d) {
				// 		try {
				// 			// busy();
				// 			console.log(d);
				// this.__closeBusyDialog(path);
				var DetailSubModel = this.getView().getModel("DetailSubModel");
				var SubProductModel = this.getView().getModel("SubProductModel");
				var SubBPModel = this.getView().getModel("SubBPModel");
				var timeSliceStart, timeSliceEnd, timeSlice,
					_oReadOptions = {};
				// _oReadOptions["oModel"] = this.getView().getModel("Z_SUBSTATUS_CLOUDSTC");
				// // _oReadOptions["oHeaders"] = {
				// // 	'X-Requested-With': 'X',
				// // 	'Accept': 'application/json',
				// // };
				// _oReadOptions["sPath"] = path;
				// _oReadOptions["oControl"] = this.getView().byId("1");
				// _oReadOptions["bGlobalBusy"] = false;
				// // _oReadOptions["isAbsolutePath"] = false;
				// _oReadOptions["oURIParameters"] = {
				// 	"sap-client": "300",
				// 	"$expand": "conHead_conItem,conHead_conPart"
				// };
				// _oReadOptions["filters"] = [new sap.ui.model.Filter(partnerFilter, true)];

				_oReadOptions["oModel"] = this.getView().getModel("Z_SUBSTATUS_CLOUDSTC");
				// _oReadOptions["oHeaders"] = {
				// 	'X-Requested-With': 'X',

				// };
				_oReadOptions["sPath"] = path;
				// _oReadOptions["isAbsolutePath"] = true;
				_oReadOptions["oControl"] = this.getView().byId("SubDetails");
				_oReadOptions["oControlM"] = this.getView().byId("ProductDetails");
				_oReadOptions["bGlobalBusy"] = false;
				_oReadOptions["oFilters"] = [new sap.ui.model.Filter(partnerFilter, true)];
				_oReadOptions["oURIParameters"] = {
					"$format": "json",
					"$expand": "conHead_conItem,conHead_conPart"
				};

				// if (d.results[0].timeslicestartdate !== undefined && d.results[0].timeslicestartdate !== null && d.results[0].timeslicestartdate !==
				// 	"") {
				// 	// var format = this.getView().getModel("viewData").getProperty("/DateFormat");
				// 	var format = "dd-MM-yyyy";
				// 	timeSliceStart = formatter.dynamicFormatDate(d.results[0].timeslicestartdate, true, format);
				// }

				// if (d.results[0].timeslicenddate !== undefined && d.results[0].timeslicenddate !== null && d.results[0].timeslicenddate !==
				// 	"") {
				// 	// var format = this.getView().getModel("viewData").getProperty("/DateFormat");
				// 	var format = "dd-MM-yyyy";
				// 	timeSliceEnd = formatter.dynamicFormatDate(d.results[0].timeslicenddate, true, format);
				// }

				// timeSlice = timeSliceStart + " - " + timeSliceEnd;
				// this.getView().getModel("viewData").setProperty("/activeTimeSlice", timeSlice);
				// this.getView().getModel("viewData").setProperty("/timeSliceStart", timeSliceStart);
				// this.getView().getModel("viewData").setProperty("/timeSliceEnd", timeSliceEnd);
				// // var SubBPModel = new JSONModel(),
				// var bindedData = d.results[0].conHead_conItem.results[0];
				// DetailSubModel.setData(d.results[0]);
				// SubProductModel.setData(d.results[0].conHead_conItem.results[0]);
				// SubBPModel.setData(d.results[0].conHead_conPart.results);
				// // this.getView().setModel(DetailSubModel, 'DetailSubModel');
				// // this.getView().setModel(SubProductModel, 'SubProductModel');
				// // this.getView().setModel(SubBPModel, 'SubBPModel');
				// var objectStatusId = this.getView().byId("objProStatus3");
				// DetailSubModel.refresh(true);
				// SubProductModel.refresh(true);
				// SubBPModel.refresh(true);
				// objectStatusId.removeStyleClass("greenDot");
				// if (bindedData.status === "Active") {
				// 	objectStatusId.setState("Success");
				// 	objectStatusId.addStyleClass("greenDot");
				// } else if (bindedData.status === "Suspended") {
				// 	objectStatusId.setState("Error");
				// 	objectStatusId.addStyleClass("redDot");
				// } else {
				// 	objectStatusId.setState("Indication10");
				// 	objectStatusId.addStyleClass("greyDot");
				// }
				// notBusy();
				_oReadOptions["fnSuccess"] = function (d, oResponse) {
					console.log(d);
					this.getView().getModel("viewData").setProperty("/ContractDetails", d.results[0]);
					if (d.results[0].timeslicestartdate !== undefined && d.results[0].timeslicestartdate !== null && d.results[0].timeslicestartdate !==
						"") {
						// var format = this.getView().getModel("viewData").getProperty("/DateFormat");
						var format = "dd-MM-yyyy";
						timeSliceStart = formatter.dynamicFormatDate(d.results[0].timeslicestartdate, true, format);
					}

					if (d.results[0].timeslicenddate !== undefined && d.results[0].timeslicenddate !== null && d.results[0].timeslicenddate !==
						"") {
						// var format = this.getView().getModel("viewData").getProperty("/DateFormat");
						var format = "dd-MM-yyyy";
						timeSliceEnd = formatter.dynamicFormatDate(d.results[0].timeslicenddate, true, format);
					}

					timeSlice = timeSliceStart + " - " + timeSliceEnd;
					this.getView().getModel("viewData").setProperty("/activeTimeSlice", timeSlice);
					this.getView().getModel("viewData").setProperty("/timeSliceStart", timeSliceStart);
					this.getView().getModel("viewData").setProperty("/timeSliceEnd", timeSliceEnd);
					// var SubBPModel = new JSONModel(),
					if (d.results[0].conHead_conItem.results[0] !== "" || d.results[0].conHead_conItem.results[0] !== null || d.results[0].conHead_conItem.results[0] !== undefined) {
						var bindedData = d.results[0].conHead_conItem.results[0];
					}
					if (d.results[0] !== "" || d.results[0] !== null || d.results[0] !== undefined) {
						DetailSubModel.setData(d.results[0]);
					}
					if (d.results[0].conHead_conItem.results[0] !== "" || d.results[0].conHead_conItem.results[0] !== null || d.results[0].conHead_conItem.results[0] !== undefined) {
						SubProductModel.setData(d.results[0].conHead_conItem.results[0]);
					}
					if (d.results[0].conHead_conPart.results !== "" || d.results[0].conHead_conPart.results !== null || d.results[0].conHead_conPart.results !== undefined) {
						SubBPModel.setData(d.results[0].conHead_conPart.results);
					}
					// this.getView().setModel(DetailSubModel, 'DetailSubModel');
					// this.getView().setModel(SubProductModel, 'SubProductModel');
					// this.getView().setModel(SubBPModel, 'SubBPModel');
					var objectStatusId;
					let deviceModel = this.getView().getModel("device").getProperty("/SystemData").phone;
					if (!deviceModel) {
						objectStatusId = this.getView().byId("objStatusDesktop");
					} else {
						objectStatusId = this.getView().byId("objStatusPhone");
					}
					DetailSubModel.refresh(true);
					SubProductModel.refresh(true);
					SubBPModel.refresh(true);
					this.ChangeTimeSliceColor();
					objectStatusId.removeStyleClass("greenDot");
					objectStatusId.removeStyleClass("redDot");
					objectStatusId.removeStyleClass("greyDot");
					if (bindedData !== undefined) {
						if (bindedData.status !== "" || bindedData.status !== undefined || bindedData.status !== null) {
							if (bindedData.status === "Active") {
								objectStatusId.setState("Success");
								objectStatusId.addStyleClass("greenDot");
							} else if (bindedData.status === "Suspended") {
								objectStatusId.setState("Error");
								objectStatusId.addStyleClass("redDot");
							} else {
								objectStatusId.setState("Indication10");
								objectStatusId.addStyleClass("greyDot");
							}
						}
					}
				}.bind(this);
				this.__readODataOperation(_oReadOptions);
			},
			_fnProductDetails: function (sContract, partnerFilter) {
				var productpath = "/Ety_ActualUsageSet";
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC");
				var _oReadOptions = {};
				_oReadOptions["oModel"] = this.getView().getModel("Z_SUBSTATUS_CLOUDSTC");
				_oReadOptions["sPath"] = productpath;
				// _oReadOptions["isAbsolutePath"] = true;
				_oReadOptions["oControl"] = this.getView().byId("productsDetailsTable");
				// _oReadOptions["oControlM"] = this.getView().byId("ProductDetails");
				_oReadOptions["bGlobalBusy"] = false;
				_oReadOptions["oFilters"] = [new sap.ui.model.Filter(partnerFilter, true)];
				_oReadOptions["oURIParameters"] = {
					"$format": "json"
					// "$expand": "conHead_conItem,conHead_conPart"
				};
				_oReadOptions["fnSuccess"] = function (d, oResponse) {
					var ProductsDetailsModel = new JSONModel();
					ProductsDetailsModel.setData(d.results);
					this.getView().setModel(ProductsDetailsModel, 'ProductsDetailsModel');

				}.bind(this);
				this.__readODataOperation(_oReadOptions);
			},
			ChangeTimeSliceColor: function () {
				var id1, id2;
				id1 = this.getView().byId("idContractHis").sId + '-labelText';
				id2 = this.getView().byId("idContractHisPhone").sId + '-labelText';
				let deviceModel = this.getView().getModel("device").getProperty("/SystemData").phone;
				if (!deviceModel) {
					var current_span1 = document.getElementById(id1).innerHTML;
				} else {
					var current_span2 = document.getElementById(id2).innerHTML;
				}
				if (!deviceModel) {
					if (!current_span1.includes("zcustomHPEColours") && current_span1 !== "") {
						var arr = current_span1.split(" ");
						var highlightedText = arr[0] + " " + '<span class="zcustomHPEColours">' + arr[1] + '</span>' + " " + arr[2] + " " + arr[3] +
							" " +
							'<span class="zcustomHPEColours">' + arr[4] + '</span>';
						document.getElementById(id1).innerHTML = highlightedText;
					}
				}
				else {
					if (!current_span2.includes("zcustomHPEColours") && current_span2 !== "") {
						var arr = current_span2.split(" ");
						var highlightedText = arr[0] + " " + '<span class="zcustomHPEColours">' + arr[1] + '</span>' + " " + arr[2] + " " + arr[3] +
							" " +
							'<span class="zcustomHPEColours">' + arr[4] + '</span>';
						document.getElementById(id2).innerHTML = highlightedText;
					}
				}
			},
			_onSubItemDetailMatched: function (oEvent) {
				// busy();
				var that = this;
				this.getView().setModel(new JSONModel(), 'DetailSubModel');
				this.getView().setModel(new JSONModel(), 'SubProductModel');
				this.getView().setModel(new JSONModel(), 'SubBPModel');
				this.getView().setModel(new JSONModel(), 'viewData');
				this.getView().setModel(new JSONModel(), 'AVCDetailsModel');

				this.getView().getModel("AVCDetailsModel").setProperty("/DisplayAVC", "");
				if (sap.ui.Device.system.desktop || sap.ui.Device.system.tablet) {
					this.getView().byId("1").getHeaderToolbar().insertContent(new sap.m.ToolbarSpacer, 2);
					this.getView().byId("DetailsDynamicPage").getTitle().mAggregations.expandedContent[0].setVisible(true);
				}
				else if (sap.ui.Device.system.phone) {
					// this.getView().byId("1").getHeaderToolbar();
					var toolbarSpacer = this.getView().byId("1").getHeaderToolbar().mAggregations.content.find(function (ele) {
						if (ele instanceof sap.m.ToolbarSpacer) {
							return true;
						}
					})
					if (toolbarSpacer) {
						this.getView().byId("1").getHeaderToolbar().removeContent(2);
					}
					if (this.getView().byId("1").getHeaderToolbar().mAggregations.content.length === 3) {
						this.getView().byId("1").getHeaderToolbar().insertContent(new sap.m.ToolbarSpacer, 2);
					} else if (this.getView().byId("1").getHeaderToolbar().mAggregations.content.length === 4) {
						this.getView().byId("idUpgradeBtn").setIcon("");
						this.getView().byId("idDowngradeBtn").setIcon("");
						// this.getView().byId("1").getHeaderToolbar().mAggregations.content[3].setIcon("");
						this.getView().byId("DetailsDynamicPage").getTitle().mAggregations.expandedContent[1].setVisible(true);
					}
				}
				let oArgs = oEvent.getParameter("arguments");
				// this.loadInvoices();
				sContract = oArgs.Contract;
				var viewData = new JSONModel();
				var _sOrderNumber = "";
				var sDraftKey, sObjectKey;
				_sProviderContract = viewData.setProperty("/ProviderContract", sContract);
				this.getView().setModel(viewData, 'viewData');
				
				let productpath = "/Ety_ActualUsageSet";
				let AVCpath = "/Ets_contractGuid('" + sContract + "')";
				

				let partnerFilter = [];
				partnerFilter.push(new sap.ui.model.Filter("providerContract", "EQ", sContract));
				// this._fnProductDetails(sContract, partnerFilter);
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC");


				
				this.__AVCConfigDetails(sContract);
				this.__fnGetHistoricalTimeSlices(sContract);
				this._fnProductDetails(sContract, partnerFilter);
				this.__fnGetProviderContractDetails(_sOrderNumber, sContract);
			},
			onPressUpgradeOrDowngrade: function (oEvent) {
				var processId = oEvent.getSource().getId(),
					ObjectID = this.getView().getModel("viewData").getProperty("/ProviderContract"),
					sUserEmailId = "",
					oResourceModel = this.getResourceBundle(),
					process;
				// _sURL = this.getView().getModel("viewData").getProperty("/ASQPunchOutURL");

				// Arjun: CPQE4302 start
				if (processId.includes("FundsAdittion")) {
					process = "FUNDS_ADDITION";
				} else if (processId.includes("idUpgradeBtn")) {
					process = "Upgrade";
				} else {
					process = "Downgrade";
				}
				// Arjun: CPQE4302 end

				//SOI jmezadeloitte SOME4302 " Add Funds Addition and remoe middle spaces"
				process = process.replace(/\s/g, "");
				//EOI jmezadeloitte SOME4302 " Add Funds Addition and remoe middle spaces"
				var f = [];
				//SOC kkalikapuram GLBP -1781 Upgrade Access issue
				var PartnerEmailId = this.getView().getModel("viewData").getProperty("/PunchOutData_Details/emailId");
				try {
					if (PartnerEmailId !== undefined && PartnerEmailId !== "" && PartnerEmailId !== null) {
						sUserEmailId = PartnerEmailId.split("|")[0];
					} else {
						if (sap.ushell !== undefined) {
							var sLoginUser = sap.ushell.Container.getUser();
							if (sLoginUser !== undefined) {
								sUserEmailId = sLoginUser.getEmail();
							}
						}

					}
				} catch (err) { }
				//EOC kkalikapuram GLBP -1781 Upgrade Access issue
				f.push(new sap.ui.model.Filter("Process", "EQ", process));
				f.push(new sap.ui.model.Filter("ObjectID", "EQ", ObjectID));
				f.push(new sap.ui.model.Filter("EmailID", "EQ", sUserEmailId));

				this.__openBusyDialog();

				var punchoutData = this.getView().getModel("viewData").getProperty("/PunchOutData");
				var oDataModel = this.getView().getModel("SSVOpportunity");
				oDataModel.read("/Ets_Details", {
					method: "GET",
					filters: f,
					success: function (oData) {
						this.__closeBusyDialog();
						var oppId = oData.results[0].OpportunityID,
							//var encodedOppId = btoa(oppId);
							//ACHOPRADELOI RAMP-1020 ASQ redirection URL adaptations 2023/09/08
							paramIdArr = btoa(oppId).split("").reverse();
						[paramIdArr[1], paramIdArr[11]] = [paramIdArr[11], paramIdArr[1]];
						[paramIdArr[2], paramIdArr[10]] = [paramIdArr[10], paramIdArr[2]];
						var encodedOppId = paramIdArr.join("");
						if (sap.ushell) {
							// var url = window.location.href;
							// url = url.substring(0, url.lastIndexOf("#"));
							// if (url.lastIndexOf("?") === -1) {
							// 	url = url + "?";
							// } else {
							// 	url = url + "&";
							// }
							// url = url + "i_opp=" + encodedOppId + "&punchoutType=SSV" + "#ZLTS-manageSolQuote";
							// sap.m.URLHelper.redirect(url, true);

							// var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
							// 	hash = "";
							// hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
							// 	target: {
							// 		semanticObject: "ZLTS",
							// 		action: "manageSolQuote",
							// 	},
							// 	params: {
							// 		"o": encodedOppId,
							// 		"e": "CROSS_APP_SSV",
							// 		"punchoutType": "SSV"
							// 	}
							// })) || "";

							// oCrossAppNavigator.toExternal({
							// 	target: {
							// 		shellHash: hash + "&/Create/External"
							// 	}
							// });

							/*SOC kkalikapuram GLBP-1214 2024/06/03*/
							sap.m.MessageBox.confirm(
								oResourceModel.getText("xtxt.Main.Subscription.QuoteCreate", oppId), {
								title: oResourceModel.getText("xtxt.Main.Subscription.QuoteConfirm"),
								actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
								onClose: function (oAction) {
									if (oAction === sap.m.MessageBox.Action.OK) {
										// User clicked OK, proceed with the action
										var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
											hash = "";

										hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
											target: {
												semanticObject: "ZLTS",
												action: "manageSolQuote",
											},
											params: {
												"o": encodedOppId,
												"e": "S",
												"b": punchoutData === "" || punchoutData === undefined || punchoutData ===
													null ? "" : punchoutData["Usertype"] === "" || punchoutData["Usertype"] === undefined || punchoutData["Usertype"] ===
														null ? "" : punchoutData["Usertype"].toUpperCase() === "INTERNAL" ?
													"so" : punchoutData["Usertype"].toUpperCase() === "PARTNER" ?
														punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("RS") ? "rs" :
															punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("DT") ? "dt" : "" : ""
											}
										})) || "";

										// var sTargetAppUrl =	oCrossAppNavigator.toExternal({
										// 		target: {
										// 			shellHash: hash + "&/Create/External"
										// 		}
										// 	});
										var sTargetAppUrl = window.location.href.split('#')[0] + hash + "&/Cr/Ex";
										sap.m.URLHelper.redirect(sTargetAppUrl, true);
										// window.open(sTargetAppUrl,'_blank');
									} else {
										// User clicked Cancel, do something else or just close the dialog
										// console.log("User clicked Cancel");
									}
								}
							}
							);
							/*EOC kkalikapuram GLBP-1214 2024/06/03*/

						} /*SOC BADH EAGLE-4243 2022/01/27*/
						else {
							// SOC kkalikapuram GLBP-1214 2024/06/19
							sap.m.MessageBox.confirm(
								oResourceModel.getText("xtxt.Main.Subscription.QuoteCreate", oppId), {
								title: oResourceModel.getText("xtxt.Main.Subscription.QuoteConfirm"),
								actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
								onClose: function (oAction) {
									if (oAction === sap.m.MessageBox.Action.OK) {

										var sProtocol = window.location.protocol,
											sHostName = window.location.hostname,
											baseurl = sProtocol + "//" + sHostName,
											_sURL = baseurl + "/go-hpe#ZLTS-manageSolQuote?";

										// var _oViewModel = this.getView().getModel("viewData"),
										// 	_sURL = _oViewModel.getProperty("/ASQPunchOutURL");
										// if (_sURL === undefined || _sURL === "" || _sURL === null) {
										// 	_sURL = window.location.origin + "/z_manage_sol_q_pp/index.html?sap-ui-xx-fesr=false";
										// }

										// if (_sURL.lastIndexOf("?") === -1) {
										// 	_sURL = _sURL + "?";
										// } else {
										// 	_sURL = _sURL + "&";
										// }
										var __sLanguage = "";
										if (sap.ui.getCore().getConfiguration().getLanguage()) {
											__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
										} else {
											__sLanguage = "EN";
										}
										var b_parameter = punchoutData === "" || punchoutData === undefined || punchoutData ===
											null ? "" : punchoutData["Usertype"] === "" || punchoutData["Usertype"] === undefined || punchoutData["Usertype"] ===
												null ? "" :
											punchoutData["Usertype"].toUpperCase() === "INTERNAL" ?
												"so" : punchoutData["Usertype"].toUpperCase() === "PARTNER" ?
													punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("RS") ? "rs" :
														punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("DT") ? "dt" : "" : "";
										_sURL = _sURL + "e=S" + "&b=" + b_parameter + "&o=" + encodedOppId + "&sap-language=" + __sLanguage +
											"#/Cr/Ex";
										sap.m.URLHelper.redirect(_sURL, true);
									} else {
										// User clicked Cancel, do something else or just close the dialog
										// console.log("User clicked Cancel");
									}
								}
							}
							);
							// EOC kkalikapuram GLBP-1214 2024/06/19
							//	this._fnOpenASQPunchOutUrl(encodedOppId, _sURL);
							//ACHOPRADELOI RAMP-1020 ASQ redirection URL adaptations 2023/09/08
						} /*EOC BADH EAGLE-4243 2022/01/27*/
					}.bind(this),
					error: function (oError) {
						this.__closeBusyDialog();
						var errorJson = JSON.parse(oError.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
						/*for(var i=0;i<msgs.lenght;i++){
							sap.ui.getCore().getMessageManager().addMessages(msgs[i].message);
						}*/
					}.bind(this)
				});
			},
			// SOC This method sets the AVC Configuration Details for select contract number
			__AVCConfigDetails: function (sContract) {
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC");
				let AVCpath = "/Ets_contractGuid('" + sContract + "')";
				var sDraftKey, sObjectKey;
				oModel.read(AVCpath, {
					method: "GET",
					urlParameters: {
						$format: "json"
					},
					success: function (d) {
						try {
							sDraftKey = d.draftKey,
								sObjectKey = d.objectKey;
							var sUI_Mode = "(7)UI_MODE(7)Display",
								_oReadOptions = {},
								aAssignedValues = [],
								sURI = "/CharacteristicsGroupSet(ContextId='VCH(12)SEMANTIC_OBJ(8)CRMOrder(10)OBJECT_KEY(26)" + sObjectKey +
									"(9)DRAFT_KEY(32)" + sDraftKey + "(16)DRAFT_KEY_IS_STR(1)X(14)EMBEDDING_MODE(13)Configuration(15)LEGACY_SCENARIO(1)X" +
									sUI_Mode +
									"',InstanceId='1',GroupId=1)/Characteristics";

							_oReadOptions["oModel"] = this.getView().getModel("AVCModel");
							_oReadOptions["oHeaders"] = {
								'X-Requested-With': 'X',
								'Accept': 'application/json',
							};
							_oReadOptions["sPath"] = sURI;
							_oReadOptions["oControl"] = this.getView().byId("AVCPopover");
							_oReadOptions["bGlobalBusy"] = false;
							_oReadOptions["oURIParameters"] = {
								"sap-client": "300",
								"$expand": "DomainValues,AssignedValues"
							};
							_oReadOptions["fnSuccess"] = function (oData, oRespongse) {
								console.log(oData);
								var AVCDetailsModel = this.getView().getModel("AVCDetailsModel");
								AVCDetailsModel.setProperty("/AssignedValues", oData.results);
								this.getView().setModel(AVCDetailsModel, 'AVCDetailsModel');
								// if (!this.oAVCFragment) {
								// 	this.oAVCFragment = Fragment.load({
								// 		id: this.getView().getId(),
								// 		name: "ui5.PartDash.fragments.AVCDetails",
								// 		controller: this
								// 	}).then(function (oPopover1) {
								// 		this.oAVCFragment = oPopover1;
								// 		// this.getView().addDependent(this.oAVCFragment);
								// 		// this.byId("dynamicForm");
								// 	}.bind(this));

								// } else {

								// }
								// AVCDetailsModel.setData(oData.results);
								// oData.results.forEach(function(attr){
								// 	if(attr.AssignedValues){
								// 		aAssignedValues = aAssignedValues.concat(attr.AssignedValues.results);
								// 	}
								// })
								this.__fnSetAVCDetails(AVCDetailsModel);

								// this.getView().setModel(AVCDetailsModel, 'AVCDetailsModel');
								AVCDetailsModel.refresh();
							}.bind(this);
							this.__readODataOperation(_oReadOptions);
						} catch (e) { }
						// notBusy();
					}.bind(this),
					error: function (err) {
						var msg = JSON.parse(err.responseText).error.message.value;
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
						// notBusy();
					}.bind(this)
				});

			},
			// EOC This method sets the AVC Configuration Details for select contract number

			onPressNotificationPrepaidDrawdown: function (oEvent) {
				var oModel = this.getOwnerComponent().getModel("SSVModel"),
					_oViewModel = this.getView().getModel("viewData"),
					_sProviderContract = _oViewModel.getProperty("/ContractDetails/providerContract"),
					_sSoldToParty = _oViewModel.getProperty("/ContractDetails/soldtoID");

				this.__openBusyDialog();
				oModel.read("/Ets_OnDemand(Contract='" + _sProviderContract.trim() + "',Subscriber_Acc='" + _sSoldToParty.trim() + "')", {
					success: function (oData, oResponse) {
						this.__closeBusyDialog();
						sap.m.MessageToast.show("Details successfully sent to CCS");
					}.bind(this),
					error: function (error) {
						this.__closeBusyDialog();
						try {
							var errMsg = JSON.parse(error.responseText).error.message.value;
							sap.m.MessageBox.show(
								errMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Service Error",
								actions: [sap.m.MessageBox.Action.OK]
							});
						} catch (err) {
							sap.m.MessageBox.show(
								error.statusText, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Service Error",
								actions: [sap.m.MessageBox.Action.OK]
							});
						}
					}.bind(this)
				});
			},
			onPressSubscriptionContractAction: function (oEvent) {
				var sURL = "",
					sURLParameter = "",
					_oViewModel = this.getView().getModel("viewData"),
					sBtnText = oEvent.getSource().getText(),
					oResourceModel = this.getResourceBundle(),
					bSFDCCaseCreation = false,
					_sProviderContract = _oViewModel.getProperty("/ContractDetails/providerContract"),
					__sLanguage = "";

				if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ExtendEval")) {
					var __bSP_Flag = _oViewModel.getProperty("/ContractDetails/SP_Flag"), //BADH SILVERPEAK-1213 2022/02/23
						startDate = _oViewModel.getProperty("/ContractDetails/conStartDate"),
						/*	endDate = _oViewModel.getProperty("/ContractDetails/conEndDate"),*/
						currDate = new Date(),
						diffDays = Math.round((currDate - startDate) / (1000 * 60 * 60 * 24));

					if (diffDays > 120 && __bSP_Flag !== "X") {
						bSFDCCaseCreation = true;
					} else {
						this.fnExtendEval(_sProviderContract, "C", sBtnText);
					}

				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.AutoRenewSet") || sBtnText === oResourceModel.getText(
					"xbtn.Main.Subscription.AutoRenewRemove")) {
					this.fnAutoRenewContractAction(_sProviderContract, "B", sBtnText);
				} else {
					bSFDCCaseCreation = true;
				}

				if (bSFDCCaseCreation) {
					if (this.fnGetParamExistsInURI("i_t") || window.location.href.includes("index.html") === true) { // ACHOPRADELOI RAMP-1458 2023/10/17
						if (_oViewModel.getProperty("/SFDCCaseWebformURL") !== undefined && _oViewModel.getProperty("/SFDCCaseWebformURL") !== "") {
							sURL = _oViewModel.getProperty("/SFDCCaseWebformURL");
						} else {
							sURL = oResourceModel.getText("xurl.Main.Subscription.SFDCCaseWebform3");
						}
						/*SOC BADH EAGLE-2850 2021/12/11*/
						if (_oViewModel.getProperty("/PunchOutData_Details/emailId")) {

							/*SOC BADH INC0698341 2022/02/22*/
							var __userDetails = _oViewModel.getProperty("/PunchOutData_Details/emailId").split("|");
							if (__userDetails.length > 1) {
								sURLParameter += "&" + "Case_Requestor_Email__c=" + __userDetails[0];
								sURLParameter += "&" + "Case_Requestor__c=" + __userDetails[1];
								sURLParameter += "&" + "Requestor_Phone__c=" + __userDetails[2];
							} else {
								sURLParameter += "&" + "Case_Requestor_Email__c=" + __userDetails[0];
							}
							/*EOC BADH INC0698341 2022/02/22*/
						}

						/*EOC BADH EAGLE-2850 2021/12/11*/
					} else {
						if (_oViewModel.getProperty("/SFDCCaseWebformURL") !== undefined && _oViewModel.getProperty("/SFDCCaseWebformURL") !== "") {
							sURL = _oViewModel.getProperty("/SFDCCaseWebformURL");
						} else {
							sURL = oResourceModel.getText("xurl.Main.Subscription.SFDCCaseWebform3");
						}
					}

					try {
						if (sap.ushell !== undefined) {
							var sLoginUser = sap.ushell.Container.getUser();
							if (sLoginUser !== undefined) {
								//Your Name:
								sURLParameter += "Case_Requestor__c=" + sLoginUser.getFullName();
								//Email:
								sURLParameter += "&" + "Case_Requestor_Email__c=" + sLoginUser.getEmail();
								//Phone number:
								/*sURL += "Requestor_Phone__c=";*/
								__sLanguage = sLoginUser.getLanguage();
							} else {
								/*SOC BADH EAGLE-2850 2021/12/07*/
								if (sap.ui.getCore().getConfiguration().getLanguage()) {
									__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
								} else {
									__sLanguage = "EN";
								}
								/*EOC BADH EAGLE-2850 2021/12/07*/
							}
						} else {
							/*SOC BADH EAGLE-2850 2021/12/11*/
							if (sap.ui.getCore().getConfiguration().getLanguage()) {
								__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
							} else {
								__sLanguage = "EN";
							}
							/*EOC BADH EAGLE-2850 2021/12/11*/
						}

					} catch (err) {
						/*SOC BADH EAGLE-2850 2021/12/11*/
						if (sap.ui.getCore().getConfiguration().getLanguage()) {
							__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
						} else {
							__sLanguage = "EN";
						}
						/*EOC BADH EAGLE-2850 2021/12/11*/
					}

					/*SOC BADH EAGLE-3706 2021/12/15*/
					switch (__sLanguage.toUpperCase()) {
						case "EN": //English
							__sLanguage = "en_US";
							break;
						case "HE": //Hebrew
							__sLanguage = "iw";
							break;
						case "ID": //Indonesian
							__sLanguage = "in";
							break;
						case "PT": //Portuguese Brazil
							__sLanguage = "pt_BR";
							break;
						case "ZH": //Chinese (Simplified)
							__sLanguage = "zh_CN";
							break;
						case "ZH-HANS": //Chinese (Simplified)
							__sLanguage = "zh_CN";
							break;
						case "ZF": //Chinese (Traditional)
							__sLanguage = "zh_TW";
							break;
						case "ZH-HANT": //Chinese (Traditional)
							__sLanguage = "zh_TW";
							break;
					}
					/*EOC BADH EAGLE-3706 2021/12/15*/

					//Language:
					sURLParameter += "&" + "lang=" + __sLanguage.toUpperCase();

					//Region:
					sURLParameter += "&" + "Region__c=" + _oViewModel.getProperty("/AdressDetailsSoldTO/region");
					//Account Country:
					sURLParameter += "&" + "Country_of_Submitter__c=" + _oViewModel.getProperty("/AdressDetailsSoldTO/country");
					//Quote Number:
					sURLParameter += "&" + "CPQ_Quote_Number__c=" + _oViewModel.getProperty("/ContractDetails/quoteID");
					//Customer Purchase Order (PO) Number:
					sURLParameter += "&" + "PO_number__c=" + _oViewModel.getProperty("/ContractDetails/poNumber");
					//Party ID:
					sURLParameter += "&" + "Target_ID__c=" + _oViewModel.getProperty("/ContractDetails/customerID");
					//HPE Order Number:
					sURLParameter += "&" + "HP_Order_Number__c=" + _sProviderContract.trim();
					//Sold-to Party Name:
					sURLParameter += "&" + "Sold_to_Party__c=" + _oViewModel.getProperty("/ContractDetails/soldtoID");
					/*SOC BADH EAGLE-2631 2021/11/26*/
					//Business Group:
					sURLParameter += "&" + "Business_Group__c=" + _oViewModel.getProperty("/ContractDetails/SalesOff");
					/*EOC BADH EAGLE-2631 2021/11/26*/

					/*//Sales Order Amount:
					sURLParameter += "&" + "Sales_Order_Amount__c=";*/
					//Currency:
					sURLParameter += "&" + "CurrencyIsoCode=" + _oViewModel.getProperty("/ContractDetails/currency");
					if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ExtendEval")) {
						//Case reason:
						sURLParameter += "&" + "Reason=Subscription Changes";
						//Scenario:
						sURLParameter += "&" + "Scenario=Evaluation extension request";
					} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqCancelation")) {
						//Case reason:
						sURLParameter += "&" + "Reason=Subscription Changes";
						//Scenario:
						sURLParameter += "&" + "Scenario=Subscription cancellation request";
					} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.DisputeInvoice")) {
						//Case reason:
						sURLParameter += "&" + "Reason=Invoicing";
						//Scenario:
						sURLParameter += "&" + "Scenario=Invoice Correction Request"; /*BADH GLBP-1771 2024.06.24*/
					} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqUpgrade")) { //SOC ACHOPRADELOI SOME-4028 2024/04/04
						//Case reason:
						sURLParameter += "&" + "Reason=Subscription Changes";
						//Scenario:
						sURLParameter += "&" + "Scenario=Upgrade request"; //kkalikapuram GLBP -1822 2024/06/19
					}
					//EOC ACHOPRADELOI SOME-4028 2024/04/04
					/*SOC EAGLE-1945 - BADH DEFECT 2021/09/24*/
					if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ExtendEval")) {
						//Subject:
						sURLParameter += "&" + "Subject=Subscription Changes/Evaluation extension request/10181-02";
					} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqCancelation")) {
						//Subject:
						sURLParameter += "&" + "Subject=Subscription Changes/Subscription cancellation request/10181-02";
					} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.DisputeInvoice")) {
						//Subject:
						sURLParameter += "&" + "Subject=Invoicing/Invoice Correction request/10181-02";
					} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqUpgrade")) { //SOC ACHOPRADELOI SOME-4028 2024/04/04
						//Subject:
						sURLParameter += "&" + "Subject=Subscription Changes/Upgrade request/10181-02";
					}
					//EOC ACHOPRADELOI SOME-4028 2024/04/04
					/*EOC EAGLE-1945 - BADH DEFECT 2021/09/25*/

					/*//Description:
					sURLParameter += "&" + "Case_description__c=";
					//Additional email addresses to keep in copy:
					sURLParameter += "&" + "Cc_Contact_Email__c=" + _oViewModel.getProperty("/ContractDetails/customerID");*/

					sURL = sURL + "?" + sURLParameter;

					sap.m.URLHelper.redirect(sURL, true);
				}
			},
			invoiceChange: function (e) {
				let invoice = e.getSource().mProperties.selectedKey;
				if (invoice != "") {
					var sPath = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_getInvoice(contract='',invoiceID='" + invoice + "',multi='Y')/$value";
					this.myWindow = window.open(sPath, "_blank");
				}
			},
			// loadInvoices: function () {
			// 	let path = "/ety_cc_invoicesSet";
			// 	let partnerFilter = [];
			// 	partnerFilter.push(new sap.ui.model.Filter("Contract", "EQ", sContract));
			// 	let oModel = this.getOwnerComponent().getModel("CloudCredit");
			// 	oModel.setHeaders({
			// 		"X-Requested-With": "X"
			// 	});
			// 	oModel.read(path, {
			// 		method: "GET",
			// 		urlParameters: {
			// 			$format: "json"
			// 		},
			// 		filters: partnerFilter,
			// 		success: function (d) {
			// 			try {
			// 				var InvoiceModel = new JSONModel();
			// 				d.results = d.results.filter(function (el) {
			// 					return el.InvoiceDate != "";
			// 				});
			// 				for (let x in d.results) {
			// 					d.results[x].InvoiceDate = d.results[x].InvoiceDate.toDateString();
			// 				}
			// 				if (d.results.length != 0)
			// 					d.results.unshift({
			// 						InvoiceDate: "Please Select Invoice Date"
			// 					})
			// 				else
			// 					d.results.unshift({
			// 						InvoiceDate: "No invoice found"
			// 					})
			// 				InvoiceModel.setData(d.results);
			// 				this.getView().setModel(InvoiceModel, 'InvoiceModel');
			// 			} catch (e) { }
			// 		}.bind(this),
			// 		error: function (err) {
			// 			var msg = JSON.parse(err.responseText).error.message.value;
			// 		}.bind(this)
			// 	});
			// }


		});
	});