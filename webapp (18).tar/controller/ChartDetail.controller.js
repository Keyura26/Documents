sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/json/JSONModel',
	'sap/m/MessageToast',
	'sap/viz/ui5/controls/common/feeds/FeedItem',
	'sap/viz/ui5/data/FlattenedDataset',
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/ui/core/UIComponent",
	"ui5/PartDash/controller/BaseController",
	// 'ui5.PartDash/view/BaseController',
	'ui5/PartDash/controller/RevealGrid',
	'sap/viz/ui5/controls/VizTooltip',
	'ui5/PartDash/chart/pieChart',
	'ui5/PartDash/chart/d3Chart', // kkalikapuram D3 Chart Changes
	'ui5/PartDash/chart/barChart'
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, JSONModel, MessageToast, FeedItem, FlattenedDataset, ChartFormatter, Format, UIComponent, BaseController,
		RevealGrid, VizTooltip,
		pieChart, d3Chart, barChart) {
		"use strict";
		var path1, path2, path3, path4,
			path1Pie, path2Pie, path3Pie, path4Pie, path5Pie,
			path1Bar, path2Bar, path3Bar, path4Bar, path5Bar,
			personaEmailModel,
			soldTo = [],
			soldToTrials,
			checkFlag = false,
			device,
			oFilterModel,
			aProd_category1,
			rtm, prodCategory, dateid, startdate, enddate, formatPattern,
			upRenewalsfilter, prodCategoryId, rtmId, dateId, startdateId, enddateId, upRenewalsfilterId,
			trailsFilter, trailsFilterId, expiredFilter, expiredFilterId;
		return BaseController.extend("ui5.PartDash.controller.ChartDetail", {
			bInitCalled: false,
			bExpiredCalled: false,
			_setCustomFormatter: function () {
				var chartFormatter = ChartFormatter.getInstance();
				formatPattern = ChartFormatter.DefaultPattern;
				Format.numericFormatter(chartFormatter);
				var UI5_FLOAT_FORMAT = "CustomFloatFormat_F2";
				chartFormatter.registerCustomFormatter(UI5_FLOAT_FORMAT, function (value) {
					var ofloatInstance = sap.ui.core.format.NumberFormat.getFloatInstance({
						style: 'short',
						maxFractionDigits: 2
					});
					return ofloatInstance.format(value);
				});
			},

			onRevealGrid: function () {
				RevealGrid.toggle("carouselGrid", this.getView());
			},

			onExit: function () {
				RevealGrid.destroy("carouselGrid", this.getView());
			},
			onUserProfile: function (oEvent) {
				if (!this._oUserPopover) {
					this._oUserPopover = sap.ui.xmlfragment("ui5.PartDash.fragments.user", this);
					this.getView().addDependent(this._oUserPopover);
				}
				var oMultiComboBox = sap.ui.getCore().byId("soldtoSelect");
				if(oMultiComboBox){
					oMultiComboBox.setSelectedKeys(soldTo);  //on initial load selecting all sold-to's
				}
				this._oUserPopover.openBy(oEvent.getSource());
			},
			onInit: function (oEvent) {
				var that = this;
				this.getOwnerComponent()._deferredPersonaDataLoaded.done(function (PersonaData) {
					//setting the initial filter values
					oFilterModel = that.getOwnerComponent().getModel("localJsonModel");
					oFilterModel.setProperty("/ProductCategory", "");
					oFilterModel.setProperty("/Category", "");
					oFilterModel.setProperty("/dateType", "");
					oFilterModel.setProperty("/StartDate", null);
					oFilterModel.setProperty("/EndDate", null);
					 device = that.getOwnerComponent().getModel("device").getData();
					 //SOC Grid Settings for phone and mobile
					if ((device.system.combi || device.system.tablet) && !device.system.desktop && device.orientation.portrait) {
						var oGridLayout = that.getView().byId("carouselGrid");
						var oGridResponsiveLayout = oGridLayout.getCustomLayout();
						var oGridSettingsL = new sap.ui.layout.cssgrid.GridSettings({
							gridTemplateColumns: "repeat(auto-fit, 50rem)",
							gridAutoRows: "minmax(10rem,auto)",
							gridGap: "5rem 5rem"
						})
						var oGridSettingsM = new sap.ui.layout.cssgrid.GridSettings({
							gridTemplateColumns: "repeat(auto-fit, 43rem)",
							gridAutoRows: "minmax(10rem,auto)",
							gridGap: "3rem 3rem"
						})
						oGridResponsiveLayout.setLayoutL(oGridSettingsL);
						oGridResponsiveLayout.setLayoutM(oGridSettingsM);
					}
					else if ((device.system.combi || device.system.tablet) && !device.system.desktop && device.orientation.landscape) {
						var oGridLayout = that.getView().byId("carouselGrid");
						var oGridResponsiveLayout = oGridLayout.getCustomLayout();
						var oGridSettingsL = new sap.ui.layout.cssgrid.GridSettings({
							gridTemplateColumns: "repeat(auto-fit, 30rem)",
							gridAutoRows: "minmax(6rem,auto)",
							gridGap: "5rem 5rem"
						})
						var oGridSettingsM = new sap.ui.layout.cssgrid.GridSettings({
							gridTemplateColumns: "repeat(auto-fit, 43rem)",
							gridAutoRows: "minmax(10rem,auto)",
							gridGap: "3rem 3rem"
						})
						oGridResponsiveLayout.setLayoutL(oGridSettingsL);
						oGridResponsiveLayout.setLayoutM(oGridSettingsM);
					}
					//EOC Grid Settings for phone and mobile
					personaEmailModel = new JSONModel();
					// aModel.setProperty("/Persona", oData.results[0].Persona);
					personaEmailModel.setData(sap.ui.getCore().getModel('personaEmailModel').getData());
					that.getView().setModel(personaEmailModel, 'personaEmailModel');
					// that.getView()
					// soldTo = PersonaData.aSoldto[0].Soldto;
					soldTo = sap.ui.getCore().getModel('personaEmailModel').getProperty("/aSoldto").map(item => item.Soldto);
					// soldToTrials = "8999299909";
					that.getView().setModel(personaEmailModel, "personaEmailModel");
					that.loadActiveSubsCard(soldTo);
					that.loadRenewalsCard(soldTo);
					that.loadTrialCard(soldTo);
					that.loadExpiredCard(soldTo);
					that._oGrid = that.getView().byId("carouselGrid");
					that._oCarousel = that.getView().byId("activeCarousel");
					// SOC Carousel shows blank list while its loading
					var oList = new sap.m.List({
						showNoData: false
					});
					that._oCarousel.addPage(oList);
					 // EOC Carousel shows blank list while its loading
					that._oCarousel.attachPageChanged(that.onCarouselPageChanged, that);  // on scroll of page in carousel of My Active Subscriptions(1st Card)
                    
				});


			},
			onAfterRendering: function () {
				
				
			},
			  // SOC Removal all existing carousel pages when app is rendered
			destroyCarouselPages: function () {
				var oCarousel = this.getView().byId("activeCarousel");
				var aPages = oCarousel.getPages();
				aPages.forEach(function (oPage) {
					oPage.destroy();
				});
				oCarousel.removeAllPages();
			},
			 // EOC Removal all existing carousel pages when app is rendered
         
			 // SOC method triggers when sold to selection is changed
			
			 onChangeSoldTo: function (oEvent) {
				// var oMainController = this.getView().getParent().getParent().getController();
				// oEventBus = sap.ui.getCore().getEventBus();
				var oSelect = oEvent.getSource(),
					selectedKey = oSelect.getSelectedKeys(),
					soldTo = selectedKey;
					sap.ui.getCore().getModel('personaEmailModel').setProperty("/aSoldto", soldTo);
				var oList = new sap.m.List({
					showNoData: false
				});
				this._oCarousel = this.getView().byId("activeCarousel");
				// this.destroyCarouselPages();
				// this._oCarousel.removeAllPages();
				this._oCarousel.addPage(oList);
				this.loadActiveSubsCard(soldTo);
				this.loadRenewalsCard(soldTo);
				this.loadTrialCard(soldTo);
				this.loadExpiredCard(soldTo);
				// SOC Same View for both filter bar and Chart so commenting it
				// this.oEventBus.publish("channel1", "event1", {
				// 	soldto: selectedKey
				// });
				// EOC Same View for both filter bar and Chart so commenting it

			},

			 // EOC method triggers when sold to selection is changed

			// SOC To Clear the Filters on click of Clear Button 
			onClearFilters: function (oEvent) {
				if (oEvent.mParameters.selectionSet[0].getSelectedKey() === "" && oEvent.mParameters.selectionSet[1].getSelectedKey() === "" &&
					oEvent.mParameters.selectionSet[2].getSelectedKey() === "" && oEvent.mParameters.selectionSet[3].getDateValue() === null && oEvent
						.mParameters.selectionSet[3].getSecondDateValue() === null) { } else {
					oEvent.mParameters.selectionSet[0].setSelectedKey("");
					oEvent.mParameters.selectionSet[1].setSelectedKey("");
					oEvent.mParameters.selectionSet[2].setSelectedKey("");
					oEvent.mParameters.selectionSet[3].setDateValue(null);
					oEvent.mParameters.selectionSet[3].setSecondDateValue(null);
					oFilterModel.setProperty("/ProductCategory", "");
					oFilterModel.setProperty("/Category", "");
					oFilterModel.setProperty("/dateType", "");
					oFilterModel.setProperty("/StartDate", null);
					oFilterModel.setProperty("/EndDate", null);
					// this.loadActiveSubsCard(soldTo);
					this.filterData(soldTo);
					this.loadRenewalsCard(soldTo);
					this.loadTrialCard(soldTo);
					this.loadExpiredCard(soldTo);
				}
			},
			
			// EOC To Clear the Filters on click of Clear Button 

			// SOC When we click on Go button after entering filters
			onPressGo: function () {
				var oFilterModel = this.getOwnerComponent().getModel("localJsonModel"),
					checkFlag = false,
					oResourceModel = this.getResourceBundle(),
					productCategory = this.getView().byId("idproductCategory").getSelectedKey(),
					RTM = this.getView().byId("idRTM").getSelectedKey(),
					Datetype = this.getView().byId("idDatetype").getSelectedKey(),
					DateRange = this.getView().byId("idDateRange").getDateValue(),
					oDateTo = this.getView().byId("idDateRange").getSecondDateValue();
				if (productCategory === "" && RTM === "" && Datetype === "" && DateRange === null && oDateTo === null) {
					oFilterModel.setProperty("/sDateTypeSetValueState", "None");
					oFilterModel.setProperty("/sSetDateTypeText", "");
					oFilterModel.setProperty("/sDateRangeSetValueState", "None");
					oFilterModel.setProperty("/sSetDateRangeText", "");
					MessageToast.show(oResourceModel.getText("xDesc.filterError"), {

					});
				}
				else if (oFilterModel.getProperty("/ProductCategory") === productCategory && oFilterModel.getProperty("/Category") === RTM
					&& oFilterModel.getProperty("/dateType") === Datetype && oFilterModel.getProperty("/StartDate") === DateRange &&
					oFilterModel.getProperty("/EndDate") === oDateTo) {
					return;
				}
				else {
					oFilterModel.setProperty("/ProductCategory", productCategory);
					oFilterModel.setProperty("/Category", RTM);
					oFilterModel.setProperty("/dateType", Datetype);
					oFilterModel.setProperty("/StartDate", DateRange);
					oFilterModel.setProperty("/EndDate", oDateTo);
					if (Datetype !== "" && DateRange === null) {
						oFilterModel.setProperty("/sDateTypeSetValueState", "None");
						oFilterModel.setProperty("/sSetDateTypeText", "");

						MessageToast.show(oResourceModel.getText("xDesc.DateRange"), {
							width: "350px"
						});

						oFilterModel.setProperty("/sDateRangeSetValueState", "Error");
						oFilterModel.setProperty("/sSetDateRangeText", "Cannot Be Empty");
						checkFlag = true;
						return;
					}
					if (DateRange !== null && Datetype === "") {

						oFilterModel.setProperty("/sDateRangeSetValueState", "None");
						oFilterModel.setProperty("/sSetDateRangeText", "");
						MessageToast.show(oResourceModel.getText("xDesc.DateType"), {
							width: "350px"
						});
						oFilterModel.setProperty("/sDateTypeSetValueState", "Error");
						oFilterModel.setProperty("/sSetDateTypeText", "Cannot Be Empty");
						checkFlag = true;
						return;
					}
					if (productCategory !== "" || RTM !== "" || Datetype !== "" || DateRange !== null) {
						if (checkFlag === false) {
							oFilterModel.setProperty("/sDateTypeSetValueState", "None");
							oFilterModel.setProperty("/sSetDateTypeText", "");
							oFilterModel.setProperty("/sDateRangeSetValueState", "None");
							oFilterModel.setProperty("/sSetDateRangeText", "");
							this.filterData(soldTo);
							// this.loadActiveSubsCard(soldTo);
							this.loadRenewalsCard(soldTo);
							this.loadTrialCard(soldToTrials);
							this.loadExpiredCard(soldTo);
						}
					}
				}
			}, 
			// EOC When we click on Go button after entering filters
		    
			// SOC c
			
			onDomPath1MoverPie: function (event) {
				var pieInId = event.target.id;
				if (pieInId) {
					var pieElement = document.getElementById(pieInId);
					pieElement.setAttribute("stroke", "black");
				}
			},
			
			// EOC hover effect on donut/pie/bar chart arc 
           
			// SOC remove hover effect on donut/pie/bar chart arcs

			onDomPath1MoutPie: function (event) {
				var pieOutId = event.target.id;
				if (pieOutId) {
					var pieElement = document.getElementById(pieOutId);
					pieElement.removeAttribute("stroke");
				}
			},

			// EOC remove hover effect on donut/pie/bar chart arc

			// SOC click event for donut chart arcs 
			onDomPath1Press: function (event) {
				console.log("Pressed on DOM element:", event.target.id);
				var oFilterModel = this.getOwnerComponent().getModel("localJsonModel")
				var parentElement = this._findparentDomElement(event.target, "sapFGLI");
				var key = "";
				var filterparam = {};
				if (parentElement) {
					var oParentGridListItem = sap.ui.getCore().byId(parentElement.id);
				}
				var parentEvent = oParentGridListItem.getCustomData()[0].getValue();
				upRenewalsfilter = event.target.__data__.data.Product.split(" ")[1];
				if (oFilterModel.getProperty("/ProductCategory")) {
					// prodCategory = prodCategory;
					key = "prodCategoryId";
					filterparam[key] = oFilterModel.getProperty("/ProductCategory");
					// filterparam.push(prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					// rtm = rtm;
					key = "rtmId";
					filterparam[key] = oFilterModel.getProperty("/Category");
				}
				if (oFilterModel.getProperty("/dateType")) {
					// dateid = dateid;
					key = "dateId";
					filterparam[key] = oFilterModel.getProperty("/dateType");
					// filterparam.push(dateid);
				}
				if (oFilterModel.getProperty("/StartDate") && oFilterModel.getProperty("/EndDate")) {
					// startdate = startdate;
					// enddate = enddate;
					key = "startdateId";
					filterparam[key] = oFilterModel.getProperty("/StartDate");
					key = "enddateId";
					filterparam[key] = oFilterModel.getProperty("/EndDate");
					// filterparam.push(startdate);
					// filterparam.push(enddate);
				}
				key = "upRenewalsfilterId";
				filterparam[key] = upRenewalsfilter;
				var serialParams = JSON.stringify(filterparam);
				this.routeToActiveSubs(false, parentEvent, serialParams);
			},
			
			// EOC click event for donut chart arcs 

			// SOC To find parent control of svg chart

			_findparentDomElement: function (element, className) {
				while (element) {
					if (element.classList && element.classList.contains(className)) {
						return element;
					}
					element = element.parentNode;
				}
				return null;
			},
           
		  // EOC To find parent control of svg chart

		  // SOC click event for pie chart arcs

			onDomPiePathPress: function (event) {
				console.log("Pressed on DOM element:", event.target.id);
				var parentElement = this._findparentDomElement(event.target, "sapFGLI");
				var key = "";
				var filterparam = {};
				if (parentElement) {
					var oParentGridListItem = sap.ui.getCore().byId(parentElement.id);
				}
				var parentEvent = oParentGridListItem.getCustomData()[0].getValue();
				trailsFilter = event.target.__data__.data.Category2;
				if (oFilterModel.getProperty("/ProductCategory")) {
					// prodCategory = prodCategory;
					key = "prodCategoryId";
					filterparam[key] = oFilterModel.getProperty("/ProductCategory");
					// filterparam.push(prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					// rtm = rtm;
					key = "rtmId";
					filterparam[key] = oFilterModel.getProperty("/Category");
				}
				if (oFilterModel.getProperty("/dateType")) {
					// dateid = dateid;
					key = "dateId";
					filterparam[key] = oFilterModel.getProperty("/dateType");
					// filterparam.push(dateid);
				}
				if (oFilterModel.getProperty("/StartDate") && oFilterModel.getProperty("/EndDate")) {
					// startdate = startdate;
					// enddate = enddate;
					key = "startdateId";
					filterparam[key] = oFilterModel.getProperty("/StartDate");
					key = "enddateId";
					filterparam[key] = oFilterModel.getProperty("/EndDate");
					// filterparam.push(startdate);
					// filterparam.push(enddate);
				}
				key = "trailsFilterId";
				filterparam[key] = trailsFilter;
				var serialParams = JSON.stringify(filterparam);
				this.routeToActiveSubs(false, parentEvent, serialParams);
			},
			
			// EOC click event for pie chart arcs

			// SOC click event for bar chart arcs

			onDomBarPathPress: function (event) {
				console.log("Pressed on DOM element:", event.target.id);
				var parentElement = this._findparentDomElement(event.target, "sapFGLI");
				var key = "";
				var filterparam = {};
				if (parentElement) {
					var oParentGridListItem = sap.ui.getCore().byId(parentElement.id);
				}
				var parentEvent = oParentGridListItem.getCustomData()[0].getValue();
				expiredFilter = event.target.__data__.Category2;
				if (oFilterModel.getProperty("/ProductCategory")) {
					// prodCategory = prodCategory;
					key = "prodCategoryId";
					filterparam[key] = oFilterModel.getProperty("/ProductCategory");
					// filterparam.push(prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					// rtm = rtm;
					key = "rtmId";
					filterparam[key] = oFilterModel.getProperty("/Category");
				}
				if (oFilterModel.getProperty("/dateType")) {
					// dateid = dateid;
					key = "dateId";
					filterparam[key] = oFilterModel.getProperty("/dateType");
					// filterparam.push(dateid);
				}
				if (oFilterModel.getProperty("/StartDate") && oFilterModel.getProperty("/EndDate")) {
					// startdate = startdate;
					// enddate = enddate;
					key = "startdateId";
					filterparam[key] = oFilterModel.getProperty("/StartDate");
					key = "enddateId";
					filterparam[key] = oFilterModel.getProperty("/EndDate");
					// filterparam.push(startdate);
					// filterparam.push(enddate);
				}
				key = "expiredFilterId";
				filterparam[key] = expiredFilter;
				var serialParams = JSON.stringify(filterparam);
				this.routeToActiveSubs(false, parentEvent, serialParams);
			},
			
			// EOC click event for bar chart arcs

			// SOC Method triggers when filters applied on Active Subscriptions Card (1st Card)
			filterData: function (soldTo) {
				var oCarousel = this.getView().byId("activeCarousel");
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC");
				let pathList = '/Ets_SubscriptionSummaryDetail';
				var that = this;
				this.getView().byId("idActiveSubsPanel").setBusy(true);
				// this.getView().byId("idActiveSubsPanel").setBusyIndicatorDelay(0);
				// this.onDateFormatter();
				var partnerFilter = [];
				partnerFilter.push(new sap.ui.model.Filter("status", "EQ", 'Active'));
				if (Array.isArray(soldTo) && soldTo.length > 1) {
					// Create multiple filters for soldToParty and combine them using OR 
					var multiFilter = new sap.ui.model.Filter(soldTo.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
					// false = OR condition 
					partnerFilter.push(multiFilter);
				}
				else if (soldTo.length === 1) {
					// Single value case 
					partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo[0]));
				}
				// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo));
				// partnerFilter.push(new sap.ui.model.Filter("category1", "EQ",'Storage'));

				if (oFilterModel.getProperty("/ProductCategory")) {
					partnerFilter.push(new sap.ui.model.Filter("prodCategory", "EQ", oFilterModel.getProperty("/ProductCategory")));
					// oFilterModel.setProperty("/ProductCategory", prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", oFilterModel.getProperty("/Category")));
					// oFilterModel.setProperty("/Category", rtm);
				}
				if (oFilterModel.getProperty("/dateType")) {
					partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", oFilterModel.getProperty("/dateType")));

					// oFilterModel.setProperty("/dateType", dateid);
				}
				if (oFilterModel.getProperty("/StartDate") !== null && oFilterModel.getProperty("/EndDate") !== null) {
					oFilterModel.setProperty("/StartDate", oFilterModel.getProperty("/StartDate"));
					oFilterModel.setProperty("/EndDate", oFilterModel.getProperty("/EndDate"));

					partnerFilter.push(new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter("date", "GE", new Date(oFilterModel.getProperty("/StartDate")).toISOString()),
						new sap.ui.model.Filter("date", "LE", new Date(oFilterModel.getProperty("/EndDate")).toISOString())
						],
						and: true

					}));
				}
				oModel.read(pathList, {
					method: "GET",
					filters: partnerFilter,
					urlParameters: {
						"$format": "json"
					},
					success: function (d) {
						console.log(d);
						that.getView().byId("idActiveSubsPanel").setBusy(false);
						var aPages = oCarousel.getPages().forEach(function (oPage, iPageIndex) {
							var oList = oPage;
							var oProductModel = oList.getModel(oList.mBindingInfos.items.model);
							if (oList.isA("sap.m.List")) {
								var aListItems = oList.getItems();
								aListItems.forEach(function (oListItem, iItemIndex) {
									var result = d.results.find(function (product, index) {
										return product.Category2 === oListItem.mProperties.title;

									})
									console.log(result);
									// if(d.results[iItemIndex].Category2 === oListItem.mProperties.title){
									// 	var updatedCount = d.results[iItemIndex].count;
									// }
									var BindingContextPath = oListItem.getBindingContextPath();
									var data = oModel.getProperty(BindingContextPath);
									oProductModel.setProperty(BindingContextPath + "/count", result.count);
									oListItem.getBinding("info").refresh();
								});
							}
						});
					}.bind(this),
					error: function (err) {
						// var msg = JSON.parse(err.responseText).error.message.value;
						that.getView().byId("idActiveSubsPanel").setBusy(false);
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}.bind(this)
				});
			},
			
		// EOC Method triggers when filters applied on Active Subscriptions Card (1st Card)
        
		// SOC Method triggers on Initial render of screen for Active Subscription(1st Card)
			loadActiveSubsCard: function (soldTo) {
				this.getView().byId("idActiveSubsPanel").setBusy(true);
				// this.getView().byId("idActiveSubsPanel").setBusyIndicatorDelay(0);
				var SubscriptionSummaryDetail_Model = new JSONModel();
				this.getView().setModel(SubscriptionSummaryDetail_Model, "SubscriptionSummaryDetail_Model");
				// var SubscriptionSummaryDetail_Model = this.getView().getModel("SubscriptionSummaryDetail_Model");
				let path = "/Ets_SubscriptionSummary";
				let pathList = '/Ets_SubscriptionSummaryDetail';
				let prodCat = '/Ets_prod_category1';
				var oCarousel = this.getView().byId("activeCarousel"),
					that = this;
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC1");
				this.getView().setModel(oModel, "items");
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				var partnerFilter = [];
				partnerFilter.push(new sap.ui.model.Filter("status", "EQ", 'Active'));
				if (Array.isArray(soldTo) && soldTo.length > 1) {
					// Create multiple filters for soldToParty and combine them using OR 
					var multiFilter = new sap.ui.model.Filter(soldTo.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
					// false = OR condition 
					partnerFilter.push(multiFilter);
				}
				else if (soldTo.length === 1) {
					// Single value case 
					partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo[0]));
				}
				// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo));
				// partnerFilter.push(new sap.ui.model.Filter("category1", "EQ",'Storage'));

				if (oFilterModel.getProperty("/ProductCategory")) {
					partnerFilter.push(new sap.ui.model.Filter("prodCategory", "EQ", oFilterModel.getProperty("/ProductCategory")));
					// oFilterModel.setProperty("/ProductCategory", prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", oFilterModel.getProperty("/Category")));
					// oFilterModel.setProperty("/Category", rtm);
				}
				if (oFilterModel.getProperty("/dateType")) {
					partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", oFilterModel.getProperty("/dateType")));
					// oFilterModel.setProperty("/dateType", dateid);
				}
				if (oFilterModel.getProperty("/StartDate") !== null && oFilterModel.getProperty("/EndDate") !== null) {
					oFilterModel.setProperty("/StartDate", startdate);
					oFilterModel.setProperty("/EndDate", enddate);
					partnerFilter.push(new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter("date", "GE", new Date(oFilterModel.getProperty("/StartDate")).toISOString()),
						new sap.ui.model.Filter("date", "LE", new Date(oFilterModel.getProperty("/EndDate")).toISOString())
						],
						and: true

					}));
				}
				oModel.read(prodCat, {
					method: "GET",
					urlParameters: {
						"$format": "json"
					},
					success: function (d) {
						try {
							var aSubscriptionSummaryDetail = [],
								oDefObj = $.Deferred(),
								// oModelJson = new JSONModel();
								aProd_category1 = d.results;
							var subscriptionModel = new JSONModel();
							subscriptionModel.setProperty("/gridTitle", "My Active Subscriptions - " + aProd_category1[0].category1);
							that.getView().setModel(subscriptionModel, 'subscriptionModel');
							// that.getView().setModel(oModelJson, "SubscriptionSummaryDetail_Model");



							oModel.read(pathList, {
								method: "GET",
								filters: partnerFilter,
								urlParameters: {
									"$format": "json"
								},
								success: function (d) {
									this.getView().byId("idActiveSubsPanel").setBusy(false);
									that.destroyCarouselPages();
									aProd_category1.forEach(function (product, index) {

										var categoryDetail = $.grep(d.results, function (oSummary) {
											return product.category1 === oSummary.category1;
										});

									
										var oList = new sap.m.List({
											id: "ActiveList" + index
										});
										SubscriptionSummaryDetail_Model.setProperty("/SubscriptionSummaryDetail" + index, categoryDetail);
										var oBindingInfo = {
											path: "SubscriptionSummaryDetail_Model>/SubscriptionSummaryDetail" + index,
											template: new sap.m.StandardListItem({
												title: "{SubscriptionSummaryDetail_Model>Category2}",
												info: "{SubscriptionSummaryDetail_Model>count}",
												id: "DetailPage" + index,
												type: "Active",
												press: that.onListItemPress.bind(that)
											}),
											events: {
												dataRequested: function (oEvent) {
													// oList.setBusy(true);
												},
												dataReceived: function (oEvent) {
													// oList.setBusy(false);
												}
											}
										};
										oList.bindItems(oBindingInfo);
										var device = that.getView().getModel("device").getData();
										if ((device.system.tablet || device.system.combi) && !device.system.desktop && device.orientation.portrait) {
											oList.addStyleClass("ActiveListPhnPadding");
										}
										else {
											oList.removeStyleClass("ActiveListPhnPadding");
										}
										//Store the list with its corresponding category
										oList.data("category1", product.category1);
										oCarousel.addPage(oList);
									});
								}.bind(this),
								error: function (err) {
									this.getView().byId("idActiveSubsPanel").setBusy(false);
									var msgs = errorJson.error.innererror.errordetails;
									sap.m.MessageBox.show(
										msgs[0].message, {
										icon: sap.m.MessageBox.Icon.ERROR,
										title: "Error",
										actions: [sap.m.MessageBox.Action.OK]
									});
								}.bind(this)
							});
							// })

						} catch (e) {

						}
					}.bind(this),
					error: function (err) {
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}.bind(this)
				});
			},
		
		// EOC Method triggers on Initial render of screen for Active Subscription(1st Card)

        // SOC method triggers on click of each list item on Active Subscription Card( 1st card) 

			onListItemPress: function (oEvent) {
				console.log(oEvent);
				var oTitle = oEvent.getSource().getTitle();
				var oRouter = this.getRouter();
				var key = "",
					filterparam = {},
					filterParams,
					subType = "Active";
				if (oTitle) {
					key = "level1_desc";
					filterparam[key] = oTitle;
				}
				if (prodCategory) {
					// prodCategory = prodCategory;
					key = "prodCategoryId";
					filterparam[key] = prodCategory;
					// filterparam.push(prodCategory);
				}
				if (rtm) {
					// rtm = rtm;
					key = "rtmId";
					filterparam[key] = rtm;
				}
				if (dateid) {
					// dateid = dateid;
					key = "dateId";
					filterparam[key] = dateid;
					// filterparam.push(dateid);
				}
				if (startdate && enddate) {
					// startdate = startdate;
					// enddate = enddate;
					key = "startdateId";
					filterparam[key] = startdate;
					key = "enddateId";
					filterparam[key] = enddate;
					// filterparam.push(startdate);
					// filterparam.push(enddate);
				}
				filterParams = filterparam;
				filterParams = JSON.stringify(filterParams);
				if (subType == "CC") {
					oRouter.navTo("CC");
				} else {
					oRouter.navTo("Activesubs", {
						subType: subType,
						filterParams: filterParams
					});
				}

			},

		// EOC method triggers on click of each list item on Active Subscription Card( 1st card) 

		//SOC Method triggers on scroll of page in carousel of My Active Subscriptions(1st Card)

			onCarouselPageChanged: function (oEvent) {
				var titleArr = {},
					value,
					prod_Cat = aProd_category1;
				var oCarousel = oEvent.getSource(),
					ActivePage = oCarousel.getActivePage(),
					allPages = oCarousel.getPages(),
					oActivePage = allPages.findIndex(function (fpage) {
						return fpage.getId() === oEvent.getSource().getActivePage()
					}),
					activePageData = allPages[oActivePage],
					customDataActivePage = activePageData.getCustomData()[1].mProperties.value;
			
				var firstTitle = "My Active Subscriptions",
					sNewTitle;
				sNewTitle = firstTitle + " - " + customDataActivePage;
				var oSubscriptionModel = this.getView().getModel("subscriptionModel");
				oSubscriptionModel.setProperty("/gridTitle", sNewTitle);
			},

		//EOC Method triggers on scroll of page in carousel of My Active Subscriptions(1st Card)

		// SOC Method triggers on render of app to load Upcoming Renewals Card (2nd Card)
			loadRenewalsCard: function (soldTo) {
				this.getView().byId("idRenewalsPanel").setBusy(true);
				// this.getView().byId("idRenewalsPanel").setBusyIndicatorDelay(0);
				let path = "/Ets_SubscriptionRenewals";
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC2");
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				let partnerFilter = [];
				if (Array.isArray(soldTo) && soldTo.length > 1) {
					// Create multiple filters for soldToParty and combine them using OR 
					var multiFilter = new sap.ui.model.Filter(soldTo.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
					// false = OR condition 
					partnerFilter.push(multiFilter);
				}
				else if (soldTo.length === 1) {
					// Single value case 
					partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo[0]));
				}
				// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo));
				if (oFilterModel.getProperty("/ProductCategory")) {
					partnerFilter.push(new sap.ui.model.Filter("productCategory", "EQ", oFilterModel.getProperty("/ProductCategory")));
					// oFilterModel.setProperty("/ProductCategory", prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", oFilterModel.getProperty("/Category")));
					// oFilterModel.setProperty("/Category", rtm);
				}
				if (oFilterModel.getProperty("/dateType")) {
					partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", oFilterModel.getProperty("/dateType")));
					// oFilterModel.setProperty("/dateType", dateid);
				}
				if (oFilterModel.getProperty("/StartDate") !== null && oFilterModel.getProperty("/EndDate") !== null) {
					oFilterModel.setProperty("/StartDate", oFilterModel.getProperty("/StartDate"));
					oFilterModel.setProperty("/EndDate", oFilterModel.getProperty("/EndDate"));
					// this.onDateFormatter();
					partnerFilter.push(new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter("date", "GE", oFilterModel.getProperty("/StartDate")),
						new sap.ui.model.Filter("date", "LE", oFilterModel.getProperty("/EndDate"))
						],
						and: true

					}));
				}
				// if (enddate) {}
				this._setCustomFormatter();
				oModel.read(path, {
					method: "GET",
					filters: partnerFilter,
					urlParameters: {
						"$format": "json"
					},
					success: function (d) {
						try {
							this.getView().byId("idRenewalsPanel").setBusy(false);
							var aData = {
								Items: [{
									Product: "In 120 days",
									Count: parseInt(d.results[0].ren120Days)
								}, {
									Product: "In 90 days",
									Count: parseInt(d.results[0].ren90Days)
								}, {
									Product: "In 60 days",
									Count: parseInt(d.results[0].ren60Days)
								}, {
									Product: "In 30 days",
									Count: parseInt(d.results[0].ren30Days)
								}]
							}
						
							var RenewalModel = new JSONModel();
							RenewalModel.setData(aData);
							this.getView().setModel(RenewalModel, 'RenewalModel');
							this.bInitCalled = true;
							// this.getView().byId("idRenewalsPanel").setBusy(false);

							//d3 chart
							this.chart2 = new d3Chart(this); // calls d3Chart.js file in chart folder
							var arcsInfo = this.chart2.getArcsData();
							var paths = Array.from(arcsInfo._groups[0]);
						
							//d3chart

							//ITS Movement Change
							const dynamicVariables = {};
							//const documentId = {};
							for (let i = 0; i < paths.length; i++) {
								dynamicVariables[`pathPie${i + 1}`] = paths[i].id;
								//documentId[`docPie${i+1}`] = document.getElementById(dynamicVariables.`pathPie${i+1}`);
								//window[`piePath${i+1}`] = document.getElement.byId(paths1[i].id);
							}

							for (let key in dynamicVariables) {
								if (dynamicVariables.hasOwnProperty(key)) {
									let elementId = dynamicVariables[key];
									let element = document.getElementById(elementId);
									element.addEventListener("mouseover", this.onDomPath1MoverPie.bind(this));
									element.addEventListener("mouseout", this.onDomPath1MoutPie.bind(this));
									element.addEventListener("click", this.onDomPath1Press.bind(this));

								}
							}

							//ITS Movement Change
						} catch (e) { }
					}.bind(this),
					error: function (err) {
						this.getView().byId("idRenewalsPanel").setBusy(false);
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}.bind(this)
				});
			},
			// EOC Method triggers on render of app to load Upcoming Renewals Card (2nd Card)
			
			// EOC Method triggers on render of app to load Trails/ Evals Card (3rd Card)

			loadTrialCard: function (soldTo) {
				this.getView().byId("idTrialsEvals").setBusy(true);
				// this.getView().byId("idTrialsEvals").setBusyIndicatorDelay(0);
				let path = "/Ets_SubscriptionTrialEval";
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC3");
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				let partnerFilter = [];
				if (Array.isArray(soldTo) && soldTo.length > 1) {
					// Create multiple filters for soldToParty and combine them using OR 
					var multiFilter = new sap.ui.model.Filter(soldTo.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
					// false = OR condition 
					partnerFilter.push(multiFilter);
				}
				else if (soldTo.length === 1) {
					// Single value case 
					partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo[0]));
				}
				// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo));
				partnerFilter.push(new sap.ui.model.Filter("type", "EQ", 'ZQTR'));
				if (oFilterModel.getProperty("/ProductCategory")) {
					partnerFilter.push(new sap.ui.model.Filter("productCategory", "EQ", prodCategory));
					// oFilterModel.setProperty("/ProductCategory", prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", oFilterModel.getProperty("/Category")));
					// oFilterModel.setProperty("/Category", rtm);
				}
				if (oFilterModel.getProperty("/dateType")) {
					partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", oFilterModel.getProperty("/dateType")));
					// oFilterModel.setProperty("/dateType", dateid);
				}
				if (oFilterModel.getProperty("/StartDate") !== null && oFilterModel.getProperty("/EndDate") !== null) {
					oFilterModel.setProperty("/StartDate", oFilterModel.getProperty("/StartDate"));
					oFilterModel.setProperty("/EndDate", oFilterModel.getProperty("/EndDate"));
					// this.onDateFormatter();
					partnerFilter.push(new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter("date", "GE", oFilterModel.getProperty("/StartDate")),
						new sap.ui.model.Filter("date", "LE", oFilterModel.getProperty("/EndDate"))
						],
						and: true

					}));
				}
				this._setCustomFormatter();
				oModel.read(path, {
					method: "GET",
					filters: partnerFilter,
					urlParameters: {
						"$format": "json"
					},
					success: function (d) {
						try {
							this.getView().byId("idTrialsEvals").setBusy(false);
							d.results[0].Compute = "222";
							d.results[0].Networking = "111";
							d.results[0].Storage = "99";
							d.results[0].Workloads = "212";
							d.results[0].Others = "333";
							d.results[0].Compute1 = "222";
							d.results[0].Networking1 = "111";
							d.results[0].Storage1 = "99";
							d.results[0].Workloads1 = "212";
							d.results[0].Others1 = "333";
							var aData = {
								Items: [{
									Product: "HPE GreenLake for Compute Ops Management",
									Count: parseInt(d.results[0].Compute)
								}, {
									Product: "HPE GreenLake for Backup and Recovery",
									Count: parseInt(d.results[0].Networking)
								}, {
									Product: "HPE GreenLake for Private Cloud Business Edition",
									Count: parseInt(d.results[0].Storage)
								}, {
									Product: "HPE GreenLake for Disaster Recovery",
									Count: parseInt(d.results[0].Workloads)
								}, {
									Product: "HPE GreenLake for Block Storage",
									Count: parseInt(d.results[0].Others)
								}
									// {
									// 	Product: "HPE Aruba Networking Central",
									// 	Count: parseInt(d.results[0].Others1)
									// }, {
									// 	Product: "HPE GreenLake for Aruba Networking",
									// 	Count: parseInt(d.results[0].Compute1)
									// }, {
									// 	Product: "HPE Aruba Networking EdgeConnect",
									// 	Count: parseInt(d.results[0].Networking1)
									// }, {
									// 	Product: "HPE Ezmeral Runtime Enterprise Software",
									// 	Count: parseInt(d.results[0].Storage1)
									// }, {
									// 	Product: "HPE Ezmeral Data Fabric Software",
									// 	Count: parseInt(d.results[0].Workloads1)
									// }, {
									// 	Product: "HPE GreenLake Private Cloud Enterprise",
									// 	Count: parseInt(d.results[0].Others1)
									// }
								]
							}
							

							//Pie Viz Chart Comment
							var oTrialsEvals = this.getView().byId("idpiechart1");
							var trialEvalModel = new JSONModel();
							trialEvalModel.setData(aData);
							// trialEvalModel.setData(d.results);
							this.getView().setModel(trialEvalModel, 'trialEvalModel');
							
							//Pie Viz Chart Comment
							this.chart3 = new pieChart(this);  // Calls pieChart.js file in chart folder
							var arcsInfo1 = this.chart3.getArcsData();
							var paths1 = Array.from(arcsInfo1._groups[0]);

						
							//ITS Movement Change
							const dynamicVariables = {};
							//const documentId = {};
							for (let i = 0; i < paths1.length; i++) {
								dynamicVariables[`pathPie${i + 1}`] = paths1[i].id;
								//documentId[`docPie${i+1}`] = document.getElementById(dynamicVariables.`pathPie${i+1}`);
								//window[`piePath${i+1}`] = document.getElement.byId(paths1[i].id);
							}

							for (let key in dynamicVariables) {
								if (dynamicVariables.hasOwnProperty(key)) {
									let elementId = dynamicVariables[key];
									let element = document.getElementById(elementId);
									element.addEventListener("mouseover", this.onDomPath1MoverPie.bind(this));
									element.addEventListener("mouseout", this.onDomPath1MoutPie.bind(this));
									element.addEventListener("click", this.onDomPiePathPress.bind(this));

								}
							}

							//ITS Movement Change

							
						} catch (e) { }
					}.bind(this),
					error: function (err) {
						this.getView().byId("idTrialsEvals").setBusy(false);
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}.bind(this)
				});
			},

			// EOC Method triggers on render of app to load Trails/ Evals Card (3rd Card)
            
			// SOC Method triggers on render of app to load Expired Subscriptions Card (4th Card)

			loadExpiredCard: function (soldTo) {
				this.getView().byId("idExpiredPanel").setBusy(true);
				// this.getView().byId("idExpiredPanel").setBusyIndicatorDelay(0);
				let path = "/Ets_SubscriptionExpired";
				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC4");
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				let partnerFilter = [];
				if (Array.isArray(soldTo) && soldTo.length > 1) {
					// Create multiple filters for soldToParty and combine them using OR 
					var multiFilter = new sap.ui.model.Filter(soldTo.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
					// false = OR condition 
					partnerFilter.push(multiFilter);
				}
				else if (soldTo.length === 1) {
					// Single value case 
					partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo[0]));
				}
				// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTo));
				partnerFilter.push(new sap.ui.model.Filter("noDaysInExpiredState", "EQ", '30'));
				if (oFilterModel.getProperty("/ProductCategory")) {
					partnerFilter.push(new sap.ui.model.Filter("prodCategory", "EQ", oFilterModel.getProperty("/ProductCategory")));
					// oFilterModel.setProperty("/ProductCategory", prodCategory);
				}
				if (oFilterModel.getProperty("/Category")) {
					partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", oFilterModel.getProperty("/Category")));
					// oFilterModel.setProperty("/Category", rtm);
				}
				if (oFilterModel.getProperty("/dateType")) {
					partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", oFilterModel.getProperty("/dateType")));
					// oFilterModel.setProperty("/dateType", dateid);
				}
				if (oFilterModel.getProperty("/StartDate") !== null && oFilterModel.getProperty("/EndDate") !== null) {
					oFilterModel.setProperty("/StartDate", oFilterModel.getProperty("/StartDate"));
					oFilterModel.setProperty("/EndDate", oFilterModel.getProperty("/EndDate"));
					// this.onDateFormatter();
					partnerFilter.push(new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter("date", "GE", oFilterModel.getProperty("/StartDate")),
						new sap.ui.model.Filter("date", "LE", oFilterModel.getProperty("/EndDate"))
						],
						and: true

					}));
				}

				this._setCustomFormatter();
				oModel.read(path, {
					method: "GET",
					filters: partnerFilter,
					urlParameters: {
						"$format": "json"
					},
					success: function (d) {
						this.getView().byId("idExpiredPanel").setBusy(false);
						try {
							d.results[0].catCompute = "222"
							d.results[0].catNetwork = "111"
							d.results[0].catOthers = "99"
							d.results[0].catStorage = "333"
							d.results[0].catWorkload = "212"
							// d.results[0].catCompute1 = "222"
							// d.results[0].catNetwork1 = "111"
							// d.results[0].catOthers1 = "99"
							// d.results[0].catStorage1 = "333"
							// d.results[0].catWorkload1 = "212"
							var aData = {
								Items: [{
									Product: "HPE GreenLake for Compute Ops Management",
									Count: parseInt(d.results[0].catCompute)
								}, {
									Product: "HPE Aruba Networking EdgeConnect",
									Count: parseInt(d.results[0].catNetwork)
								}, {
									Product: "HPE GreenLake for Disaster Recovery",
									Count: parseInt(d.results[0].catStorage)
								}, {
									Product: "HPE GreenLake for Private Cloud Business Edition",
									Count: parseInt(d.results[0].catWorkload)
								}, {
									Product: "HPE GreenLake for Backup and Recovery",
									Count: parseInt(d.results[0].catOthers)
								}
									// {
									// 	Product: "HPE GreenLake for Block Storage",
									// 	Count: parseInt(d.results[0].catOthers1)
									// }, {
									// 	Product: "HPE GreenLake for Private Cloud Business Edition",
									// 	Count: parseInt(d.results[0].catWorkload1)
									// }, {
									// 	Product: "HPE Ezmeral Runtime Enterprise Software",
									// 	Count: parseInt(d.results[0].catCompute1)
									// }, {
									// 	Product: "HPE Aruba Networking EdgeConnect",
									// 	Count: parseInt(d.results[0].catNetwork1)
									// }, {
									// 	Product: "HPE Ezmeral Data Fabric Software",
									// 	Count: parseInt(d.results[0].catStorage1)
									// }, {
									// 	Product: "HPE GreenLake for Block Storage",
									// 	Count: parseInt(d.results[0].catCompute1)
									// }, {
									// 	Product: "HPE Aruba Networking Central",
									// 	Count: parseInt(d.results[0].catNetwork1)
									// }, {
									// 	Product: "HPE GreenLake for Aruba Networking",
									// 	Count: parseInt(d.results[0].catStorage1)
									// }
								]
							}
						
							var expiredModel = new JSONModel();
							expiredModel.setData(aData);
							// expiredModel.setData(d.results);
							this.getView().setModel(expiredModel, 'expiredModel');
						

							this.chart4 = new barChart(this); // calls barChart.js file in chart folder
							var arcsInfo2 = this.chart4.getArcsData();
							var paths1 = Array.from(arcsInfo2._groups[0]);

						
							//ITS Movement Change
							const dynamicVariables = {};
							//const documentId = {};
							for (let i = 0; i < paths1.length; i++) {
								dynamicVariables[`pathPie${i + 1}`] = paths1[i].id;
								//documentId[`docPie${i+1}`] = document.getElementById(dynamicVariables.`pathPie${i+1}`);
								//window[`piePath${i+1}`] = document.getElement.byId(paths1[i].id);
							}

							for (let key in dynamicVariables) {
								if (dynamicVariables.hasOwnProperty(key)) {
									let elementId = dynamicVariables[key];
									let element = document.getElementById(elementId);
									element.addEventListener("mouseover", this.onDomPath1MoverPie.bind(this));
									element.addEventListener("mouseout", this.onDomPath1MoutPie.bind(this));
									element.addEventListener("click", this.onDomBarPathPress.bind(this));

								}
							}

							//ITS Movement Change

						} catch (e) { }
					}.bind(this),
					error: function (err) {
						this.getView().byId("idExpiredPanel").setBusy(false);
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}.bind(this)
				});
			},
           
			// EOC Method triggers on render of app to load Expired Subscriptions Card (4th Card)

			// SOC Method triggers when clicked on an arc of chart to navigate other page

			routeToActiveSubs: function (oEvent, subtype, filter) {
				if (oEvent) {
					var subType = oEvent.getSource().getCustomData()[0].getValue();
					var key = "";
					var filterparam = {};
					var filterParams;
					if (prodCategory) {
						// prodCategory = prodCategory;
						key = "prodCategoryId";
						filterparam[key] = prodCategory;
						// filterparam.push(prodCategory);
					}
					if (rtm) {
						// rtm = rtm;
						key = "rtmId";
						filterparam[key] = rtm;
					}
					if (dateid) {
						// dateid = dateid;
						key = "dateId";
						filterparam[key] = dateid;
						// filterparam.push(dateid);
					}
					if (startdate && enddate) {
						// startdate = startdate;
						// enddate = enddate;
						key = "startdateId";
						filterparam[key] = startdate;
						key = "enddateId";
						filterparam[key] = enddate;
						// filterparam.push(startdate);
						// filterparam.push(enddate);
					}
					filterParams = filterparam;
					filterParams = JSON.stringify(filterParams);
				} else {
					subType = subtype;
					filterParams = filter;
				}

				var oRouter = this.getRouter();
				if (subType == "CC") {
					oRouter.navTo("CC");
				} else {
					oRouter.navTo("Activesubs", {
						subType: subType,
						filterParams: filterParams
					});
				}
			},

			// EOC Method triggers when clicked on an arc of chart to navigate other page
          
			// SOC To get Router
			
			getRouter: function () {
				return UIComponent.getRouterFor(this);
			},
           
			// EOC To get Router

			// SOC to navigate to report section on press of reports
			
			oReports: function () {
				var oRouter = this.getRouter();
				oRouter.navTo("Reports");
			}
			
			// EOC to navigate to report section on press of reports


		});
	});