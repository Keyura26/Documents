sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"ui5/PartDash/controller/BaseController"
	], function(Controller,BaseController){
		"use strict";
		return BaseController.extend("ui5.PartDash.controller.Main",{
			onInit: function(){
				this.oTargetController = this.getView().byId("View1").getController();
				// $(window).resize(this._onWindowsResize.bind(this));
			},
			// _onWindowsResize: function(){
			// 	var oDynamicPage = this.byId("idDynamicPage");
			// 	oDynamicPage.invalidate();
			// 	oDynamicPage.rerender();
			// },
			callTargetMethod: function(){
				this.oTargetController.loadRenewalsCard();    
			}
		});
	});