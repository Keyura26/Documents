sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"ui5/PartDash/utils/formatter",
	"sap/m/DynamicDateUtil",
	"ui5/PartDash/controller/BaseController",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/Tokenizer",
	"sap/ui/model/Filter",
	"sap/ui/export/Spreadsheet",
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, UIComponent, formatter, DynamicDateUtil, BaseController, MessageToast, MessageBox, Token, Tokenizer, Filter,
		Spreadsheet) {
		"use strict";

		return BaseController.extend("ui5.PartDash.controller.Reports", {
			_formatter: formatter,

			getRouter: function () {
				return UIComponent.getRouterFor(this);
			},

			onInit: function () {
				var oRouter = this.getRouter();
				oRouter.getRoute("Reports").attachPatternMatched(this._onObjectMatched(), this);
			},

			_onObjectMatched: function () {
				var reportType = this.getView().byId("idReportIconTabBar").setSelectedKey("1");
				this.onReportChange();
				var oMultiInput = this.getView().byId("idPartyID");

				//validation for multiinput to make input a token
				oMultiInput.addValidator(function (args) {
					var text = args.text;
					return new Token({
						key: text,
						text: text
					});
				});

				var oMultiInpReport2 = this.getView().byId("idPartyIDIAB");

				//validation for multiinput to make input a token
				oMultiInpReport2.addValidator(function (args) {
					var text = args.text;
					return new Token({
						key: text,
						text: text
					});
				});

				var oMultiInpReport3 = this.getView().byId("idPartyIDUAR");

				//validation for multiinput to make input a token
				oMultiInpReport3.addValidator(function (args) {
					var text = args.text;
					return new Token({
						key: text,
						text: text
					});
				});

				var oMultiInpReport4 = this.getView().byId("idPartyIDDMI");

				//validation for multiinput to make input a token
				oMultiInpReport4.addValidator(function (args) {
					var text = args.text;
					return new Token({
						key: text,
						text: text
					});
				});

				/*SOC BADH EAGLE-SOME4028B 2021/11/08*/
				var oMultiInpReport5 = this.getView().byId("idPartyIDCCC");

				//validation for multiinput to make input a token
				oMultiInpReport5.addValidator(function (args) {
					var text = args.text;
					return new Token({
						key: text,
						text: text
					});
				});
				/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

				/*SOC BADH EAGLE-2700 2021/11/17*/
				var oRptSchDate = this.getView().byId("idDateScheduleStartDateDMI");

				//validation for multiinput to make input a token
				oRptSchDate.setMinDate(new Date());
				/*EOC BADH EAGLE-2700 2021/11/17*/
			},

			/*Functions for Reports section*/

			//report type select
			// onReportChange: function () {
			// 	var _oView = this.getView(),
			// 		reportType = _oView.byId("idReportIconTabBar").getSelectedKey();

			// 	_oView.byId("idContractStatusF1").setVisible(false);
			// 	// _oView.byId("idContractStatusF2").setVisible(false);
			// 	_oView.byId("idContractStatusF3").setVisible(false);
			// 	// _oView.byId("idContractStatusF4").setVisible(false);
			// 	_oView.byId("idIABF1").setVisible(false);
			// 	//_oView.byId("idIABF2").setVisible(false);
			// 	_oView.byId("idIABF3").setVisible(false);
			// 	//_oView.byId("idIABF4").setVisible(false);
			// 	//_oView.byId("idIABF5").setVisible(false);
			// 	_oView.byId("idUARF1").setVisible(false);
			// 	_oView.byId("idUARF2").setVisible(false);
			// 	_oView.byId("idUARF3").setVisible(false);
			// 	_oView.byId("idUARF4").setVisible(false);
			// 	_oView.byId("idUARF5").setVisible(false);
			// 	_oView.byId("idDMIF1").setVisible(false);
			// 	// _oView.byId("idDMIF2").setVisible(false);
			// 	_oView.byId("idDMIF3").setVisible(false);
			// 	// _oView.byId("idDMIF4").setVisible(false);
			// 	/*SOC BADH EAGLE-SOME4028B 2021/01/28*/
			// 	_oView.byId("idCCCF1").setVisible(false);
			// 	_oView.byId("idCCCF2").setVisible(false);
			// 	_oView.byId("idCCCF3").setVisible(false);
			// 	_oView.byId("idCCCF4").setVisible(false);
			// 	_oView.byId("idCCCF5").setVisible(false);

			// 	var __oViewModel = sap.ui.getCore().getModel("viewData"); // Flag to identify internal users
			// 	if (sap.ushell && sap.ushell.Container) {
			// 		__oViewModel.setProperty("/bInternal", true);
			// 	} else {
			// 		var __oPunchOutData = __oViewModel.getProperty("/PunchOutData"),
			// 			__sUserType = __oPunchOutData.Usertype;
			// 		if (__sUserType.toUpperCase() === "INTERNAL") {
			// 			__oViewModel.setProperty("/bInternal", true);
			// 		} else {
			// 			__oViewModel.setProperty("/bInternal", false);
			// 		}
			// 	}

			// 	/*EOC BADH EAGLE-SOME4028B 2021/01/28*/
			// 	if (reportType === "1") {
			// 		_oView.byId("idContractStatusF1").setVisible(true);
			// 		// _oView.byId("idContractStatusF2").setVisible(true);
			// 		_oView.byId("idContractStatusF3").setVisible(true);
			// 		// _oView.byId("idContractStatusF4").setVisible(true);

			// 	} else if (reportType === "2") {
			// 		_oView.byId("idIABF1").setVisible(true);
			// 		//	_oView.byId("idIABF2").setVisible(true);
			// 		_oView.byId("idIABF3").setVisible(true);
			// 		//	_oView.byId("idIABF4").setVisible(true);
			// 	} else if (reportType === "3") {
			// 		_oView.byId("idUARF1").setVisible(true);
			// 		_oView.byId("idUARF2").setVisible(true);
			// 		_oView.byId("idUARF3").setVisible(true);
			// 		_oView.byId("idUARF4").setVisible(true);
			// 		_oView.byId("idUARF5").setVisible(true);
			// 	} else if (reportType === "4") {
			// 		_oView.byId("idDMIF1").setVisible(true);
			// 		// _oView.byId("idDMIF2").setVisible(true);
			// 		_oView.byId("idDMIF3").setVisible(true);
			// 		// _oView.byId("idDMIF4").setVisible(true);
			// 	} else if (reportType === "5") {
			// 		_oView.byId("idCCCF1").setVisible(true);
			// 		_oView.byId("idCCCF2").setVisible(true);
			// 		_oView.byId("idCCCF3").setVisible(true);
			// 		_oView.byId("idCCCF4").setVisible(true);
			// 		_oView.byId("idCCCF5").setVisible(true);
			// 	}
			// },
			onReportChange: function () {
				var _oView = this.getView(),
					reportType = _oView.byId("idReportIconTabBar").getSelectedKey();

				_oView.byId("idContractStatusF1").setVisible(false);
				_oView.byId("idIABF1").setVisible(false);
				_oView.byId("idUARF1").setVisible(false);
				_oView.byId("idUARF2").setVisible(false);
				_oView.byId("idUARF3").setVisible(false);
				_oView.byId("idUARF4").setVisible(false);
				_oView.byId("idUARF5").setVisible(false);
				_oView.byId("idDMIF1").setVisible(false);
				_oView.byId("idCCCF1").setVisible(false);
				_oView.byId("idCCCF2").setVisible(false);
				_oView.byId("idCCCF3").setVisible(false);
				_oView.byId("idCCCF4").setVisible(false);
				_oView.byId("idCCCF5").setVisible(false);

				var __oViewModel = sap.ui.getCore().getModel("viewData"); // Flag to identify internal users
				if (sap.ushell && sap.ushell.Container) {
					__oViewModel.setProperty("/bInternal", true);
				} else {
					var __oPunchOutData = __oViewModel.getProperty("/PunchOutData"),
						__sUserType = __oPunchOutData.Usertype;
					if (__sUserType.toUpperCase() === "INTERNAL") {
						__oViewModel.setProperty("/bInternal", true);
					} else {
						__oViewModel.setProperty("/bInternal", false);
					}
				}

				/*EOC BADH EAGLE-SOME4028B 2021/01/28*/
				if (reportType === "1") {
					_oView.byId("idContractStatusF1").setVisible(true);
				} else if (reportType === "2") {
					_oView.byId("idIABF1").setVisible(true);
				} else if (reportType === "3") {
					_oView.byId("idUARF1").setVisible(true);
					_oView.byId("idUARF2").setVisible(true);
					_oView.byId("idUARF3").setVisible(true);
					_oView.byId("idUARF4").setVisible(true);
					_oView.byId("idUARF5").setVisible(true);
				} else if (reportType === "4") {
					_oView.byId("idDMIF1").setVisible(true);
				} else if (reportType === "5") {
					_oView.byId("idCCCF1").setVisible(true);
					_oView.byId("idCCCF2").setVisible(true);
					_oView.byId("idCCCF3").setVisible(true);
					_oView.byId("idCCCF4").setVisible(true);
					_oView.byId("idCCCF5").setVisible(true);
				}
			},
			//Run report
			// onReportRun: function () {
			// 	var reportType = this.getView().byId("idReportIconTabBar").getSelectedKey(),
			// 		oModel = this.getView().getModel("viewData");
			// 	oModel.setProperty("/Persona", "SALES_OPS");
			// 	// Begin defect 10555 GASINGHDELOI
			// 	var bInternal = true; // Flag to identify internal users
			// 	if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 		//Internal User FLP //Date Fields Mand Logic
			// 		if (reportType === "1") {
			// 			this._Report1(bInternal);
			// 		} else if (reportType === "2") {
			// 			this._Report2(bInternal);
			// 		} else if (reportType === "3") {
			// 			this._Report3(bInternal);
			// 		} else if (reportType === "4") {
			// 			this._Report4(bInternal);
			// 		} else if (reportType === "5") {
			// 			this._Report5(bInternal); //BADH EAGLE-SOME4028B 2021/11/08
			// 		}
			// 	} else {
			// 		var oLocalPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
			// 		var sUserType = oLocalPunchoutData.Usertype;
			// 		if (sUserType.toUpperCase() === "INTERNAL") {
			// 			//Internal User Punchout //Date Fields Mand Logic
			// 			if (reportType === "1") {
			// 				this._Report1(bInternal);
			// 			} else if (reportType === "2") {
			// 				this._Report2(bInternal);
			// 			} else if (reportType === "3") {
			// 				this._Report3(bInternal);
			// 			} else if (reportType === "4") {
			// 				this._Report4(bInternal);
			// 			} else if (reportType === "5") {
			// 				this._Report5(bInternal); //BADH EAGLE-SOME4028B 2021/11/08
			// 			}
			// 		} else {
			// 			//Party ID Mand Logic
			// 			if (reportType === "1") {
			// 				this._Report1(!bInternal);
			// 			} else if (reportType === "2") {
			// 				this._Report2(!bInternal);
			// 			} else if (reportType === "3") {
			// 				this._Report3(!bInternal);
			// 			} else if (reportType === "4") {
			// 				this._Report4(!bInternal);
			// 			} else if (reportType === "5") {
			// 				this._Report5(!bInternal); //BADH EAGLE-SOME4028B 2021/11/08
			// 			}
			// 		}
			// 	}
			// 	// End defect 10555 GASINGHDELOI
			// },

			onReportRun: function () {
				var reportType = this.getView().byId("idReportIconTabBar").getSelectedKey(),
					oModel = this.getView().getModel("viewData");
				// Begin defect 10555 GASINGHDELOI
				var bInternal = true; // Flag to identify internal users
				if (!this.fnGetParamExistsInURI("i_t") /**&& oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS" **/) {
					//Internal User FLP //Date Fields Mand Logic
					if (reportType === "1") {
						this._Report1(bInternal);
					} else if (reportType === "2") {
						this._Report2(bInternal);
					} else if (reportType === "3") {
						this._Report3(bInternal);
					} else if (reportType === "4") {
						this._Report4(bInternal);
					} else if (reportType === "5") {
						this._Report5(bInternal); //BADH EAGLE-SOME4028B 2021/11/08
					}
				} else {
					var oLocalPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var sUserType = oLocalPunchoutData.Usertype;
					if (sUserType.toUpperCase() === "INTERNAL") {
						//Internal User Punchout //Date Fields Mand Logic
						if (reportType === "1") {
							this._Report1(bInternal);
						} else if (reportType === "2") {
							this._Report2(bInternal);
						} else if (reportType === "3") {
							this._Report3(bInternal);
						} else if (reportType === "4") {
							this._Report4(bInternal);
						} else if (reportType === "5") {
							this._Report5(bInternal); //BADH EAGLE-SOME4028B 2021/11/08
						}
					} else {
						//Party ID Mand Logic
						if (reportType === "1") {
							this._Report1(!bInternal);
						} else if (reportType === "2") {
							this._Report2(!bInternal);
						} else if (reportType === "3") {
							this._Report3(!bInternal);
						} else if (reportType === "4") {
							this._Report4(!bInternal);
						} else if (reportType === "5") {
							this._Report5(!bInternal); //BADH EAGLE-SOME4028B 2021/11/08
						}
					}
				}
				// End defect 10555 GASINGHDELOI
			},
			// for Contract Status

			// _Report1: function (bInternal) {

			// 	var aPartyToken = this.getView().byId("idPartyID"),
			// 		aPartyId = [],
			// 		oModel = this.getView().getModel("viewData");
			// 	for (var u = 0; u < aPartyToken.getTokens().length; u++) {
			// 		var t1 = aPartyToken.getTokens()[u].getText();
			// 		aPartyId.push(t1);
			// 	}

			// 	var partyType = this.getView().byId("idPartyType").getSelectedKey(),

			// 		contractLowDate = /*this.getView().byId("idDateRangeContract")*/ DynamicDateUtil.toDates(this.getView().byId("idDateRangeContract")
			// 			.getValue())[0],
			// 		contractHighDate = /*this.getView().byId("idDateRangeContract")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeContract").getValue())[1],
			// 		activationLowDate = /*this.getView().byId("idDateRangeActivation")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeActivation").getValue())[0],
			// 		activationHighDate = /*this.getView().byId("idDateRangeActivation")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeActivation").getValue())[1],
			// 		documentTypeSel = this.getView().byId("idsubscriptiontypeRepCS").getSelectedKey();
			// 	if (documentTypeSel === "ST1") {
			// 		var documentType = "ZQST";
			// 	} else if (documentTypeSel === "ST2") {
			// 		documentType = "ZQTR";
			// 	} else {
			// 		documentType = "";
			// 	}
			// 	var HPEQuotNo = this.getView().byId("idHPEQuotNo").getValue(),
			// 		regionID = this.getView().byId("idRegionCS").getSelectedKey(),
			// 		idCountry = this.getView().byId("idCountryCS"),
			// 		countryTokens = idCountry.getTokens();

			// 	contractLowDate = formatter.changeDateToUTC(contractLowDate);
			// 	contractHighDate = formatter.changeDateToUTC(contractHighDate);
			// 	activationLowDate = formatter.changeDateToUTC(activationLowDate);
			// 	activationHighDate = formatter.changeDateToUTC(activationHighDate);

			// 	var aTokens = [];
			// 	countryTokens.forEach(function (data) {
			// 		var t = data.getKey();
			// 		aTokens.push(t);
			// 	});
			// 	var arr = [];
			// 	var obj = {};
			// 	var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// 	// for Punchout Scenario 
			// 	//if (this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	if (oModel.getProperty("/Persona") !== "SALES_OPS") {
			// 		var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
			// 		var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
			// 		var l_pricingVisibility = localPunchoutData.Pricingvisibility,
			// 			l_pricingVisibility = l_pricingVisibility.toString(),
			// 			l_userType = localPunchoutData.Usertype;
			// 		if (localPunchoutData.tierMapping.results.length !== 0) {
			// 			var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
			// 		} else {
			// 			l_tierMapping = "";
			// 		}
			// 		if (localPunchoutData.userDetails.results.length !== 0) {
			// 			var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
			// 				"," + localPunchoutData.userDetails.results[0].Visibilitytype +
			// 				"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

			// 		} else {
			// 			l_userDetails = "";
			// 		}

			// 		var l_orderNumber = localPunchoutData_Details.orderNumber,
			// 			l_emailId = localPunchoutData_Details.emailId,
			// 			l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
			// 		l_emailId = l_emailId.split("|")[0];
			// 	}

			// 	if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
			// 		//Checks mandatory fields for Non-INTERNAL users
			// 		MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
			// 		this.getView().setBusy(false);

			// 	} else if (((contractLowDate === null || contractHighDate === null) && (activationLowDate === null || activationHighDate === null)) &&
			// 		bInternal) {
			// 		//Checks mandatory fields for INTERNAL users
			// 		MessageBox.error("Please fill the mandatory date fields.");
			// 		this.getView().setBusy(false);
			// 	} else {
			// 		var _exeRpt1fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

			// 			// Begin Defect 10555 GASINGHDELOI
			// 			if (partyType === "") {
			// 				//Begin jmezadeloitte defect 12427
			// 				if (nLenOfPayload === undefined) {
			// 					var data = {
			// 						"emailId": l_emailId,
			// 						"orderNumber": l_orderNumber,
			// 						"HPEQuoteNo": l_brimSolQuote,
			// 						"pricingVisibility": l_pricingVisibility,
			// 						"userType": l_userType,
			// 						"zcontractNo": "",
			// 						"zcontractItem": "",
			// 						"contractStatusReportNav": arr
			// 					};

			// 					obj = {
			// 						"distributorID": "",
			// 						"resellerID": "",
			// 						"endCustID": "",
			// 						"endCustName": "",
			// 						"contractStartDateB": contractLowDate,
			// 						"contractStartDateE": contractHighDate,
			// 						"Country": "",
			// 						"Region": regionID,
			// 						"docType": documentType,
			// 						"contractEndDateB": activationLowDate,
			// 						"contractEndDateE": activationHighDate,
			// 						"HPEQuoteNo": HPEQuotNo
			// 					};
			// 					data.contractStatusReportNav.push(obj);
			// 				} else {
			// 					//Begin jmezadeloitte defect 12427
			// 					if (nLenOfPayload === 0 || nLenOfPayload === undefined) {
			// 						var data = {
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};
			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": "",
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);
			// 						//End jmezadeloitte defect 12427
			// 					} else {
			// 						for (var i = 0; i < nLenOfPayload; i++) {
			// 							var data = {
			// 								"emailId": l_emailId,
			// 								"orderNumber": l_orderNumber,
			// 								"HPEQuoteNo": l_brimSolQuote,
			// 								"pricingVisibility": l_pricingVisibility,
			// 								"userType": l_userType,
			// 								"zcontractNo": "",
			// 								"zcontractItem": "",
			// 								"contractStatusReportNav": arr
			// 							};
			// 							if (aTokens[i] !== undefined) {
			// 								var sCountryVal = aTokens[i];
			// 							} else {
			// 								sCountryVal = "";
			// 							}
			// 							obj = {
			// 								"distributorID": "",
			// 								"resellerID": "",
			// 								"endCustID": "",
			// 								"endCustName": "",
			// 								"contractStartDateB": contractLowDate,
			// 								"contractStartDateE": contractHighDate,
			// 								"Country": sCountryVal,
			// 								"Region": regionID,
			// 								"docType": documentType,
			// 								"contractEndDateB": activationLowDate,
			// 								"contractEndDateE": activationHighDate,
			// 								"HPEQuoteNo": HPEQuotNo
			// 							};
			// 							arr.push(obj);
			// 							//data.contractStatusReportNav.push(obj);
			// 						}
			// 					}
			// 				}
			// 				//END jmezadeloitte defect 12427
			// 			}
			// 			//if (partyType === "1") {
			// 			else if (partyType === "1") {
			// 				// End Defect 10555 GASINGHDELOI
			// 				// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 				if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}
			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);
			// 					}
			// 				}

			// 			} else if (partyType === "2") {

			// 				// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 				if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr.push(obj);

			// 					}

			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}

			// 				}

			// 			} else if (partyType === "3") {
			// 				// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 				if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr.push(obj);

			// 					}

			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}

			// 				};

			// 			}

			// 			var oServiceModel = this._getODataModel("SSVModel");

			// 			var sPath = "/Ets_ConStatRep";
			// 			this.getView().setBusy(true);

			// 			var mParameters = {
			// 				method: "POST",
			// 				success: jQuery.proxy(function (oData) {

			// 					this.getView().setBusy(false);
			// 					if (oData.errorMsg.length !== 0) {
			// 						var errMasg = oData.errorMsg;
			// 						MessageBox.error(errMasg);
			// 					} else {

			// 						/*var sUrl =
			// 						"/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ConStatRep?$format=xlsx";*/
			// 						var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ContStatRepFile('" + oData.zguid22 + "')/$value";
			// 						window.open(sUrl, "_blank");
			// 					}

			// 				}, this),

			// 				error: jQuery.proxy(function (oError) {

			// 					this.getView().setBusy(false);
			// 					var oMessage = oError.headers.errorMsg;
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
			// 					if (typeof oMessage !== "undefined") {
			// 						oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
			// 					} else if (oError.statusCode === "502") { // Timeout issue
			// 						oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
			// 					} else {
			// 						oMessage = oError.message;
			// 					}
			// 					MessageBox.error(oMessage, {
			// 						icon: sap.m.MessageBox.Icon.ERROR,
			// 						title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
			// 					});
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
			// 				}, this)
			// 			};

			// 			oServiceModel.create(sPath, data, mParameters);
			// 			/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 		}.bind(this);

			// 		var sMsgDateValidRpt1 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
			// 			bMsgDateValidRpt1 = true;

			// 		if (contractHighDate !== null && contractLowDate !== null) {
			// 			if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt1 = false;
			// 			}
			// 		}

			// 		if (activationHighDate !== null && activationLowDate !== null) {
			// 			if (((activationHighDate.getTime() - activationLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt1 = false;
			// 			}
			// 		}

			// 		if (!bMsgDateValidRpt1) {
			// 			this.getView().setBusy(false);

			// 			MessageBox.show(
			// 				sMsgDateValidRpt1, {
			// 				icon: MessageBox.Icon.WARNING,
			// 				title: "Warning",
			// 				actions: ["Proceed", MessageBox.Action.CANCEL],
			// 				emphasizedAction: MessageBox.Action.CANCEL,
			// 				onClose: function (oAction) {
			// 					if (oAction === "Proceed") {
			// 						_exeRpt1fn();
			// 					}
			// 				}
			// 			}
			// 			);

			// 		} else {
			// 			_exeRpt1fn();
			// 		}
			// 		/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 	}

			// },

			// _Report1: function (bInternal) {

			// 	var aPartyToken = this.getView().byId("idPartyID"),
			// 		aPartyId = [],
			// 		oModel = this.getView().getModel("viewData");
			// 	for (var u = 0; u < aPartyToken.getTokens().length; u++) {
			// 		var t1 = aPartyToken.getTokens()[u].getText();
			// 		aPartyId.push(t1);
			// 	}

			// 	var partyType = this.getView().byId("idPartyType").getSelectedKey(),

			// 		contractLowDate = this.getView().byId("idDateRangeContract").getDateValue(),
			// 		contractHighDate = this.getView().byId("idDateRangeContract").getSecondDateValue(),
			// 		activationLowDate = this.getView().byId("idDateRangeActivation").getDateValue(),
			// 		activationHighDate = this.getView().byId("idDateRangeActivation").getSecondDateValue(),
			// 		documentTypeSel = this.getView().byId("idsubscriptiontypeRepCS").getSelectedKey();
			// 	if (documentTypeSel === "ST1") {
			// 		var documentType = "ZQST";
			// 	} else if (documentTypeSel === "ST2") {
			// 		documentType = "ZQTR";
			// 	} else {
			// 		documentType = "";
			// 	}
			// 	var HPEQuotNo = this.getView().byId("idHPEQuotNo").getValue(),
			// 		regionID = this.getView().byId("idRegionCS").getSelectedKey(),
			// 		idCountry = this.getView().byId("idCountryCS"),
			// 		countryTokens = idCountry.getTokens();

			// 	contractLowDate = formatter.changeDateToUTC(contractLowDate);
			// 	contractHighDate = formatter.changeDateToUTC(contractHighDate);
			// 	activationLowDate = formatter.changeDateToUTC(activationLowDate);
			// 	activationHighDate = formatter.changeDateToUTC(activationHighDate);

			// 	var aTokens = [];
			// 	countryTokens.forEach(function (data) {
			// 		var t = data.getKey();
			// 		aTokens.push(t);
			// 	});
			// 	var arr = [];
			// 	var obj = {};
			// 	var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// 	// for Punchout Scenario 
			// 	if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") !== "SALES_OPS")) {
			// 		var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
			// 		var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
			// 		var l_pricingVisibility = localPunchoutData.Pricingvisibility,
			// 			l_pricingVisibility = l_pricingVisibility.toString(),
			// 			l_userType = localPunchoutData.Usertype;
			// 		if (localPunchoutData.tierMapping.results.length !== 0) {
			// 			var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
			// 		} else {
			// 			l_tierMapping = "";
			// 		}
			// 		if (localPunchoutData.userDetails.results.length !== 0) {
			// 			var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
			// 				"," + localPunchoutData.userDetails.results[0].Visibilitytype +
			// 				"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

			// 		} else {
			// 			l_userDetails = "";
			// 		}

			// 		var l_orderNumber = localPunchoutData_Details.orderNumber,
			// 			l_emailId = localPunchoutData_Details.emailId,
			// 			l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
			// 		l_emailId = l_emailId.split("|")[0];
			// 	}

			// 	if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
			// 		//Checks mandatory fields for Non-INTERNAL users
			// 		MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
			// 		this.getView().setBusy(false);

			// 	} else if (((contractLowDate === null || contractHighDate === null) && (activationLowDate === null || activationHighDate === null)) &&
			// 		bInternal) {
			// 		//Checks mandatory fields for INTERNAL users
			// 		MessageBox.error("Please fill the mandatory date fields.");
			// 		this.getView().setBusy(false);
			// 	} else {
			// 		var _exeRpt1fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

			// 			// Begin Defect 10555 GASINGHDELOI
			// 			if (partyType === "") {
			// 				//Begin jmezadeloitte defect 12427
			// 				if (nLenOfPayload === undefined) {
			// 					var data = {
			// 						"emailId": l_emailId,
			// 						"orderNumber": l_orderNumber,
			// 						"HPEQuoteNo": l_brimSolQuote,
			// 						"pricingVisibility": l_pricingVisibility,
			// 						"userType": l_userType,
			// 						"zcontractNo": "",
			// 						"zcontractItem": "",
			// 						"contractStatusReportNav": arr
			// 					};

			// 					obj = {
			// 						"distributorID": "",
			// 						"resellerID": "",
			// 						"endCustID": "",
			// 						"endCustName": "",
			// 						"contractStartDateB": contractLowDate,
			// 						"contractStartDateE": contractHighDate,
			// 						"Country": "",
			// 						"Region": regionID,
			// 						"docType": documentType,
			// 						"contractEndDateB": activationLowDate,
			// 						"contractEndDateE": activationHighDate,
			// 						"HPEQuoteNo": HPEQuotNo
			// 					};
			// 					data.contractStatusReportNav.push(obj);
			// 				} else {
			// 					//Begin jmezadeloitte defect 12427
			// 					if (nLenOfPayload === 0 || nLenOfPayload === undefined) {
			// 						var data = {
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};
			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": "",
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);
			// 						//End jmezadeloitte defect 12427
			// 					} else {
			// 						for (var i = 0; i < nLenOfPayload; i++) {
			// 							var data = {
			// 								"emailId": l_emailId,
			// 								"orderNumber": l_orderNumber,
			// 								"HPEQuoteNo": l_brimSolQuote,
			// 								"pricingVisibility": l_pricingVisibility,
			// 								"userType": l_userType,
			// 								"zcontractNo": "",
			// 								"zcontractItem": "",
			// 								"contractStatusReportNav": arr
			// 							};
			// 							if (aTokens[i] !== undefined) {
			// 								var sCountryVal = aTokens[i];
			// 							} else {
			// 								sCountryVal = "";
			// 							}
			// 							obj = {
			// 								"distributorID": "",
			// 								"resellerID": "",
			// 								"endCustID": "",
			// 								"endCustName": "",
			// 								"contractStartDateB": contractLowDate,
			// 								"contractStartDateE": contractHighDate,
			// 								"Country": sCountryVal,
			// 								"Region": regionID,
			// 								"docType": documentType,
			// 								"contractEndDateB": activationLowDate,
			// 								"contractEndDateE": activationHighDate,
			// 								"HPEQuoteNo": HPEQuotNo
			// 							};
			// 							arr.push(obj);
			// 							//data.contractStatusReportNav.push(obj);
			// 						}
			// 					}
			// 				}
			// 				//END jmezadeloitte defect 12427
			// 			}
			// 			//if (partyType === "1") {
			// 			else if (partyType === "1") {
			// 				// End Defect 10555 GASINGHDELOI
			// 				if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}
			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);
			// 					}
			// 				}

			// 			} else if (partyType === "2") {

			// 				if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr.push(obj);

			// 					}

			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}

			// 				}

			// 			} else if (partyType === "3") {
			// 				if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr.push(obj);

			// 					}

			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}

			// 				};

			// 			}

			// 			var oServiceModel = this._getODataModel();

			// 			var sPath = "/Ets_ConStatRep";
			// 			this.getView().setBusy(true);

			// 			var mParameters = {
			// 				method: "POST",
			// 				success: jQuery.proxy(function (oData) {

			// 					this.getView().setBusy(false);
			// 					if (oData.errorMsg.length !== 0) {
			// 						var errMasg = oData.errorMsg;
			// 						MessageBox.error(errMasg);
			// 					} else {

			// 						/*var sUrl =
			// 						"/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ConStatRep?$format=xlsx";*/
			// 						var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ContStatRepFile('" + oData.zguid22 + "')/$value";
			// 						window.open(sUrl, "_blank");
			// 					}

			// 				}, this),

			// 				error: jQuery.proxy(function (oError) {

			// 					this.getView().setBusy(false);
			// 					var oMessage = oError.headers.errorMsg;
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
			// 					if (typeof oMessage !== "undefined") {
			// 						oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
			// 					} else if (oError.statusCode === "502") { // Timeout issue
			// 						oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
			// 					} else {
			// 						oMessage = oError.message;
			// 					}
			// 					MessageBox.error(oMessage, {
			// 						icon: sap.m.MessageBox.Icon.ERROR,
			// 						title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
			// 					});
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
			// 				}, this)
			// 			};

			// 			oServiceModel.create(sPath, data, mParameters);
			// 			/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 		}.bind(this);

			// 		var sMsgDateValidRpt1 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
			// 			bMsgDateValidRpt1 = true;

			// 		if (contractHighDate !== null && contractLowDate !== null) {
			// 			if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt1 = false;
			// 			}
			// 		}

			// 		if (activationHighDate !== null && activationLowDate !== null) {
			// 			if (((activationHighDate.getTime() - activationLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt1 = false;
			// 			}
			// 		}

			// 		if (!bMsgDateValidRpt1) {
			// 			this.getView().setBusy(false);

			// 			MessageBox.show(
			// 				sMsgDateValidRpt1, {
			// 				icon: MessageBox.Icon.WARNING,
			// 				title: "Warning",
			// 				actions: ["Proceed", MessageBox.Action.CANCEL],
			// 				emphasizedAction: MessageBox.Action.CANCEL,
			// 				onClose: function (oAction) {
			// 					if (oAction === "Proceed") {
			// 						_exeRpt1fn();
			// 					}
			// 				}
			// 			}
			// 			);

			// 		} else {
			// 			_exeRpt1fn();
			// 		}
			// 		/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 	}

			// },

			// _Report1: function (bInternal) {

			// 	var aPartyToken = this.getView().byId("idPartyID"),
			// 		aPartyId = [],
			// 		oModel = this.getView().getModel("viewData");
			// 	for (var u = 0; u < aPartyToken.getTokens().length; u++) {
			// 		var t1 = aPartyToken.getTokens()[u].getText();
			// 		aPartyId.push(t1);
			// 	}

			// 	var partyType = this.getView().byId("idPartyType").getSelectedKey(),

			// 		contractLowDate = this.getView().byId("idDateRangeContract").getDateValue(),
			// 		contractHighDate = this.getView().byId("idDateRangeContract").getSecondDateValue(),
			// 		activationLowDate = this.getView().byId("idDateRangeActivation").getDateValue(),
			// 		activationHighDate = this.getView().byId("idDateRangeActivation").getSecondDateValue(),
			// 		documentTypeSel = this.getView().byId("idsubscriptiontypeRepCS").getSelectedKey();
			// 	if (documentTypeSel === "ST1") {
			// 		var documentType = "ZQST";
			// 	} else if (documentTypeSel === "ST2") {
			// 		documentType = "ZQTR";
			// 	} else {
			// 		documentType = "";
			// 	}
			// 	var HPEQuotNo = this.getView().byId("idHPEQuotNo").getValue(),
			// 		regionID = this.getView().byId("idRegionCS").getSelectedKey(),
			// 		idCountry = this.getView().byId("idCountryCS"),
			// 		countryTokens = idCountry.getTokens();

			// 	contractLowDate = formatter.changeDateToUTC(contractLowDate);
			// 	contractHighDate = formatter.changeDateToUTC(contractHighDate);
			// 	activationLowDate = formatter.changeDateToUTC(activationLowDate);
			// 	activationHighDate = formatter.changeDateToUTC(activationHighDate);

			// 	var aTokens = [];
			// 	countryTokens.forEach(function (data) {
			// 		var t = data.getKey();
			// 		aTokens.push(t);
			// 	});
			// 	var arr = [];
			// 	var obj = {};
			// 	var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// 	// for Punchout Scenario 
			// 	if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") !== "SALES_OPS")) {
			// 		var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
			// 		var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
			// 		var l_pricingVisibility = localPunchoutData.Pricingvisibility,
			// 			l_pricingVisibility = l_pricingVisibility.toString(),
			// 			l_userType = localPunchoutData.Usertype;
			// 		if (localPunchoutData.tierMapping.results.length !== 0) {
			// 			var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
			// 		} else {
			// 			l_tierMapping = "";
			// 		}
			// 		if (localPunchoutData.userDetails.results.length !== 0) {
			// 			var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
			// 				"," + localPunchoutData.userDetails.results[0].Visibilitytype +
			// 				"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

			// 		} else {
			// 			l_userDetails = "";
			// 		}

			// 		var l_orderNumber = localPunchoutData_Details.orderNumber,
			// 			l_emailId = localPunchoutData_Details.emailId,
			// 			l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
			// 		l_emailId = l_emailId.split("|")[0];
			// 	}

			// 	if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
			// 		//Checks mandatory fields for Non-INTERNAL users
			// 		MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
			// 		this.getView().setBusy(false);

			// 	} else if (((contractLowDate === null || contractHighDate === null) && (activationLowDate === null || activationHighDate === null)) &&
			// 		bInternal) {
			// 		//Checks mandatory fields for INTERNAL users
			// 		MessageBox.error("Please fill the mandatory date fields.");
			// 		this.getView().setBusy(false);
			// 	} else {
			// 		var _exeRpt1fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

			// 			// Begin Defect 10555 GASINGHDELOI
			// 			if (partyType === "") {
			// 				//Begin jmezadeloitte defect 12427
			// 				if (nLenOfPayload === undefined) {
			// 					var data = {
			// 						"emailId": l_emailId,
			// 						"orderNumber": l_orderNumber,
			// 						"HPEQuoteNo": l_brimSolQuote,
			// 						"pricingVisibility": l_pricingVisibility,
			// 						"userType": l_userType,
			// 						"zcontractNo": "",
			// 						"zcontractItem": "",
			// 						"contractStatusReportNav": arr
			// 					};

			// 					obj = {
			// 						"distributorID": "",
			// 						"resellerID": "",
			// 						"endCustID": "",
			// 						"endCustName": "",
			// 						"contractStartDateB": contractLowDate,
			// 						"contractStartDateE": contractHighDate,
			// 						"Country": "",
			// 						"Region": regionID,
			// 						"docType": documentType,
			// 						"contractEndDateB": activationLowDate,
			// 						"contractEndDateE": activationHighDate,
			// 						"HPEQuoteNo": HPEQuotNo
			// 					};
			// 					data.contractStatusReportNav.push(obj);
			// 				} else {
			// 					//Begin jmezadeloitte defect 12427
			// 					if (nLenOfPayload === 0 || nLenOfPayload === undefined) {
			// 						var data = {
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};
			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": "",
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);
			// 						//End jmezadeloitte defect 12427
			// 					} else {
			// 						for (var i = 0; i < nLenOfPayload; i++) {
			// 							var data = {
			// 								"emailId": l_emailId,
			// 								"orderNumber": l_orderNumber,
			// 								"HPEQuoteNo": l_brimSolQuote,
			// 								"pricingVisibility": l_pricingVisibility,
			// 								"userType": l_userType,
			// 								"zcontractNo": "",
			// 								"zcontractItem": "",
			// 								"contractStatusReportNav": arr
			// 							};
			// 							if (aTokens[i] !== undefined) {
			// 								var sCountryVal = aTokens[i];
			// 							} else {
			// 								sCountryVal = "";
			// 							}
			// 							obj = {
			// 								"distributorID": "",
			// 								"resellerID": "",
			// 								"endCustID": "",
			// 								"endCustName": "",
			// 								"contractStartDateB": contractLowDate,
			// 								"contractStartDateE": contractHighDate,
			// 								"Country": sCountryVal,
			// 								"Region": regionID,
			// 								"docType": documentType,
			// 								"contractEndDateB": activationLowDate,
			// 								"contractEndDateE": activationHighDate,
			// 								"HPEQuoteNo": HPEQuotNo
			// 							};
			// 							arr.push(obj);
			// 							//data.contractStatusReportNav.push(obj);
			// 						}
			// 					}
			// 				}
			// 				//END jmezadeloitte defect 12427
			// 			}
			// 			//if (partyType === "1") {
			// 			else if (partyType === "1") {
			// 				// End Defect 10555 GASINGHDELOI
			// 				if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}
			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);
			// 					}
			// 				}

			// 			} else if (partyType === "2") {

			// 				if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr.push(obj);

			// 					}

			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}

			// 				}

			// 			} else if (partyType === "3") {
			// 				if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"contractStatusReportNav": arr
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr.push(obj);

			// 					}

			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"contractStatusReportNav": arr,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj = {
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractStartDateB": contractLowDate,
			// 							"contractStartDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"contractEndDateB": activationLowDate,
			// 							"contractEndDateE": activationHighDate,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr.push(obj);

			// 					}

			// 				};

			// 			}

			// 			var oServiceModel = this._getODataModel();

			// 			var sPath = "/Ets_ConStatRep";
			// 			this.getView().setBusy(true);

			// 			var mParameters = {
			// 				method: "POST",
			// 				success: jQuery.proxy(function (oData) {

			// 					this.getView().setBusy(false);
			// 					if (oData.errorMsg.length !== 0) {
			// 						var errMasg = oData.errorMsg;
			// 						MessageBox.error(errMasg);
			// 					} else {

			// 						/*var sUrl =
			// 						"/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ConStatRep?$format=xlsx";*/
			// 						var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ContStatRepFile('" + oData.zguid22 + "')/$value";
			// 						window.open(sUrl, "_blank");
			// 					}

			// 				}, this),

			// 				error: jQuery.proxy(function (oError) {

			// 					this.getView().setBusy(false);
			// 					var oMessage = oError.headers.errorMsg;
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
			// 					if (typeof oMessage !== "undefined") {
			// 						oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
			// 					} else if (oError.statusCode === "502") { // Timeout issue
			// 						oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
			// 					} else {
			// 						oMessage = oError.message;
			// 					}
			// 					MessageBox.error(oMessage, {
			// 						icon: sap.m.MessageBox.Icon.ERROR,
			// 						title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
			// 					});
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
			// 				}, this)
			// 			};

			// 			oServiceModel.create(sPath, data, mParameters);
			// 			/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 		}.bind(this);

			// 		var sMsgDateValidRpt1 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
			// 			bMsgDateValidRpt1 = true;

			// 		if (contractHighDate !== null && contractLowDate !== null) {
			// 			if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt1 = false;
			// 			}
			// 		}

			// 		if (activationHighDate !== null && activationLowDate !== null) {
			// 			if (((activationHighDate.getTime() - activationLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt1 = false;
			// 			}
			// 		}

			// 		if (!bMsgDateValidRpt1) {
			// 			this.getView().setBusy(false);

			// 			MessageBox.show(
			// 				sMsgDateValidRpt1, {
			// 				icon: MessageBox.Icon.WARNING,
			// 				title: "Warning",
			// 				actions: ["Proceed", MessageBox.Action.CANCEL],
			// 				emphasizedAction: MessageBox.Action.CANCEL,
			// 				onClose: function (oAction) {
			// 					if (oAction === "Proceed") {
			// 						_exeRpt1fn();
			// 					}
			// 				}
			// 			}
			// 			);

			// 		} else {
			// 			_exeRpt1fn();
			// 		}
			// 		/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 	}

			// },

			_Report1: function (bInternal) {

				var aPartyToken = this.getView().byId("idPartyID"),
					aPartyId = [],
					oModel = this.getView().getModel("viewData");
				for (var u = 0; u < aPartyToken.getTokens().length; u++) {
					var t1 = aPartyToken.getTokens()[u].getText();
					aPartyId.push(t1);
				}

				var partyType = this.getView().byId("idPartyType").getSelectedKey(),

					contractLowDate = this.getView().byId("idDateRangeContract").getDateValue(),
					contractHighDate = this.getView().byId("idDateRangeContract").getSecondDateValue(),
					activationLowDate = this.getView().byId("idDateRangeActivation").getDateValue(),
					activationHighDate = this.getView().byId("idDateRangeActivation").getSecondDateValue(),
					documentTypeSel = this.getView().byId("idsubscriptiontypeRepCS").getSelectedKey();
				if (documentTypeSel === "ST1") {
					var documentType = "ZQST";
				} else if (documentTypeSel === "ST2") {
					documentType = "ZQTR";
				} else {
					documentType = "";
				}
				var HPEQuotNo = this.getView().byId("idHPEQuotNo").getValue(),
					regionID = this.getView().byId("idRegionCS").getSelectedKey(),
					idCountry = this.getView().byId("idCountryCS"),
					countryTokens = idCountry.getTokens();

				contractLowDate = formatter.changeDateToUTC(contractLowDate);
				contractHighDate = formatter.changeDateToUTC(contractHighDate);
				activationLowDate = formatter.changeDateToUTC(activationLowDate);
				activationHighDate = formatter.changeDateToUTC(activationHighDate);

				var aTokens = [];
				countryTokens.forEach(function (data) {
					var t = data.getKey();
					aTokens.push(t);
				});
				var arr = [];
				var obj = {};
				var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

				// for Punchout Scenario 
				if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") !== "SALES_OPS")) {
					var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
					var l_pricingVisibility = localPunchoutData.Pricingvisibility,
						l_pricingVisibility = l_pricingVisibility.toString(),
						l_userType = localPunchoutData.Usertype;
					if (localPunchoutData.tierMapping.results.length !== 0) {
						var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
					} else {
						l_tierMapping = "";
					}
					if (localPunchoutData.userDetails.results.length !== 0) {
						var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
							"," + localPunchoutData.userDetails.results[0].Visibilitytype +
							"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

					} else {
						l_userDetails = "";
					}

					var l_orderNumber = localPunchoutData_Details.orderNumber,
						l_emailId = localPunchoutData_Details.emailId,
						l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
					l_emailId = l_emailId.split("|")[0];
				}

				if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
					//Checks mandatory fields for Non-INTERNAL users
					MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
					this.getView().setBusy(false);

				} else if (((contractLowDate === null || contractHighDate === null) && (activationLowDate === null || activationHighDate === null)) &&
					bInternal) {
					//Checks mandatory fields for INTERNAL users
					MessageBox.error("Please fill the mandatory date fields.");
					this.getView().setBusy(false);
				} else {
					var _exeRpt1fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

						// Begin Defect 10555 GASINGHDELOI
						if (partyType === "") {
							//Begin jmezadeloitte defect 12427
							if (nLenOfPayload === undefined) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"contractStatusReportNav": arr
								};

								obj = {
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};
								data.contractStatusReportNav.push(obj);
							} else {
								//Begin jmezadeloitte defect 12427
								if (nLenOfPayload === 0 || nLenOfPayload === undefined) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"contractStatusReportNav": arr
									};
									obj = {
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": "",
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};
									arr.push(obj);
									//End jmezadeloitte defect 12427
								} else {
									for (var i = 0; i < nLenOfPayload; i++) {
										var data = {
											"emailId": l_emailId,
											"orderNumber": l_orderNumber,
											"HPEQuoteNo": l_brimSolQuote,
											"pricingVisibility": l_pricingVisibility,
											"userType": l_userType,
											"zcontractNo": "",
											"zcontractItem": "",
											"contractStatusReportNav": arr
										};
										if (aTokens[i] !== undefined) {
											var sCountryVal = aTokens[i];
										} else {
											sCountryVal = "";
										}
										obj = {
											"distributorID": "",
											"resellerID": "",
											"endCustID": "",
											"endCustName": "",
											"contractStartDateB": contractLowDate,
											"contractStartDateE": contractHighDate,
											"Country": sCountryVal,
											"Region": regionID,
											"docType": documentType,
											"contractEndDateB": activationLowDate,
											"contractEndDateE": activationHighDate,
											"HPEQuoteNo": HPEQuotNo
										};
										arr.push(obj);
										//data.contractStatusReportNav.push(obj);
									}
								}
							}
							//END jmezadeloitte defect 12427
						}
						//if (partyType === "1") {
						else if (partyType === "1") {
							// End Defect 10555 GASINGHDELOI
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"contractStatusReportNav": arr
									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj = {
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};
									arr.push(obj);

								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"contractStatusReportNav": arr,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj = {
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};
									arr.push(obj);
								}
							}

						} else if (partyType === "2") {

							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"contractStatusReportNav": arr
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj = {
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};

									arr.push(obj);

								}

							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"contractStatusReportNav": arr,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj = {
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};
									arr.push(obj);

								}

							}

						} else if (partyType === "3") {
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"contractStatusReportNav": arr
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj = {
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};

									arr.push(obj);

								}

							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"contractStatusReportNav": arr,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj = {
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};
									arr.push(obj);

								}

							};

						}

						var oServiceModel = this._getODataModel();

						var sPath = "/Ets_ConStatRep";
						this.getView().setBusy(true);

						var mParameters = {
							method: "POST",
							success: jQuery.proxy(function (oData) {

								this.getView().setBusy(false);
								if (oData.errorMsg.length !== 0) {
									var errMasg = oData.errorMsg;
									MessageBox.error(errMasg);
								} else {

									/*var sUrl =
									"/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ConStatRep?$format=xlsx";*/
									var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ContStatRepFile('" + oData.zguid22 + "')/$value";
									window.open(sUrl, "_blank");
								}

							}, this),

							error: jQuery.proxy(function (oError) {

								this.getView().setBusy(false);
								var oMessage = oError.headers.errorMsg;
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
								if (typeof oMessage !== "undefined") {
									oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
								} else if (oError.statusCode === "502") { // Timeout issue
									oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
								} else {
									oMessage = oError.message;
								}
								MessageBox.error(oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
								});
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
							}, this)
						};

						oServiceModel.create(sPath, data, mParameters);
						/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
					}.bind(this);

					var sMsgDateValidRpt1 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
						bMsgDateValidRpt1 = true;

					if (contractHighDate !== null && contractLowDate !== null) {
						if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
							bMsgDateValidRpt1 = false;
						}
					}

					if (activationHighDate !== null && activationLowDate !== null) {
						if (((activationHighDate.getTime() - activationLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
							bMsgDateValidRpt1 = false;
						}
					}

					if (!bMsgDateValidRpt1) {
						this.getView().setBusy(false);

						MessageBox.show(
							sMsgDateValidRpt1, {
							icon: MessageBox.Icon.WARNING,
							title: "Warning",
							actions: ["Proceed", MessageBox.Action.CANCEL],
							emphasizedAction: MessageBox.Action.CANCEL,
							onClose: function (oAction) {
								if (oAction === "Proceed") {
									_exeRpt1fn();
								}
							}
						}
						);

					} else {
						_exeRpt1fn();
					}
					/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}

			},

			_getODataModel: function () {
				return this.getOwnerComponent().getModel("SSVModel");
			},
			// for Invoice Billing
			// _Report2: function (bInternal) {

			// 	var aPartyToken = this.getView().byId("idPartyIDIAB"),
			// 		aPartyId = [],
			// 		oModel = this.getView().getModel("viewData");
			// 	for (var u = 0; u < aPartyToken.getTokens().length; u++) {
			// 		var t1 = aPartyToken.getTokens()[u].getText();
			// 		aPartyId.push(t1);
			// 	}

			// 	var partyType = this.getView().byId("idPartyTypeIAB").getSelectedKey(),
			// 		contractLowDate = /*this.getView().byId("idDateRangeContractIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeContractIAB").getValue())[0],
			// 		contractHighDate = /*this.getView().byId("idDateRangeContractIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeContractIAB").getValue())[1],
			// 		HPESolQuLowDate = /*this.getView().byId("idDateRangeHPESolQuIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeHPESolQuIAB").getValue())[0],
			// 		HPESolQuHighDate = /*this.getView().byId("idDateRangeHPESolQuIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeHPESolQuIAB").getValue())[1],
			// 		HPEQuotLowDate = /*this.getView().byId("idDateRangeHPEQuoteIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeHPEQuoteIAB").getValue())[0],
			// 		HPEQuotHighDate = /*this.getView().byId("idDateRangeHPEQuoteIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeHPEQuoteIAB").getValue())[1],
			// 		invoicingLowDate = /*this.getView().byId("idDateRangeInvoicingIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeInvoicingIAB").getValue())[0],
			// 		invoicingHighDate = /*this.getView().byId("idDateRangeInvoicingIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
			// 			"idDateRangeInvoicingIAB").getValue())[1];
			// 	var documentTypeSel = this.getView().byId("idsubscriptiontypeRepIAB").getSelectedKey();
			// 	if (documentTypeSel === "ST1") {
			// 		var documentType = "ZQST";
			// 	} else if (documentTypeSel === "ST2") {
			// 		documentType = "ZQTR";
			// 	} else {
			// 		documentType = "";
			// 	}
			// 	var billingType = this.getView().byId("idBillingTypeIAB").getSelectedKey(),
			// 		invoiceFreq = this.getView().byId("idInvoiceFreqIAB").getValue(),
			// 		HPEQuotNo = this.getView().byId("idHPEQuotNoIAB").getValue(),
			// 		ContractStatus = this.getView().byId("idContractStatusIAB").getSelectedKey(),
			// 		regionID = this.getView().byId("idRegionIAB").getSelectedKey(),
			// 		idCountry = this.getView().byId("idCountryIAB"),
			// 		countryTokens = idCountry.getTokens();

			// 	contractLowDate = formatter.changeDateToUTC(contractLowDate);
			// 	contractHighDate = formatter.changeDateToUTC(contractHighDate);
			// 	HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
			// 	HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
			// 	HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
			// 	HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);
			// 	invoicingLowDate = formatter.changeDateToUTC(invoicingLowDate);
			// 	invoicingHighDate = formatter.changeDateToUTC(invoicingHighDate);

			// 	var aTokens = [];
			// 	countryTokens.forEach(function (data) {
			// 		var t = data.getKey();
			// 		aTokens.push(t);
			// 	});
			// 	var arr1 = [];
			// 	var obj1 = {};
			// 	var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// 	//if (this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	if (oModel.getProperty("/Persona") !== "SALES_OPS") {
			// 		var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
			// 		var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
			// 		var l_pricingVisibility = localPunchoutData.Pricingvisibility,
			// 			l_pricingVisibility = l_pricingVisibility.toString(),
			// 			l_userType = localPunchoutData.Usertype;
			// 		if (localPunchoutData.tierMapping.results.length !== 0) {
			// 			var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
			// 		} else {
			// 			l_tierMapping = "";
			// 		}
			// 		if (localPunchoutData.userDetails.results.length !== 0) {
			// 			var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
			// 				"," + localPunchoutData.userDetails.results[0].Visibilitytype +
			// 				"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;
			// 		} else {
			// 			l_userDetails = "";
			// 		}

			// 		var l_orderNumber = localPunchoutData_Details.orderNumber,
			// 			l_emailId = localPunchoutData_Details.emailId,
			// 			l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
			// 		l_emailId = l_emailId.split("|")[0];
			// 	}

			// 	if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
			// 		//Checks mandatory fields for Non-INTERNAL users
			// 		MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
			// 		this.getView().setBusy(false);
			// 	} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
			// 		HPEQuotLowDate === null || HPEQuotHighDate === null) && (invoicingLowDate === null || invoicingHighDate === null)) && bInternal) {
			// 		//Checks mandatory fields for INTERNAL users
			// 		MessageBox.error("Please fill the mandatory date fields.");
			// 		this.getView().setBusy(false);
			// 	} else {

			// 		var _exeRpt2fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
			// 			// Begin Defect 10555 GASINGHDELOI
			// 			if (partyType === "") {
			// 				//BEGIN jmezadeloitte defect 12427
			// 				if (nLenOfPayload === undefined) {
			// 					var data = {
			// 						"emailId": l_emailId,
			// 						"orderNumber": l_orderNumber,
			// 						"HPEQuoteNo": l_brimSolQuote,
			// 						"pricingVisibility": l_pricingVisibility,
			// 						"userType": l_userType,
			// 						"zcontractNo": "",
			// 						"zcontractItem": "",
			// 						"invoiceBillReportNav": []
			// 					};
			// 					obj1 = {
			// 						"creationStartDate": HPESolQuLowDate,
			// 						"creationEndDate": HPESolQuHighDate,
			// 						"contractStartDateB": HPEQuotLowDate,
			// 						"contractStartDateE": HPEQuotHighDate,
			// 						"contractSatus": ContractStatus,
			// 						"distributorID": "",
			// 						"resellerID": "",
			// 						"endCustID": "",
			// 						"endCustName": "",
			// 						"contractEndDateB": contractLowDate,
			// 						"contractEndDateE": contractHighDate,
			// 						"Country": "",
			// 						"Region": regionID,
			// 						"docType": documentType,
			// 						"invoiceStartDate": invoicingLowDate,
			// 						"invoiceEndDate": invoicingHighDate,
			// 						"billType": billingType,
			// 						"frequency": invoiceFreq,
			// 						"HPEQuoteNo": HPEQuotNo
			// 					};
			// 					data.invoiceBillReportNav.push(obj1);
			// 				} else {
			// 					//Begin jmezadeloitte defect 12427
			// 					if (nLenOfPayload === 0) {
			// 						var data = {
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"invoiceBillReportNav": arr1
			// 						};
			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": "",
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};
			// 						arr1.push(obj1);
			// 					} else {
			// 						for (var i = 0; i < nLenOfPayload; i++) {
			// 							var data = {
			// 								"emailId": l_emailId,
			// 								"orderNumber": l_orderNumber,
			// 								"HPEQuoteNo": l_brimSolQuote,
			// 								"pricingVisibility": l_pricingVisibility,
			// 								"userType": l_userType,
			// 								"zcontractNo": "",
			// 								"zcontractItem": "",
			// 								"invoiceBillReportNav": arr1
			// 							};
			// 							if (aTokens[i] !== undefined) {
			// 								var sCountryVal = aTokens[i];
			// 							} else {
			// 								sCountryVal = "";
			// 							}
			// 							obj1 = {
			// 								"creationStartDate": HPESolQuLowDate,
			// 								"creationEndDate": HPESolQuHighDate,
			// 								"contractStartDateB": HPEQuotLowDate,
			// 								"contractStartDateE": HPEQuotHighDate,
			// 								"contractSatus": ContractStatus,
			// 								"distributorID": "",
			// 								"resellerID": "",
			// 								"endCustID": "",
			// 								"endCustName": "",
			// 								"contractEndDateB": contractLowDate,
			// 								"contractEndDateE": contractHighDate,
			// 								"Country": sCountryVal,
			// 								"Region": regionID,
			// 								"docType": documentType,
			// 								"invoiceStartDate": invoicingLowDate,
			// 								"invoiceEndDate": invoicingHighDate,
			// 								"billType": billingType,
			// 								"frequency": invoiceFreq,
			// 								"HPEQuoteNo": HPEQuotNo
			// 							};
			// 							arr1.push(obj1);
			// 						}
			// 					}
			// 				} //END jmezadeloitte defect 12427
			// 			}
			// 			//if (partyType === "1") {
			// 			else if (partyType === "1") {
			// 				// End Defect 10555 GASINGHDELOI
			// 				// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 				if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"invoiceBillReportNav": arr1
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}
			// 						//if(jQuery.sap.getUriParameters().get("i_t")===null){

			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr1.push(obj1);

			// 					}
			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"invoiceBillReportNav": arr1,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": nPartyIDVal,
			// 							"resellerID": "",
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo
			// 						};

			// 						arr1.push(obj1);

			// 					}

			// 				}

			// 			} else if (partyType === "2") {

			// 				// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 				if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"invoiceBillReportNav": arr1
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo

			// 						};
			// 						arr1.push(obj1);
			// 					}
			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"invoiceBillReportNav": arr1,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": "",
			// 							"resellerID": nPartyIDVal,
			// 							"endCustID": "",
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo

			// 						};

			// 						arr1.push(obj1);

			// 					}

			// 				}

			// 			} else if (partyType === "3") {
			// 				// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 				if (oModel.getProperty("/Persona") === "SALES_OPS") {
			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"invoiceBillReportNav": arr1
			// 						};

			// 						if (aPartyId[i] !== undefined) {
			// 							nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo

			// 						};
			// 						arr1.push(obj1);
			// 					}
			// 				} else {

			// 					for (var i = 0; i < nLenOfPayload; i++) {
			// 						var data = {
			// 							"zcontractNo": "",
			// 							"zcontractItem": "",
			// 							"emailId": l_emailId,
			// 							"orderNumber": l_orderNumber,
			// 							"HPEQuoteNo": l_brimSolQuote,
			// 							"pricingVisibility": l_pricingVisibility,
			// 							"userType": l_userType,
			// 							"invoiceBillReportNav": arr1,
			// 							"tierMappingNav": [{
			// 								"tierMapping": l_tierMapping
			// 							}],
			// 							"userDetailsNav": [{
			// 								"userDetails": l_userDetails
			// 							}]

			// 						};
			// 						if (aPartyId[i] !== undefined) {
			// 							var nPartyIDVal = aPartyId[i];
			// 						} else {
			// 							nPartyIDVal = "";
			// 						}
			// 						if (aTokens[i] !== undefined) {
			// 							var sCountryVal = aTokens[i];
			// 						} else {
			// 							sCountryVal = "";
			// 						}

			// 						obj1 = {
			// 							"creationStartDate": HPESolQuLowDate,
			// 							"creationEndDate": HPESolQuHighDate,
			// 							"contractStartDateB": HPEQuotLowDate,
			// 							"contractStartDateE": HPEQuotHighDate,
			// 							"contractSatus": ContractStatus,
			// 							"distributorID": "",
			// 							"resellerID": "",
			// 							"endCustID": nPartyIDVal,
			// 							"endCustName": "",
			// 							"contractEndDateB": contractLowDate,
			// 							"contractEndDateE": contractHighDate,
			// 							"Country": sCountryVal,
			// 							"Region": regionID,
			// 							"docType": documentType,
			// 							"invoiceStartDate": invoicingLowDate,
			// 							"invoiceEndDate": invoicingHighDate,
			// 							"billType": billingType,
			// 							"frequency": invoiceFreq,
			// 							"HPEQuoteNo": HPEQuotNo

			// 						};

			// 						arr1.push(obj1);

			// 					}

			// 				}
			// 			}
			// 			this.getView().setBusy(true);

			// 			var oServiceModel = this._getODataModel("SSVModel");

			// 			var sPath = "/Ets_InvBillRep";

			// 			var mParameters = {
			// 				method: "POST",
			// 				success: jQuery.proxy(function (oData) {
			// 					this.getView().setBusy(false);

			// 					this.getView().setBusy(false);
			// 					if (oData.errorMsg.length !== 0) {
			// 						var errMasg = oData.errorMsg;
			// 						MessageBox.error(errMasg);
			// 					} else {

			// 						var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_InvBillRepFile('" + oData.zguid22 + "')/$value";
			// 						window.open(sUrl, "_blank");
			// 					}

			// 				}, this),

			// 				error: jQuery.proxy(function (oError) {

			// 					this.getView().setBusy(false);
			// 					var oMessage = oError.headers.errorMsg;
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
			// 					if (typeof oMessage !== "undefined") {
			// 						oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
			// 					} else if (oError.statusCode === "502") { // Timeout issue
			// 						oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
			// 					} else {
			// 						oMessage = oError.message;
			// 					}
			// 					MessageBox.error(oMessage, {
			// 						icon: sap.m.MessageBox.Icon.ERROR,
			// 						title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
			// 					});
			// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
			// 				}, this)
			// 			};

			// 			oServiceModel.create(sPath, data, mParameters);
			// 			/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 		}.bind(this);

			// 		var sMsgDateValidRpt2 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
			// 			bMsgDateValidRpt2 = true;

			// 		if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
			// 			if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt2 = false;
			// 			}
			// 		}

			// 		if (contractHighDate !== null && contractLowDate !== null) {
			// 			if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt2 = false;
			// 			}
			// 		}

			// 		if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
			// 			if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt2 = false;
			// 			}
			// 		}

			// 		if (invoicingHighDate !== null && invoicingLowDate !== null) {
			// 			if (((invoicingHighDate.getTime() - invoicingLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
			// 				bMsgDateValidRpt2 = false;
			// 			}
			// 		}

			// 		if (!bMsgDateValidRpt2) {
			// 			this.getView().setBusy(false);

			// 			MessageBox.show(
			// 				sMsgDateValidRpt2, {
			// 				icon: MessageBox.Icon.WARNING,
			// 				title: "Warning",
			// 				actions: ["Proceed", MessageBox.Action.CANCEL],
			// 				emphasizedAction: MessageBox.Action.CANCEL,
			// 				onClose: function (oAction) {
			// 					if (oAction === "Proceed") {
			// 						_exeRpt2fn();
			// 					}
			// 				}
			// 			}
			// 			);

			// 		} else {
			// 			_exeRpt2fn();
			// 		}
			// 		/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			// 	}

			// },
			_Report2: function (bInternal) {

				var aPartyToken = this.getView().byId("idPartyIDIAB"),
					aPartyId = [],
					oModel = this.getView().getModel("viewData");
				for (var u = 0; u < aPartyToken.getTokens().length; u++) {
					var t1 = aPartyToken.getTokens()[u].getText();
					aPartyId.push(t1);
				}

				var partyType = this.getView().byId("idPartyTypeIAB").getSelectedKey(),
					contractLowDate = this.getView().byId("idDateRangeContractIAB").getDateValue(),
					contractHighDate = this.getView().byId("idDateRangeContractIAB").getSecondDateValue(),
					HPESolQuLowDate = this.getView().byId("idDateRangeHPESolQuIAB").getDateValue(),
					HPESolQuHighDate = this.getView().byId("idDateRangeHPESolQuIAB").getSecondDateValue(),
					HPEQuotLowDate = this.getView().byId("idDateRangeHPEQuoteIAB").getDateValue(),
					HPEQuotHighDate = this.getView().byId("idDateRangeHPEQuoteIAB").getSecondDateValue(),
					invoicingLowDate = this.getView().byId("idDateRangeInvoicingIAB").getDateValue(),
					invoicingHighDate = this.getView().byId("idDateRangeInvoicingIAB").getSecondDateValue();
				var documentTypeSel = this.getView().byId("idsubscriptiontypeRepIAB").getSelectedKey();
				if (documentTypeSel === "ST1") {
					var documentType = "ZQST";
				} else if (documentTypeSel === "ST2") {
					documentType = "ZQTR";
				} else {
					documentType = "";
				}
				var billingType = this.getView().byId("idBillingTypeIAB").getSelectedKey(),
					invoiceFreq = this.getView().byId("idInvoiceFreqIAB").getValue(),
					HPEQuotNo = this.getView().byId("idHPEQuotNoIAB").getValue(),
					ContractStatus = this.getView().byId("idContractStatusIAB").getSelectedKey(),
					regionID = this.getView().byId("idRegionIAB").getSelectedKey(),
					idCountry = this.getView().byId("idCountryIAB"),
					countryTokens = idCountry.getTokens();

				contractLowDate = formatter.changeDateToUTC(contractLowDate);
				contractHighDate = formatter.changeDateToUTC(contractHighDate);
				HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
				HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
				HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
				HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);
				invoicingLowDate = formatter.changeDateToUTC(invoicingLowDate);
				invoicingHighDate = formatter.changeDateToUTC(invoicingHighDate);

				var aTokens = [];
				countryTokens.forEach(function (data) {
					var t = data.getKey();
					aTokens.push(t);
				});
				var arr1 = [];
				var obj1 = {};
				var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

				if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") !== "SALES_OPS")) {
					var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
					var l_pricingVisibility = localPunchoutData.Pricingvisibility,
						l_pricingVisibility = l_pricingVisibility.toString(),
						l_userType = localPunchoutData.Usertype;
					if (localPunchoutData.tierMapping.results.length !== 0) {
						var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
					} else {
						l_tierMapping = "";
					}
					if (localPunchoutData.userDetails.results.length !== 0) {
						var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
							"," + localPunchoutData.userDetails.results[0].Visibilitytype +
							"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;
					} else {
						l_userDetails = "";
					}

					var l_orderNumber = localPunchoutData_Details.orderNumber,
						l_emailId = localPunchoutData_Details.emailId,
						l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
					l_emailId = l_emailId.split("|")[0];
				}

				if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
					//Checks mandatory fields for Non-INTERNAL users
					MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
					this.getView().setBusy(false);
				} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
					HPEQuotLowDate === null || HPEQuotHighDate === null) && (invoicingLowDate === null || invoicingHighDate === null)) && bInternal) {
					//Checks mandatory fields for INTERNAL users
					MessageBox.error("Please fill the mandatory date fields.");
					this.getView().setBusy(false);
				} else {

					var _exeRpt2fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
						// Begin Defect 10555 GASINGHDELOI
						if (partyType === "") {
							//BEGIN jmezadeloitte defect 12427
							if (nLenOfPayload === undefined) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"invoiceBillReportNav": []
								};
								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								data.invoiceBillReportNav.push(obj1);
							} else {
								//Begin jmezadeloitte defect 12427
								if (nLenOfPayload === 0) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"invoiceBillReportNav": arr1
									};
									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": "",
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr1.push(obj1);
								} else {
									for (var i = 0; i < nLenOfPayload; i++) {
										var data = {
											"emailId": l_emailId,
											"orderNumber": l_orderNumber,
											"HPEQuoteNo": l_brimSolQuote,
											"pricingVisibility": l_pricingVisibility,
											"userType": l_userType,
											"zcontractNo": "",
											"zcontractItem": "",
											"invoiceBillReportNav": arr1
										};
										if (aTokens[i] !== undefined) {
											var sCountryVal = aTokens[i];
										} else {
											sCountryVal = "";
										}
										obj1 = {
											"creationStartDate": HPESolQuLowDate,
											"creationEndDate": HPESolQuHighDate,
											"contractStartDateB": HPEQuotLowDate,
											"contractStartDateE": HPEQuotHighDate,
											"contractSatus": ContractStatus,
											"distributorID": "",
											"resellerID": "",
											"endCustID": "",
											"endCustName": "",
											"contractEndDateB": contractLowDate,
											"contractEndDateE": contractHighDate,
											"Country": sCountryVal,
											"Region": regionID,
											"docType": documentType,
											"invoiceStartDate": invoicingLowDate,
											"invoiceEndDate": invoicingHighDate,
											"billType": billingType,
											"frequency": invoiceFreq,
											"HPEQuoteNo": HPEQuotNo
										};
										arr1.push(obj1);
									}
								}
							} //END jmezadeloitte defect 12427
						}
						//if (partyType === "1") {
						else if (partyType === "1") {
							// End Defect 10555 GASINGHDELOI
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"invoiceBillReportNav": arr1
									};

									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}
									//if(jQuery.sap.getUriParameters().get("i_t")===null){

									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};

									arr1.push(obj1);

								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"invoiceBillReportNav": arr1,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};

									arr1.push(obj1);

								}

							}

						} else if (partyType === "2") {

							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"invoiceBillReportNav": arr1
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo

									};
									arr1.push(obj1);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"invoiceBillReportNav": arr1,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo

									};

									arr1.push(obj1);

								}

							}

						} else if (partyType === "3") {
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"invoiceBillReportNav": arr1
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo

									};
									arr1.push(obj1);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"invoiceBillReportNav": arr1,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo

									};

									arr1.push(obj1);

								}

							}
						}
						this.getView().setBusy(true);

						var oServiceModel = this._getODataModel();

						var sPath = "/Ets_InvBillRep";

						var mParameters = {
							method: "POST",
							success: jQuery.proxy(function (oData) {
								this.getView().setBusy(false);

								this.getView().setBusy(false);
								if (oData.errorMsg.length !== 0) {
									var errMasg = oData.errorMsg;
									MessageBox.error(errMasg);
								} else {

									var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_InvBillRepFile('" + oData.zguid22 + "')/$value";
									window.open(sUrl, "_blank");
								}

							}, this),

							error: jQuery.proxy(function (oError) {

								this.getView().setBusy(false);
								var oMessage = oError.headers.errorMsg;
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
								if (typeof oMessage !== "undefined") {
									oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
								} else if (oError.statusCode === "502") { // Timeout issue
									oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
								} else {
									oMessage = oError.message;
								}
								MessageBox.error(oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
								});
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
							}, this)
						};

						oServiceModel.create(sPath, data, mParameters);
						/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
					}.bind(this);

					var sMsgDateValidRpt2 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
						bMsgDateValidRpt2 = true;

					if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
						if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
							bMsgDateValidRpt2 = false;
						}
					}

					if (contractHighDate !== null && contractLowDate !== null) {
						if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
							bMsgDateValidRpt2 = false;
						}
					}

					if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
						if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
							bMsgDateValidRpt2 = false;
						}
					}

					if (invoicingHighDate !== null && invoicingLowDate !== null) {
						if (((invoicingHighDate.getTime() - invoicingLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
							bMsgDateValidRpt2 = false;
						}
					}

					if (!bMsgDateValidRpt2) {
						this.getView().setBusy(false);

						MessageBox.show(
							sMsgDateValidRpt2, {
							icon: MessageBox.Icon.WARNING,
							title: "Warning",
							actions: ["Proceed", MessageBox.Action.CANCEL],
							emphasizedAction: MessageBox.Action.CANCEL,
							onClose: function (oAction) {
								if (oAction === "Proceed") {
									_exeRpt2fn();
								}
							}
						}
						);

					} else {
						_exeRpt2fn();
					}
					/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}

			},

			// for Usage and Rate Report
			_Report3: function (bInternal) {

				var aPartyToken = this.getView().byId("idPartyIDUAR"),
					aPartyId = [],
					oModel = this.getView().getModel("viewData");
				for (var u = 0; u < aPartyToken.getTokens().length; u++) {
					var t1 = aPartyToken.getTokens()[u].getText();
					aPartyId.push(t1);
				}

				var partyType = this.getView().byId("idPartyTypeUAR").getSelectedKey(),
					partyID = this.getView().byId("idPartyIDUAR").getValue(),
					contractLowDate = /*this.getView().byId("idDateRangeContractUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContractUAR").getValue())[0],
					contractHighDate = /*this.getView().byId("idDateRangeContractUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContractUAR").getValue())[1],
					HPESolQuLowDate = /*this.getView().byId("idDateRangeHPESolQuUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPESolQuUAR").getValue())[0],
					HPESolQuHighDate = /*this.getView().byId("idDateRangeHPESolQuUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPESolQuUAR").getValue())[1],
					HPEQuotLowDate = /*this.getView().byId("idDateRangeHPEQuoteUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPEQuoteUAR").getValue())[0],
					HPEQuotHighDate = /*this.getView().byId("idDateRangeHPEQuoteUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPEQuoteUAR").getValue())[1];
				var documentTypeSel = this.getView().byId("idsubscriptiontypeRepUAR").getSelectedKey();
				if (documentTypeSel === "ST1") {
					var documentType = "ZQST";
				} else if (documentTypeSel === "ST2") {
					documentType = "ZQTR";
				} else {
					documentType = "";
				}
				var billingType = this.getView().byId("idBillingTypeUAR").getSelectedKey(),
					invoiceFreq = this.getView().byId("idInvoiceFreqUAR").getValue(),
					ContractStatus = this.getView().byId("idContractStatusUAR").getSelectedKey(),
					HPEQuotNo = this.getView().byId("idHPEQuotNoUAR").getValue(),
					regionID = this.getView().byId("idRegionUAR").getSelectedKey(),
					idCountry = this.getView().byId("idCountryUAR"),
					countryTokens = idCountry.getTokens();

				contractLowDate = formatter.changeDateToUTC(contractLowDate);
				contractHighDate = formatter.changeDateToUTC(contractHighDate);
				HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
				HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
				HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
				HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);

				var aTokens = [];
				countryTokens.forEach(function (data) {
					var t = data.getKey();
					aTokens.push(t);
				});
				var arr2 = [];
				var obj2 = {};
				var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

				//if (this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
				if (oModel.getProperty("/Persona") !== "SALES_OPS") {
					var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
					var l_pricingVisibility = localPunchoutData.Pricingvisibility,
						l_pricingVisibility = l_pricingVisibility.toString(),
						l_userType = localPunchoutData.Usertype;
					if (localPunchoutData.tierMapping.results.length !== 0) {
						var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
					} else {
						l_tierMapping = "";
					}
					if (localPunchoutData.userDetails.results.length !== 0) {
						var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
							"," + localPunchoutData.userDetails.results[0].Visibilitytype +
							"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

					} else {
						l_userDetails = "";
					}

					var l_orderNumber = localPunchoutData_Details.orderNumber,
						l_emailId = localPunchoutData_Details.emailId,
						l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
					l_emailId = l_emailId.split("|")[0];
				}

				if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
					//Checks mandatory fields for Non-INTERNAL users
					MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
					this.getView().setBusy(false);
				} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
					HPEQuotLowDate === null || HPEQuotHighDate === null)) && bInternal) {
					//Checks mandatory fields for INTERNAL users
					MessageBox.error("Please fill the mandatory date fields.");
					this.getView().setBusy(false);
				} else {
					var _exeRpt3fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
						// Begin Defect 10555 GASINGHDELOI
						if (partyType === "") {
							//BEGIN jmezadeloitte defect 12427
							if (nLenOfPayload === undefined) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"usageRatingReportNav": []
								};
								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								data.usageRatingReportNav.push(obj2);
							} else {
								if (nLenOfPayload === 0) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"usageRatingReportNav": arr2
									};
									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": "",
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								} else {
									for (var i = 0; i < nLenOfPayload; i++) {
										var data = {
											"emailId": l_emailId,
											"orderNumber": l_orderNumber,
											"HPEQuoteNo": l_brimSolQuote,
											"pricingVisibility": l_pricingVisibility,
											"userType": l_userType,
											"zcontractNo": "",
											"zcontractItem": "",
											"usageRatingReportNav": arr2
										};
										if (aTokens[i] !== undefined) {
											var sCountryVal = aTokens[i];
										} else {
											sCountryVal = "";
										}
										obj2 = {
											"creationStartDate": HPESolQuLowDate,
											"creationEndDate": HPESolQuHighDate,
											"contractStartDateB": HPEQuotLowDate,
											"contractStartDateE": HPEQuotHighDate,
											"contractSatus": ContractStatus,
											"distributorID": "",
											"resellerID": "",
											"endCustID": "",
											"endCustName": "",
											"contractEndDateB": contractLowDate,
											"contractEndDateE": contractHighDate,
											"Country": sCountryVal,
											"Region": regionID,
											"docType": documentType,
											"billType": billingType,
											"frequency": invoiceFreq,
											"HPEQuoteNo": HPEQuotNo
										};
										arr2.push(obj2);
									}
								}
							} //END jmezadeloitte defect 12427
						}
						//if (partyType === "1") {
						else if (partyType === "1") {
							// End Defect 10555 GASINGHDELOI
							// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
							if (oModel.getProperty("/Persona") === "SALES_OPS") {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"usageRatingReportNav": arr2
									};

									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};

									arr2.push(obj2);

								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"usageRatingReportNav": arr2,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									//if(jQuery.sap.getUriParameters().get("i_t")===null){

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};

									arr2.push(obj2);

								}

							}

						} else if (partyType === "2") {
							// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
							if (oModel.getProperty("/Persona") === "SALES_OPS") {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"usageRatingReportNav": arr2
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"usageRatingReportNav": arr2,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);

								}

							}

						} else if (partyType === "3") {
							// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
							if (oModel.getProperty("/Persona") === "SALES_OPS") {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"usageRatingReportNav": arr2
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"usageRatingReportNav": arr2,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);

								}

							}
						}

						this.getView().setBusy(true);
						var oServiceModel = this._getODataModel("SSVModel");

						var sPath = "/Ets_UsaRatRep";

						var mParameters = {
							method: "POST",
							success: jQuery.proxy(function (oData) {
								this.getView().setBusy(false);

								if (oData.errorMsg.length !== 0) {
									var errMasg = oData.errorMsg;
									MessageBox.error(errMasg);
								} else {
									var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_UsaRatRepFile('" + oData.zguid22 + "')/$value";
									window.open(sUrl, "_blank");
								}

							}, this),

							error: jQuery.proxy(function (oError) {

								this.getView().setBusy(false);
								var oMessage = oError.headers.errorMsg;
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
								if (typeof oMessage !== "undefined") {
									oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
								} else if (oError.statusCode === "502") { // Timeout issue
									oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
								} else {
									oMessage = oError.message;
								}
								MessageBox.error(oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
								});
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
							}, this)
						};

						oServiceModel.create(sPath, data, mParameters);
						/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
					}.bind(this);

					var sMsgDateValidRpt3 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
						bMsgDateValidRpt3 = true;

					if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
						if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt3 = false;
						}
					}

					if (contractHighDate !== null && contractLowDate !== null) {
						if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt3 = false;
						}
					}

					if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
						if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt3 = false;
						}
					}

					if (!bMsgDateValidRpt3) {

						this.getView().setBusy(false);

						MessageBox.show(
							sMsgDateValidRpt3, {
							icon: MessageBox.Icon.WARNING,
							title: "Warning",
							actions: ["Proceed", MessageBox.Action.CANCEL],
							emphasizedAction: MessageBox.Action.CANCEL,
							onClose: function (oAction) {
								if (oAction === "Proceed") {
									_exeRpt3fn();
								}
							}
						}
						);

					} else {
						_exeRpt3fn();
					}

					/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}

			},

			_Report4: function (bInternal) {

				var aPartyToken = this.getView().byId("idPartyIDDMI"),
					aPartyId = [],
					oModel = this.getView().getModel("viewData");
				for (var u = 0; u < aPartyToken.getTokens().length; u++) {
					var t1 = aPartyToken.getTokens()[u].getText();
					aPartyId.push(t1);
				}

				var partyType = this.getView().byId("idPartyTypeDMI").getSelectedKey(),

					invoiceLowDate = this.getView().byId("idDateRangeInvoicingDMI").getDateValue(),
					invoiceHighDate = this.getView().byId("idDateRangeInvoicingDMI").getSecondDateValue(),
					invoiceLowDate = formatter.changeDateToUTC(invoiceLowDate),
					invoiceHighDate = formatter.changeDateToUTC(invoiceHighDate),
					scheduleLowDate = this._formatter.formatDateForBackend(this.getView().byId("idDateRangeInvoicingDMI").getDateValue()),
					scheduleHighDate = this._formatter.formatDateForBackend(this.getView().byId("idDateRangeInvoicingDMI").getSecondDateValue()),
					dateOfMonth = this.getView().byId("idDOMDMI").getSelectedKey(),
					email = this.getView().byId("idEmailID").getValue;

				var arr3 = [];
				var obj3 = {};
				var nLenOfPayload = aPartyId.length;

				if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") !== "SALES_OPS")) {
					var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
					var l_pricingVisibility = localPunchoutData.Pricingvisibility,
						l_pricingVisibility = l_pricingVisibility.toString(),
						l_userType = localPunchoutData.Usertype;
					if (localPunchoutData.tierMapping.results.length !== 0) {
						var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
					} else {
						l_tierMapping = "";
					}
					if (localPunchoutData.userDetails.results.length !== 0) {
						var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
							"," + localPunchoutData.userDetails.results[0].Visibilitytype +
							"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;
					} else {
						l_userDetails = "";
					}

					var l_orderNumber = localPunchoutData_Details.orderNumber,
						l_emailId = localPunchoutData_Details.emailId,
						l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
					l_emailId = l_emailId.split("|")[0];
				}

				if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
					//Checks mandatory fields for Non-INTERNAL users
					MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
					this.getView().setBusy(false);
				} else if ((invoiceLowDate === null || invoiceHighDate === null || scheduleLowDate === null || scheduleHighDate === null) &&
					bInternal) {
					//Checks mandatory fields for INTERNAL users
					MessageBox.error("Please fill the mandatory date fields.");
					this.getView().setBusy(false);
				} else {
					var _exeRpt4fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

						// Begin Defect 10555 GASINGHDELOI
						if (partyType === "") {
							var data = {
								"emailId": l_emailId,
								"orderNumber": l_orderNumber,
								"HPEQuoteNo": l_brimSolQuote,
								"pricingVisibility": l_pricingVisibility,
								"userType": l_userType,
								"zcontractNo": "",
								"zcontractItem": "",
								"monthlyInvoiceReportNav": []
							};
							obj3 = {
								"distrID": "",
								"partnerID": "",
								"endCustID": "",
								"invoicePeriodBegin": invoiceLowDate,
								"invoicePeriodEnd": invoiceHighDate
							};
							data.monthlyInvoiceReportNav.push(obj3);
						}
						//if (partyType === "1") {
						else if (partyType === "1") {
							// End Defect 10555 GASINGHDELOI
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"monthlyInvoiceReportNav": arr3
									};

									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}

									//if(jQuery.sap.getUriParameters().get("i_t")===null){

									obj3 = {
										"distrID": nPartyIDVal,
										"partnerID": "",
										"endCustID": "",
										"invoicePeriodBegin": invoiceLowDate,
										"invoicePeriodEnd": invoiceHighDate

									};

									arr3.push(obj3);

								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"monthlyInvoiceReportNav": arr3,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}

									obj3 = {
										"distrID": nPartyIDVal,
										"partnerID": "",
										"endCustID": "",
										"invoicePeriodBegin": invoiceLowDate,
										"invoicePeriodEnd": invoiceHighDate

									};

									arr3.push(obj3);

								}

							}

						} else if (partyType === "2") {
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"monthlyInvoiceReportNav": arr3
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}

									obj3 = {
										"distrID": "",
										"partnerID": nPartyIDVal,
										"endCustID": "",
										"invoicePeriodBegin": invoiceLowDate,
										"invoicePeriodEnd": invoiceHighDate

									};
									arr2.push(obj3);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"monthlyInvoiceReportNav": arr3,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}

									obj3 = {
										"distrID": "",
										"partnerID": nPartyIDVal,
										"endCustID": "",
										"invoicePeriodBegin": invoiceLowDate,
										"invoicePeriodEnd": invoiceHighDate

									};
									arr3.push(obj3);

								}

							}

						}
						//SOC LEPRIYA INC1712496-SSV_MIissing customer search option in the account detail field for SSV Monthly Invoice Report-2022/09/13
						else if (partyType === "3") {
							if (!this.fnGetParamExistsInURI("i_t") && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"monthlyInvoiceReportNav": arr3
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}

									obj3 = {
										"distrID": "",
										"partnerID": "",
										"endCustID": nPartyIDVal,
										"invoicePeriodBegin": invoiceLowDate,
										"invoicePeriodEnd": invoiceHighDate

									};
									arr3.push(obj3);

								}

							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"monthlyInvoiceReportNav": arr3,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}

									obj3 = {
										"distrID": "",
										"partnerID": "",
										"endCustID": nPartyIDVal,
										"invoicePeriodBegin": invoiceLowDate,
										"invoicePeriodEnd": invoiceHighDate

									};
									arr3.push(obj3);

								}

							};

						}
						//EOC LEPRIYA INC1712496-SSV_MIissing customer search option in the account detail field for SSV Monthly Invoice Report-2022/09/13
						this.getView().setBusy(true);
						var oServiceModel = this._getODataModel();

						var sPath = "/Ets_MonthInvRep";

						var mParameters = {
							method: "POST",
							success: jQuery.proxy(function (oData) {
								this.getView().setBusy(false);

								if (oData.errorMsg.length !== 0) {
									var errMasg = oData.errorMsg;
									MessageBox.error(errMasg);
								} else {
									var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_MontInvRepFile('" + oData.zguid22 + "')/$value";
									window.open(sUrl, "_blank");
								}
							}, this),

							error: jQuery.proxy(function (oError) {

								this.getView().setBusy(false);
								var oMessage = oError.headers.errorMsg;
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
								if (typeof oMessage !== "undefined") {
									oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
								} else if (oError.statusCode === "502") { // Timeout issue
									oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
								} else {
									oMessage = oError.message;
								}
								MessageBox.error(oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
								});
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
							}, this)
						};

						oServiceModel.create(sPath, data, mParameters);
						/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
					}.bind(this);

					var sMsgDateValidRpt4 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarningScheduleRpt"),
						bMsgDateValidRpt4 = true;

					if (invoiceHighDate !== null && invoiceLowDate !== null) {
						if (((invoiceHighDate.getTime() - invoiceLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt4 = false;
						}
					}

					if (!bMsgDateValidRpt4) {
						this.getView().setBusy(false);

						MessageBox.show(
							sMsgDateValidRpt4, {
							icon: MessageBox.Icon.WARNING,
							title: "Warning",
							actions: ["Proceed", MessageBox.Action.CANCEL],
							emphasizedAction: MessageBox.Action.CANCEL,
							onClose: function (oAction) {
								if (oAction === "Proceed") {
									_exeRpt4fn();
								}
							}
						}
						);

					} else {
						_exeRpt4fn();
					}

					/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}
			},
			// for Cloud Credit Report - /*SOC BADH EAGLE-SOME4028B 2021/11/08*/
			_Report5: function (bInternal) {
				var aPartyToken = this.getView().byId("idPartyIDCCC"),
					aPartyId = [],
					oModel = this.getView().getModel("viewData");
				for (var u = 0; u < aPartyToken.getTokens().length; u++) {
					var t1 = aPartyToken.getTokens()[u].getText();
					aPartyId.push(t1);
				}

				var partyType = this.getView().byId("idPartyTypeCCC").getSelectedKey(),
					partyID = this.getView().byId("idPartyIDCCC").getValue(),
					contractLowDate = /*this.getView().byId("idDateRangeContractCCC")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContractCCC").getValue())[0],
					contractHighDate = /*this.getView().byId("idDateRangeContractCCC")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContractCCC").getValue())[1],
					HPESolQuLowDate = /*this.getView().byId("idDateRangeHPESolQuCCC")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPESolQuCCC").getValue())[0],
					HPESolQuHighDate = /*this.getView().byId("idDateRangeHPESolQuCCC")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPESolQuCCC").getValue())[1],
					HPEQuotLowDate = /*this.getView().byId("idDateRangeHPEQuoteCCC")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPEQuoteCCC").getValue())[0],
					HPEQuotHighDate = /*this.getView().byId("idDateRangeHPEQuoteCCC")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPEQuoteCCC").getValue())[1],
					documentType = "ZQST";

				var billingType = this.getView().byId("idBillingTypeCCC").getSelectedKey(),
					invoiceFreq = this.getView().byId("idInvoiceFreqCCC").getValue(),
					ContractStatus = this.getView().byId("idContractStatusCCC").getSelectedKey(),
					HPEQuotNo = this.getView().byId("idHPEQuotNoCCC").getValue(),
					regionID = this.getView().byId("idRegionCCC").getSelectedKey(),
					idCountry = this.getView().byId("idCountryCCC"),
					countryTokens = idCountry.getTokens();

				contractLowDate = formatter.changeDateToUTC(contractLowDate);
				contractHighDate = formatter.changeDateToUTC(contractHighDate);
				HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
				HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
				HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
				HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);

				var aTokens = [];
				countryTokens.forEach(function (data) {
					var t = data.getKey();
					aTokens.push(t);
				});
				var arr2 = [];
				var obj2 = {};
				var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

				//if (this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
				if (oModel.getProperty("/Persona") !== "SALES_OPS") {
					var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
					var l_pricingVisibility = localPunchoutData.Pricingvisibility,
						l_pricingVisibility = l_pricingVisibility.toString(),
						l_userType = localPunchoutData.Usertype;
					if (localPunchoutData.tierMapping.results.length !== 0) {
						var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
					} else {
						l_tierMapping = "";
					}
					if (localPunchoutData.userDetails.results.length !== 0) {
						var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
							"," + localPunchoutData.userDetails.results[0].Visibilitytype +
							"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

					} else {
						l_userDetails = "";
					}

					var l_orderNumber = localPunchoutData_Details.orderNumber,
						l_emailId = localPunchoutData_Details.emailId,
						l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
					l_emailId = l_emailId.split("|")[0];
				}

				if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
					//Checks mandatory fields for Non-INTERNAL users
					MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
					this.getView().setBusy(false);
				} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
					HPEQuotLowDate === null || HPEQuotHighDate === null)) && bInternal) {
					//Checks mandatory fields for INTERNAL users
					MessageBox.error("Please fill the mandatory date fields.");
					this.getView().setBusy(false);
				} else {
					var _exeRpt5fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
						// Begin Defect 10555 GASINGHDELOI
						if (partyType === "") {
							//BEGIN jmezadeloitte defect 12427
							if (nLenOfPayload === undefined) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"cloudCreditReportNav": []
								};
								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								data.cloudCreditReportNav.push(obj2);
							} else {
								if (nLenOfPayload === 0) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"cloudCreditReportNav": arr2
									};
									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": "",
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								} else {
									for (var i = 0; i < nLenOfPayload; i++) {
										var data = {
											"emailId": l_emailId,
											"orderNumber": l_orderNumber,
											"HPEQuoteNo": l_brimSolQuote,
											"pricingVisibility": l_pricingVisibility,
											"userType": l_userType,
											"zcontractNo": "",
											"zcontractItem": "",
											"cloudCreditReportNav": arr2
										};
										if (aTokens[i] !== undefined) {
											var sCountryVal = aTokens[i];
										} else {
											sCountryVal = "";
										}
										obj2 = {
											"creationStartDate": HPESolQuLowDate,
											"creationEndDate": HPESolQuHighDate,
											"contractStartDateB": HPEQuotLowDate,
											"contractStartDateE": HPEQuotHighDate,
											"contractSatus": ContractStatus,
											"distributorID": "",
											"resellerID": "",
											"endCustID": "",
											"endCustName": "",
											"contractEndDateB": contractLowDate,
											"contractEndDateE": contractHighDate,
											"Country": sCountryVal,
											"Region": regionID,
											"docType": documentType,
											"billType": billingType,
											"frequency": invoiceFreq,
											"HPEQuoteNo": HPEQuotNo
										};
										arr2.push(obj2);
									}
								}
							} //END jmezadeloitte defect 12427
						}
						//if (partyType === "1") {
						else if (partyType === "1") {
							// End Defect 10555 GASINGHDELOI
							// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
							if (oModel.getProperty("/Persona") === "SALES_OPS") {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"cloudCreditReportNav": arr2
									};

									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};

									arr2.push(obj2);

								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"cloudCreditReportNav": arr2,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										var nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									//if(jQuery.sap.getUriParameters().get("i_t")===null){

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": nPartyIDVal,
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};

									arr2.push(obj2);

								}

							}

						} else if (partyType === "2") {
							// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
							if (oModel.getProperty("/Persona") === "SALES_OPS") {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"cloudCreditReportNav": arr2
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"cloudCreditReportNav": arr2,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": nPartyIDVal,
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);

								}

							}

						} else if (partyType === "3") {
							// if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
							if (oModel.getProperty("/Persona") === "SALES_OPS") {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"cloudCreditReportNav": arr2
									};

									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								}
							} else {

								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"zcontractNo": "",
										"zcontractItem": "",
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"cloudCreditReportNav": arr2,
										"tierMappingNav": [{
											"tierMapping": l_tierMapping
										}],
										"userDetailsNav": [{
											"userDetails": l_userDetails
										}]

									};
									if (aPartyId[i] !== undefined) {
										nPartyIDVal = aPartyId[i];
									} else {
										nPartyIDVal = "";
									}
									if (aTokens[i] !== undefined) {
										sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}

									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": nPartyIDVal,
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);

								}

							}
						}

						this.getView().setBusy(true);
						var oServiceModel = this._getODataModel("SSVModel");

						var sPath = "/Ets_cloudCreditRep";

						var mParameters = {
							method: "POST",
							success: jQuery.proxy(function (oData) {
								this.getView().setBusy(false);

								if (oData.errorMsg.length !== 0) {
									var errMasg = oData.errorMsg;
									MessageBox.error(errMasg);
								} else {
									var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_CloudCredRepFile('" + oData.zguid22 + "')/$value";
									window.open(sUrl, "_blank");
								}

							}, this),

							error: jQuery.proxy(function (oError) {

								this.getView().setBusy(false);
								var oMessage = oError.headers.errorMsg;
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
								if (typeof oMessage !== "undefined") {
									oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
								} else if (oError.statusCode === "502") { // Timeout issue
									oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
								} else {
									oMessage = oError.message;
								}
								MessageBox.error(oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
								});
								// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
							}, this)
						};

						oServiceModel.create(sPath, data, mParameters);
						/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
					}.bind(this);

					var sMsgDateValidRpt5 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
						bMsgDateValidRpt5 = true;

					if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
						if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt5 = false;
						}
					}

					if (contractHighDate !== null && contractLowDate !== null) {
						if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt5 = false;
						}
					}

					if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
						if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
							bMsgDateValidRpt5 = false;
						}
					}

					if (!bMsgDateValidRpt5) {

						this.getView().setBusy(false);

						MessageBox.show(
							sMsgDateValidRpt5, {
							icon: MessageBox.Icon.WARNING,
							title: "Warning",
							actions: ["Proceed", MessageBox.Action.CANCEL],
							emphasizedAction: MessageBox.Action.CANCEL,
							onClose: function (oAction) {
								if (oAction === "Proceed") {
									_exeRpt5fn();
								}
							}
						}
						);

					} else {
						_exeRpt5fn();
					}

					/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}

			},
			/*EOC BADH EAGLE-SOME4028B 2021/11/08*/
			// this function will be called on click of "save as" button
			fnOnReport4SaveAs: function () {
				var aPartyToken = this.getView().byId("idPartyIDDMI");
				var partyType = this.getView().byId("idPartyTypeDMI").getSelectedKey();
				var partyID = [];
				var ofilters = [];
				for (var u = 0; u < aPartyToken.getTokens().length; u++) {
					var t1 = aPartyToken.getTokens()[u].getText();
					partyID.push(t1);
				}

				var invoiceLowDate = /*this.getView().byId("idDateRangeInvoicingDMI")*/ DynamicDateUtil.toDates(this.getView().byId(
					"idDateRangeInvoicingDMI").getValue())[0],

					invoiceHighDate = /*this.getView().byId("idDateRangeInvoicingDMI")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeInvoicingDMI").getValue())[1],

					scheduleLowDate = this.getView().byId("idDateScheduleStartDateDMI").getDateValue(),

					scheduleHighDate = this.getView().byId("idDateScheduleStartDateDMI").getSecondDateValue(),

					dateOfMonth = this.getView().byId("idDOMDMI").getValue(),
					email = this.getView().byId("idEmailID").getValue();

				invoiceLowDate = formatter.changeDateToUTC(invoiceLowDate);
				invoiceHighDate = formatter.changeDateToUTC(invoiceHighDate);
				scheduleLowDate = formatter.changeDateToUTC(scheduleLowDate);
				scheduleHighDate = formatter.changeDateToUTC(scheduleHighDate);
				//if (this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
				if (oModel.getProperty("/Persona") !== "SALES_OPS") {
					var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
					var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
					var l_pricingVisibility = localPunchoutData.Pricingvisibility,
						l_pricingVisibility = l_pricingVisibility.toString(),
						l_userType = localPunchoutData.Usertype;
					if (localPunchoutData.tierMapping.results.length !== 0) {
						var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
					} else {
						l_tierMapping = "";
					}
					if (localPunchoutData.userDetails.results.length !== 0) {
						var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
							"," + localPunchoutData.userDetails.results[0].Visibilitytype +
							"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;
					} else {
						l_userDetails = "";
					}

					var l_orderNumber = localPunchoutData_Details.orderNumber,
						l_emailId = localPunchoutData_Details.emailId,
						l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;

					l_emailId = l_emailId.split("|")[0];

					ofilters.push(new sap.ui.model.Filter("orderNumber", "EQ", l_orderNumber));
					//Remove the hard code value
					ofilters.push(new sap.ui.model.Filter("solutionQuoteId", "EQ", l_brimSolQuote));
					ofilters.push(new sap.ui.model.Filter("pricingVisibility", "EQ", l_pricingVisibility));
					ofilters.push(new sap.ui.model.Filter("userType", "EQ", l_userType));
					ofilters.push(new sap.ui.model.Filter("tierMapping", "EQ", l_tierMapping));
					ofilters.push(new sap.ui.model.Filter("userDetails", "EQ", l_userDetails));

				}

				this.getView().setBusy(true);
				/*SOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
				var _localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				if (_localPunchoutData === undefined || _localPunchoutData === null) {
					_localPunchoutData = {
						Usertype: ""
					};
				}
				var _bInternal = (_localPunchoutData.Usertype === "INTERNAL" || _localPunchoutData.Usertype ===
					"Internal" || _localPunchoutData.Usertype === "internal");
				//var _bToken = (!this.fnGetParamExistsInURI("q")); //ACHOPRADELOI RAMP-1458 2023/10/17

				if (( /**_bToken  ||**/ _bInternal) && (scheduleLowDate === null || scheduleHighDate ===
					null || dateOfMonth === "" || email === "")) {
					MessageBox.error("Please fill all the form fields");
					this.getView().setBusy(false);
				} /*EOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
				else if ( /**!_bToken && **/ !_bInternal && (partyType === "" || scheduleLowDate === null || scheduleHighDate ===
					null || dateOfMonth === "" || email === "")) {
					MessageBox.error("Please fill all the form fields");
					this.getView().setBusy(false);
				} else {
					/*SOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
					if (partyID.length > 1) {
						var aPartyIDFilters = [];
						if (partyType === "1") {
							for (var sPartyID of partyID) {
								aPartyIDFilters.push(new sap.ui.model.Filter("distrID", "EQ", sPartyID));
							}
						} else if (partyType === "2") {
							for (var sPartyID of partyID) {
								aPartyIDFilters.push(new sap.ui.model.Filter("partnerID", "EQ", sPartyID));
							}
						}
						ofilters.push(new sap.ui.model.Filter(aPartyIDFilters, false));

					} else {
						if (partyType === "1") {
							ofilters.push(new sap.ui.model.Filter("distrID", "EQ", partyID));
						} else if (partyType === "2") {
							ofilters.push(new sap.ui.model.Filter("partnerID", "EQ", partyID));
						}
					}
					/*EOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
					ofilters.push(new sap.ui.model.Filter("invoicePeriodBegin", "EQ", invoiceLowDate));
					ofilters.push(new sap.ui.model.Filter("invoicePeriodEnd", "EQ", invoiceHighDate));
					ofilters.push(new sap.ui.model.Filter("startDate", "EQ", scheduleLowDate));
					ofilters.push(new sap.ui.model.Filter("endDate", "EQ", scheduleHighDate));
					ofilters.push(new sap.ui.model.Filter("dateOfMonth", "EQ", dateOfMonth));
					ofilters.push(new sap.ui.model.Filter("emailID", "EQ", email));
					var oServiceModel = this._getODataModel("SSVModel");

					var sPath = "/Ets_MonthlyInvSch";

					var mParameters = {
						method: "GET",
						filters: ofilters,
						success: jQuery.proxy(function (oData) {

							this.getView().setBusy(false);

							if (oData.results[0].errorMsg.length !== 0) {
								var errMasg = oData.results[0].errorMsg;
								MessageBox.error(errMasg);
							} else {
								MessageBox.success("Monthly Invoicing Report has scheduled");

							}

						}, this),
						error: jQuery.proxy(function (oError) {
							this.getView().setBusy(false);
							var errMasg = oError.responseText;
							MessageBox.error(errMasg);
						}, this)
					};

					oServiceModel.read(sPath, mParameters);
				}

			},

			// to check the entered day of Month value for the 4th report
			fnCheckDayValue: function () {
				var enteredNo = this.getView().byId("idDOMDMI").getValue(),
					enterNoPar = this.getView().byId("idDOMDMI");
				if (isNaN(enteredNo) || enteredNo < 1 || enteredNo > 28) {
					var oEnteredVal = "";
					enterNoPar.setValue(oEnteredVal);
					MessageBox.error("Please Enter Number Between 1 to 28", {
						width: "550px"

					});
				} else {
					return enteredNo;
				}

			},

			fnCheckInvoiveDateReport4: function () {
				//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
				var dateVal = this.getView().byId("idDateRangeInvoicingDMI");
				var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM-dd-yyyy"
				});
				var dateString = dateFormat.format(dateValues[0]) + " - ";
				if (dateFormat.format(dateValues[1])) {
					dateString = dateString + dateFormat.format(dateValues[1]);
				} else {
					dateString = dateString + dateFormat.format(sdateRangeVal[0]);
				}
				this.fnOnchangeDateValForReport(dateVal, dateString);
				//}
			},

			fnCheckStartDateReport4: function () {
				//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
				var dateVal = this.getView().byId("idDateScheduleStartDateDMI");
				var dateString = this.getView().byId("idDateScheduleStartDateDMI").mProperties.value;
				this.fnOnchangeDateValForReport4(dateVal, dateString);
				//}
			},

			// fnCheckContractDateReport1: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeContract");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			fnCheckContractDateReport1: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeContract");
					var dateString = this.getView().byId("idDateRangeContract").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			// fnCheckActivationDateReport1: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeActivation");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },

			fnCheckActivationDateReport1: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeActivation");
					var dateString = this.getView().byId("idDateRangeActivation").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckHPEDateReport2: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeHPEQuoteIAB");
					var dateString = this.getView().byId("idDateRangeHPEQuoteIAB").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckSolHPEDateReport2: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeHPESolQuIAB");
					var dateString = this.getView().byId("idDateRangeHPESolQuIAB").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckContractDateReport2: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeContractIAB");
					var dateString = this.getView().byId("idDateRangeContractIAB").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckInvoicetDateReport2: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeInvoicingIAB");
					var dateString = this.getView().byId("idDateRangeInvoicingIAB").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckHPEDateReport3: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeHPEQuoteUAR");
					var dateString = this.getView().byId("idDateRangeHPEQuoteUAR").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckSolHPEDateReport3: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeHPESolQuUAR");
					var dateString = this.getView().byId("idDateRangeHPESolQuUAR").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckContractDateReport3: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeContractUAR");
					var dateString = this.getView().byId("idDateRangeContractUAR").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckHPEDateReport5: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeHPEQuoteCCC");
					var dateString = this.getView().byId("idDateRangeHPEQuoteCCC").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckSolHPEDateReport5: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeHPESolQuCCC");
					var dateString = this.getView().byId("idDateRangeHPESolQuCCC").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},

			fnCheckContractDateReport5: function () {
				if (!this.fnGetParamExistsInURI("i_t")) {
					var dateVal = this.getView().byId("idDateRangeContractCCC");
					var dateString = this.getView().byId("idDateRangeContractCCC").mProperties.value;
					this.fnOnchangeDateValForReport(dateVal, dateString);
				}

			},
			// fnCheckHPEDateReport2: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeHPEQuoteIAB");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckSolHPEDateReport2: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeHPESolQuIAB");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckContractDateReport2: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeContractIAB");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckInvoicetDateReport2: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeInvoicingIAB");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckHPEDateReport3: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeHPEQuoteUAR");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//	}

			// },
			// fnCheckSolHPEDateReport3: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeHPESolQuUAR");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckContractDateReport3: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeContractUAR");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//	}

			// },
			/*SOC BADH EAGLE-SOME4028B 2021/11/08*/
			// fnCheckHPEDateReport5: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeHPEQuoteCCC");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckSolHPEDateReport5: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeHPESolQuCCC");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			// fnCheckContractDateReport5: function () {
			// 	//if (!this.fnGetParamExistsInURI("q")) { //ACHOPRADELOI RAMP-1458 2023/10/17
			// 	var dateVal = this.getView().byId("idDateRangeContractCCC");
			// 	var dateValues = /*dateVal*/ DynamicDateUtil.toDates(dateVal.getValue());
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "MM-dd-yyyy"
			// 	});
			// 	var dateString = dateFormat.format(dateValues[0]) + " - ";
			// 	if (dateFormat.format(dateValues[1])) {
			// 		dateString = dateString + dateFormat.format(dateValues[1]);
			// 	} else {
			// 		dateString = dateString + dateFormat.format(sdateRangeVal[0]);
			// 	}
			// 	this.fnOnchangeDateValForReport(dateVal, dateString);
			// 	//}

			// },
			/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

			// to validate the entered date range format for all the reports
			fnOnchangeDateValForReport: function (dateVal, dateString) {

				var regEx = /^(\d{1,2})-(\d{1,2})-(\d{4}) - (\d{1,2})-(\d{1,2})-(\d{4})/g;

				if (dateString.match(regEx) === null) {
					//var oSelectedItem = "";

					dateVal.setValue(null);
					MessageBox.error("Enter date in MM-DD-YYYY - MM-DD-YYYY format");

				} else {
					return dateString;
				}
			},

			// to validate the entered date range format for 4th reports
			fnOnchangeDateValForReport4: function (dateVal, dateString) {

				var regEx = /^((0|1)\d{1})-((0|1|2)\d{1})-((19|20)\d{2}) - ((0|1)\d{1})-((0|1|2)\d{1})-((19|20)\d{2})/g;

				if (dateString.match(regEx) === null) {
					//var oSelectedItem = "";

					dateVal.setValue(null);
					MessageBox.error("Enter date in MM-DD-YYYY - MM-DD-YYYY format");

				} else {
					return dateString;
				}
			},

			/*Value helps for country*/

			//Open Value help Box for Country
			handleValueHelpCountryCS: function (oEvent) {
				this.flagCountry = "CS";

				if (!this._oCountry) {
					this._oCountry = sap.ui.xmlfragment("ui5.PartDash.fragments.ValueHelpCountry", this);
					this.getView().addDependent(this._oCountry);
					// Remember selections if required
					this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
				}

				var region = this.getView().byId("idRegionCS").getSelectedKey();
				this._getCountry(region);

				this._oCountry.open();
			},

			//get Values for country
			_getCountry: function (sRegion) {
				var oModel = this.getView().getModel("viewData");

				oModel.setProperty("/CountrySet", []);

				this.getView().setBusy(true);
				var f = [];
				f.push(new sap.ui.model.Filter("regionID", "EQ", sRegion));
				var oServiceModel = this._getODataModel("SSVModel");

				var sPath = "/Ets_getCountry";

				var mParameters = {
					method: "GET",
					filters: f,
					success: jQuery.proxy(function (oData) {
						this.getView().setBusy(false);
						oModel.setProperty("/CountrySet", oData.results);
					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);
			},

			//for excel copy paste of Country
			onTokenUpdateCountryCS: function (oEvt) {
				var idCountry = this.getView().byId("idCountryCS");
				idCountry.addValidator(this._multiInputValidator);
			},

			//Open Value help Box for Country
			handleValueHelpCountryUAR: function (oEvent) {
				this.flagCountry = "UAR";

				if (!this._oCountry) {
					this._oCountry = sap.ui.xmlfragment("ui5.PartDash.fragments.ValueHelpCountry", this);
					this.getView().addDependent(this._oCountry);
					// Remember selections if required
					this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
				}

				var region = this.getView().byId("idRegionUAR").getSelectedKey();
				this._getCountry(region);

				this._oCountry.open();

			},

			//for excel copy paste of Country
			onTokenUpdateCountryUAR: function (oEvt) {
				var idCountry = this.getView().byId("idCountryUAR");
				idCountry.addValidator(this._multiInputValidator);
			},

			//Open Value help Box for Country
			handleValueHelpCountryIAB: function (oEvent) {
				this.flagCountry = "IAB";

				if (!this._oCountry) {
					this._oCountry = sap.ui.xmlfragment("ui5.PartDash.fragments.ValueHelpCountry", this);
					this.getView().addDependent(this._oCountry);
					// Remember selections if required
					this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
				}

				var region = this.getView().byId("idRegionIAB").getSelectedKey();
				this._getCountry(region);

				this._oCountry.open();

			},

			//for excel copy paste of Country
			onTokenUpdateCountryIAB: function (oEvt) {
				var idCountry = this.getView().byId("idCountryIAB");
				idCountry.addValidator(this._multiInputValidator);
			},

			//Arjun code merge functions
			/*SOC BADH EAGLE-SOME4028B 2021/10/28*/
			handleValueHelpCountryCCC: function (oEvent) {
				this.flagCountry = "CCC";

				if (!this._oCountry) {
					this._oCountry = sap.ui.xmlfragment("ui5.PartDash.fragments.ValueHelpCountry", this);
					this.getView().addDependent(this._oCountry);
					// Remember selections if required
					this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
				}

				var region = this.getView().byId("idRegionCCC").getSelectedKey();
				this._getCountry(region);

				this._oCountry.open();
			},
			/*EOC BADH EAGLE-SOME4028B 2021/10/28*/

			getTierMappingFilter: function (oDataPartnerInfo) {
				try {
					var orFilters = [];
					var Tier = "";
					var Brtypecode = "";
					var tierMappingFilterValue = "";
					var tierMappingFilterArray = oDataPartnerInfo.results[0].userData.results[0].tierMapping.results;
					for (var i = 0; i < tierMappingFilterArray.length; i++) {
						try {
							Tier = tierMappingFilterArray[i].Tier;
							if (Tier === "Tier2") {
								flagTier++;
							}
						} catch (e) {
							Tier = "";
						}
						try {
							Brtypecode = tierMappingFilterArray[i].Brtypecode;
						} catch (e) {
							Brtypecode = "";
						}
						tierMappingFilterValue = Tier + "," + Brtypecode;
						orFilters.push(new sap.ui.model.Filter("tierMapping", sap.ui.model.FilterOperator.EQ, tierMappingFilterValue));
						tierMappingFilterValue = "";
						Brtypecode = "";
						Tier = "";

					}

					if (tierMappingFilterArray.length === 0) {
						orFilters.push(new sap.ui.model.Filter("tierMapping", sap.ui.model.FilterOperator.EQ, ""));

					}

					return orFilters;

				} catch (e) {
					return [];
				}
			},

			getUserDetailsFilter: function (oDataPartnerInfo) {
				try {
					var orFilters = [];
					var Groupid = "";
					var Partyid = "";
					var Visibilitytype = "";
					var Brtype = "";
					var userDetailsFilterValue = "";
					//arjun correction
					var userDetailsFilterArray = oDataPartnerInfo.results[0].userData.results[0].userDetails.results;
					for (var i = 0; i < userDetailsFilterArray.length; i++) {
						// arjun changes
						if (userDetailsFilterArray[i].brTypeSet.results.length === 0) {
							try {
								Groupid = userDetailsFilterArray[i].Groupid;
							} catch (e) {
								Groupid = "";
							}
							try {
								Partyid = userDetailsFilterArray[i].Partyid;
							} catch (e) {
								Partyid = "";
							}
							try {
								Visibilitytype = userDetailsFilterArray[i].Visibilitytype;
							} catch (e) {
								Visibilitytype = "";
							}
							Brtype = "";
							userDetailsFilterValue = Groupid + "," + Partyid + "," + Visibilitytype + "," + Brtype;
							orFilters.push(new sap.ui.model.Filter("userDetails", sap.ui.model.FilterOperator.EQ, userDetailsFilterValue));
							userDetailsFilterValue = "";
							Groupid = "";
							Partyid = "";
							Visibilitytype = "";
							Brtype = "";
							continue;
						}
						for (var j = 0; j < userDetailsFilterArray[i].brTypeSet.results.length; j++) {

							try {
								Groupid = userDetailsFilterArray[i].Groupid;
							} catch (e) {
								Groupid = "";
							}
							try {
								Partyid = userDetailsFilterArray[i].Partyid;
							} catch (e) {
								Partyid = "";
							}
							try {
								Visibilitytype = userDetailsFilterArray[i].Visibilitytype;
							} catch (e) {
								Visibilitytype = "";
							}
							try {
								Brtype = userDetailsFilterArray[i].brTypeSet.results[j].Brtype;
							} catch (e) {
								Brtype = "";
							}

							userDetailsFilterValue = Groupid + "," + Partyid + "," + Visibilitytype + "," + Brtype;
							orFilters.push(new sap.ui.model.Filter("userDetails", sap.ui.model.FilterOperator.EQ, userDetailsFilterValue));
							userDetailsFilterValue = "";
							Groupid = "";
							Partyid = "";
							Visibilitytype = "";
							Brtype = "";

						}
					}

					if (userDetailsFilterArray.length === 0) {
						orFilters.push(new sap.ui.model.Filter("userDetails", sap.ui.model.FilterOperator.EQ, ""));
					}

					return orFilters;

				} catch (e) {
					return [];
				}
			},

			// below function is used to validate the Party ID for 1st report

			// below function is used to validate the Party ID for the 4th report

			fnOnChanPartyDMIRep: function () {
				var oServiceModel = this._getODataModel("SSVModel");
				var sPath = "/Ets_validatePartner";
				this.getView().setBusy(true);
				var partyID = this.getView().byId("idPartyIDDMI").getValue();
				var oFilters = [];
				var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
				oFilters.push(CustID);

				var mParameters = {
					method: "GET",
					filters: oFilters,
					success: jQuery.proxy(function (oData) {
						this.getView().setBusy(false);
						//	MessageBox.success("Filter Pass");

					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);

						var msg = JSON.parse(oError.responseText).error.message.value;
						MessageBox.error(msg);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);

			},

			// below function is used to validate the Party ID for the 2nd report

			fnOnChanPartyIABRep: function () {

				var oServiceModel = this._getODataModel("SSVModel");
				var sPath = "/Ets_validatePartner";
				this.getView().setBusy(true);
				var partyID = this.getView().byId("idPartyIDIAB").getValue();
				var oFilters = [];
				var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
				oFilters.push(CustID);

				var mParameters = {
					method: "GET",
					filters: oFilters,
					success: jQuery.proxy(function (oData) {
						this.getView().setBusy(false);
						//	MessageBox.success("Filter Pass");

					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);

						var msg = JSON.parse(oError.responseText).error.message.value;
						MessageBox.error(msg);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);
			},

			// below function is used to validate the Party ID for the 3rd report

			fnOnChanPartyUARRep: function () {

				var oServiceModel = this._getODataModel("SSVModel");
				var sPath = "/Ets_validatePartner";
				this.getView().setBusy(true);
				var partyID = this.getView().byId("idPartyIDUAR").getValue();
				var oFilters = [];
				var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
				oFilters.push(CustID);

				var mParameters = {
					method: "GET",
					filters: oFilters,
					success: jQuery.proxy(function (oData) {
						this.getView().setBusy(false);
						//	MessageBox.success("Filter Pass");

					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);

						var msg = JSON.parse(oError.responseText).error.message.value;
						MessageBox.error(msg);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);
			},

			// Common function to validate party id for all the report
			fnOnChanPartyCSRep_gg: function () {
				var oServiceModel = this._getODataModel("SSVModel");
				var sPath = "/Ets_validatePartner";
				this.getView().setBusy(true);
				var partyID = this.getView().byId("idPartyID").getValue();
				var oFilters = [];
				var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
				oFilters.push(CustID);

				var mParameters = {
					method: "GET",
					filters: oFilters,
					success: jQuery.proxy(function (oData) {
						this.getView().setBusy(false);
						//	MessageBox.success("Filter Pass");

					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);

						var msg = JSON.parse(oError.responseText).error.message.value;
						MessageBox.error(msg);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);

			},
			/*SOC BADH EAGLE-SOME4028B 2021/11/08*/
			fnOnChanPartyCCCRep: function () {

				var oServiceModel = this._getODataModel("SSVModel");
				var sPath = "/Ets_validatePartner";
				this.getView().setBusy(true);
				var partyID = this.getView().byId("idPartyIDCCC").getValue();
				var oFilters = [];
				var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
				oFilters.push(CustID);

				var mParameters = {
					method: "GET",
					filters: oFilters,
					success: jQuery.proxy(function (oData) {
						this.getView().setBusy(false);
						//	MessageBox.success("Filter Pass");

					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);

						var msg = JSON.parse(oError.responseText).error.message.value;
						MessageBox.error(msg);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);
			},
			/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

			fnValidatePartyId: function (aPatryIDs) {

				var aParyIDVals = aPatryIDs;

				var oModel = this.getView().getModel("viewData");
				var oServiceModel = this._getODataModel("SSVModel");

				var sPath = "/Ets_defaultUrls";

				var mParameters = {
					method: "GET",
					success: jQuery.proxy(function (oData) {

						if (oData !== "") {

							var nPartyData = oData.results;

							var aMatchedPartyVals = nPartyData.filter(function (val) {
								return aParyIDVals.indexOf(val) != -1;
							});

							if (aMatchedPartyVals.length === aParyIDVals.length) {

							} else {

								MessageBox.error("Party Ids are not valid");
							}

						}

					}, this),
					error: jQuery.proxy(function (oError) {
						var k = 0;

					}, this)
				};

				oServiceModel.read(sPath, mParameters);

			},

			// Common function to validate party id for all the report ( in case of punchout)
			fnValidatePartyPunchout: function (aPatryIDs) {

				var aParyIDVals = aPatryIDs;

				var oModel = this.getView().getModel("viewData");
				var oServiceModel = this._getODataModel("SSVModel");

				var sPath = "/Ets_defaultUrls";

				var mParameters = {
					method: "GET",
					success: jQuery.proxy(function (oData) {

						if (oData !== "") {

							var nPartyData = oData.results;

							var aMatchedPartyVals = nPartyData.filter(function (val) {
								return aParyIDVals.indexOf(val) != -1;
							});

							if (aMatchedPartyVals.length === aParyIDVals.length) {

							} else {

								MessageBox.error("Party Ids are not valid");
							}

						}

					}, this),
					error: jQuery.proxy(function (oError) {
						var k = 0;

					}, this)
				};

				oServiceModel.read(sPath, mParameters);

			},

			//Begin jmezadeloitte phoenix 10811
			onChangeRegion: function (oEvent) {
				//this.Region = oEvent.getSource().getValue();
				var CountryMultiInput = this.getView().byId("idCountry");
				if (this._oCountry !== undefined) {
					this._oCountry._resetSelection(); //AVERMA4 Defect 10811 1/4
				}
				CountryMultiInput.removeAllTokens();

			},
			//End jmezadeloitte phoenix 10811
			//BOC AVERMA4 Defect 10555
			validateInput: function (reportType) {
				var raise_error = "";
				if (reportType === "1") {
					var RangeContract = /*this.getView().byId("idDateRangeContract")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContract").getValue())[0];
					var RangeActivation = /*this.getView().byId("idDateRangeActivation")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeActivation").getValue())[0];

					if (RangeContract === null && RangeActivation === null) {
						raise_error = "X";
					}

				} else if (reportType === "2") {
					var HPESolQuIAB = /*this.getView().byId("idDateRangeHPESolQuIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPESolQuIAB").getValue())[0];
					var HPEQuoteIAB = /*this.getView().byId("idDateRangeHPEQuoteIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPEQuoteIAB").getValue())[0];
					var ContractIAB = /*this.getView().byId("idDateRangeContractIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContractIAB").getValue())[0];
					var InvoicingIAB = /*this.getView().byId("idDateRangeInvoicingIAB")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeInvoicingIAB").getValue())[0];

					if (HPESolQuIAB === null && HPEQuoteIAB === null && ContractIAB === null && InvoicingIAB === null) {
						raise_error = "X";
					}

				} else if (reportType === "3") {
					var HPESolQuUAR = /*this.getView().byId("idDateRangeHPESolQuUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPESolQuUAR").getValue())[0];
					var HPEQuoteUAR = /*this.getView().byId("idDateRangeHPEQuoteUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeHPEQuoteUAR").getValue())[0];
					var ContractUAR = /*this.getView().byId("idDateRangeContractUAR")*/ DynamicDateUtil.toDates(this.getView().byId(
						"idDateRangeContractUAR").getValue())[0];

					if (HPESolQuUAR === null && HPEQuoteUAR === null && ContractUAR === null) {
						raise_error = "X";
					}
				} else if (reportType === "4") {
					var scheduleLowDate = this.getView().byId("idDateScheduleStartDateDMI").getDateValue();

					if (scheduleLowDate === null) {
						raise_error = "X";
					}
				}

				if (raise_error === "X") {
					MessageBox.error("Please fill any of the dates to execute the report.");
					return false;
				} else {
					return true;
				}
			},
			//EOC AVERMA4 Defect 10555

			/*SOC BADH EAGLE-2619 2021/11/12*/
			onSalesOrgValueHelpRequested: function (oEvent) {
				var aCols = [{
					"label": this.getResourceBundle().getText("xfld.Main.Subscriptions.SalesOrg"),
					"template": "SalesOrganization"
				}];

				sap.ui.core.Fragment.load({
					name: "ui5.PartDash.fragments.salesOrgValueHelp",
					controller: this
				}).then(function name(oFragment) {
					this._salesOrgVHelpDialog = oFragment;
					this.getView().addDependent(this._salesOrgVHelpDialog);

					this._salesOrgVHelpDialog.getTableAsync().then(function (oTable) {
						oTable.setModel(this.getView().getModel("API_SALESORGANIZATION_SRV"));
						oTable.setModel(new sap.ui.model.json.JSONModel({
							"cols": aCols
						}), "columns");

						if (oTable.bindRows) {
							oTable.bindAggregation("rows", "/A_SalesOrganization");
						}

						if (oTable.bindItems) {
							oTable.bindAggregation("items", "/A_SalesOrganization", function () {
								return new ColumnListItem({
									cells: aCols.map(function (column) {
										return new Label({
											text: "{" + column.template + "}"
										});
									})
								});
							});
						}

						this._salesOrgVHelpDialog.update();
					}.bind(this));

					this._salesOrgVHelpDialog.open();
				}.bind(this));

			},

			onSalesOrgFilterBarSearch: function (oEvent) {
				var aSelectionSet = oEvent.getParameter("selectionSet");
				var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
					if (oControl.getValue()) {
						aResult.push(new sap.ui.model.Filter({
							path: oControl.getName(),
							operator: sap.ui.model.FilterOperator.Contains,
							value1: oControl.getValue()
						}));
					}

					return aResult;
				}, []);

				this._filterSalesOrgTable(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			},

			_filterSalesOrgTable: function (oFilter) {
				var oValueHelpDialog = this._salesOrgVHelpDialog;

				oValueHelpDialog.getTableAsync().then(function (oTable) {
					if (oTable.bindRows) {
						oTable.getBinding("rows").filter(oFilter);
					}

					if (oTable.bindItems) {
						oTable.getBinding("items").filter(oFilter);
					}

					oValueHelpDialog.update();
				});
			},

			onSalesOrgValueHelpOkPress: function (oEvent) {
				var aTokens = oEvent.getParameter("tokens");
				if (aTokens.length > 0) {
					this.getView().byId("idSalesOrg").setValue(aTokens[0].getKey());
				}
				if (this._salesOrgVHelpDialog) {
					this._salesOrgVHelpDialog.close();
				}
			},

			onSalesOrgValueHelpCancelPress: function () {
				if (this._salesOrgVHelpDialog) {
					this._salesOrgVHelpDialog.close();
				}
			},

			onSalesOrgValueHelpAfterClose: function () {
				if (this._salesOrgVHelpDialog) {
					this._salesOrgVHelpDialog.destroy();
				}
			},
			/*EOC BADH EAGLE-2619 2021/11/12*/
			/*SOC BADH EAGLE-2776 2021/11/17*/
			_openCountryVHelpDialog: function () {
				var aCols = [{
					"label": this.getResourceBundle().getText("xfld.VHelp.Subscriptions.CountryID"),
					"template": "countryID"
				}, {
					"label": this.getResourceBundle().getText("xfld.VHelp.Subscriptions.CountryName"),
					"template": "countryName"
				}, {
					"label": this.getResourceBundle().getText("xfld.VHelp.Subscriptions.RegionID"),
					"template": "regionID"
				}];

				sap.ui.core.Fragment.load({
					name: "ui5.PartDash.fragments.countryValueHelp",
					controller: this
				}).then(function name(oFragment) {
					this._countryVHelpDialog = oFragment;
					this.getView().addDependent(this._countryVHelpDialog);

					this._countryVHelpDialog.getTableAsync().then(function (oTable) {
						oTable.setModel(this.getView().getModel("viewData"));
						oTable.setModel(new sap.ui.model.json.JSONModel({
							"cols": aCols
						}), "columns");

						if (oTable.bindRows) {
							oTable.bindAggregation("rows", "/CountrySet");
						}

						if (oTable.bindItems) {
							oTable.bindAggregation("items", "/CountrySet", function () {
								return new ColumnListItem({
									cells: aCols.map(function (column) {
										return new Label({
											text: "{" + column.template + "}"
										});
									})
								});
							});
						}

						this._countryVHelpDialog.update();
					}.bind(this));

					var __aTokens = [],
						_oView = this.getView(),
						__aSelTokens = [];
					if (this.flagCountry === "S") {
						__aTokens = _oView.byId("idCountry").getTokens();
					} else if (this.flagCountry === "CS") {
						__aTokens = _oView.byId("idCountryCS").getTokens();
					} else if (this.flagCountry === "UAR") {
						__aTokens = _oView.byId("idCountryUAR").getTokens();
					} else if (this.flagCountry === "IAB") {
						__aTokens = _oView.byId("idCountryIAB").getTokens();
					} else if (this.flagCountry === "CCC") {
						__aTokens = _oView.byId("idCountryCCC").getTokens();
					}

					__aTokens.forEach(function (oToken) {
						var t = new sap.m.Token({
							key: oToken.getKey(),
							text: oToken.getText() + " (" + oToken.getKey() + ")"
						});
						oToken.getCustomData().forEach(function (cData) {
							t.addCustomData(new sap.ui.core.CustomData({
								key: cData.getKey(),
								value: cData.getValue()
							}));
						});
						__aSelTokens.push(t);
					});

					this._countryVHelpDialog.setTokens(__aSelTokens);
					this._countryVHelpDialog.open();
				}.bind(this));
			},

			onCountryFilterBarSearch: function (oEvent) {
				var aSelectionSet = oEvent.getParameter("selectionSet");
				var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
					if (oControl.getMetadata().getElementName() === "sap.m.ComboBox") {
						if (oControl.getSelectedKey()) {
							aResult.push(new sap.ui.model.Filter({
								path: oControl.getName(),
								operator: sap.ui.model.FilterOperator.EQ,
								value1: oControl.getSelectedKey()
							}));
						}
					} else if (oControl.getValue()) {
						aResult.push(new sap.ui.model.Filter({
							path: oControl.getName(),
							operator: sap.ui.model.FilterOperator.EQ,
							value1: oControl.getValue()
						}));
					}

					return aResult;
				}, []);

				this._filterCountryTable(new sap.ui.model.Filter({
					filters: aFilters,
					and: true
				}));
			},

			_filterCountryTable: function (oFilter) {
				var oValueHelpDialog = this._countryVHelpDialog;

				oValueHelpDialog.getTableAsync().then(function (oTable) {
					if (oTable.bindRows) {
						oTable.getBinding("rows").filter(oFilter);
					}

					if (oTable.bindItems) {
						oTable.getBinding("items").filter(oFilter);
					}

					oValueHelpDialog.update();
				});
			},

			onCountryValueHelpOkPress: function (oEvent) {
				var aTokens = oEvent.getParameter("tokens");
				if (aTokens.length > 0) {
					var aSelectedTokens = [],
						_oView = this.getView();
					aTokens.forEach(function (oToken) {
						var t = new sap.m.Token({
							key: oToken.getKey(),
							text: oToken.data("row").countryName
						});
						oToken.getCustomData().forEach(function (cData) {
							t.addCustomData(new sap.ui.core.CustomData({
								key: cData.getKey(),
								value: cData.getValue()
							}));
						});
						aSelectedTokens.push(t);
					});

					if (this.flagCountry === "S") {
						_oView.byId("idCountry").setTokens(aSelectedTokens);
					} else if (this.flagCountry === "CS") {
						_oView.byId("idCountryCS").setTokens(aSelectedTokens);
					} else if (this.flagCountry === "UAR") {
						_oView.byId("idCountryUAR").setTokens(aSelectedTokens);
					} else if (this.flagCountry === "IAB") {
						_oView.byId("idCountryIAB").setTokens(aSelectedTokens);
					}
					//SOC BADH EAGLE-SOME4028B 2021/01/28
					else if (this.flagCountry === "CCC") {
						_oView.byId("idCountryCCC").setTokens(aSelectedTokens);
					}
					//EOC BADH EAGLE-SOME4028B 2021/01/28
					if (aTokens && aTokens.length) {
						MessageToast.show("You have chosen " + aTokens.map(function (oContext) {
							return oContext.data("row").countryName;
						}).join(", "));
					}

					this._filterCountryTable([]);
				} else {
					if (this.flagCountry === "S") {
						_oView.byId("idCountry").removeAllTokens();
					} else if (this.flagCountry === "CS") {
						_oView.byId("idCountryCS").removeAllTokens();
					} else if (this.flagCountry === "UAR") {
						_oView.byId("idCountryUAR").removeAllTokens();
					} else if (this.flagCountry === "IAB") {
						_oView.byId("idCountryIAB").removeAllTokens();
					}
					//SOC BADH EAGLE-SOME4028B 2021/01/28
					else if (this.flagCountry === "CCC") {
						this.getView().byId("idCountryCCC").removeAllTokens();
					}
				}

				if (this._countryVHelpDialog) {
					this._countryVHelpDialog.close();
				}
			},

			onCountryValueHelpCancelPress: function () {
				if (this._countryVHelpDialog) {
					this._countryVHelpDialog.close();
				}
			},

			onCountryValueHelpAfterClose: function () {
				if (this._countryVHelpDialog) {
					this._countryVHelpDialog.destroy();
				}
			},
			/*EOC BADH EAGLE-2776 2021/11/17*/

			onSelectIconTabBar1: function (oEvt) {
				if (oEvt.getSource().getSelectedKey() === "Reports") {
					var reportType = this.getView().byId("idReportIconTabBar").setSelectedKey("1");
					this.onReportChange();
				}
			},
			//Open Value help Box for Country
			handleValueHelpCountry: function (oEvent) {
				this.flagCountry = "S";

				if (!this._oCountry) {
					this._oCountry = sap.ui.xmlfragment("ui5.PartDash.fragments.ValueHelpCountry", this);
					this.getView().addDependent(this._oCountry);
					// Remember selections if required
					this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
				}
				var region = this.getView().byId("idRegion").getSelectedKey();
				this._getCountry(region);
				this._oCountry.open();

			},

			//handle the search with the Value help of Country
			handleCountrySearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oBinding = oEvent.getSource().getBinding("items");
				oBinding.filter([new sap.ui.model.Filter([
					new sap.ui.model.Filter("countryID", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("countryName", sap.ui.model.FilterOperator.Contains, sValue)
				], false)]);
			},

			//close value help dialog box after selection
			handleCountryConfirm: function (oEvent) {
				var oModel = this.getModel("viewData");
				//	var region = oModel.setProperty("/EngineeringRecord", []);
				var aContexts = oEvent.getParameter("selectedContexts");
				var selection = aContexts.map(function (oContext) {
					return oContext.getObject().countryID;
				}).join(", ");

				var tokenselection = aContexts.map(function (oContext) {
					return {
						key: oContext.getObject().countryID,
						text: oContext.getObject().countryName
					};

				});
				var aTokens = [];
				tokenselection.forEach(function (data) {
					var t = new sap.m.Token(data);
					aTokens.push(t);
				});

				if (this.flagCountry === "S") {
					this.getView().byId("idCountry").setTokens(aTokens);
				} else if (this.flagCountry === "CS") {
					this.getView().byId("idCountryCS").setTokens(aTokens);
				} else if (this.flagCountry === "UAR") {
					this.getView().byId("idCountryUAR").setTokens(aTokens);
				} else if (this.flagCountry === "IAB") {
					this.getView().byId("idCountryIAB").setTokens(aTokens);
				}
				/*SOC BADH EAGLE-SOME4028B 2021/01/28*/
				else if (this.flagCountry === "CCC") {
					this.getView().byId("idCountryCCC").setTokens(aTokens);
				}
				/*EOC BADH EAGLE-SOME4028B 2021/01/28*/
				if (aContexts && aContexts.length) {
					MessageToast.show("You have chosen " + aContexts.map(function (oContext) {
						return oContext.getObject().countryName;
					}).join(", "));
				}

				oEvent.getSource().getBinding("items").filter([]);
			},

			//close value help dialog box
			handleClose: function (oEvent) {
				oEvent.getSource().getBinding("items").filter([]);

			},

		});

	});