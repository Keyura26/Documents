sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/core/UIComponent",
	"ui5/PartDash/utils/formatter",
	"sap/ui/core/Fragment",
	"ui5/PartDash/controller/BaseController",
	"sap/ui/model/Sorter"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, JSONModel, Filter, UIComponent, formatter, Fragment, BaseController, Sorter) {
		"use strict";
		var __controller__,
			bindedData,
			daysCol;

		return BaseController.extend("ui5.PartDash.controller.TableDetail", {
			_formatter: formatter,
			onInit: function () {
				__controller__ = this;
				var oRouter = this.getRouter();
				oRouter.getRoute("Activesubs").attachPatternMatched(this._onObjectMatchedActive, this);
				let ProductDesc = this.byId("idProductDesc");
				let ProductDescTbl = this.byId("idProductsTable");
				
			},
		    
			_onObjectMatchedActive: function (oEvent) {
				this.getView().byId("idFilterListSearchField").setValue("");
				this.getView().byId("idFilterListSearchFieldPhone").setValue("");
				let ProductDescTbl = this.byId("idProductsTable");
				daysCol = ProductDescTbl.getColumns().find((item) => {
					if (item.mAggregations.header.mProperties.text === "Days To Expire" && item.getVisible()) {
						return item;
					}
				});
				var that = this;
				let oArgs = oEvent.getParameter("arguments");
				var subType = oArgs.subType;
				var serializedFilterParams = oArgs.filterParams;
				var filterParams = JSON.parse(serializedFilterParams);
				let visibilityModel = new JSONModel({
					"subType": subType,
					"filterParams": filterParams
				});
				this.getView().setModel(visibilityModel, "visibilityModel");
				var oView = this.getView();
				this.getOwnerComponent()._deferredPersonaDataLoaded.done(function (PersonaData) {
					that.loadSubsList(subType, filterParams);
				})
				// this.loadSubsList(subType, filterParams);
			},

			loadSubsList: function (subType, filterParams) {
				var that = this;
				// if (!sap.ui.getCore().getModel('personaEmailModel')) {
				// 	this.getRouter().navTo("Home");
				// } else {
				//let soldTO = sap.ui.getCore().getModel('personaModel').getData().customerId;
				let soldTO = sap.ui.getCore().getModel('personaEmailModel').getProperty("/aSoldto").map(item => item.Soldto);
				// let soldTOTrails = "8999299909";
				// this.getView().byId("subsTable").setBusy(true);
				// this.getView().byId("subsTable").setBusyIndicatorDelay(0);
				this.getView().byId("idProductsTable").setBusy(true);
				this.getView().byId("idProductsTable").setBusyIndicatorDelay(0);
				let partnerFilter = [];
				let path = "";
				if (subType == "Active") {
					this.getView().byId("idListPageTitle").setText("My Active Subscriptions");
					this.getView().byId("idListPageTitlePhone").setText("My Active Subscriptions");
					path = "/Ety_Subscriptions_CloudSet";
					if (Array.isArray(soldTO) && soldTO.length > 1) {
						// Create multiple filters for soldToParty and combine them using OR 
						var multiFilter = new sap.ui.model.Filter(soldTO.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
						// false = OR condition 
						partnerFilter.push(multiFilter);
					}
					else if (soldTO.length === 1) {
						// Single value case 
						partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO[0]));
					}
					// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO));
					partnerFilter.push(new sap.ui.model.Filter("Category2", "EQ", filterParams.level1_desc));
					if (filterParams.hasOwnProperty("prodCategoryId")) {
						partnerFilter.push(new sap.ui.model.Filter("productCategory", "EQ", filterParams.prodCategoryId));
					}
					if (filterParams.hasOwnProperty("rtmId")) {
						partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", filterParams.rtmId));
					}
					if (filterParams.hasOwnProperty("dateId")) {
						partnerFilter.push(new sap.ui.model.Filter("dateId ", "EQ", filterParams.dateId));
					}
					if (filterParams.hasOwnProperty("startdateId") && filterParams.hasOwnProperty("enddateId")) {
						partnerFilter.push(new sap.ui.model.Filter({
							filters: [new sap.ui.model.Filter("dateRange", "GE", filterParams.startdateId),
							new sap.ui.model.Filter("dateRange", "LE", filterParams.enddateId)
							],
							and: true

						}));
					}
				} else if (subType == "Upcoming") {
					this.getView().byId("idListPageTitle").setText("Upcoming Renewals");
					this.getView().byId("idListPageTitlePhone").setText("Upcoming Renewals");
					path = "/Ets_SubscriptionRenewalsLst";
					if (Array.isArray(soldTO) && soldTO.length > 1) {
						// Create multiple filters for soldToParty and combine them using OR 
						var multiFilter = new sap.ui.model.Filter(soldTO.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
						// false = OR condition 
						partnerFilter.push(multiFilter);
					}
					else if (soldTO.length === 1) {
						// Single value case 
						partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO[0]));
					}
					// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO));
					partnerFilter.push(new sap.ui.model.Filter("daysToExpire", "EQ", filterParams.upRenewalsfilterId));
					if (filterParams.hasOwnProperty("prodCategoryId")) {
						partnerFilter.push(new sap.ui.model.Filter("productCategory", "EQ", filterParams.prodCategoryId));
					}
					if (filterParams.hasOwnProperty("rtmId")) {
						partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", filterParams.rtmId));
					}
					if (filterParams.hasOwnProperty("dateId")) {
						partnerFilter.push(new sap.ui.model.Filter("dateId ", "EQ", filterParams.dateId));
					}
					if (filterParams.hasOwnProperty("startdateId") && filterParams.hasOwnProperty("enddateId")) {
						partnerFilter.push(new sap.ui.model.Filter({
							filters: [new sap.ui.model.Filter("dateRange", "GE", filterParams.startdateId),
							new sap.ui.model.Filter("dateRange", "LE", filterParams.enddateId)
							],
							and: true

						}));
					}
				} else if (subType == "Trial") {
					this.getView().byId("idListPageTitle").setText("My Trials/Evals");
					this.getView().byId("idListPageTitlePhone").setText("My Trials/Evals");
					path = "/Ets_SubscriptionTrialEvalLst";
					if (Array.isArray(soldTO) && soldTO.length > 1) {
						// Create multiple filters for soldToParty and combine them using OR 
						var multiFilter = new sap.ui.model.Filter(soldTO.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
						// false = OR condition 
						partnerFilter.push(multiFilter);
					}
					else if (soldTO.length === 1) {
						// Single value case 
						partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO[0]));
					}
					// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO));
					partnerFilter.push(new sap.ui.model.Filter("type", "EQ", 'ZQTR'));
					partnerFilter.push(new sap.ui.model.Filter("Category2", "EQ", filterParams.trailsFilterId));
					if (filterParams.hasOwnProperty("prodCategoryId")) {
						partnerFilter.push(new sap.ui.model.Filter("productCategory", "EQ", filterParams.prodCategoryId));
					}
					if (filterParams.hasOwnProperty("rtmId")) {
						partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", filterParams.rtmId));
					}
					if (filterParams.hasOwnProperty("dateId")) {
						partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", filterParams.dateId));
					}
					if (filterParams.hasOwnProperty("startdateId") && filterParams.hasOwnProperty("enddateId")) {
						partnerFilter.push(new sap.ui.model.Filter({
							filters: [new sap.ui.model.Filter("date", "GE", filterParams.startdateId),
							new sap.ui.model.Filter("date", "LE", filterParams.enddateId)
							],
							and: true

						}));
					}
				} else if (subType == "Expired") {
					this.getView().byId("idListPageTitle").setText("Expired Subscription ( last 30 days )");
					this.getView().byId("idListPageTitlePhone").setText("Expired Subscription ( last 30 days )");
					path = "/Ets_SubscriptionExpiredLst";
					if (Array.isArray(soldTO) && soldTO.length > 1) {
						// Create multiple filters for soldToParty and combine them using OR 
						var multiFilter = new sap.ui.model.Filter(soldTO.map(id => new sap.ui.model.Filter("soldToParty", "EQ", id)), false);
						// false = OR condition 
						partnerFilter.push(multiFilter);
					}
					else if (soldTO.length === 1) {
						// Single value case 
						partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO[0]));
					}
					// partnerFilter.push(new sap.ui.model.Filter("soldToParty", "EQ", soldTO));
					partnerFilter.push(new sap.ui.model.Filter("daysExpired", "EQ", '30'));
					partnerFilter.push(new sap.ui.model.Filter("Category2", "EQ", filterParams.expiredFilterId));
					if (filterParams.hasOwnProperty("prodCategoryId")) {
						partnerFilter.push(new sap.ui.model.Filter("productCategory", "EQ", filterParams.prodCategoryId));
					}
					if (filterParams.hasOwnProperty("rtmId")) {
						partnerFilter.push(new sap.ui.model.Filter("rtm", "EQ", filterParams.rtmId));
					}
					if (filterParams.hasOwnProperty("dateId")) {
						partnerFilter.push(new sap.ui.model.Filter("dateId", "EQ", filterParams.dateId));
					}
					if (filterParams.hasOwnProperty("startdateId") && filterParams.hasOwnProperty("enddateId")) {
						partnerFilter.push(new sap.ui.model.Filter({
							filters: [new sap.ui.model.Filter("date", "GE", filterParams.startdateId),
							new sap.ui.model.Filter("date", "LE", filterParams.enddateId)
							],
							and: true

						}));
					}
				}

				let oModel = this.getOwnerComponent().getModel("Z_SUBSTATUS_CLOUDSTC");
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				oModel.read(path, {
					method: "GET",
					filters: partnerFilter,
					urlParameters: {
						"$format": "json"
					},
					success: function (d) {
						try {
							for (let x in d.results) {
								d.results[x].providerContract = d.results[x].providerContract.replace(/\s/g, "");;
							}
							var ActiveSubModel = new JSONModel();
							ActiveSubModel.setData(d.results);
							this.getView().setModel(ActiveSubModel, 'ActiveSubModel');
							// this.getView().byId("subsTable").setBusy(false);
							this.getView().byId("idProductsTable").setBusy(false);
							if (!this._oResponsivePopover) {
								this._oResponsivePopover = sap.ui.xmlfragment("ui5.PartDash.fragments.filterPopover", this);
								this._oResponsivePopover.setModel(this.getView().getModel("ActiveSubModel"));
							}
							var oTable = this.getView().byId("idProductsTable");
							// if (!this._oResponsivePopover) {
							// 	Fragment.load({
							// 		id: oView.getId(),
							// 		name: "ui5.PartDash.fragments.filterPopover",
							// 		controller: this
							// 	}).then(function (oPopover) {
							// 		this._oResponsivePopover = oPopover;
							// 		// this._oResponsivePopover.openBy(oTarget);
							// 	}.bind(this));
							// } else {
							// 	this._oResponsivePopover.openBy(oTarget);
							// }
							oTable.addEventDelegate({
								onAfterRendering: function () {
									var oHeader = this.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
									for (var i = 0; i < oHeader.length; i++) {
										var oID = oHeader[i].id;
										that.onClick(oID);
									}
								}
							}, oTable);
						} catch (e) { }
					}.bind(this),
					error: function (err) {
						var errorJson = JSON.parse(err.responseText);
						var msgs = errorJson.error.innererror.errordetails;
						sap.m.MessageBox.show(
							msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					}.bind(this)
				});
				// }

			},
			// For custom sorting of number of days in table
			onClick: function (oID) {
				var that = this;
				$('#' + oID).click(function (oEvent) { //Attach Table Header Element Event
					var oTarget = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
					var oIndex = oTarget.id.slice(-1); //Get the column Index
					var oView = that.getView();
					var oTable = oView.byId("idProductsTable");
					var oModel = oTable.getModel("ActiveSubModel").getProperty("/"); //Get Hold of Table Model Values
					var oKeys = Object.keys(oModel[0]); //Get Hold of Model Keys to filter the value
					oView.getModel("ActiveSubModel").setProperty("/bindingValue", oKeys[40]); //Save the key value to property
					if (oLabelText === "Days To Expire") {
						that._oResponsivePopover.openBy(oTarget);
					}
				});
			},
			//for custom sorting of number of days in table
			onAscending: function (oEvent) {
				var oTable = this.getView().byId("idProductsTable");

				daysCol = oTable.getColumns().find((item) => {
					if (item.mAggregations.header.mProperties.text === "Days To Expire" && item.getVisible()) {
						return item;
					}
				});
				daysCol.setSortIndicator("Ascending");
			
				var oItems = oTable.getBinding("items");
				var oBindingPath = this.getView().getModel("ActiveSubModel").getProperty("/bindingValue");
				var oSorter = new Sorter(oBindingPath);
				oItems.sort(oSorter);
				this._oResponsivePopover.close();
			},
			
			//for custom sorting of number of days in table
			onDescending: function (oEvent) {
				var oTable = this.getView().byId("idProductsTable");
				// var column = oTable.getColumns()[0].mAggregations;
				// var colname = column.header.mProperties.text;
				// if (colname === "Days To Expire") {
				// 	column.setSortIndicator("Descending");
				// }
				daysCol.setSortIndicator("Descending");
				var oItems = oTable.getBinding("items");
				var oBindingPath = this.getView().getModel("ActiveSubModel").getProperty("/bindingValue");
				var oSorter = new Sorter(oBindingPath, true);
				oItems.sort(oSorter);
				this._oResponsivePopover.close();
			},
			getRouter: function () {
				return UIComponent.getRouterFor(this);
			},

			onPressTrack: function (oEvent) {
				// let providerContract = oEvent.getSource().getParent().getParent().getParent().mAggregations.content[0].mAggregations.items[0].mAggregations.items[1].mAggregations.items[1].mProperties.text.replace(/\s/g, "");
				bindedData = oEvent.getSource().getParent().getParent().getBindingContext("ActiveSubModel").getObject();
				// getParent()
				// this.contractNo = bindedData.providerContract;               
				let quickViewModel = new JSONModel();
				quickViewModel.setData(bindedData);
				this.getView().setModel(quickViewModel, "quickViewModel");
				var oView = this.getView();
				var oButton = oEvent.getSource();

				// create popover
				if (!this._pPopover) {
					this._pPopover = Fragment.load({
						id: oView.getId(),
						name: "ui5.PartDash.fragments.quickView",
						controller: this
					}).then(function (oPopover) {
						oView.addDependent(oPopover);
						oPopover.attachAfterOpen(this.onPopOverAfterOpen, this);
						return oPopover;
					}.bind(this));
				}
				this._pPopover.then(function (oPopover) {
					oPopover.openBy(oButton);
				});

				
			},
			// SOC for color coding of Quick View Pop up
			onPopOverAfterOpen: function () {
				var objectStatusId = this.getView().byId("objProStatus");
				objectStatusId.removeStyleClass("greenDot");
				objectStatusId.removeStyleClass("redDot");
				objectStatusId.removeStyleClass("greyDot");
				if (bindedData.contractStatus !== "" || bindedData.contractStatus !== null || bindedData.contractStatus !== undefined
					|| bindedData.status !== "" || bindedData.status !== null || bindedData.status !== undefined
				) {
					if (bindedData.contractStatus === "Active" || bindedData.status === "Active") {
						objectStatusId.setState("Success");
						objectStatusId.addStyleClass("greenDot");
					} else if (bindedData.contractStatus === "Suspended" || bindedData.status === "Suspended") {
						objectStatusId.setState("Error");
						objectStatusId.addStyleClass("redDot");
					} else {
						objectStatusId.setState("Indication10");
						objectStatusId.addStyleClass("greyDot");
					}
				}
				// this._oWizard = this.byId("CreateProductWizard");
				// this._iSelectedStepIndex = 0;
				// this._oSelectedStep = this._oWizard.getSteps()[this._iSelectedStepIndex];
				// // write a function to set wizard current step once you add quotation API
				// this._oWizard.setCurrentStep(this._oWizard.getSteps()[2]);
			},
		   	// EOC for color coding of Quick View Pop up
 
			//SOC table search on apply of filters
			onTableSearch: function (e) {
				let value = e.getSource().getValue();
				let deviceModel = this.getView().getModel("device").getProperty("/SystemData").phone;
				// deviceModel = 
				var selectedKey;
				if (!deviceModel) {
					selectedKey = this.getView().byId("idFilterListSelect").getSelectedKey();
				} else {
					selectedKey = this.getView().byId("idFilterListSelectPhone").getSelectedKey();
				}
				var aFilters = [];
				if (value && selectedKey == "3") {
					aFilters.push(new Filter("quote", sap.ui.model.FilterOperator.EQ, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "2") {
					aFilters.push(new Filter("providerContract", sap.ui.model.FilterOperator.EQ, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "7") {
					aFilters.push(new Filter("endCustomerFullname", sap.ui.model.FilterOperator.Contains, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "4") {
					aFilters.push(new Filter("orderNumber", sap.ui.model.FilterOperator.Contains, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "5") {
					aFilters.push(new Filter("partNumber", sap.ui.model.FilterOperator.Contains, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "6") {
					aFilters.push(new Filter("poNumber", sap.ui.model.FilterOperator.Contains, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "11") {
					aFilters.push(new Filter("licenseKey", sap.ui.model.FilterOperator.Contains, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else if (value && selectedKey == "12") {
					aFilters.push(new Filter("billingModel", sap.ui.model.FilterOperator.Contains, value));
					// var binding = this.getView().byId("subsTable").getBinding("items");
					var bindingTable = this.getView().byId("idProductsTable").getBinding("items");
					// binding.filter(aFilters);
					bindingTable.filter(aFilters);
				} else {
					// this.getView().byId("subsTable").getBinding("items").filter([]);
					this.getView().byId("idProductsTable").getBinding("items").filter([]);
				}
			},
			//EOC table search on apply of filters
           
			// SOC Navigate to SubItemDetailView
			fnNavSubItemDetail: function (oEvent) {
				let bindedData = oEvent.getSource().getBindingContext("ActiveSubModel").getObject();
				let sContractNo = bindedData.providerContract;
				this.getRouter().navTo("SubItemDetail", {
					Contract: sContractNo
				});
			}
			// EOC Navigate to SubItemDetailView
		});
	});