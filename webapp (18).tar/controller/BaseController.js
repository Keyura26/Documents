sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/base/util/UriParameters",
	"ui5/PartDash/Libs/zBusyLoaderUtils",
	"ui5/PartDash/Libs/ExtBusyDialog"
], function (Controller, UriParameters, BusyLoaderUtils, BusyDialog) {
	"use strict";

	var oUriParameters = new UriParameters(window.location.href); //ACHOPRADELOI RAMP-1458 2023/10/17

	return Controller.extend("ui5.PartDash.controller.BaseController", {

		onInit: function () {

		},

		//get the router
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		// callTargetMethod: function(){
		// 	var oTargetController = this.getView().byId("View1").getController();
		// }
		// Get the serivce model
		getODataModel: function () {

			return this.getOwnerComponent().getModel();
		},

		//resource bundle for i18n in controller
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getModel: function (sName) {
			if (sName) {
				return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
			} else {
				return this.getView().getModel() || this.getOwnerComponent().getModel();
			}
		},

		// __openBusyDialog: function () { //Global Method to  Open Busy Dialog
		// 	if (!this.__oBusyDialog) {
		// 		var _oBusyDialog = new sap.m.BusyDialog();
		// 		_oBusyDialog.removeAllCustomData();
		// 		_oBusyDialog.addCustomData(new sap.ui.core.CustomData({
		// 			"key": "bOpened",
		// 			"value": false
		// 		}));
		// 		this.__oBusyDialog = _oBusyDialog;
		// 		jQuery.sap.delayedCall(0, this, function () {
		// 			this.__oBusyDialog.open();
		// 		});

		// 	} else {
		// 		if (this.__oBusyDialog.data("bOpened") !== undefined && this.__oBusyDialog.data("bOpened") !== true) {
		// 			this.__oBusyDialog.removeAllCustomData();
		// 			this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
		// 				"key": "bOpened",
		// 				"value": true
		// 			}));
		// 			jQuery.sap.delayedCall(0, this, function () {
		// 				this.__oBusyDialog.open();
		// 			});
		// 		}
		// 	}
		// },

		// __closeBusyDialog: function () { //Global Method to Close Busy Dialog
		// 	if (this.__oBusyDialog) {
		// 		this.__oBusyDialog.removeAllCustomData();
		// 		this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
		// 			"key": "bOpened",
		// 			"value": false
		// 		}));
		// 		this.__oBusyDialog.close();
		// 	}
		// },

		__openBusyDialog: function (__sBusyOpenedBy) {
			if (!this.__oBusyDialog) {
				var _oBusyDialog = new BusyDialog();
				this.__oBusyDialog = _oBusyDialog;
				window.setTimeout(function () {
					this.__oBusyDialog.openBusyDialog(__sBusyOpenedBy);
				}.bind(this), 0);
			} else {
				window.setTimeout(function () {
					this.__oBusyDialog.openBusyDialog(__sBusyOpenedBy);
				}.bind(this), 0);
			}
		},

		__closeBusyDialog: function (bForceClose) {
			if (this.__oBusyDialog) {
				this.__oBusyDialog.closeBusyDialog(bForceClose);
			}
		},

		getBusyDialogOpened: function () {
			if (this.__oBusyDialog) {
				return this.__oBusyDialog.getIsOpen();
			} else {
				return false;
			}
		},
		__readODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !BusyLoaderUtils.getBusyDialogOpened()) {
							window.setTimeout(function () {
								_options.oControl.setBusyIndicatorDelay(0);
								_options.oControl.setBusy(true);
							}.bind(this), 0);
						}
					}
					if (_options.oControlM) {
						if (!_options.oControlM.getBusy() && !BusyLoaderUtils.getBusyDialogOpened()) {
							window.setTimeout(function () {
								_options.oControlM.setBusyIndicatorDelay(0);
								_options.oControlM.setBusy(true);
							}.bind(this), 0);
						}
					}
				} else {
					BusyLoaderUtils.__openBusyDialog(_options.sPath);
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add Filter Parameters
				if (_options.oFilters) {
					_oParameters["filters"] = _options.oFilters;
				}

				/*SOC BADH PERFORMANCE FIXES 2022/09/07*/
				if (_options.oSorters) {
					_oParameters["sorters"] = _options.oSorters;
				}
				/*EOC BADH PERFORMANCE FIXES 2022/09/07*/

				if (_oModel.aUrlParams.length > 0) {
					_oModel.aUrlParams = [];
				}
				if (_options.aUrlParams) {
					_oModel.aUrlParams = _options.aUrlParams;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
						if (_options.oControlM) {
							_options.oControlM.setBusy(false);
						}
					} else {
						BusyLoaderUtils.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
						if (_options.oControlM) {
							_options.oControlM.setBusy(false);
						}
					} else {
						BusyLoaderUtils.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.read(_options.sPath, _oParameters);

			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					BusyLoaderUtils.__closeBusyDialog(_options.sPath);
				}
				if (_options.oControlM && __bGlobalBusy === false) {
					_options.oControlM.setBusy(false);
				} else if (__bGlobalBusy === true) {
					BusyLoaderUtils.__closeBusyDialog(_options.sPath);
				}
			}
		},


		__updateODataOperation: function (_options) {
			try {
				this.__openBusyDialog();
				var _oModel = _options.oModel,
					_oParameters = {};

				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//Add Merge flag
				if (_options.bMerge) {
					_oParameters["merge"] = _options.bMerge;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					this.__closeBusyDialog();
					_options.fnSuccess(oData, oResponse);
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					this.__closeBusyDialog();
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.update(_options.sPath, _oParameters);
				});
			} catch (err) {
				this.__closeBusyDialog();
			}
		},

		__createODataOperation: function (_options) {
			try {
				this.__openBusyDialog();
				var _oModel = _options.oModel,
					_oParameters = {};

				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					this.__closeBusyDialog();
					_options.fnSuccess(oData, oResponse);
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					this.__closeBusyDialog();
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.create(_options.sPath, _options.oRequestBody, _oParameters);
				});
			} catch (err) {
				this.__closeBusyDialog();
			}
		},

		//SOC ACHOPRADELOI RAMP-1458 2023/10/17
		fnGetParamExistsInURI: function (param) {
			var __bOpptyExistsInURI = false;
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getOwnerComponent().getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null && __oURIParam.get(param) !== "") {
					__bOpptyExistsInURI = true;
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null && __aStartUpParameter[param] !== "") {
							__bOpptyExistsInURI = true;
						}
					}
				}
			} catch (err) {

			}
			return __bOpptyExistsInURI;
		},

		fnGetParamIdFrmURI: function (param) {
			var __sOpptyId;
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getOwnerComponent().getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null) {
					__sOpptyId = __oURIParam.get(param);
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null) {
							__sOpptyId = decodeURIComponent(__aStartUpParameter[param][0]);
						}
					}
				}
			} catch (err) {

			}
			return __sOpptyId;
		},

		fnGetDecryptedParamID: function (param) {
			return atob(param);
		},

		fnGetParamValueFromQuery: function (param) {
			var rtValue = "";
			if (this.fnGetParamExistsInURI("q")) {
				var encQuery = this.fnGetParamIdFrmURI("q"),
					query = this.fnGetDecryptedParamID(encQuery),
					qArr = query.split(",");
				switch (param) {
					case "brimSolutionQuote":
						rtValue = qArr[0];
						break;

					case "orderNumber":
						rtValue = qArr[1];
						break;
				}
			}

			return rtValue;
		},

		fnSetUrlDataInMdl: function () {
			var oModel = this.getView().getModel("viewData"),
				brimSolutionQuote = this.fnGetParamValueFromQuery("brimSolutionQuote"),
				orderNumber = this.fnGetParamValueFromQuery("orderNumber"),
				emailId = oModel.getProperty("/EmailId"),
				userData = oModel.getProperty("/userData"),
				data = {
					"results": [{
						"asqpunchouturl": "",
						"brimSolutionQuote": brimSolutionQuote,
						"emailId": emailId,
						"orderNumber": orderNumber,
						"osvdefaulturl": "",
						"osvorderurl": "",
						"sfdccaseurl": "",
						"userData": userData
					}]
				};

			oModel.setProperty("/PunchOutData_Full", data);
			oModel.setProperty("/PunchOutData_Details", data.results[0]);
			if (userData && userData.results.length > 0) {
				oModel.setProperty("/PunchOutData", userData.results[0]);
			}
		},

		//get oData model
		_getODataModel: function (mModel) {
			return this.getOwnerComponent().getModel(mModel);
		},

		fnGetUserInfo: function (odefObj) {

			var oModel = this.getView().getModel("viewData"),
				oServiceModel = this._getODataModel(),
				sPath = "/Ets_GetEmail",
				userFilter = [];
			if (this.fnGetParamExistsInURI("imp")) {
				var impValue = this.fnGetParamIdFrmURI("imp"),
					decryptedImpValue = this.fnGetDecryptedParamID(impValue);
				userFilter.push(new sap.ui.model.Filter("Email", "EQ", decryptedImpValue));
			}
			var mParameters = {
				method: "GET",
				filters: userFilter,
				urlParameters: {
					$expand: "userData/tierMapping,userData/userDetails,userData/userDetails/brTypeSet"
				},
				success: jQuery.proxy(function (oData) {

					try {
						oModel.setProperty("/Persona", oData.results[0].Persona);
						oModel.setProperty("/EmailId", oData.results[0].Email);
						oModel.setProperty("/userData", oData.results[0].userData);
						odefObj.resolve();
					} catch (e) {
						odefObj.reject();
					}

				}, this),
				error: jQuery.proxy(function (oError) {
					odefObj.reject();
				}, this)
			};

			oServiceModel.read(sPath, mParameters);

		},

		//EOC ACHOPRADELOI RAMP-1458 2023/10/17
	});
});