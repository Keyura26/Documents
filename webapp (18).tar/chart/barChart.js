/*global d3Js*/

sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/core/Fragment",
], function (UI5Object, Fragment) {
	"use strict";
	var arcs;
	var arcsData;
	var svgB;
	var isDarkTheme;
	return UI5Object.extend("ui5.PartDash.chart.barChart", {
		constructor: function (that) {
			// Constructor logic here
			this.chart = this.draw(that);

		},

		draw: function (that) {

			//SOC kkalikapuram D3 Chart Changes
			var oTheme = sap.ui.getCore().getConfiguration().getTheme();
			isDarkTheme = oTheme === "zhpe_horizon_evening" ? true : false;
			// isDarkTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
			var expiredModel = that.getView().getModel("expiredModel");



			var data = expiredModel.oData.Items;  // Hardcoded entries for bar chart
			// var data = expiredModel.oData;     // Uncomment it for real time data of pie chart and comment the above line 

			var device = that.getView().getModel("device").getData(),
			 oRenewalsPanel = that.getView().byId("idExpiredPanel"),
			 font_size ,
            widthD = oRenewalsPanel.getDomRef().clientWidth,
            heightD = oRenewalsPanel.getDomRef().clientHeight;


			//EOC kkalikapuram D3 Chart Changes
			//390 , 410 earlier height 270 earlier // 280 280 50

			//SOC Hard Coded Data Change
			// var heightD,
			// 	widthD;
			// // for Phone
			// // if ((window.innerWidth < 600 && window.innerHeight <= 844) || (window.innerWidth <= 844 && window.innerHeight < 600)) {
			// if (device.system.phone) {

			// 	widthD = Math.floor(device.resize.width * 0.9);
			// 	heightD = Math.floor(device.resize.height * 0.52);
			// 	//for Tablet
			// }
			// // else if ((window.innerWidth >= 600 && window.innerWidth <= 1024) || (window.innerHeight >= 600 && window.innerHeight <= 1024)) {
			// else if ((device.system.tablet || device.system.combi) && !device.system.desktop && device.orientation.portrait) {

			// 	widthD = Math.floor(device.resize.width * 0.4);
			// 	heightD = Math.floor(device.resize.height * 0.27);
			// 	//for Desktop
			// } else if ((device.system.tablet || device.system.combi) && !device.system.desktop && device.orientation.landscape) {
			// 	widthD = Math.floor(device.resize.width * 0.35);
			// 	heightD = Math.floor(device.resize.height * 0.37);
			// }
			// else {

			// 	if (zoomLevel < 47) {
			// 		widthD = Math.floor(device.resize.width * 0.09);
			// 		heightD = Math.floor(device.resize.height * 0.6);

			// 	}

			// 	else if (zoomLevel > 47 && zoomLevel < 67) {
			// 		widthD = Math.floor(device.resize.width * 0.2);
			// 		heightD = Math.floor(device.resize.height * 0.6);

			// 	}
			// 	else if (zoomLevel > 67 && zoomLevel < 90) {
			// 		widthD = Math.floor(device.resize.width * 0.3);
			// 		heightD = Math.floor(device.resize.height * 0.5);

			// 	}
			// 	else {
			// 		widthD = Math.floor(device.resize.width * 0.4);
			// 		heightD = Math.floor(device.resize.height * 0.6);
			// 	}
			// }
			if (data.length === 7) {
				heightD = heightD + heightD / 10 + heightD / 20;
			} else
				if (data.length === 8 || data.length === 9) {
					heightD = heightD + (heightD / 10) * 4 + heightD / 20;
				} else if (data.length === 10 || data.length === 11) {
					heightD = heightD + (heightD / 10) * 7 + heightD / 20;
				} else if (data.length === 12 || data.length === 13) {
					heightD = heightD + (heightD / 10) * 10 + heightD / 20;
				} else if (data.length === 14 || data.length === 15) {
					heightD = heightD + (heightD / 10) * 13 + heightD / 20;
				}
			//EOC Hard Coded Data Change
			if(device.media.getCurrentRange("StdExt").name === "Phone" || device.media.getCurrentRange("StdExt").name === "Tablet"){
				font_size = 9 ;
			}
			else{
                font_size = 12 ;
			}
			var margin = {
				top: 20,
				right: 20,
				bottom: 30,
				left: 200
			},
				// 380
				width = widthD - margin.left - margin.right,
				height = heightD - margin.top - margin.bottom;
			console.log("Dimensions:", width, height);
			// Calculate the total value of all data entries

			//SOC Hard Coded Data Change

			var total = d3Js.sum(data, function (d) {
				return d.Count;
			});

			//EOC Hard Coded Data Change

			// SOC Real Time Data Change

			// var total = d3Js.sum(data, function (d) {
			// 	return parseInt(d.count);

			// });

			// EOC Real Time Data Change

			var vBoxControl = that.getView().byId("barChart");

			// // remove all existing Items
			vBoxControl.removeAllItems();
			d3Js.select("#" + vBoxControl.getId()).select("svg").remove();
			var container = vBoxControl.$();

			// // Define the SVG element and its properties

			//SOC Hard Coded Data Change

			if (total !== 0) {
				svgB = d3Js.select(container[0])
					.append("svg")
					.attr("width", width + margin.left + margin.right)
					.attr("height", height + margin.top + margin.bottom)
					.append("g")
					.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
				console.log("SVG:", svgB);

				//set up the x-scale using a linear scale
				var x = d3Js.scaleLinear()
					.domain([0, d3Js.max(data, function (d) {
						return d.Count;
					})])
					.range([0, width]);
				console.log("X Scale:", x);

				//set up the y-scale using a band scale
				var y = d3Js.scaleBand()
					.domain(data.map(function (d) {
						return d.Product;
					}))
					.range([0, height])
					.padding(0.1);
				console.log("Y Scale:", y);

				// Factor to reduce width and height of bars
				var widthFactor = 0.6;
				var heightFactor = 0.6;
				svgB.selectAll(".bar")
					.data(data)
					.enter().append("rect")
					.attr("class", "bar")
					.attr("x", 0)
					.attr("y", function (d) {
						return y(d.Product);
					})
					.attr("width", function (d) {
						return x(d.Count) * widthFactor;
					})
					.attr("height", y.bandwidth() * heightFactor)
					.attr("fill", "#7630EA")
					.attr("id", (d, i) => {
						// return ["b1", "b2", "b3", "b4", "b5"][i];
						return `b${i}`;
					});
				console.log("Bars appended");

				svgB.append("g")
					.attr("class", "x axis")
					.attr("transform", "translate(0," + height + ")")
					.call(d3Js.axisBottom(x).ticks(0));
				console.log("X Axis Appended");

				svgB.append("g")
					.attr("class", "y axis")
					.call(d3Js.axisLeft(y))
					.selectAll(".tick text")
					.style("font-size", font_size + "px")
					.call(this.wrapText, 150);

				console.log("Y Axis Appended");

				svgB.selectAll(".x.axis text")
					.attr("class", "axis-label");

				svgB.selectAll(".y.axis text")



				svgB.selectAll(".label")
					.data(data)
					.enter().append("text")
					.attr("class", "label")
					.attr("x", function (d) {
						return x(d.Count) * widthFactor + 5; // Position labels outside the bars
					})
					.attr("y", function (d) {
						return y(d.Product) + y.bandwidth() * heightFactor / 2; // center labels vertically
					})
					.attr("dy", ".35em")
					.attr("text-anchor", "start")
					.attr("class", "bar-label")
					.text(function (d) {
						return d.Count;
					})
					.style("fill", isDarkTheme ? "#FFFFFF" : "#000000")
					.style("font-size", font_size +"px");
			}

			//EOC Hard Coded Data Change

			//SOC Real Time Data Change
			// if (total !== 0) {
			// 	svgB = d3Js.select(container[0])
			// 		.append("svg")
			// 		.attr("width", width + margin.left + margin.right)
			// 		.attr("height", height + margin.top + margin.bottom)
			// 		.append("g")
			// 		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
			// 	console.log("SVG:", svgB);

			// 	//set up the x-scale using a linear scale
			// 	var x = d3Js.scaleLinear()
			// 		.domain([0, d3Js.max(data, function (d) {
			// 			return parseInt(d.count);
			// 			// return d.Count;
			// 		})])
			// 		.range([0, width]);
			// 	console.log("X Scale:", x);

			// 	//set up the y-scale using a band scale
			// 	var y = d3Js.scaleBand()
			// 		.domain(data.map(function (d) {
			// 			return d.Category2;
			// 		}))
			// 		.range([0, height])
			// 		.padding(0.1);
			// 	console.log("Y Scale:", y);

			// 	// Factor to reduce width and height of bars
			// 	var widthFactor = 0.6;
			// 	var heightFactor = 0.6;
			// 	svgB.selectAll(".bar")
			// 		.data(data)
			// 		.enter().append("rect")
			// 		.attr("class", "bar")
			// 		.attr("x", 0)
			// 		.attr("y", function (d) {
			// 			return y(d.Category2);
			// 		})
			// 		.attr("width", function (d) {
			// 			return x(parseInt(d.count)) * widthFactor;
			// 		})
			// 		.attr("height", y.bandwidth() * heightFactor)
			// 		.attr("fill", "#7630EA")
			// 		.attr("id", (d, i) => {
			// 			// return ["b1", "b2", "b3", "b4", "b5"][i];
			// 			return `b${i}`;
			// 		});
			// 	console.log("Bars appended");

			// 	svgB.append("g")
			// 		.attr("class", "x axis")
			// 		.attr("transform", "translate(0," + height + ")")
			// 		.call(d3Js.axisBottom(x).ticks(0));
			// 	console.log("X Axis Appended");

			// 	svgB.append("g")
			// 		.attr("class", "y axis")
			// 		.call(d3Js.axisLeft(y));
			// 	selectAll(".tick text")
			// 		.style("font-size", "12px")
			// 		.call(this.wrapText, 150);
				
			// 	console.log("Y Axis Appended");

			// 	svgB.selectAll(".x.axis text")
			// 		.attr("class", "axis-label");

			// 	svgB.selectAll(".y.axis text")
					

			// 	svgB.selectAll(".label")
			// 		.data(data)
			// 		.enter().append("text")
			// 		.attr("class", "label")
			// 		.attr("x", function (d) {
			// 			return x(parseInt(d.count)) * widthFactor + 5; // Position labels outside the bars
			// 		})
			// 		.attr("y", function (d) {
			// 			return y(d.Category2) + y.bandwidth() * heightFactor / 2; // center labels vertically
			// 		})
			// 		.attr("dy", ".35em")
			// 		.attr("text-anchor", "start")
			// 		.attr("class", "bar-label")
			// 		.text(function (d) {
			// 			return parseInt(d.count);
			// 		})
			// 		// .style("fill", isDarkTheme ? "#FFFFFF" : "#000000")
			// 		.style("font-size", "12px");
			// }
			//EOC Real Time Data Change

			arcsData = svgB.selectAll(".bar");
		},

		wrapText: function (text, width) {
			text.each(function () {
				var text = d3Js.select(this),
					words = text.text().split(/\s+/).reverse(),
					word,
					line = [],
					lineNumber = 0,
					lineHeight = 1, // ems
					y = text.attr("y"),
					dy = parseFloat(text.attr("dy")),
					tspan = text.text(null).append("tspan").attr("x", -10).attr("y", y).attr("dy", dy + "em");

				while (word = words.pop()) {
					line.push(word);
					tspan.text(line.join(" "));
					if (tspan.node().getComputedTextLength() > width) {
						line.pop();
						tspan.text(line.join(" "));
						line = [word];
						tspan = text.append("tspan").attr("x", -10).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
						// 	if (lineNumber >= 2) { // To ensure max 3 lines
						// 		tspan.text(line.join(" "));
						// 		//+ '...'
						// 		break;
						// 	}
					}
				}
			});

		},
		getArcsData: function () {
			return arcsData;
		}
	});
});