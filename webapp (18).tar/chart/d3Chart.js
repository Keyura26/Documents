/*global d3Js*/
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/core/Fragment",
	"sap/ui/Device"
], function (UI5Object, Fragment, Device) {
	"use strict";
	var arcs,
		arcsData,
		svgD,
		innerWidth,
		innerHeight,
		isDarkTheme;
	return UI5Object.extend("ui5.PartDash.chart.d3Chart", {
		constructor: function (that) {
			// Constructor logic here
			this.chart = this.draw(that);
			
		},
		
		draw: function (that) {

			//SOC kkalikapuram D3 Chart Changes
			var oTheme = sap.ui.getCore().getConfiguration().getTheme();
			isDarkTheme = oTheme === "zhpe_horizon_evening" ? true : false;
			var renewalModel = that.getView().getModel("RenewalModel");
			var data = renewalModel.oData.Items;
			var device = that.getView().getModel("device").getData();
            var oRenewalsPanel = that.getView().byId("idRenewalsPanel"),
            width = oRenewalsPanel.getDomRef().clientWidth,
            height = oRenewalsPanel.getDomRef().clientHeight;

			

			// Calculate the total value of all data entries
			var total = d3Js.sum(data, function (d) {
				return d.Count;
			});

			var vBoxControl = that.getView().byId("d3Chart");

			// remove all existing Items
			vBoxControl.removeAllItems();
			d3Js.select("#" + vBoxControl.getId()).select("svg").remove();
			var container = vBoxControl.$();

			// Define the SVG element and its properties
			if (total !== 0) {
				svgD = d3Js.select(container[0])
					.append("svg")
					.attr("width", width)
					.attr("height", height)
					.append("g")
					// .attr("transform", `translate(${width / 2} , ${height / 2})`)
					.attr("transform", "translate(" + (width / 2) + "," + (height / 2) + ")");

			var radius = Math.min(width, height) / 3;

				// Define the arc generator
				var arc = d3Js.arc()
					.innerRadius(radius * 0.5)
					.outerRadius(radius * 0.8);

				// Generate arcs for each data entry
				var pie = d3Js.pie()
					.sort(null)
					.value(function (d) {
						return d.Count;
					});

				arcs = pie(data);

				// Append the arcs to the SVG element
				svgD.selectAll("path")
					.data(arcs)
					.enter()
					.append("path")
					.attr("d", arc)
					.attr("id", function (d, i) {
						return ["1", "2", "3", "4"][i];
					})
					.attr("fill", function (d, i) {
						// You can define custom colors here based on your data
						return ["#32DAC8", "#FF8300", "#FEC901", "#C140FF"][i];
					});


				//Add labels outside of the donut chart
				svgD.selectAll(".label")
					.data(arcs)
					.enter().append("text")
					.attr("class", "donut-label")
					// .append("text")
					.attr("transform", function (d) {
						var pos = arc.centroid(d);
						var midAngle = (d.startAngle + d.endAngle) / 2;
						// Increase the distance between the labels and the chart
						var distance = radius * 0.9;
						pos[0] = pos[0] * 1.4; // Adjust label position based on angle
						pos[1] = pos[1] * 1.4; // Increase the vertical position of the labels
						return "translate(" + pos + ")";
					})
					.attr("dy", "0.35em")
					.attr("text-anchor", function (d, i) {
						return (d.startAngle + d.endAngle) / 2 < Math.PI ? "start" : "end"; // Adjust text-anchor based on angle
					})
					.text(function (d) {
						if (d.data.Count) {
							return d.data.Product;
						}
					})
				// .style("fill",isDarkTheme?"#FFFFFF":"#000000");
			}

			arcsData = svgD.selectAll('path');
			
		},
		getArcsData: function () {
			return arcsData;
		}
	});
});