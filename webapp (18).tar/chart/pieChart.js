/*global d3Js*/
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/core/Fragment",
], function (UI5Object, Fragment) {
	"use strict";
	var arcs;
	var arcsData;
	var svgP;
	var isDarkTheme,
	 legendDvc,
	 legendItemSize;
	return UI5Object.extend("ui5.PartDash.chart.pieChart", {
		constructor: function (that) {
			// Constructor logic here
			this.chart = this.draw(that);
		
		},

		draw: function (that) {

			var oTheme = sap.ui.getCore().getConfiguration().getTheme();
			isDarkTheme = oTheme === "zhpe_horizon_evening" ? true : false;
			var trialEvalModel = that.getView().getModel("trialEvalModel");
			var device = that.getView().getModel("device").getData();
            var oTrialsEvals = that.getView().byId("idTrialsEvals"),
            width = oTrialsEvals.getDomRef().clientWidth,
            height = oTrialsEvals.getDomRef().clientHeight,
			font_size;            
			
			var data = trialEvalModel.oData.Items; // Hardcoded entries for pie chart
			// var data = trialEvalModel.oData;    // Uncomment it for real time data of pie chart and comment the above line 

			
			// var	height = 780 380 ;

			
				// svgWidth,
				// svgHeight;

            var margin = Math.min(width, height) * 0.05;
			// if(zoomLevel > 64 && zoomLevel<67){ // for zoom level in 60's
			// var margin = 35;
			// }else{
			// var margin = 50;
			// }
			// if (data.length === 7) {
			// 	height = height + height / 10 + height / 20;
			// }
			// else if (data.length === 8 || data.length === 9) {
			// 	height = height + (height / 10) * 4 + height / 20;
			// } else if (data.length === 10 || data.length === 11) {
			// 	height = height + (height / 10) * 7 + height / 20;
			// } else if (data.length === 12 || data.length === 13) {
			// 	height = height + (height / 10) * 10 + height / 20;
			// } else if (data.length === 14 || data.length === 15) {
			// 	height = height + (height / 10) * 13 + height / 20;
			// }
			// if(zoomLevel > 64 && zoomLevel<67){ // for zoom level in 60's
			// 	var radius = Math.min(width, height) / 3 - margin/2;
			// }else{
			// 	var radius = Math.min(width, height) / 2 - margin;

			// }
			
            var radius = Math.min(width, height) / 5  ;

			var total = d3Js.sum(data, function (d) {
				return d.Count;
			});
           
			
			

			var vBoxControl = that.getView().byId("pieChart");
			var colors = ["#32DAC8", "#FF8300", "#FEC901", "#C140FF", "#7630EA"];

			// remove all existing Items
			vBoxControl.removeAllItems();
			d3Js.select("#" + vBoxControl.getId()).select("svg").remove();
			var container = vBoxControl.$(),
			    xaxisPhone =  radius + margin * 3 ,
				xaxisDesktop = radius + margin * 1.5 ;
           
			// Define the SVG element and its properties

			//SOC Hard Coded Data Change
			if (total !== 0) {
				if(device.media.getCurrentRange("StdExt").name === "Phone" || device.media.getCurrentRange("StdExt").name === "Tablet"){
				svgP = d3Js.select(container[0])
					.append("svg")
					.attr("width", width)
					// .attr("width", zoomLevel<65?width:(svgWidth === undefined ? width + 200 : svgWidth))
					.attr("height", height)
					.append("g")
					.attr("transform", "translate(" + (radius + margin* 3) + "," +  (height / 2)  + ")");
				}
				else{
					svgP = d3Js.select(container[0])
					.append("svg")
					.attr("width", width)
					// .attr("width", zoomLevel<65?width:(svgWidth === undefined ? width + 200 : svgWidth))
					.attr("height", height)
					.append("g")
					.attr("transform", "translate(" + (radius + margin* 2) + "," +  (height * 0.4)  + ")");
				}

				var color = d3Js.scaleOrdinal()
					.domain(data.map(function (d) {
						return d.Count;
					}))
					.range(d3Js.schemeCategory10);


				// Generate arcs for each data entry
				var pie = d3Js.pie()
					.sort(null)
					.value(function (d) {
						return d.Count;
					});

				arcs = pie(data);

				// Define the arc generator
				var arc = d3Js.arc()
					.innerRadius(0)
					.outerRadius(radius);

				// Append the arcs to the SVG element
				svgP.selectAll("path")
					.data(arcs)
					.enter()
					.append("path")
					.attr("d", arc)
					.attr("id", function (d, i) {
						// return ["p1", "p2", "p3", "p4", "p5"][i];
						return `p${i}`;
					})
					.attr("fill", function (d, i) {
						// You can define custom colors here based on your data
						return colors[i % colors.length];
					});
				

				var outerArc = d3Js.arc()
					.innerRadius(radius * 1.2)
					.outerRadius(radius * 1.2);
				// removing *1.1 to reduce label spacing from arc

				// Add labels outside of the donut chart
				svgP.selectAll("text")
					.data(arcs)
					.enter()
					.append("text")
					.text(function (d) {
						if (d.data.Count) {
							return d.data.Count;
						}
					})
					.attr("transform", function (d) {
						var centroid = arc.centroid(d);
						var pos = outerArc.centroid(d);

						return 'translate(' + pos + ')';
						
					})
					// .attr("dy", "0.35em")
					.attr("class", "pie-label")
					.attr("text-anchor", function (d, i) {
						var angle = d.startAngle + (d.endAngle - d.startAngle) / 2;
						return angle < Math.PI ? 'start' : 'end';
						// Adjust text-anchor based on angle
					}).attr('dy', '0.35em')
					.style("fill", isDarkTheme ? "#FFFFFF" : "#000000");
				
			}
            var legendHeight = data.length * (margin * 1.5);
            var legendY = -(legendHeight/2);
			// // Add legend  radius + 20 earlier
			// if (device.system.phone ) {//65
				// SOC legend Right
				// ( radius*1.5) 1.8
				if(device.media.getCurrentRange("StdExt").name === "Phone" ){
				    legendDvc = radius*1.8;
					font_size = margin*0.9;
					legendItemSize = margin * 2.5;
				}
				else if(device.media.getCurrentRange("StdExt").name === "LargeDesktop"){
                    legendDvc = radius*1.7;
					font_size = margin*0.6;
					legendItemSize = margin * 2.5;
				}
				else if(device.media.getCurrentRange("StdExt").name === "Tablet"){
                    legendDvc = radius*2;
					font_size = margin;
					legendItemSize = margin * 2.3;
				}
				else{
					legendDvc = radius*2;
					font_size = margin*0.7;
					legendItemSize = margin * 2.3;
				}

				// if(!device.media.getCurrentRange("StdExt").name === "Phone" || device.media.getCurrentRange("StdExt").name === "Desktop"){
				
				var legend = svgP.append("g")
					.attr("transform", "translate(" + ( legendDvc) + "," + legendY + ")");

				var legendItem = legend.selectAll(".legend-item")
					.data(data)
					.enter()
					.append("g")
					.attr("class", "legend-item")
					.attr("transform", function (d, i) {
						return "translate(0," + i * (legendItemSize) + ")"; //1.7
						//60 earlier
					});
				// 18 18 earlier
				legendItem.append("rect")
					.attr("width", margin*0.7)
					.attr("height",margin*0.7)
					.attr("fill", function (d, i) {
						// You can define custom colors here based on your data
						return colors[i % colors.length];
					});

				var legendText = legendItem.append("text")
					.attr("x", margin*1.2)
					.attr("y", margin * 0.35)
					.attr("dy", ".35em")
					.attr("class", "pie-label")
					.style("font-size", font_size +"px")
					.text(function (d) {
						// return d.Category2;
						return d.Product;
					});

				// EOC legend Right
			// }
			// else {
			// 	//SOC Legend Bottom
			// 	var legend = svgP.append("g").
			// 		attr("transform", "translate(" + (-width / 2 + margin) + "," + (height / 8 + radius + 20) + ")");
			// 	// Create legend items 
			// 	var legendItem = legend.selectAll(".legend-item")
			// 		.data(data)
			// 		.enter()
			// 		.append("g")
			// 		.attr("class", "legend-item")
			// 		.attr("transform", function (d, i) {
			// 			// var xOffset = Math.floor(i / 4) * 150; // Adjust for multi-line legends (150px per column)
			// 			var yOffset = i * 40; // 30px spacing per row 
			// 			return "translate(0," + yOffset + ")";
			// 		}); // Add legend rectangles 
			// 	legendItem.append("rect")
			// 		.attr("width", 18)
			// 		.attr("height", 20)
			// 		.attr("fill", function (d, i) {
			// 			return colors[i % colors.length];
			// 		}); // Add legend text 
			// 	var legendText = legendItem.append("text")
			// 		.attr("x", 24) // Position text to the right of the rectangle 
			// 		.attr("y", 9) // Align text vertically with the rectangle 
			// 		.attr("dy", ".35em")
			// 		.attr("class", "pie-label")
			// 		.style("font-size", "12px")
			// 		.text(function (d) { return d.Product; });

			// 	//EOC Legend Bottom
			// }
			
			//EOC Hard Coded Data Change

			//SOC Real Time Data Change
            
			// if (total !== 0) {
			// svgP = d3Js.select(container[0])
			// 		.append("svg")
			// 		// .attr("width", width + 200)
			// 		.attr("width", zoomLevel<65?width:(svgWidth === undefined ? width + 200 : svgWidth))
			// 		.attr("height", height)
			// 		.append("g")
			// 		.attr("transform", "translate(" + (width / 2) + "," + (svgHeight === undefined ? height / 2 : svgHeight / 4) + ")");

			// var color = d3Js.scaleOrdinal()
			// 	.domain(data.map(function (d) {
			// 		return parseInt(d.count);
			// 	}))
			// 	.range(d3Js.schemeCategory10);
				

			// // // Generate arcs for each data entry
			// var pie = d3Js.pie()
			// 	.sort(null)
			// 	.value(function (d) {
			// 		return parseInt(d.count);
			// 	});

			// arcs = pie(data);

			// // // Define the arc generator
			// var arc = d3Js.arc()
			// 	.innerRadius(0)
			// 	.outerRadius(radius);

			// // // Append the arcs to the SVG element

			// svgP.selectAll("path")
			// 	.data(arcs)
			// 	.enter()
			// 	.append("path")
			// 	.attr("d", arc)
			// 	.attr("id", (d, i) => {
			// 		// return ["p1", "p2", "p3", "p4", "p5"][i];
			// 		return `p${i}`;
			// 	})
			// 	.attr("fill", function (d, i) {
			// 		// You can define custom colors here based on your data
			// 		return colors[i % colors.length];
			// 	});

			// var outerArc = d3Js.arc()
			// 	.innerRadius(radius * 1.2)
			// 	.outerRadius(radius * 1.2);

			// 	var outerArc = d3Js.arc()
			// 		.innerRadius(radius * 1.2)
			// 		.outerRadius(radius * 1.2);
			// 	// removing *1.1 to reduce label spacing from arc

			// 	// Add labels outside of the donut chart
			// 	svgP.selectAll("text")
			// 		.data(arcs)
			// 		.enter()
			// 		.append("text")
			// 		.text(function (d) {
			// 			if (d.data.Count) {
			// 				return d.data.Count;
			// 			}
			// 		})
			// 		.attr("transform", function (d) {
			// 			var centroid = arc.centroid(d);
			// 			var pos = outerArc.centroid(d);

			// 			return 'translate(' + pos + ')';
						
			// 		})
			// 		// .attr("dy", "0.35em")
			// 		.attr("class", "pie-label")
			// 		.attr("text-anchor", function (d, i) {
			// 			var angle = d.startAngle + (d.endAngle - d.startAngle) / 2;
			// 			return angle < Math.PI ? 'start' : 'end';
			// 			// Adjust text-anchor based on angle
			// 		}).attr('dy', '0.35em')
			// 		.style("fill", isDarkTheme ? "#FFFFFF" : "#000000");
            // }

			// Add legend  radius + 20 earlier
			// if (!device.system.phone && zoomLevel > 45) {//65
			// 	// SOC legend Right
			// var legend = svgP.append("g")
			// 	.attr("transform", "translate(" + (width / 2 + radius - 38) + "," + (-height / 2 + margin) + ")");

			// var legendItem = legend.selectAll(".legend-item")
			// 	.data(data)
			// 	.enter()
			// 	.append("g")
			// 	.attr("class", "legend-item")
			// 	.attr("transform", function (d, i) {
			// 		return "translate(0," + i * 50 + ")";
			// 		//60 earlier
			// 	});
			// // 18 18 earlier
			// legendItem.append("rect")
			// 	.attr("width", 18)
			// 	.attr("height", 18)
			// 	.attr("fill", function (d, i) {
			// 		// You can define custom colors here based on your data
			// 		return colors[i % colors.length];
			// 	});

			// var legendText = legendItem.append("text")
			// 	.attr("x", 24)
			// 	.attr("y", 9)
			// 	.attr("dy", ".35em")
			// 	.attr("class","pie-label")
			// 	.style("font-size", "12px")
			// 	.text(function (d) {
			// 		return d.Category2;
			// 	})
			// 	// EOC legend Right
			// }
			// else {
			// 	//SOC Legend Bottom
			// 	var legend = svgP.append("g").
			// 		attr("transform", "translate(" + (-width / 2 + margin) + "," + (height / 8 + radius + 20) + ")");
			// 	// Create legend items 
			// 	var legendItem = legend.selectAll(".legend-item")
			// 		.data(data)
			// 		.enter()
			// 		.append("g")
			// 		.attr("class", "legend-item")
			// 		.attr("transform", function (d, i) {
			// 			// var xOffset = Math.floor(i / 4) * 150; // Adjust for multi-line legends (150px per column)
			// 			var yOffset = i * 40; // 30px spacing per row 
			// 			return "translate(0," + yOffset + ")";
			// 		}); // Add legend rectangles 
			// 	legendItem.append("rect")
			// 		.attr("width", 18)
			// 		.attr("height", 20)
			// 		.attr("fill", function (d, i) {
			// 			return colors[i % colors.length];
			// 		}); // Add legend text 
			// 	var legendText = legendItem.append("text")
			// 		.attr("x", 24) // Position text to the right of the rectangle 
			// 		.attr("y", 9) // Align text vertically with the rectangle 
			// 		.attr("dy", ".35em")
			// 		.attr("class", "pie-label")
			// 		.style("font-size", "12px")
			// 		.text(function (d) { return d.Category2; });

			// 	//EOC Legend Bottom
			// }
			
			//EOC Real Time Data Change

			if(device.media.getCurrentRange("StdExt").name === "Phone"){
				this.wrapText(legendText, 110);
			} else {
				//SOC Bottom Legend
				this.wrapText(legendText, 150);
				//EOC Bottom Legend
			}
			arcsData = svgP.selectAll('path');

			
		},
		wrapText: function (text, width) {
			text.each(function () {
				var text = d3Js.select(this),
					words = text.text().split(/\s+/).reverse(),
					word,
					line = [],
					lineNumber = 0,
					lineHeight = 1.1, // ems
					y = text.attr("y"),
					dy = parseFloat(text.attr("dy")),
					tspan = text.text(null).append("tspan").attr("x", 24).attr("y", y).attr("dy", dy + "em");

				while (word = words.pop()) {
					line.push(word);
					tspan.text(line.join(" "));
					if (tspan.node().getComputedTextLength() > width) {
						line.pop();
						tspan.text(line.join(" "));
						line = [word];
						tspan = text.append("tspan").attr("x", 24).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
						if (lineNumber >= 2) { // To ensure max 3 lines
							tspan.text(line.join(" "));
							//+ '...'
							break;
						}
					}
				}
			});

		},
		getArcsData: function () {
			return arcsData;
		}
	});
});