sap.ui.define([
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast",
	"sap/ui/core/format/NumberFormat",
	"ui5/PartDash/utils/utilslib"
], function (DateFormat, MessageToast, NumberFormat, utilslib) {
	"use strict";
	return {
		fnDateRange: function (startDate, endDate) {
			if (startDate, endDate) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MMddYY"
				});
				return oDateFormat.format(startDate).slice(0, 2) + "/" +
					oDateFormat.format(startDate).slice(2, 4) + "/" +
					oDateFormat.format(startDate).slice(4, 6) + " - " +
					oDateFormat.format(endDate).slice(0, 2) + "/" +
					oDateFormat.format(endDate).slice(2, 4) + "/" +
					oDateFormat.format(endDate).slice(4, 6);
			} else {
				return null;
			}
		},
		formatTitleText: function (providerContract, productDesc) {
			if (providerContract && productDesc) {
				return `Subscription - ${providerContract} (${productDesc})`;
			}
			else {
				return `Subscription - ()`;
			}
		},
		dateExpiryColor: function (days) {
			if (days == "0") {
				return "Error"
			} else if (parseInt(days) < 31) {
				return "Warning"
			} else return "Success"
		},
		renewaltypeText: function (type) {
			if (type == "") {
				return "   N/A"
			} else return type;
		},
		dynamicFormatDate: function (Date1, timeSliceFlag, formatIn, payloadflag) {
			if (payloadflag) {
				if (Date1) {
					var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "yyyy-MM-dd",
						formatOptions: {
							UTC: true
						}
					});
					var date = oDateFormat.format(Date1, true);
					if (timeSliceFlag) {
						// Get the hours, minutes, and seconds
						var hours = ("00" + Date1.getUTCHours()).slice(-2);
						var minutes = ("00" + Date1.getUTCMinutes()).slice(-2);
						var seconds = ("00" + Date1.getUTCSeconds()).slice(-2);
						return date + " " + hours + ":" + minutes + ":" + seconds;
					} else {
						return date;
					}
				}
			}

			if (Date1) {
				var format = "dd-MM-yyyy";
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: format,
					formatOption: {
						UTC: true
					}
				});
				var date = oDateFormat.format(Date1, true);
				if (timeSliceFlag) {
					// Get the hours, minutes, and seconds
					var hours = ("00" + Date1.getUTCHours()).slice(-2);
					var minutes = ("00" + Date1.getUTCMinutes()).slice(-2);
					var seconds = ("00" + Date1.getUTCSeconds()).slice(-2);
					return date + " " + hours + ":" + minutes + ":" + seconds;
				} else {
					return date;
				}
			} else {
				return Date1;
			}
		},
		fnContractActionVisible: function (sAction, sUserType, sTier, bPricingVisibility, sProcessIndicator, sEventCode, sInvModel, sSpflag,
			upgradeFlag) { // ACHOPRADELOI SOME-4028 2024/04/04
			var bVisible = false,
				__bDVSEnabled = utilslib.__fnGetDevOnlyEnabled("DVS"),
				__bITSEnabled = utilslib.__fnGetDevOnlyEnabled("ITS"),
				__bDVEEnabled = utilslib.__fnGetDevOnlyEnabled("DVE"),
				__bITEEnabled = utilslib.__fnGetDevOnlyEnabled("ITE"),
				__bSTSEnabled = utilslib.__fnGetDevOnlyEnabled("STS");
			try {
				//BADH INC0815184  2022/02/22 - Removed Tier and Pricing Visibility logic for Customer
				sEventCode = sEventCode === undefined || sEventCode === null ? "" : sEventCode; //(+)BADH EAGLE-3423 2021/12/06
				sInvModel = sInvModel === undefined || sInvModel === null ? "" : sInvModel; //(+)BADH EAGLE-3299 2021/12/09
				switch (sAction) {
					case "UPGRADE":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) && ( /*sSpflag !== "X" && */ upgradeFlag === "X" /* ACHOPRADELOI SOME-4028 2024/04/04 */ &&
								sProcessIndicator !==
								"02") /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						) {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) && ( /*sSpflag !== "X" && */ upgradeFlag === "X" /* ACHOPRADELOI SOME-4028 2024/04/04 */ &&
								sProcessIndicator !==
								"02") /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						) {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						//ACHOPRADELOI GLBP-2702 2024/08/30
						else if (sUserType.toUpperCase() === "CUSTOMER" || sUserType.toUpperCase() === "INTERNAL") /**SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = false;
						}

						break;
					case "DOWNGRADE":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) && ( /*sSpflag !== "X" && */ sProcessIndicator !==
								"02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) && ( /*sSpflag !== "X" && */ sProcessIndicator !==
								"02") /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						) {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) &&
							( /*sSpflag !== "X" && */ sProcessIndicator !== "02")) /**SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						}

						break;
					case "COTERM":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) && ( /*sSpflag !== "X" &&*/ sProcessIndicator !==
								"02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) && ( /*sSpflag !== "X" &&*/ sProcessIndicator !==
								"02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4079 2022/01/18*/) &&
							( /*sSpflag !== "X" && */ sProcessIndicator !== "02")) /**SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						}
						break;
					case "ADD_FUNDS":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel === "CL_PR_DR" || sInvModel === "PR_DR" || sInvModel === "HCC" /*BADH EAGLE-4079 2022/01/18*/)
						) {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel === "CL_PR_DR" || sInvModel === "PR_DR" || sInvModel === "HCC" /*BADH EAGLE-4079 2022/01/18*/)
						) {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sInvModel ===
							"CL_PR_DR" ||
							sInvModel ===
							"PR_DR" || sInvModel === "HCC" /*BADH EAGLE-4079 2022/01/18*/)) {
							bVisible = true;
						}
						break;
					case "PREPAID_DRAWDOWN":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel === "CL_PR_DR" || sInvModel === "PR_DR")) {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel === "CL_PR_DR" || sInvModel === "PR_DR")) {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sInvModel ===
							"CL_PR_DR" ||
							sInvModel === "PR_DR")) {
							bVisible = true;
						}
						break;
					case "AUTO_RENEW":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4269 2022/01/27*/) && (sSpflag !== "X" && sProcessIndicator !== "02") /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						) {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4269 2022/01/27*/) && (sSpflag !== "X" && sProcessIndicator !== "02") /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						) {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sInvModel !== "HCC" /*BADH EAGLE-4269 2022/01/27*/) &&
							(sSpflag !== "X" && sProcessIndicator !== "02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						}
						break;
					case "EXTEND_EVAL":
						/*	if (__bDVSEnabled || __bITSEnabled) {*/ //BADH RAMP-INC1554273 2022/08/09
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sProcessIndicator ===
							"02" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sProcessIndicator ===
							"02" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sProcessIndicator === "02" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						}
						/*}*/
						break;
					case "CONTRACT_ACTIONS":
						if (sUserType.toUpperCase() !== "RESELLER" /*&& sTier.toUpperCase() !== "TIER2"*/ && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						}
						break;
					case "RAISE_A_QUESTION":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1"  /*BADH OR-1948 2022/06/27*/) {
							bVisible = true;
						} else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2") {  // MSHARMAINFO1 INC5799702 3/10/2024 making false for T2
							bVisible = false;
						} else if (sUserType.toUpperCase() === "CUSTOMER") {
							bVisible = true;
						} else if (sUserType.toUpperCase() === "INTERNAL") {
							bVisible = true;
						}
						break;
					case "REQUEST_INOVICE_CORRECTION":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = false; // MSHARMAINFO1 INC5799702 3/10/2024 making false for T2
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						}
						break;
					case "REQUEST_FOR_CANCELATION":
						if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility === true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = false; // MSHARMAINFO1 INC5799702 3/10/2024 making false for T2
						} /*EOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "CUSTOMER" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						} else if (sUserType.toUpperCase() === "INTERNAL" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") { //(+)EAGLE BADH DEFECT-2370 2021/10/27
							bVisible = true;
						}
						break;
					//SOC ACHOPRADELOI SOME-4028 2024/04/04
					case "REQUEST_FOR_UPGRADE":
						if (sProcessIndicator === "02" || sInvModel === "HCC") {
							bVisible = false;
						} else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER1" && bPricingVisibility ===
							true && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						} /*SOC BADH OR-1948 2022/06/27*/
						else if (sUserType.toUpperCase() === "PARTNER" && sTier.toUpperCase() === "TIER2" && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						} /*EOC BADH OR-1948 2022/06/27*/
						//ACHOPRADELOI GLBP-2702 2024/08/30
						else if (sUserType.toUpperCase() === "CUSTOMER" || sUserType.toUpperCase() === "INTERNAL") /**SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = false;
						}
						break;
					//EOC ACHOPRADELOI SOME-4028 2024/04/04
					default:
						if (sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						}
				}
			} catch (err) {
				switch (sAction) {
					case "EXTEND_EVAL":
						/*	if (__bDVSEnabled || __bITSEnabled) {*/ //BADH RAMP-INC1554273 2022/08/09
						if (sProcessIndicator === "02" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						}
						/*}*/
						break;
					case "ADD_FUNDS":
						if ((sInvModel === "CL_PR_DR" || sInvModel === "PR_DR" || sInvModel === "HCC" /*BADH EAGLE-4079 2022/01/18*/) && sEventCode.toUpperCase() !==
							"CANCELLED CONTRACT") {
							bVisible = true;
						}
						break;
					case "PREPAID_DRAWDOWN":
						if ((sInvModel === "CL_PR_DR" || sInvModel === "PR_DR") && sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						}
						break;
					case "UPGRADE":
						//(-) ACHOPRADELOI GLBP-2702 2024/08/28
						// if (__bDVSEnabled || __bITSEnabled || __bSTSEnabled) {
						// if (sInvModel !== "HCC" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && sSpflag !== "X" && sProcessIndicator !== "02" &&
						// 	upgradeFlag === "X") //kkalikapuram GLBP-1645 2024/06/11
						// /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						// { //BADH EAGLE-4079 2022/01/18
						// 	bVisible = true;
						// }
						// // }
						break;
					//SOC kkalikapuram GLBP-1645 2024/06/11
					case "REQUEST_FOR_UPGRADE":
						//(-) ACHOPRADELOI GLBP-2702 2024/08/28
						// if (__bDVSEnabled || __bITSEnabled || __bSTSEnabled) {
						// if (sInvModel !== "HCC" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && sSpflag !== "X" && sProcessIndicator !== "02" &&
						// 	upgradeFlag === "X")
						// /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/
						// { //BADH EAGLE-4079 2022/01/18
						// 	bVisible = true;
						// }
						// }
						break;
					//EOC kkalikapuram GLBP-1645 2024/06/11
					case "DOWNGRADE":
						if (sInvModel !== "HCC" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sSpflag !== "X" && sProcessIndicator !== "02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ { //BADH EAGLE-4079 2022/01/18
							bVisible = true;
						}
						break;
					case "COTERM":
						if (sInvModel !== "HCC" && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sSpflag !== "X" && sProcessIndicator !== "02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ { //BADH EAGLE-4079 2022/01/18
							bVisible = true;
						}
						break;
					case "AUTO_RENEW":
						if ((sInvModel !== "HCC" /*BADH EAGLE-4269 2022/01/27*/) && sEventCode.toUpperCase() !== "CANCELLED CONTRACT" && (sSpflag !==
							"X" &&
							sProcessIndicator !== "02")) /*SULALWANI-2022/04/01-SILVERPEAK-1692-Enable upgrade,downgrade,auto renewal buttons*/ {
							bVisible = true;
						}
						break;
					default:
						if (sEventCode.toUpperCase() !== "CANCELLED CONTRACT") {
							bVisible = true;
						}
				}
			}
			return bVisible;
		},
		formatTextSelect: function (selectText) {

			// var selectArr = selectText.split(" ");

			// var formattedParts = selectArr.map(function (part) {
			// 	if (part === selectArr[1] || part === selectArr[4]) {
			// 		return "<span class='zcustomHPEColours'>" + part + "</span>";
			// 	} else {
			// 		return part;
			// 	}
			// });
			//var formattedText = formattedParts.join(" ");
			return selectText;
		},
		dateExpiryText: function (days) {
			if (days == "0") {
				return "Expiring today"
			} else if (days == "1") {
				return "1 day"
			} else if (parseInt(days) > 1) {
				return days + " days"
			} else return "N/A"
		},
		CCAmount: function (value, currency) {
			if (value) {
				return parseFloat(value).toFixed(2) + " " + currency;
			} else {
				return "N/A"
			}
		},
		CCDate: function (value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "MMddYY"
				});
				return oDateFormat.format(value).slice(0, 2) + "/" +
					oDateFormat.format(value).slice(2, 4) + "/" +
					oDateFormat.format(value).slice(4, 6);
			} else {
				return "N/A"
			}
		},
		formatDateForBackend: function (value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern: "YYYYMMdd"
				});
				return oDateFormat.format(value);
			} else {
				return value;
			}
		},
		// dynamicFormatDate: function (Date) {

		// 	if (jQuery.sap.getUriParameters().get("i_t")) {
		// 		var format = this.getView().getModel("viewData").getProperty("/DateFormat");
		// 		if (Date) {
		// 			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
		// 				pattern: format,
		// 				formatOption: {
		// 					UTC: true
		// 				}
		// 			});
		// 			return oDateFormat.format(Date);
		// 		} else {
		// 			return Date;
		// 		}
		// 	}

		// 	// <!--SOC Raghav SOME4028 - Part 1 - 1/6 - for-"showing the date in a proper format "->

		// 	if (Date !== null && Date !== undefined && Date !== "") {
		// 		var dateStr =
		// 			Date.getFullYear() + "-" +
		// 			("00" + (Date.getUTCMonth() + 1)).slice(-2) + "-" +
		// 			("00" + Date.getUTCDate()).slice(-2);
		// 		return dateStr;
		// 	}

		// 	//	<!--EOC Raghav SOME4028 - Part 1 - 1/6 > 
		// },
		// BOC Vsingh correct date to avoid date issue in UTC conversion
		changeDateToUTC: function (oDate) { //for sending dates to backend
			if (oDate) {
				var oTempDate = new Date(oDate.setHours("00", "00", "00", "00"));
				oDate = new Date(oTempDate.getTime() + oTempDate.getTimezoneOffset() * (-60000));
				return oDate;
			} else {
				return oDate;
			}

		},
		//EOC Vsingh

		checkPdfDownload: function (Flag) { //for  checking pdf file is available or not
			if (Flag === "X") {
				return true;
			} else {
				return false;
			}

		},

	};
});