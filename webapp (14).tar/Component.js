sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/hpe/it/ui5/asq/zui5_priccalc/model/models",
	"sap/base/util/UriParameters"
], function (UIComponent, Device, models, UriParameters) {
	"use strict";

	var oUriParameters = new UriParameters(window.location.href); //MSHEKHARDELO: Custom header for mobile app 10/07/2024

	
	return UIComponent.extend("com.hpe.it.ui5.asq.zui5_priccalc.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			//(-) SOC MSHEKHARDELO ASQ ASQ Optimization 9/22/2023
			// if (sap.ushell) {
			// 	var fnThemeChange = function (bInitial) {
			// 		var __oCore = sap.ui.getCore(),
			// 			sCurrentTheme = __oCore.getConfiguration().getTheme();
			// 		if (bInitial) {
			// 			__oCore["__isASQCalExitDone"] = false;
			// 		}
			// 		if (sCurrentTheme !== "zhpe_external" && !__oCore["__isASQCalExitDone"]) {
			// 			__oCore.setThemeRoot("zhpe_external", ("/sap/public/bc/themes/~client-300/UI5"));
			// 			__oCore.applyTheme("zhpe_external");
			// 		}
			// 	};
			// 	fnThemeChange(true);
			// 	sap.ui.getCore().attachThemeChanged(function (oEvt) {
			// 		if (oEvt.getParameter("theme") !== "zhpe_external") {
			// 			fnThemeChange(false);
			// 		}
			// 	}, this);
			// }
			//(-) EOC MSHEKHARDELO ASQ ASQ Optimization 9/22/2023
			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			//SOC MSHEKHARDELO: Custom header for mobile app 10/07/2024
			// creating a global model
			var oModel = new sap.ui.model.json.JSONModel();
			this.setModel(oModel, "GlobalModel");
			this.getModel("GlobalModel").setProperty("/sapUShellConfig",false);
			if(oUriParameters.get("sap-ushell-config") !== null || window.location.href.includes("/calculator") ){
				this.getModel("GlobalModel").setProperty("/sapUShellConfig",true);
			}
			//EOC MSHEKHARDELO: Custom header for mobile app 10/07/2024
		},

		destroy: function () {
			UIComponent.prototype.destroy.apply(this, arguments);
			//(-) SOC MSHEKHARDELO ASQ ASQ Optimization 9/22/2023
			// if (sap.ushell) {
			// 	var sUserTheme = sap.ushell.Container.getService('UserInfo').getUser().getTheme(),
			// 		__oCore = sap.ui.getCore(),
			// 		sCurrentTheme = __oCore.getConfiguration().getTheme();
			// 	if (sCurrentTheme !== sUserTheme) {
			// 		__oCore["__isASQCalExitDone"] = true;
			// 		__oCore.applyTheme(sUserTheme);
			// 	}
			// }
			//(-) EOC MSHEKHARDELO ASQ ASQ Optimization 9/22/2023
		},
	});
});