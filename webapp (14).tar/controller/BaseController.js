sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/CustomData",
	"sap/ui/core/Fragment"
], function (Controller, CustomData, Fragment) {
	"use strict";
	return Controller.extend("com.hpe.it.ui5.asq.zui5_priccalc.controller.BaseController", {

		onInit: function () {
			// this.fnGetGeoLocation();
			this.getRouter().attachRoutePatternMatched(this._handleRouteMatched, this);
			this.extOnInit();
		},

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getModel: function (sName) {
			if (sName) {
				return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
			} else {
				return this.getView().getModel() || this.getOwnerComponent().getModel();
			}
		},
		setJSONModel: function (oData, sName, bGlobal) {
			if (bGlobal) {
				if (sName) {
					this.getOwnerComponent().setModel(oData, sName);
				} else {
					this.getOwnerComponent().setModel(oData);
				}
			} else {
				if (sName) {
					this.getView().setModel(oData, sName);
				} else {
					this.getView().setModel(oData);
				}
			}
		},
		__openBusyDialog: function (__sBusyOpenedBy) { //Global Method to  Open Busy Dialog
			if (!this.__oBusyDialog) {
				var _oBusyDialog = new sap.m.BusyDialog();
				_oBusyDialog.removeAllCustomData();
				_oBusyDialog.addCustomData(new sap.ui.core.CustomData({
					"key": "bOpened",
					"value": true
				}));
				if (__sBusyOpenedBy) {
					_oBusyDialog.addCustomData(new sap.ui.core.CustomData({
						"key": "sOpenedBySrv",
						"value": __sBusyOpenedBy
					}));
				}
				this.__oBusyDialog = _oBusyDialog;
				jQuery.sap.delayedCall(0, this, function () {
					this.__oBusyDialog.open();
				});

			} else {
				if (!this.__isBusyDialogOpened()) {
					this.__oBusyDialog.removeAllCustomData();
					this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
						"key": "bOpened",
						"value": true
					}));
					if (__sBusyOpenedBy) {
						this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
							"key": "sOpenedBySrv",
							"value": __sBusyOpenedBy
						}));
					}
					jQuery.sap.delayedCall(0, this, function () {
						this.__oBusyDialog.open();
					});
				} else {
					if (this.__oBusyDialog.data("sOpenedBySrv") !== undefined && this.__oBusyDialog.data("sOpenedBySrv") !== __sBusyOpenedBy) {
						this.__oBusyDialog.removeAllCustomData();
						this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
							"key": "bOpened",
							"value": true
						}));
						if (__sBusyOpenedBy) {
							this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
								"key": "sOpenedBySrv",
								"value": __sBusyOpenedBy
							}));
						}
					}
				}
			}
		},

		__closeBusyDialog: function (__sBusyOpenedBy) { //Global Method to Close Busy Dialog
			/* SOC VPASTOREK SILVERPEAK IN:697356 Dec 7, 2022 */
			if (this.__oBusyDialog) {
				var bPunchout = jQuery.sap.getUriParameters().get("i_t") !== null && jQuery.sap.getUriParameters().get("i_t") !== undefined;
				if (this.__isBusyDialogOpened()) {
					if (this.__oBusyDialog.data("sOpenedBySrv") !== undefined && this.__oBusyDialog.data("sOpenedBySrv") === __sBusyOpenedBy) {
						this.__oBusyDialog.removeAllCustomData();
						this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
							"key": "bOpened",
							"value": false
						}));
						this.__oBusyDialog.close();
						if (bPunchout) { // SOC VPASTOREKDEL Mar 10 2023 session timer only for punchout
							this.getOwnerComponent()._resetTimer();
						}
					} else if ((this.__oBusyDialog.data("sOpenedBySrv") === undefined || this.__oBusyDialog.data("sOpenedBySrv") === null) ||
						__sBusyOpenedBy === undefined) {
						this.__oBusyDialog.removeAllCustomData();
						this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
							"key": "bOpened",
							"value": false
						}));
						this.__oBusyDialog.close();
						if (bPunchout) { // SOC VPASTOREKDEL Mar 10 2023 session timer only for punchout
							this.getOwnerComponent()._resetTimer();
						}
					}
				} else {
					if (this.__oBusyDialog.data("bOpened") === undefined || this.__oBusyDialog.data("bOpened") === false) {
						this.__oBusyDialog.removeAllCustomData();
						this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
							"key": "bOpened",
							"value": false
						}));
						this.__oBusyDialog.close();
						if (bPunchout) { // SOC VPASTOREKDEL Mar 10 2023 session timer only for punchout
							this.getOwnerComponent()._resetTimer();
						}
					}
				}
			}
			/* EOC VPASTOREK SILVERPEAK IN:697356 Dec 7, 2022 */
		},

		__isBusyDialogOpened: function () {
			if (this.__oBusyDialog) {
				var __bOpened = this.__oBusyDialog.data("bOpened");
				if (__bOpened !== undefined && __bOpened !== null && __bOpened === true) {
					return true;
				}
			}
			return false;
		},

		__readODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !this.__isBusyDialogOpened()) {
							jQuery.sap.delayedCall(0, this, function () {
								_options.oControl.setBusyIndicatorDelay(0);
								_options.oControl.setBusy(true);
							});
						}
					}
				} else {
					this.__openBusyDialog(_options.sPath);
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add Filter Parameters
				if (_options.oFilters) {
					_oParameters["filters"] = _options.oFilters;
				}

				/*SOC BADH PERFORMANCE FIXES 2022/09/07*/
				if (_options.oSorters) {
					_oParameters["sorters"] = _options.oSorters;
				}
				/*EOC BADH PERFORMANCE FIXES 2022/09/07*/

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.read(_options.sPath, _oParameters);
				//});
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog(_options.sPath);
				}
			}
		},

		__deleteODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy === false) {
					__bGlobalBusy = false;
				}
				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !this.__isBusyDialogOpened()) {
							// jQuery.sap.delayedCall(0, this, function () { // VPASTOREK SILVERPEAK IN:698356 Dec 7, 2022
							_options.oControl.setBusyIndicatorDelay(0);
							_options.oControl.setBusy(true);
							// });
						}
					}
				} else {
					this.__openBusyDialog(_options.sPath);
				}

				var _oModel = _options.oModel,
					_oParameters = {};

				//Add Header Parameter
				if (_options.Odata_V1) {
					_oModel.setHeaders({
						'X-Requested-With': 'XMLHttpRequest',
						'Content-Type': 'application/atom+xml'
					});
				} else {
					_oModel.setHeaders({
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					});
				}

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.remove(_options.sPath, _oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog(_options.sPath);
				}
			}
		},

		__updateODataOperation: async function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy === false) {
					__bGlobalBusy = false;
				}
				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !this.__isBusyDialogOpened()) {
							jQuery.sap.delayedCall(0, this, function () {
								_options.oControl.setBusyIndicatorDelay(0);
								_options.oControl.setBusy(true);
							});
						}
					}
				} else {
					this.__openBusyDialog(_options.sPath);
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};
				//Add Header Parameter

				if (_options.IfMatch) {
					_oHeader["If-Match"] = _options.IfMatch;
				}
				if (_options.csrfToken) {
					_oHeader["x-csrf-token"] = _options.csrfToken;
				}
				if (_options.CondenseMessagesInHttpResponseHeader) {
					_oHeader["CondenseMessagesInHttpResponseHeader"] = _options.CondenseMessagesInHttpResponseHeader;
				}

				_oModel.setHeaders(_oHeader);
				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add change set id
				if (_options.changeSetId) {
					_oParameters["changeSetId"] = _options.changeSetId;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//Add Merge flag
				if (_options.bMerge) {
					_oParameters["merge"] = _options.bMerge;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.update(_options.sPath, _options.oRequestBody, _oParameters);
				//});
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog(_options.sPath);
				}
			}
		},

		__updateODataOperationPromise: async function (_options) {
			var __oContext__ = this,
				__oUpdPromise__ = new Promise(function (oResolve, oReject) {
					var __bGlobalBusy = true;
					try {
						if (_options.bGlobalBusy === false) {
							__bGlobalBusy = false;
						}

						if (__bGlobalBusy === false) {
							if (_options.oControl) {
								if (!_options.oControl.getBusy() && !__oContext__.__isBusyDialogOpened()) {
									jQuery.sap.delayedCall(0, __oContext__, function () {
										_options.oControl.setBusyIndicatorDelay(0);
										_options.oControl.setBusy(true);
									});
								}
							}
						} else {
							__oContext__.__openBusyDialog(_options.sPath);
						}

						var _oModel = _options.oModel,
							_oParameters = {};

						//Add Headers
						if (_options.oHeaders) {
							var __oHeaders = Object.assign(_oModel.getHeaders(), _options.oHeaders);
							_oModel.setHeaders(__oHeaders);
						}
						//Add Batch GroupId
						if (_options.sBatchGroupId) {
							_oModel.setDeferredGroups([_options.sBatchGroupId]);
							_oParameters["groupId"] = _options.sBatchGroupId;
						}

						//Add change set id
						if (_options.changeSetId) {
							_oParameters["changeSetId"] = _options.changeSetId;
						}

						//Add URL Parameters
						if (_options.oURIParameters) {
							_oParameters["urlParameters"] = _options.oURIParameters;
						}

						//Add Async flag
						if (_options.bAsync) {
							_oParameters["async"] = _options.bAsync;
						}

						//Add Merge flag
						if (_options.bMerge) {
							_oParameters["merge"] = _options.bMerge;
						}

						//OData Success Handling
						_oParameters["success"] = function (oData, oResponse) {
							if (__bGlobalBusy === false) {
								if (_options.oControl) {
									_options.oControl.setBusy(false);
								}
							} else {
								__oContext__.__closeBusyDialog(_options.sPath);
							}
							if (_options.fnSuccess) {
								_options.fnSuccess(oData, oResponse);
							}
							oResolve(oData, oResponse);
						}.bind(__oContext__);

						//OData Error Handling
						_oParameters["error"] = function (oErrResponse) {
							if (__bGlobalBusy === false) {
								if (_options.oControl) {
									_options.oControl.setBusy(false);
								}
							} else {
								__oContext__.__closeBusyDialog(_options.sPath);
							}
							if (_options.fnError) {
								_options.fnError(oErrResponse);
							}

							oReject(oErrResponse);
						}.bind(__oContext__);

						_oModel.update(_options.sPath, _options.oRequestBody, _oParameters);
					} catch (err) {
						if (_options.oControl && __bGlobalBusy === false) {
							_options.oControl.setBusy(false);
						} else if (__bGlobalBusy === true) {
							__oContext__.__closeBusyDialog(_options.sPath);
						}
					}
				});

			if (_options["bAsync"] === false) {
				await __oUpdPromise__;
			}
		},

		__createODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy === false) {
					__bGlobalBusy = false;
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !this.__isBusyDialogOpened()) {
							jQuery.sap.delayedCall(0, this, function () {
								_options.oControl.setBusyIndicatorDelay(0);
								_options.oControl.setBusy(true);
							});
						}
					}
				} else {
					this.__openBusyDialog(_options.sPath);
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};
				//Add Header Parameter

				if (_options.IfMatch) {
					_oHeader["If-Match"] = _options.IfMatch;
				}
				if (_options.csrfToken) {
					_oHeader["x-csrf-token"] = _options.csrfToken;
				}
				if (_options.CondenseMessagesInHttpResponseHeader) {
					_oHeader["CondenseMessagesInHttpResponseHeader"] = _options.CondenseMessagesInHttpResponseHeader;
				}

				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//Add change set id
				if (_options.changeSetId) {
					_oParameters["changeSetId"] = _options.changeSetId;
				}
				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.create(_options.sPath, _options.oRequestBody, _oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog(_options.sPath);
				}
			}
		},

		//SOC ACHOPRADELOI- OR-2477-IRIS File Upload 28/07/2022
		__callFunctionODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy === false) {
					__bGlobalBusy = false;
				}
				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !this.__isBusyDialogOpened()) {
							jQuery.sap.delayedCall(0, this, function () {
								_options.oControl.setBusyIndicatorDelay(0);
								_options.oControl.setBusy(true);
							});
						}
					}
				} else {
					this.__openBusyDialog(_options.sPath);
				}

				var _oModel = _options.oModel,
					_oParameters = {};

				//Add Header Parameter
				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				if (_options.method) {
					_oParameters["method"] = _options.method;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sPath);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.callFunction(_options.sPath, _oParameters);
				//});
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog(_options.sPath);
				}
			}
		},
		//EOC ACHOPRADELOI- OR-2477-IRIS File Upload 28/07/2022

		__submitChangeODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy === false) {
					__bGlobalBusy = false;
				}
				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy() && !this.__isBusyDialogOpened()) {
							jQuery.sap.delayedCall(0, this, function () {
								_options.oControl.setBusyIndicatorDelay(0);
								_options.oControl.setBusy(true);
							});
						}
					}
				} else {
					this.__openBusyDialog(_options.sBatchGroupId);
				}

				var _oModel = _options.oModel,
					_oParameters = {};
				//Add Header Parameter
				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});
				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}
				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sBatchGroupId);
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);
				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog(_options.sBatchGroupId);
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);
				_oModel.submitChanges(_oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog(_options.sBatchGroupId);
				}
			}
		},

		__submitChangeODataOperationPromise: async function (_options) {
			var __oContext__ = this,
				__oSubmitChgPromise__ = new Promise(function (oResolve, oReject) {
					var __bGlobalBusy = true;
					try {
						if (_options.bGlobalBusy === false) {
							__bGlobalBusy = false;
						}
						if (__bGlobalBusy === false) {
							if (_options.oControl) {
								if (!_options.oControl.getBusy() && !__oContext__.__isBusyDialogOpened()) {
									jQuery.sap.delayedCall(0, __oContext__, function () {
										_options.oControl.setBusyIndicatorDelay(0);
										_options.oControl.setBusy(true);
									});
								}
							}
						} else {
							__oContext__.__openBusyDialog(_options.sBatchGroupId);
						}

						var _oModel = _options.oModel,
							_oParameters = {};

						//Add Header Parameter
						_oModel.setHeaders({
							'X-Requested-With': 'X',
							'Accept': 'application/json'
						});

						//Add Batch GroupId
						if (_options.sBatchGroupId) {
							_oModel.setDeferredGroups([_options.sBatchGroupId]);
							_oParameters["groupId"] = _options.sBatchGroupId;
						}

						//OData Success Handling
						_oParameters["success"] = function (oData, oResponse) {
							if (__bGlobalBusy === false) {
								if (_options.oControl) {
									_options.oControl.setBusy(false);
								}
							} else {
								__oContext__.__closeBusyDialog(_options.sBatchGroupId);
							}
							if (_options.fnSuccess) {
								_options.fnSuccess(oData, oResponse);
							}
							oResolve(oData, oResponse);
						}.bind(__oContext__);

						//OData Error Handling
						_oParameters["error"] = function (oErrResponse) {
							if (__bGlobalBusy === false) {
								if (_options.oControl) {
									_options.oControl.setBusy(false);
								}
							} else {
								__oContext__.__closeBusyDialog(_options.sBatchGroupId);
							}
							if (_options.fnError) {
								_options.fnError(oErrResponse);
							}
							oReject(oErrResponse);
						}.bind(__oContext__);
						_oModel.submitChanges(_oParameters);
					} catch (err) {
						if (_options.oControl && __bGlobalBusy === false) {
							_options.oControl.setBusy(false);
						} else if (__bGlobalBusy === true) {
							__oContext__.__closeBusyDialog(_options.sBatchGroupId);
						}
					}
				});

			if (_options["bAsync"] === false) {
				await __oSubmitChgPromise__;
			}

			return __oSubmitChgPromise__;
		},

		fnUXVisibilityPostOrderable: function (sQuoteStatus) {
			var bVisible = false;
			try {
				var __oGlobalModel = this.getModel("globalModel");
				if (__oGlobalModel !== undefined && __oGlobalModel !== null) {
					var __aUXVibilityData = __oGlobalModel.getProperty("/UX_VISIBILITY");
					__aUXVibilityData.find(function (oData) {
						if (oData["Zzlow"] === sQuoteStatus) {
							bVisible = true;
						}
					});
				}
				return bVisible;
			} catch (err) {
				return bVisible;
			}
		},

		fnGetODataErrorDetails: function (oError) {
			var __aErrors = [];
			try {
				if (oError.responseText) {
					var oJsonError = JSON.parse(oError.responseText).error;

					if (oJsonError) {
						if (oJsonError["message"]) {
							__aErrors.push({
								"errorCode": oJsonError["code"],
								"errorMessage": oJsonError["message"]["value"]
							});
						}

						if (oJsonError["innererror"]) {
							var aErrorDetails = oJsonError["innererror"]["errordetails"];
							if (aErrorDetails) {
								for (var oErrDetail of aErrorDetails) {
									__aErrors.push({
										"errorCode": oErrDetail["code"],
										"errorMessage": oErrDetail["message"]
									});
								}
							}

						}
					}
				} else {
					var sErrorMsg = "";
					if (oError["message"]) {
						var __sErrMsg = oError["message"].toUpperCase();
						if (__sErrMsg.indexOf("REQUEST FAILED") !== -1) {
							sErrorMsg = this.getResourceBundle().getText("xmsg.GlobalSeviceError1");
						} else if (__sErrMsg.indexOf("TIMEOUT") !== -1) {
							sErrorMsg = this.getResourceBundle().getText("xmsg.GlobalSeviceError2");
						} else if (__sErrMsg.indexOf("COMMUNICATION") !== -1) {
							sErrorMsg = this.getResourceBundle().getText("xmsg.GlobalSeviceError3");
						} else {
							sErrorMsg = this.getResourceBundle().getText("xmsg.GlobalSeviceError4");
						}
					} else {
						sErrorMsg = this.getResourceBundle().getText("xmsg.GlobalSeviceError4");
					}

					__aErrors.push({
						"errorCode": "000",
						"errorMessage": sErrorMsg
					});
				}
			} catch (err) {
				__aErrors.push({
					"errorCode": "000",
					"errorMessage": err.message
				});
			}
			return __aErrors;
		},

		fnOpenErrorMessageDialog: function (aMessageDetails) {
			if (!this.getModel("ErrMsgMdl")) {
				this.setJSONModel(new sap.ui.model.json.JSONModel({}), "ErrMsgMdl", false);
			}
			var oErrMsgMdl = this.getModel("ErrMsgMdl"),
				__oContext = this;

			oErrMsgMdl.setProperty("/bBackBtnVisible", false);
			if (aMessageDetails) {
				oErrMsgMdl.setProperty("/aErrMsgs", aMessageDetails);
			} else {
				oErrMsgMdl.setProperty("/aErrMsgs", []);
			}
			oErrMsgMdl.refresh(true);

			if (!this.__oMsgDtlDialog) {
				Fragment.load({
					name: "com.hpe.it.ui5.asq.zui5_priccalc.view.fragments.MsgDtlDialog",
					controller: this
				}).then(function (oDialog) {
					__oContext.__oMsgDtlDialog = oDialog;
					__oContext.getView().addDependent(__oContext.__oMsgDtlDialog);
					oDialog.open();
				});

			} else {
				this.__oMsgDtlDialog.open();
			}

		},

		onMsgDltItemSelect: function (oEvent) {
			if (this.__oMsgDtlDialog) {
				this.getModel("ErrMsgMdl").setProperty("/bBackBtnVisible", true);
			}
		},

		onMsgDltBackBtnPress: function (oEvent) {
			if (this.__oMsgDtlDialog) {
				this.__oMsgDtlDialog.getContent()[0].navigateBack();
				this.getModel("ErrMsgMdl").setProperty("/bBackBtnVisible", false);
			}
		},

		onMsgDltCloseBtnPress: function (oEvent) {
			if (this.__oMsgDtlDialog) {
				this.__oMsgDtlDialog.getContent()[0].navigateBack();
				this.__oMsgDtlDialog.close();
			}
		},

		fnGetGeoLocation: function () {
			if (navigator.geolocation) {
				var fnGetLocation = function (oPosition) {
					debugger;
					console.log("Latitude: " + oPosition.coords.latitude);
					console.log("Longitude: " + oPosition.coords.longitude);
					$.getJSON('http://ws.geonames.org/countryCode', {
						lat: oPosition.coords.latitude,
						lng: oPosition.coords.longitude,
						type: 'JSON'
					}, function (result) {
						console.log('Country: ' + result.countryName + '\n' + 'Code: ' + result.countryCode);
					});
				}
				navigator.geolocation.getCurrentPosition(fnGetLocation);
			} else {
				console.log("Geolocation is not supported by this browser.");
			}
		}

	});
});