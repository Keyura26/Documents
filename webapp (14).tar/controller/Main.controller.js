sap.ui.define([
	"com/hpe/it/ui5/asq/zui5_priccalc/controller/BaseController",
	"com/hpe/it/ui5/asq/zui5_priccalc/libs/formatter",
	//BOC SMDELOITTE2 utils lib added 23-Jun-23
	// "com/hpe/it/ui5/asq/zui5_priccalc/libs/PickProductUtils",
	// "com/hpe/it/ui5/asq/zui5_priccalc/libs/AVCUtils",
	"com/hpe/it/lib/zui5asqlibrary/libs/PickProductUtils",
	"com/hpe/it/lib/zui5asqlibrary/libs/AVCUtils",
	"com/hpe/it/lib/zui5asqlibrary/libs/PCE_AVCUtils",
	//EOC SMDELOITTE2 utils lib added 23-Jun-23
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/util/Storage",
	"sap/m/MessageToast",
	"com/hpe/it/lib/zui5asqlibrary/libs/utilslib",
	"sap/base/util/UriParameters",
	"sap/ui/Device"

], function (BaseController, formatter, libPickProductUtils, libAVCUtils, libPCEAVCUtils, JSONModel, Sorter, Storage, MessageToast, utilslib, UriParameters, Device) {
	"use strict";
	var __oCtrlContext__,
		__randomNumberRange__ = [],
		oUriParameters = new UriParameters(window.location.href);
	return BaseController.extend("com.hpe.it.ui5.asq.zui5_priccalc.controller.Main", {

		_formatter: formatter,
		//BOC SMDELOITTE2 utils lib added 23-Jun-23
		// _PickProductUtils: new PickProductUtils(),
		_PickProductUtils: new libPickProductUtils("CREATEQUOTE"),

		// _AVCUtils: new AVCUtils(),
		_AVCUtils: new libAVCUtils("CREATEQUOTE"),
		//EOC SMDELOITTE2 utils lib added 23-Jun-23
		_PCE_AVC_Utils: new libPCEAVCUtils("CREATEQUOTE"), //PCE prep AVC intervention GSINGHDELOI1 4May2023

		_utilslib: utilslib,

		extOnInit: function () {
			__oCtrlContext__ = this;
			this.bIsInitial = true;
			this.oLoadingDefaultSalesOrgASQ = $.Deferred();
			this.oSetDafaultValDone = $.Deferred();

			if (!this.getModel("viewData")) {
				this.setJSONModel(new JSONModel(), "viewData", false);
			}
			this.__getFnCurrencyIncoTerms(); //Get Currency and incoterms
			this._PickProductUtils.onInit(this);
			this._PickProductUtils.setAdditionalViewDetails({
				mode: "CREATE",
				RTM: "DIRECT",
				sPurchaseAgreement: "HPETC",
				sPersona: "SALES_OPS",
				sHeaderSMC: "E"
			});
			this._AVCUtils.onInit(this);
			this._PCE_AVC_Utils.onInit(this);
			sap.ui.Device.orientation.attachHandler(function (oEvent) {
				__oCtrlContext__._PickProductUtils.fnOrientationChange(oEvent);
			});
			//SOC MSHEKHARDELO: Custom header for mobile app
			if (oUriParameters.get("sap-ushell-config") !== null) {
				var navCont = this.byId("pickPrd_navContId");
				navCont.attachAfterNavigate(function (oEvent) {
					this.byId("idCustomNavBack").setVisible(oEvent.getSource().getCurrentPage().getId() !== oEvent.getSource().getPages()[0].getId());
				}.bind(this));
			}
			//EOC MSHEKHARDELO: Custom header for mobile app

		},
		_handleRouteMatched: function (oEvent) {
			this.getModel("GlobalModel").setProperty("/routerArgumentsSearch", oEvent.getParameters()); //MSHEKHARDELO: service catalog navigational changes
			var sParameterName = oEvent.getParameter("name");
			if (sParameterName !== "MAIN" && sParameterName !== "MAINCatalog" && sParameterName !== "MAINProduct" && sParameterName !== "MAINCart" && sParameterName !== "MAINCartEdit") {
				return;
			} else if (this.bIsInitial && (sParameterName === "MAIN" || sParameterName === "MAINCart" || sParameterName === "MAINCartEdit")) {
				this._PickProductUtils.onOpenPickProduct();
				this.bIsInitial = false;
			} else if (sParameterName === "MAINCatalog" || sParameterName === "MAINProduct" || (!this.bIsInitial && (sParameterName === "MAINCart" || sParameterName === "MAINCartEdit"))) {
				if (this.bIsInitial) {
					this.bIsInitial = false;
				}
					this.oSetDafaultValDone.done(function () {
						var sCatalogId = oEvent.getParameters().arguments.CatalogId,
							sProductId = oEvent.getParameters().arguments.ProductId;
						this._PickProductUtils.navServiceCatalogPriceCalc(sParameterName, sCatalogId, sProductId);
						return;
					}.bind(this));
				// } 
				// else {
				// 	var sCatalogId = oEvent.getParameters().arguments.CatalogId,
				// 		sProductId = oEvent.getParameters().arguments.ProductId;
				// 	this._PickProductUtils.navServiceCatalogPriceCalc(sParameterName, sCatalogId, sProductId);
				// 	return;
				// }
			}
		},

		__getFnCurrencyIncoTerms: function () {
			// this.__getFnCurrency();
			this.fnGetCurrencyIncoTerms();
			this.__getFnIncoTerms();
		},

		fnGetCurrencyIncoTerms: function () {
			var _oReadOptions = {};
			_oReadOptions["oModel"] = this.getModel("ZCV_VH_COUNTRYCURRENCY_CDS");
			_oReadOptions["sPath"] = "/ZCV_VH_COUNTRYCURRENCY";
			_oReadOptions["oSorters"] = [new Sorter("Country")];
			_oReadOptions["oURIParameters"] = {
				"$expand": "to_vhCurrency"
			};
			_oReadOptions["bGlobalBusy"] = false;

			_oReadOptions["fnSuccess"] = function (oData, oResponse) {
				if (oData.results) {
					var aCurrencyIncoTerm = [];

					oData.results.forEach(function (obj) {
						if (obj.to_vhCurrency.results.length > 0) {
							aCurrencyIncoTerm.push({
								Country: obj["Country"],
								Country_LongDesc: obj["Country_LongDesc"],
								Country_ShortDesc: obj["Country_ShortDesc"],
								DistChannel: obj["DistChannel"],
								Division: obj["Division"],
								SalesArea: obj["SalesArea"],
								SalesOrg: obj["SalesOrg"],
								to_vhCurrencys: [],
								to_vhIncoTerms: []
							});

							var __iCountryIdx = aCurrencyIncoTerm.findIndex(function (oCountry) {
								return oCountry.Country === obj["Country"];
							}),
								__bCountryExists = __iCountryIdx > -1 ? true : false;
							if (__bCountryExists) {

								obj.to_vhCurrency.results.forEach(function (oVhCurr) {
									var __iCurrencyIdx = aCurrencyIncoTerm[__iCountryIdx].to_vhCurrencys.findIndex(function (oCurr) {
										return oCurr.Currency === oVhCurr.Currency;
									}),
										__iIncoTermIdx = aCurrencyIncoTerm[__iCountryIdx].to_vhIncoTerms.findIndex(function (oIncoTerm) {
											return oIncoTerm.IncoTerm === oVhCurr.IncoTerm;
										}),
										__bCurrencyExists = __iCurrencyIdx > -1 ? true : false,
										__bIncoTermExists = __iIncoTermIdx > -1 ? true : false;

									if (!__bCurrencyExists) {
										aCurrencyIncoTerm[__iCountryIdx].to_vhCurrencys.push({
											Currency: oVhCurr["Currency"],
											Curr_Code: oVhCurr["Curr_Code"],
											Curr_Desc: oVhCurr["Curr_Desc"],
											DefaultFlag: oVhCurr["DefaultFlag"],
											HPEFSFlag: oVhCurr["HPEFSFlag"]
										});
									}

									if (!__bIncoTermExists) {
										aCurrencyIncoTerm[__iCountryIdx].to_vhIncoTerms.push({
											IncoTerm: oVhCurr["IncoTerm"],
											IncoTerm_Code: oVhCurr["IncoTerm_Code"],
											IncoTerm_Desc: oVhCurr["IncoTerm_Desc"],
											DefaultFlag: oVhCurr["DefaultFlag"],
											HPEFSFlag: oVhCurr["HPEFSFlag"]
										});
									}

								});
							}
						}
					});

					this.getModel("viewData").setProperty("/aCurrencyIncoTerms", aCurrencyIncoTerm);
					this.fnGetSavedEstimate();
				}
			}.bind(this);

			this.__readODataOperation(_oReadOptions);
		},

		/*	__getFnCurrency: function () {
				var _oReadOptions = {};

				_oReadOptions["oModel"] = this.getModel();
				_oReadOptions["sPath"] = "/Ets_Vh_Currency";
				_oReadOptions["bGlobalBusy"] = false;

				_oReadOptions["oURIParameters"] = {
					"$format": "json"
				};

				_oReadOptions["fnSuccess"] = function (oData, oResponse) {
					__oCtrlContext__.getModel("viewData").setProperty("/EtsCurrency", oData.results);
				}.bind(this);

				this.__readODataOperation(_oReadOptions);

			},*/

		__getFnIncoTerms: function () {
			var _oReadOptions = {};

			_oReadOptions["oModel"] = this.getModel();
			_oReadOptions["sPath"] = "/Ets_Vh_IncoTerms";
			_oReadOptions["bGlobalBusy"] = false;

			_oReadOptions["oURIParameters"] = {
				"$format": "json"
			};

			_oReadOptions["fnSuccess"] = function (oData, oResponse) {
				__oCtrlContext__.getModel("viewData").setProperty("/EtsIncoTerms", oData.results);
			}.bind(this);

			this.__readODataOperation(_oReadOptions);
		},

		getRandomNumber: function () {
			var randomNos = __randomNumberRange__;
			var x = 1;

			if (__randomNumberRange__.length === 0) {
				__randomNumberRange__.push(x);
			} else {
				x = __randomNumberRange__[(__randomNumberRange__.length - 1)] + 1;
				__randomNumberRange__.push(x);
			}

			return x;
		},

		onBtnSaveEstimate: function () {
			var sUserId,
				oStorageData = {},
				oViewModel = this.getModel("viewData"),
				oPickProductMdl = this.getModel("pickProductMdl"),
				oStorage = new Storage(Storage.Type.local),
				sSuccessMsg = this.getResourceBundle().getText("xmsg.PriceCalc.EstimatedSaved");
			if (sap.ushell) {
				sUserId = sap.ushell.Container.getUser().getId();
			}
			oStorageData = {
				"__UserId": sUserId,
				"SALESAREA": oViewModel.getProperty("/SalesArea"),
				"COUNTRY": oViewModel.getProperty("/Country_Code"),
				"COUNTRY_DESC": oViewModel.getProperty("/Country"),
				"CURRENCY": oViewModel.getProperty("/Currency"),
				"INCOTERM": oViewModel.getProperty("/IncoTerms"),
				"CARTDTLS": oPickProductMdl.getProperty("/productCart"),
				"CARTCOUNT": oPickProductMdl.getProperty("/cartItemsCount")
			};

			oStorage.put("com.hpe.it.ui5.asq.zui5_priccalc.estimates", JSON.stringify(oStorageData));
			MessageToast.show(sSuccessMsg);
		},

		fnGetSavedEstimate: function () {
			var sUserId,
				oStorageData = {},
				oViewModel = this.getModel("viewData"),
				oPickProductMdl = this.getModel("pickProductMdl"),
				oStorage = new Storage(Storage.Type.local);

			if (oStorage.get("com.hpe.it.ui5.asq.zui5_priccalc.estimates")) {
				oStorageData = JSON.parse(oStorage.get("com.hpe.it.ui5.asq.zui5_priccalc.estimates"));

				if (sap.ushell) {
					sUserId = sap.ushell.Container.getUser().getId();
				}

				if (sUserId === oStorageData["__UserId"]) {
					oViewModel.setProperty("/SalesArea", oStorageData["SALESAREA"]);
					oViewModel.setProperty("/Country_Code", oStorageData["COUNTRY"]);
					oViewModel.setProperty("/Country", oStorageData["COUNTRY_DESC"]);
					oViewModel.setProperty("/Currency", oStorageData["CURRENCY"]);
					oViewModel.setProperty("/IncoTerms", oStorageData["INCOTERM"]);
					oPickProductMdl.setProperty("/productCart", oStorageData["CARTDTLS"]);
					oPickProductMdl.setProperty("/cartItemsCount", oStorageData["CARTCOUNT"]);

					__oCtrlContext__._PickProductUtils.fnSetDefaultVals(true, oStorageData["COUNTRY"]);
				} else {
					__oCtrlContext__._PickProductUtils.fnSetDefaultVals(true);
				}
			} else {
				__oCtrlContext__._PickProductUtils.fnSetDefaultVals(true);
			}
		},
		formatNegative: function (discount) {
			if (discount.indexOf("-") > 0) {
				discount = (parseFloat(discount) * -1).toFixed(9);
			}
			return discount;
		},
		//SOC MSHEKHARDELO: Custom header for mobile app 10/07/2024
		onPressCustomNavBack: function (oEvent) {
			var oPickPrd_navCon = this.byId("pickPrd_navContId");
			if (oPickPrd_navCon.getCurrentPage().getId() === oPickPrd_navCon.getPages()[1].getId() ||
				oPickPrd_navCon.getCurrentPage().getId() === oPickPrd_navCon.getPages()[2].getId()) {
				oPickPrd_navCon.to(oPickPrd_navCon.getPages()[0].getId());
				this.getModel("pickProductMdl").setProperty("/bPrdCatSelVisibility", true);
				this.byId("idSub2CatProducts").removeSelections();
			} else if (oPickPrd_navCon.getCurrentPage().getId() === oPickPrd_navCon.getPages()[3].getId()) {
				oPickPrd_navCon.to(oPickPrd_navCon.getPages()[0].getId());
				this.getModel("pickProductMdl").setProperty("/bPrdCatSelVisibility", true);
				this.byId("idSub2CatProducts").removeSelections();
			}
		}
		//EOC MSHEKHARDELO: Custom header for mobile app 10/07/2024

	});

});