sap.ui.define([
	"som/ssv/controller/BaseController",
	"sap/ui/core/ComponentContainer"
], function (BaseController, ComponentContainer) {
	"use strict";

	return BaseController.extend("som.ssv.controller.CoTerm", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf som.ssv.view.coterm
		 */
		onInit: function () {
			jQuery.sap.registerModulePath("zcpq.coterm.Z_CPQ_COTERM", "/sap/bc/ui5_ui5/sap/z_cpq_coterm");
			sap.ui.core.UIComponent.getRouterFor(this).attachRoutePatternMatched(this.onRoutePatternMatched, this);
		},

		onRoutePatternMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "CoTerm") {
				var oPageId = this.getView().byId("pageId_coterm");

				oPageId.removeAllContent();
				var oCotermComponent = new ComponentContainer({
					height: "98%",
					name: "zcpq.coterm.Z_CPQ_COTERM",
					manifest: true,
					async: true,
					component: "z_cpq_coterm"
				});
				oPageId.addContent(oCotermComponent);

			}
		}

	});

});