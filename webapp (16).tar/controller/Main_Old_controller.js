// for Cloud Credit Report - /*SOC BADH EAGLE-SOME4028B 2021/11/08*/
		// _Report5: function (bInternal) {
		// 	var aPartyToken = this.getView().byId("idPartyIDCCC"),
		// 		aPartyId = [],
		// 		oModel = this.getView().getModel("viewData");
		// 	for (var u = 0; u < aPartyToken.getTokens().length; u++) {
		// 		var t1 = aPartyToken.getTokens()[u].getText();
		// 		aPartyId.push(t1);
		// 	}

		// 	var partyType = this.getView().byId("idPartyTypeCCC").getSelectedKey(),
		// 		partyID = this.getView().byId("idPartyIDCCC").getValue(),
		// 		contractLowDate = this.getView().byId("idDateRangeContractCCC").getDateValue(),
		// 		contractHighDate = this.getView().byId("idDateRangeContractCCC").getSecondDateValue(),
		// 		HPESolQuLowDate = this.getView().byId("idDateRangeHPESolQuCCC").getDateValue(),
		// 		HPESolQuHighDate = this.getView().byId("idDateRangeHPESolQuCCC").getSecondDateValue(),
		// 		HPEQuotLowDate = this.getView().byId("idDateRangeHPEQuoteCCC").getDateValue(),
		// 		HPEQuotHighDate = this.getView().byId("idDateRangeHPEQuoteCCC").getSecondDateValue(),
		// 		documentType = "ZQST";

		// 	var billingType = this.getView().byId("idBillingTypeCCC").getSelectedKey(),
		// 		invoiceFreq = this.getView().byId("idInvoiceFreqCCC").getValue(),
		// 		ContractStatus = this.getView().byId("idContractStatusCCC").getSelectedKey(),
		// 		HPEQuotNo = this.getView().byId("idHPEQuotNoCCC").getValue(),
		// 		regionID = this.getView().byId("idRegionCCC").getSelectedKey(),
		// 		idCountry = this.getView().byId("idCountryCCC"),
		// 		countryTokens = idCountry.getTokens();

		// 	contractLowDate = formatter.changeDateToUTC(contractLowDate);
		// 	contractHighDate = formatter.changeDateToUTC(contractHighDate);
		// 	HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
		// 	HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
		// 	HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
		// 	HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);

		// 	var aTokens = [];
		// 	countryTokens.forEach(function (data) {
		// 		var t = data.getKey();
		// 		aTokens.push(t);
		// 	});
		// 	var arr2 = [];
		// 	var obj2 = {};
		// 	var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

		// 	if ((this.fnGetParamExistsInURI("i_t") || this.fnGetParamExistsInURI("s")) || (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") !== "SALES_OPS")) {
		// 		var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
		// 		var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
		// 		var l_pricingVisibility = localPunchoutData.Pricingvisibility,
		// 			l_pricingVisibility = l_pricingVisibility.toString(),
		// 			l_userType = localPunchoutData.Usertype;
		// 		if (localPunchoutData.tierMapping.results.length !== 0) {
		// 			var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
		// 		} else {
		// 			l_tierMapping = "";
		// 		}
		// 		if (localPunchoutData.userDetails.results.length !== 0) {
		// 			var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
		// 				"," + localPunchoutData.userDetails.results[0].Visibilitytype +
		// 				"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype;

		// 		} else {
		// 			l_userDetails = "";
		// 		}

		// 		var l_orderNumber = localPunchoutData_Details.orderNumber,
		// 			l_emailId = localPunchoutData_Details.emailId,
		// 			l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
		// 		l_emailId = l_emailId.split("|")[0];
		// 	}

		// 	if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
		// 		//Checks mandatory fields for Non-INTERNAL users
		// 		MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
		// 		this.getView().setBusy(false);
		// 	} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
		// 		HPEQuotLowDate === null || HPEQuotHighDate === null)) && bInternal) {
		// 		//Checks mandatory fields for INTERNAL users
		// 		MessageBox.error("Please fill the mandatory date fields.");
		// 		this.getView().setBusy(false);
		// 	} else {
		// 		var _exeRpt5fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
		// 			// Begin Defect 10555 GASINGHDELOI
		// 			if (partyType === "") {
		// 				//BEGIN jmezadeloitte defect 12427
		// 				if (nLenOfPayload === undefined) {
		// 					var data = {
		// 						"emailId": l_emailId,
		// 						"orderNumber": l_orderNumber,
		// 						"HPEQuoteNo": l_brimSolQuote,
		// 						"pricingVisibility": l_pricingVisibility,
		// 						"userType": l_userType,
		// 						"zcontractNo": "",
		// 						"zcontractItem": "",
		// 						"cloudCreditReportNav": []
		// 					};
		// 					obj2 = {
		// 						"creationStartDate": HPESolQuLowDate,
		// 						"creationEndDate": HPESolQuHighDate,
		// 						"contractStartDateB": HPEQuotLowDate,
		// 						"contractStartDateE": HPEQuotHighDate,
		// 						"contractSatus": ContractStatus,
		// 						"distributorID": "",
		// 						"resellerID": "",
		// 						"endCustID": "",
		// 						"endCustName": "",
		// 						"contractEndDateB": contractLowDate,
		// 						"contractEndDateE": contractHighDate,
		// 						"Country": "",
		// 						"Region": regionID,
		// 						"docType": documentType,
		// 						"billType": billingType,
		// 						"frequency": invoiceFreq,
		// 						"HPEQuoteNo": HPEQuotNo
		// 					};
		// 					data.cloudCreditReportNav.push(obj2);
		// 				} else {
		// 					if (nLenOfPayload === 0) {
		// 						var data = {
		// 							"emailId": l_emailId,
		// 							"orderNumber": l_orderNumber,
		// 							"HPEQuoteNo": l_brimSolQuote,
		// 							"pricingVisibility": l_pricingVisibility,
		// 							"userType": l_userType,
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"cloudCreditReportNav": arr2
		// 						};
		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": "",
		// 							"resellerID": "",
		// 							"endCustID": "",
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": "",
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};
		// 						arr2.push(obj2);
		// 					} else {
		// 						for (var i = 0; i < nLenOfPayload; i++) {
		// 							var data = {
		// 								"emailId": l_emailId,
		// 								"orderNumber": l_orderNumber,
		// 								"HPEQuoteNo": l_brimSolQuote,
		// 								"pricingVisibility": l_pricingVisibility,
		// 								"userType": l_userType,
		// 								"zcontractNo": "",
		// 								"zcontractItem": "",
		// 								"cloudCreditReportNav": arr2
		// 							};
		// 							if (aTokens[i] !== undefined) {
		// 								var sCountryVal = aTokens[i];
		// 							} else {
		// 								sCountryVal = "";
		// 							}
		// 							obj2 = {
		// 								"creationStartDate": HPESolQuLowDate,
		// 								"creationEndDate": HPESolQuHighDate,
		// 								"contractStartDateB": HPEQuotLowDate,
		// 								"contractStartDateE": HPEQuotHighDate,
		// 								"contractSatus": ContractStatus,
		// 								"distributorID": "",
		// 								"resellerID": "",
		// 								"endCustID": "",
		// 								"endCustName": "",
		// 								"contractEndDateB": contractLowDate,
		// 								"contractEndDateE": contractHighDate,
		// 								"Country": sCountryVal,
		// 								"Region": regionID,
		// 								"docType": documentType,
		// 								"billType": billingType,
		// 								"frequency": invoiceFreq,
		// 								"HPEQuoteNo": HPEQuotNo
		// 							};
		// 							arr2.push(obj2);
		// 						}
		// 					}
		// 				} //END jmezadeloitte defect 12427
		// 			}
		// 			//if (partyType === "1") {
		// 			else if (partyType === "1") {
		// 				// End Defect 10555 GASINGHDELOI
		// 				if ((!this.fnGetParamExistsInURI("i_t")||!this.fnGetParamExistsInURI("s")) && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
		// 					for (var i = 0; i < nLenOfPayload; i++) {
		// 						var data = {
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"cloudCreditReportNav": arr2
		// 						};

		// 						if (aPartyId[i] !== undefined) {
		// 							var nPartyIDVal = aPartyId[i];
		// 						} else {
		// 							nPartyIDVal = "";
		// 						}
		// 						if (aTokens[i] !== undefined) {
		// 							var sCountryVal = aTokens[i];
		// 						} else {
		// 							sCountryVal = "";
		// 						}

		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": nPartyIDVal,
		// 							"resellerID": "",
		// 							"endCustID": "",
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": sCountryVal,
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};

		// 						arr2.push(obj2);

		// 					}
		// 				} else {

		// 					for (var i = 0; i < nLenOfPayload; i++) {
		// 						var data = {
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"emailId": l_emailId,
		// 							"orderNumber": l_orderNumber,
		// 							"HPEQuoteNo": l_brimSolQuote,
		// 							"pricingVisibility": l_pricingVisibility,
		// 							"userType": l_userType,
		// 							"cloudCreditReportNav": arr2,
		// 							"tierMappingNav": [{
		// 								"tierMapping": l_tierMapping
		// 							}],
		// 							"userDetailsNav": [{
		// 								"userDetails": l_userDetails
		// 							}]

		// 						};
		// 						if (aPartyId[i] !== undefined) {
		// 							var nPartyIDVal = aPartyId[i];
		// 						} else {
		// 							nPartyIDVal = "";
		// 						}
		// 						if (aTokens[i] !== undefined) {
		// 							var sCountryVal = aTokens[i];
		// 						} else {
		// 							sCountryVal = "";
		// 						}

		// 						//if(jQuery.sap.getUriParameters().get("i_t")===null){

		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": nPartyIDVal,
		// 							"resellerID": "",
		// 							"endCustID": "",
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": sCountryVal,
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};

		// 						arr2.push(obj2);

		// 					}

		// 				}

		// 			} else if (partyType === "2") {
		// 				if ((!this.fnGetParamExistsInURI("i_t")||!this.fnGetParamExistsInURI("s")) && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
		// 					for (var i = 0; i < nLenOfPayload; i++) {
		// 						var data = {
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"cloudCreditReportNav": arr2
		// 						};

		// 						if (aPartyId[i] !== undefined) {
		// 							nPartyIDVal = aPartyId[i];
		// 						} else {
		// 							nPartyIDVal = "";
		// 						}
		// 						if (aTokens[i] !== undefined) {
		// 							sCountryVal = aTokens[i];
		// 						} else {
		// 							sCountryVal = "";
		// 						}

		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": "",
		// 							"resellerID": nPartyIDVal,
		// 							"endCustID": "",
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": sCountryVal,
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};
		// 						arr2.push(obj2);
		// 					}
		// 				} else {

		// 					for (var i = 0; i < nLenOfPayload; i++) {
		// 						var data = {
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"emailId": l_emailId,
		// 							"orderNumber": l_orderNumber,
		// 							"HPEQuoteNo": l_brimSolQuote,
		// 							"pricingVisibility": l_pricingVisibility,
		// 							"userType": l_userType,
		// 							"cloudCreditReportNav": arr2,
		// 							"tierMappingNav": [{
		// 								"tierMapping": l_tierMapping
		// 							}],
		// 							"userDetailsNav": [{
		// 								"userDetails": l_userDetails
		// 							}]

		// 						};
		// 						if (aPartyId[i] !== undefined) {
		// 							nPartyIDVal = aPartyId[i];
		// 						} else {
		// 							nPartyIDVal = "";
		// 						}
		// 						if (aTokens[i] !== undefined) {
		// 							sCountryVal = aTokens[i];
		// 						} else {
		// 							sCountryVal = "";
		// 						}

		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": "",
		// 							"resellerID": nPartyIDVal,
		// 							"endCustID": "",
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": sCountryVal,
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};
		// 						arr2.push(obj2);

		// 					}

		// 				}

		// 			} else if (partyType === "3") {
		// 				if ((!this.fnGetParamExistsInURI("i_t") || !this.fnGetParamExistsInURI("s")) && (oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS")) {
		// 					for (var i = 0; i < nLenOfPayload; i++) {
		// 						var data = {
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"cloudCreditReportNav": arr2
		// 						};

		// 						if (aPartyId[i] !== undefined) {
		// 							nPartyIDVal = aPartyId[i];
		// 						} else {
		// 							nPartyIDVal = "";
		// 						}
		// 						if (aTokens[i] !== undefined) {
		// 							sCountryVal = aTokens[i];
		// 						} else {
		// 							sCountryVal = "";
		// 						}

		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": "",
		// 							"resellerID": "",
		// 							"endCustID": nPartyIDVal,
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": sCountryVal,
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};
		// 						arr2.push(obj2);
		// 					}
		// 				} else {

		// 					for (var i = 0; i < nLenOfPayload; i++) {
		// 						var data = {
		// 							"zcontractNo": "",
		// 							"zcontractItem": "",
		// 							"emailId": l_emailId,
		// 							"orderNumber": l_orderNumber,
		// 							"HPEQuoteNo": l_brimSolQuote,
		// 							"pricingVisibility": l_pricingVisibility,
		// 							"userType": l_userType,
		// 							"cloudCreditReportNav": arr2,
		// 							"tierMappingNav": [{
		// 								"tierMapping": l_tierMapping
		// 							}],
		// 							"userDetailsNav": [{
		// 								"userDetails": l_userDetails
		// 							}]

		// 						};
		// 						if (aPartyId[i] !== undefined) {
		// 							nPartyIDVal = aPartyId[i];
		// 						} else {
		// 							nPartyIDVal = "";
		// 						}
		// 						if (aTokens[i] !== undefined) {
		// 							sCountryVal = aTokens[i];
		// 						} else {
		// 							sCountryVal = "";
		// 						}

		// 						obj2 = {
		// 							"creationStartDate": HPESolQuLowDate,
		// 							"creationEndDate": HPESolQuHighDate,
		// 							"contractStartDateB": HPEQuotLowDate,
		// 							"contractStartDateE": HPEQuotHighDate,
		// 							"contractSatus": ContractStatus,
		// 							"distributorID": "",
		// 							"resellerID": "",
		// 							"endCustID": nPartyIDVal,
		// 							"endCustName": "",
		// 							"contractEndDateB": contractLowDate,
		// 							"contractEndDateE": contractHighDate,
		// 							"Country": sCountryVal,
		// 							"Region": regionID,
		// 							"docType": documentType,
		// 							"billType": billingType,
		// 							"frequency": invoiceFreq,
		// 							"HPEQuoteNo": HPEQuotNo
		// 						};
		// 						arr2.push(obj2);

		// 					}

		// 				}
		// 			}

		// 			this.getView().setBusy(true);
		// 			var oServiceModel = this._getODataModel();

		// 			var sPath = "/Ets_cloudCreditRep";

		// 			var mParameters = {
		// 				method: "POST",
		// 				success: jQuery.proxy(function (oData) {
		// 					this.getView().setBusy(false);

		// 					if (oData.errorMsg.length !== 0) {
		// 						var errMasg = oData.errorMsg;
		// 						MessageBox.error(errMasg);
		// 					} else {
		// 						var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_CloudCredRepFile('" + oData.zguid22 + "')/$value";
		// 						window.open(sUrl, "_blank");
		// 					}

		// 				}, this),

		// 				error: jQuery.proxy(function (oError) {

		// 					this.getView().setBusy(false);
		// 					var oMessage = oError.headers.errorMsg;
		// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
		// 					if (typeof oMessage !== "undefined") {
		// 						oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
		// 					} else if (oError.statusCode === "502") { // Timeout issue
		// 						oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
		// 					} else {
		// 						oMessage = oError.message;
		// 					}
		// 					MessageBox.error(oMessage, {
		// 						icon: sap.m.MessageBox.Icon.ERROR,
		// 						title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
		// 					});
		// 					// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
		// 				}, this)
		// 			};

		// 			oServiceModel.create(sPath, data, mParameters);
		// 			/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
		// 		}.bind(this);

		// 		var sMsgDateValidRpt5 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
		// 			bMsgDateValidRpt5 = true;

		// 		if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
		// 			if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
		// 				bMsgDateValidRpt5 = false;
		// 			}
		// 		}

		// 		if (contractHighDate !== null && contractLowDate !== null) {
		// 			if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
		// 				bMsgDateValidRpt5 = false;
		// 			}
		// 		}

		// 		if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
		// 			if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
		// 				bMsgDateValidRpt5 = false;
		// 			}
		// 		}

		// 		if (!bMsgDateValidRpt5) {

		// 			this.getView().setBusy(false);

		// 			MessageBox.show(
		// 				sMsgDateValidRpt5, {
		// 				icon: MessageBox.Icon.WARNING,
		// 				title: "Warning",
		// 				actions: ["Proceed", MessageBox.Action.CANCEL],
		// 				emphasizedAction: MessageBox.Action.CANCEL,
		// 				onClose: function (oAction) {
		// 					if (oAction === "Proceed") {
		// 						_exeRpt5fn();
		// 					}
		// 				}
		// 			}
		// 			);

		// 		} else {
		// 			_exeRpt5fn();
		// 		}

		// 		/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
		// 	}

		// },
		/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

        	// fnCheckHPEDateReport3: function () {
		// 	if (!this.fnGetParamExistsInURI("i_t")|| !this.fnGetParamExistsInURI("s") ) {
		// 		var dateVal = this.getView().byId("idDateRangeHPEQuoteUAR");
		// 		var dateString = this.getView().byId("idDateRangeHPEQuoteUAR").mProperties.value;
		// 		this.fnOnchangeDateValForReport(dateVal, dateString);
		// 	}

		// },
		// fnCheckSolHPEDateReport3: function () {
		// 	if (!this.fnGetParamExistsInURI("i_t")|| !this.fnGetParamExistsInURI("s") ) {
		// 		var dateVal = this.getView().byId("idDateRangeHPESolQuUAR");
		// 		var dateString = this.getView().byId("idDateRangeHPESolQuUAR").mProperties.value;
		// 		this.fnOnchangeDateValForReport(dateVal, dateString);
		// 	}

		// },
		// fnCheckContractDateReport3: function () {
		// 	if (!this.fnGetParamExistsInURI("i_t")|| !this.fnGetParamExistsInURI("s") ) {
		// 		var dateVal = this.getView().byId("idDateRangeContractUAR");
		// 		var dateString = this.getView().byId("idDateRangeContractUAR").mProperties.value;
		// 		this.fnOnchangeDateValForReport(dateVal, dateString);
		// 	}

		// },
		/*SOC BADH EAGLE-SOME4028B 2021/11/08*/
		// fnCheckHPEDateReport5: function () {
		// 	if (!this.fnGetParamExistsInURI("i_t")|| !this.fnGetParamExistsInURI("s") ) {
		// 		var dateVal = this.getView().byId("idDateRangeHPEQuoteCCC");
		// 		var dateString = this.getView().byId("idDateRangeHPEQuoteCCC").mProperties.value;
		// 		this.fnOnchangeDateValForReport(dateVal, dateString);
		// 	}

		// },
		// fnCheckSolHPEDateReport5: function () {
		// 	if (!this.fnGetParamExistsInURI("i_t")|| !this.fnGetParamExistsInURI("s") ) {
		// 		var dateVal = this.getView().byId("idDateRangeHPESolQuCCC");
		// 		var dateString = this.getView().byId("idDateRangeHPESolQuCCC").mProperties.value;
		// 		this.fnOnchangeDateValForReport(dateVal, dateString);
		// 	}

		// },
		// fnCheckContractDateReport5: function () {
		// 	if (!this.fnGetParamExistsInURI("i_t")|| !this.fnGetParamExistsInURI("s") ) {
		// 		var dateVal = this.getView().byId("idDateRangeContractCCC");
		// 		var dateString = this.getView().byId("idDateRangeContractCCC").mProperties.value;
		// 		this.fnOnchangeDateValForReport(dateVal, dateString);
		// 	}

		// },
		/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

        //Open Value help Box for Country
		// handleValueHelpCountryUAR: function (oEvent) {
		// 	this.flagCountry = "UAR";

		// 	if (!this._oCountry) {
		// 		this._oCountry = sap.ui.xmlfragment("som.ssv.fragments.ValueHelpCountry", this);
		// 		this.getView().addDependent(this._oCountry);
		// 		// Remember selections if required
		// 		this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
		// 		// toggle compact style
		// 		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
		// 	}

		// 	var region = this.getView().byId("idRegionUAR").getSelectedKey();
		// 	this._getCountry(region);

		// 	this._oCountry.open();

		// },

		//for excel copy paste of Country
		// onTokenUpdateCountryUAR: function (oEvt) {
		// 	var idCountry = this.getView().byId("idCountryUAR");
		// 	idCountry.addValidator(this._multiInputValidator);
		// },

        //Arjun code merge functions
		/*SOC BADH EAGLE-SOME4028B 2021/10/28*/
		// handleValueHelpCountryCCC: function (oEvent) {
		// 	this.flagCountry = "CCC";

		// 	if (!this._oCountry) {
		// 		this._oCountry = sap.ui.xmlfragment("som.ssv.fragments.ValueHelpCountry", this);
		// 		this.getView().addDependent(this._oCountry);
		// 		// Remember selections if required
		// 		this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
		// 		// toggle compact style
		// 		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
		// 	}

		// 	var region = this.getView().byId("idRegionCCC").getSelectedKey();
		// 	this._getCountry(region);

		// 	this._oCountry.open();
		// },
		/*EOC BADH EAGLE-SOME4028B 2021/10/28*/

        /*SOC BADH EAGLE-SOME4028B 2021/11/08*/
		// fnOnChanPartyCCCRep: function () {

		// 	var oServiceModel = this._getODataModel();
		// 	var sPath = "/Ets_validatePartner";
		// 	this.getView().setBusy(true);
		// 	var partyID = this.getView().byId("idPartyIDCCC").getValue();
		// 	var oFilters = [];
		// 	var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
		// 	oFilters.push(CustID);

		// 	var mParameters = {
		// 		method: "GET",
		// 		filters: oFilters,
		// 		success: jQuery.proxy(function (oData) {
		// 			this.getView().setBusy(false);
		// 			//	MessageBox.success("Filter Pass");

		// 		}, this),
		// 		error: jQuery.proxy(function (oError) {
		// 			this.getView().setBusy(false);

		// 			var msg = JSON.parse(oError.responseText).error.message.value;
		// 			MessageBox.error(msg);
		// 		}, this)
		// 	};

		// 	oServiceModel.read(sPath, mParameters);
		// },
		/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

		// fnValidatePartyId: function (aPatryIDs) {

		// 	var aParyIDVals = aPatryIDs;

		// 	var oModel = this.getView().getModel("viewData");
		// 	var oServiceModel = this._getODataModel();

		// 	var sPath = "/Ets_defaultUrls";

		// 	var mParameters = {
		// 		method: "GET",
		// 		success: jQuery.proxy(function (oData) {

		// 			if (oData !== "") {

		// 				var nPartyData = oData.results;

		// 				var aMatchedPartyVals = nPartyData.filter(function (val) {
		// 					return aParyIDVals.indexOf(val) != -1;
		// 				});

		// 				if (aMatchedPartyVals.length === aParyIDVals.length) {

		// 				} else {

		// 					MessageBox.error("Party Ids are not valid");
		// 				}

		// 			}

		// 		}, this),
		// 		error: jQuery.proxy(function (oError) {
		// 			var k = 0;

		// 		}, this)
		// 	};

		// 	oServiceModel.read(sPath, mParameters);

		// },

		// Common function to validate party id for all the report ( in case of punchout)
		// fnValidatePartyPunchout: function (aPatryIDs) {

		// 	var aParyIDVals = aPatryIDs;

		// 	var oModel = this.getView().getModel("viewData");
		// 	var oServiceModel = this._getODataModel();

		// 	var sPath = "/Ets_defaultUrls";

		// 	var mParameters = {
		// 		method: "GET",
		// 		success: jQuery.proxy(function (oData) {

		// 			if (oData !== "") {

		// 				var nPartyData = oData.results;

		// 				var aMatchedPartyVals = nPartyData.filter(function (val) {
		// 					return aParyIDVals.indexOf(val) != -1;
		// 				});

		// 				if (aMatchedPartyVals.length === aParyIDVals.length) {

		// 				} else {

		// 					MessageBox.error("Party Ids are not valid");
		// 				}

		// 			}

		// 		}, this),
		// 		error: jQuery.proxy(function (oError) {
		// 			var k = 0;

		// 		}, this)
		// 	};

		// 	oServiceModel.read(sPath, mParameters);

		// },

		// below function is used to validate the Party ID for the 3rd report

		// fnOnChanPartyUARRep: function () {

		// 	var oServiceModel = this._getODataModel();
		// 	var sPath = "/Ets_validatePartner";
		// 	this.getView().setBusy(true);
		// 	var partyID = this.getView().byId("idPartyIDUAR").getValue();
		// 	var oFilters = [];
		// 	var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
		// 	oFilters.push(CustID);

		// 	var mParameters = {
		// 		method: "GET",
		// 		filters: oFilters,
		// 		success: jQuery.proxy(function (oData) {
		// 			this.getView().setBusy(false);
		// 			//	MessageBox.success("Filter Pass");

		// 		}, this),
		// 		error: jQuery.proxy(function (oError) {
		// 			this.getView().setBusy(false);

		// 			var msg = JSON.parse(oError.responseText).error.message.value;
		// 			MessageBox.error(msg);
		// 		}, this)
		// 	};

		// 	oServiceModel.read(sPath, mParameters);
		// },

		//BOC AVERMA4 Defect 10555
		// validateInput: function (reportType) {
		// 	var raise_error = "";
		// 	if (reportType === "1") {
		// 		var RangeContract = this.getView().byId("idDateRangeContract").getDateValue();
		// 		var RangeActivation = this.getView().byId("idDateRangeActivation").getDateValue();

		// 		if (RangeContract === null && RangeActivation === null) {
		// 			raise_error = "X";
		// 		}

		// 	} else if (reportType === "2") {
		// 		var HPESolQuIAB = this.getView().byId("idDateRangeHPESolQuIAB").getDateValue();
		// 		var HPEQuoteIAB = this.getView().byId("idDateRangeHPEQuoteIAB").getDateValue();
		// 		var ContractIAB = this.getView().byId("idDateRangeContractIAB").getDateValue();
		// 		var InvoicingIAB = this.getView().byId("idDateRangeInvoicingIAB").getDateValue();

		// 		if (HPESolQuIAB === null && HPEQuoteIAB === null && ContractIAB === null && InvoicingIAB === null) {
		// 			raise_error = "X";
		// 		}

		// 	} else if (reportType === "3") {
		// 		var HPESolQuUAR = this.getView().byId("idDateRangeHPESolQuUAR").getDateValue();
		// 		var HPEQuoteUAR = this.getView().byId("idDateRangeHPEQuoteUAR").getDateValue();
		// 		var ContractUAR = this.getView().byId("idDateRangeContractUAR").getDateValue();

		// 		if (HPESolQuUAR === null && HPEQuoteUAR === null && ContractUAR === null) {
		// 			raise_error = "X";
		// 		}
		// 	} else if (reportType === "4") {
		// 		var scheduleLowDate = this.getView().byId("idDateScheduleStartDateDMI").getDateValue();

		// 		if (scheduleLowDate === null) {
		// 			raise_error = "X";
		// 		}
		// 	}

		// 	if (raise_error === "X") {
		// 		MessageBox.error("Please fill any of the dates to execute the report.");
		// 		return false;
		// 	} else {
		// 		return true;
		// 	}
		// },
		//EOC AVERMA4 Defect 10555