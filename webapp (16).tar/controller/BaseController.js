sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/base/util/UriParameters"
], function (Controller, UriParameters) {
	"use strict";
	
	var oUriParameters = new UriParameters(window.location.href); //ACHOPRADELOI RAMP-1458 2023/10/17
	
	return Controller.extend("som.ssv.controller.BaseController", {

		onInit: function () {

		},

		//get the router
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		// Get the serivce model
		
		getODataModel: function () {

			return this.getOwnerComponent().getModel();
		},
		

		//resource bundle for i18n in controller
		
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		

		getModel: function (sName) {
			if (sName) {
				return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
			} else {
				return this.getView().getModel() || this.getOwnerComponent().getModel();
			}
		},

		__openBusyDialog: function () { //Global Method to  Open Busy Dialog
			if (!this.__oBusyDialog) {
				var _oBusyDialog = new sap.m.BusyDialog();
				_oBusyDialog.removeAllCustomData();
				_oBusyDialog.addCustomData(new sap.ui.core.CustomData({
					"key": "bOpened",
					"value": false
				}));
				this.__oBusyDialog = _oBusyDialog;
				jQuery.sap.delayedCall(0, this, function () {
					this.__oBusyDialog.open();
				});

			} else {
				if (this.__oBusyDialog.data("bOpened") !== undefined && this.__oBusyDialog.data("bOpened") !== true) {
					this.__oBusyDialog.removeAllCustomData();
					this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
						"key": "bOpened",
						"value": true
					}));
					jQuery.sap.delayedCall(0, this, function () {
						this.__oBusyDialog.open();
					});
				}
			}
		},

		__closeBusyDialog: function () { //Global Method to Close Busy Dialog
			if (this.__oBusyDialog) {
				this.__oBusyDialog.removeAllCustomData();
				this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
					"key": "bOpened",
					"value": false
				}));
				this.__oBusyDialog.close();
			}
		},

		/*
		__readODataOperation: function (_options) {
			try {
				this.__openBusyDialog();
				var _oModel = _options.oModel,
					_oParameters = {};

				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add Filter Parameters
				if (_options.oFilters) {
					_oParameters["filters"] = _options.oFilters;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					this.__closeBusyDialog();
					_options.fnSuccess(oData, oResponse);
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					this.__closeBusyDialog();
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.read(_options.sPath, _oParameters);
				});
			} catch (err) {
				this.__closeBusyDialog();
			}
		},

		__deleteODataOperation: function (_options) {
			try {
				this.__openBusyDialog();
				var _oModel = _options.oModel,
					_oParameters = {};

				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					this.__closeBusyDialog();
					_options.fnSuccess(oData, oResponse);
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					this.__closeBusyDialog();
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.remove(_options.sPath, _oParameters);
				});

			} catch (err) {
				this.__closeBusyDialog();
			}
		},

		__updateODataOperation: function (_options) {
			try {
				this.__openBusyDialog();
				var _oModel = _options.oModel,
					_oParameters = {};

				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//Add Merge flag
				if (_options.bMerge) {
					_oParameters["merge"] = _options.bMerge;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					this.__closeBusyDialog();
					_options.fnSuccess(oData, oResponse);
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					this.__closeBusyDialog();
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.update(_options.sPath, _oParameters);
				});
			} catch (err) {
				this.__closeBusyDialog();
			}
		},

		__createODataOperation: function (_options) {
			try {
				this.__openBusyDialog();
				var _oModel = _options.oModel,
					_oParameters = {};

				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					this.__closeBusyDialog();
					_options.fnSuccess(oData, oResponse);
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					this.__closeBusyDialog();
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.create(_options.sPath, _options.oRequestBody, _oParameters);
				});
			} catch (err) {
				this.__closeBusyDialog();
			}
		},
		*/
		//SOC ACHOPRADELOI RAMP-1458 2023/10/17
		fnGetParamExistsInURI: function (param) {
			var __bOpptyExistsInURI = false;
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getOwnerComponent().getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null && __oURIParam.get(param) !== "") {
					__bOpptyExistsInURI = true;
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null && __aStartUpParameter[param] !== "") {
							__bOpptyExistsInURI = true;
						}
					}
				}
			} catch (err) {

			}
			return __bOpptyExistsInURI;
		},

		fnGetParamIdFrmURI: function (param) {
			var __sOpptyId;
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getOwnerComponent().getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null) {
					__sOpptyId = __oURIParam.get(param);
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null) {
							__sOpptyId = decodeURIComponent(__aStartUpParameter[param][0]);
						}
					}
				}
			} catch (err) {

			}
			return __sOpptyId;
		},

		// fnGetDecryptedParamID: function (param) {
		// 	return atob(param);
		// },

		fnGetParamValueFromQuery: function (param) {
			var rtValue = "";
			if (this.fnCheckOorQParamInHash()) {
				var q = this.fnGetOandQParamValuesFromHash().q,
				o= this.fnGetOandQParamValuesFromHash().o;
				if(q !== undefined && o !== undefined){
					var decryptedQuote = this.fnGetDecryptedParamIDs(q),
					 decryptedOrder = this.fnGetDecryptedParamIDs(o);
				}
					
				switch (param) {
				case "brimSolutionQuote":
					if(decryptedQuote !== undefined)
					{rtValue = decryptedQuote;}
					break;

				case "orderNumber":
					if(decryptedOrder !== undefined)
					{rtValue = decryptedOrder;}
					break;
				}
			}

			return rtValue;
		},

		fnSetUrlDataInMdl: function () {
			var oModel = this.getView().getModel("viewData"),
				brimSolutionQuote = this.fnGetParamValueFromQuery("brimSolutionQuote"),
				orderNumber = this.fnGetParamValueFromQuery("orderNumber"),
				emailId = 	oModel.getProperty("/EmailId"),
				userData = oModel.getProperty("/userData"),
				data = {
					"results": [{
						"asqpunchouturl": "",
						"brimSolutionQuote": brimSolutionQuote,
						"emailId": emailId,
						"orderNumber": orderNumber,
						"osvdefaulturl": "",
						"osvorderurl": "",
						"sfdccaseurl": "",
						"userData": userData
					}]
				};

			oModel.setProperty("/PunchOutData_Full", data);
			oModel.setProperty("/PunchOutData_Details", data.results[0]);
			if(userData && userData.results.length > 0) {
				oModel.setProperty("/PunchOutData", userData.results[0]);
			}
		},

		//get oData model
		_getODataModel: function () {
			return this.getOwnerComponent().getModel();
		},
		//EOC ACHOPRADELOI RAMP-1458 2023/10/17
		
		// Check if 'o' or 'q' parameters exist in the hash of a given URL
		fnCheckOorQParamInHash: function () {
			var bParamExists = false;
			try {
				// Extract hash from URL
				var hashIndex = window.location.href.indexOf('#');
				if (hashIndex !== -1) {
					var hash = window.location.href.substring(hashIndex + 1);
					
					// Check if hash contains query parameters
					var queryIndex = hash.indexOf('?');
					if (queryIndex !== -1) {
						var queryString = hash.substring(queryIndex + 1);
						
						// Create UriParameters from the query string
						var oHashUriParameters = new UriParameters("?" + queryString);
						
						// Check if 'o' or 'q' parameters exist
						if ((oHashUriParameters.get('o') !== undefined && oHashUriParameters.get('o') !== null && oHashUriParameters.get('o') !== "") ||
							(oHashUriParameters.get('q') !== undefined && oHashUriParameters.get('q') !== null && oHashUriParameters.get('q') !== "")) {
							bParamExists = true;
						}
					}
				}
			} catch (err) {
				// Handle any parsing errors
			}
			return bParamExists;
		},
		
		// Get values of 'o', 'q', and 'p' parameters from the hash of a given URL
		fnGetOandQParamValuesFromHash: function () {
			var oParamValues = {
				q: null,
				o: null,
				p: null
			};
			try {
				// Extract hash from URL
				var hashIndex = window.location.href.indexOf('#');
				if (hashIndex !== -1) {
					var hash = window.location.href.substring(hashIndex + 1);

					// Check if hash contains query parameters
					var queryIndex = hash.indexOf('?');
					if (queryIndex !== -1) {
						var queryString = hash.substring(queryIndex + 1);
						
						// Create UriParameters from the query string
						var oHashUriParameters = new UriParameters("?" + queryString);
						
						// Get values of 'q', 'o', and 'p' parameters
						var qValue = oHashUriParameters.get('q');
						var oValue = oHashUriParameters.get('o');
						var pValue = oHashUriParameters.get('p');
						
						if (qValue !== undefined && qValue !== null) {
							oParamValues.q = qValue;
						}
						
						if (oValue !== undefined && oValue !== null) {
							oParamValues.o = oValue;
						}
						
						if (pValue !== undefined && pValue !== null) {
							oParamValues.p = pValue;
						}
					}
				}
			} catch (err) {
				// Handle any parsing errors
			}
			return oParamValues;
		},
		
		fnGetDecryptedParamIDs: function (param) {
			var paramArr = param.split('').reverse().join('');
			return atob(paramArr);
		}
	});
});