sap.ui.define([
	"som/ssv/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/Tokenizer",
	"sap/ui/model/Filter",
	"sap/ui/export/Spreadsheet",
	"som/ssv/utils/formatter"
], function (BaseController, JSONModel, MessageToast, MessageBox, Token, Tokenizer, Filter, Spreadsheet, formatter) {
	"use strict";
	return BaseController.extend("som.ssv.controller.Results", {
		_formatter: formatter,

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf som.ssv.view.Results
		 */
		onInit: function () {
			sap.ui.core.UIComponent.getRouterFor(this).attachRoutePatternMatched(this.onRoutePatternMatched, this);
			var oTimeSlice = this.getView().byId("IdtimeSlice"),
				oSnapTimeSlice = this.getView().byId("IdsnapTimeSlice"),
				that = this;
			oTimeSlice.addEventDelegate({
				onAfterRendering: function () {
					//oTimeSlice.addStyleClass("zcustomHPEColours");
					that.ChangeTimeSliceColor();
				}
			}, oTimeSlice);
			oSnapTimeSlice.addEventDelegate({
				onAfterRendering: function () {
					//oSnapTimeSlice.addStyleClass("zcustomHPEColours");
					that.ChangeTimeSliceColor();
				}
			}, oSnapTimeSlice);
		},

		onRoutePatternMatched: function (oEvent) {

			if (oEvent.getParameter("name") === "Results") {
				var _oViewModel = this.getView().getModel("viewData"),
					_sOrderNumber = _oViewModel.getProperty("/ContractDetailsOrderNumber"),
					_sProviderContract = _oViewModel.getProperty("/ProviderContract");
				this.__fnGetHistoricalTimeSlices(_sProviderContract); // ACHOPRADELOI SOME-4028 2024/04/08
				this.__fnGetProviderContractDetails(_sOrderNumber, _sProviderContract);
			}
		},

		__fnGetProviderContractDetails: function (_sOrderNumber, _sProviderContract, timeSliceStart, timeSliceEnd) {

			var oModel = this.getView().getModel("viewData"),
				that = this;

			oModel.setProperty("/ContractDetails", []);
			oModel.setProperty("/ResultDetailsData", []);
			oModel.setProperty("/PartnerDetailsData", []);

			this.getView().setBusy(true);
			var f = [];
			f.push(new sap.ui.model.Filter("providerContract", "EQ", _sProviderContract));
			if (timeSliceStart !== undefined && timeSliceStart !== null && timeSliceStart !== "") {
				f.push(new sap.ui.model.Filter("timeslicestartdate", "EQ", timeSliceStart));
			}
			if (timeSliceEnd !== undefined && timeSliceEnd !== null && timeSliceEnd !== "") {
				f.push(new sap.ui.model.Filter("timeslicenddate", "EQ", timeSliceEnd));
			}

			var oServiceModel = this._getODataModel();

			var sPath = "/Ets_contractHeadDetail";
			var mParameters = {
				method: "GET",
				filters: f,
				urlParameters: {
					$expand: "conHead_conItem,conHead_conPart"
				},
				success: jQuery.proxy(function (oData) {
					this.getView().getModel("viewData").setProperty("/ContractDetails", oData.results[0]);
					var timeSliceStart, timeSliceEnd, timeSlice;
					if (oData.results[0].timeslicestartdate !== undefined && oData.results[0].timeslicestartdate !== null && oData.results[0].timeslicestartdate !==
						"") {
						var format = this.getView().getModel("viewData").getProperty("/DateFormat");
						timeSliceStart = formatter.dynamicFormatDate(oData.results[0].timeslicestartdate, true, format);
					}

					if (oData.results[0].timeslicenddate !== undefined && oData.results[0].timeslicenddate !== null && oData.results[0].timeslicenddate !==
						"") {
						var format = this.getView().getModel("viewData").getProperty("/DateFormat");
						timeSliceEnd = formatter.dynamicFormatDate(oData.results[0].timeslicenddate, true, format);
					}

					timeSlice = timeSliceStart + " - " + timeSliceEnd;
					this.getView().getModel("viewData").setProperty("/activeTimeSlice", timeSlice);
					this.ChangeTimeSliceColor();
					this.getView().getModel("viewData").setProperty("/ResultDetailsData", oData.results[0].conHead_conItem.results);
					this.getView().getModel("viewData").setProperty("/PartnerDetailsData", oData.results[0].conHead_conPart.results);
					this._jsonRestructure();
					this.getView().getModel("viewData").setProperty("/Flag", "Result");
					this.getView().setBusy(false);
				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);
				}, this)
			};

			oServiceModel.read(sPath, mParameters);
		},

		//JSON Restructure of partners
		_jsonRestructure: function () {
			var contractDetails = this.getView().getModel("viewData").getProperty("/PartnerDetailsData");
			var data = contractDetails;
			var T1 = [],
				T2 = [],
				T3 = [],
				T4 = [],
				T5 = [],
				T6 = [],
				aPartners = [];
			this.getView().getModel("viewData").setProperty("/ContractAdmin", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsShipTo", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsSoldTO", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsSoldTOContact", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsInvoice", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsBillTo", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsBillToContact", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsPayer", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsReseller", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsResellerContact", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsEndCustomer", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsHPEEndCust", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsRespCen", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsEntitledParty", {});
			this.getView().getModel("viewData").setProperty("/AdressDetailsEndCustomerContact", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction0", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction1", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction2", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction3", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction4", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction5", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction6", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction7", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction8", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction9", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction10", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction11", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction12", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction13", {});
			this.getView().getModel("viewData").getProperty("/PartnerFunction14", {});

			for (var i = 0; i < data.length; i++) {
				var a = {};
				a.label = data[i].label;
				a.partnerFunc = data[i].partnerFunc;
				a.contact = data[i].contact;
				a.phone = data[i].phone;
				a.email = data[i].email;
				a.partnerNo = data[i].partnerNo;
				a.address = data[i].address;
				a.region = data[i].region;
				a.country = data[i].country;

				if (data[i].partnerFunc === "ZPF000AC") {
					this.getView().getModel("viewData").setProperty("/ContractAdmin", a);
					aPartners.push("/ContractAdmin");
				} else if (data[i].partnerFunc === "00000001") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsSoldTO", a);
					aPartners.push("/AdressDetailsSoldTO");
				} else if (data[i].partnerFunc === "ZPF000CS") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsSoldTOContact", a);
					aPartners.push("/AdressDetailsSoldTOContact");
				} else if (data[i].partnerFunc === "ZPF000EE") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsEndCustomer", a);
					aPartners.push("/AdressDetailsEndCustomer");
				} else if (data[i].partnerFunc === "ZPF000IC") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsInvoice", a);
					aPartners.push("/AdressDetailsInvoice");
				} else if (data[i].partnerFunc === "ZPF000R1") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsRespCen", a);
					aPartners.push("/AdressDetailsRespCen");
				} else if (data[i].partnerFunc === "00000003") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsBillTo", a);
					aPartners.push("/AdressDetailsBillTo");
				} else if (data[i].partnerFunc === "00000004") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsPayer", a);
					aPartners.push("/AdressDetailsPayer");
				} else if (data[i].partnerFunc === "ZPF000RT") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsResellerContact", a);
					aPartners.push("/AdressDetailsResellerContact");
				} else if (data[i].partnerFunc === "00000002") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsShipTo", a);
					aPartners.push("/AdressDetailsShipTo");
				} else if (data[i].partnerFunc === "ZPF000Z1") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsReseller", a);
					aPartners.push("/AdressDetailsReseller");
				} else if (data[i].partnerFunc === "ZPF000ZC") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsHPEEndCust", a);
					aPartners.push("/AdressDetailsHPEEndCust");
				} else if (data[i].partnerFunc === "ZPF000ZE") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsEntitledParty", a);
					aPartners.push("/AdressDetailsEntitledParty");
				} else if (data[i].partnerFunc === "ZPF000ZF") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsBillToContact", a);
					aPartners.push("/AdressDetailsBillToContact");
				} else if (data[i].partnerFunc === "ZPF000ZG") {
					this.getView().getModel("viewData").setProperty("/AdressDetailsBillToContact", a);
					aPartners.push("/AdressDetailsEndCustomerContact");
				}
			}

			for (var i = 0; i < aPartners.length; i++) {
				this.getView().getModel("viewData").setProperty("/PartnerFunction" + i, this.getView().getModel("viewData").getProperty(aPartners[
					i]));
			}

		},

		// below function is used to Concatinate double zero(00) at starting of the contract detail order number
		fnconcatenateZero: function (number, length) {
			var my_string = '' + number;
			while (my_string.length < 10) {
				my_string = '0' + my_string;
			}

			return my_string;
		},

		onHPEOrderNumberPress: function (oEvent) {
			var ContractDetailsOrderNumber = this.getView().getModel("viewData").getProperty("/ContractDetailsOrderNumber").trim();
			var ContractDetailsOrderNoFormated = this.fnconcatenateZero(ContractDetailsOrderNumber, ContractDetailsOrderNumber.length);
			var orderUrl = this.getView().getModel("viewData").getProperty("/OrderURL");
			var urlStrings = orderUrl.split("OrderNumber=");
			//START INC2044166 fix by MSHARMAINFO1 9/2/2023
			//	var urlStringLang = urlStrings[1].split("ORDER_NUM");
			var sUrl = urlStrings[0] + "OrderNumber=" + ContractDetailsOrderNoFormated;
			//END INC2044166 fix by MSHARMAINFO1 9/2/2023
			window.open(sUrl, "_blank");
		},

		//get oData model
		_getODataModel: function () {
			return this.getOwnerComponent().getModel();
		},

		//get invoices
		_getInvoices: function () {

			var oModel = this.getView().getModel("viewData");
			var ProviderContract = this.getView().getModel("viewData").getProperty("/ProviderContract");

			oModel.setProperty("/Invoices", []);

			this.getView().setBusy(true);
			var f = [];
			f.push(new sap.ui.model.Filter("Contract", "EQ", ProviderContract));
			var oServiceModel = this._getODataModel();

			var sPath = "/Ets_invoiceDetails";

			var mParameters = {
				method: "GET",
				filters: f,
				success: jQuery.proxy(function (oData) {

					this.getView().setBusy(false);
					oModel.setProperty("/Invoices", oData.results);

					// the below functioanlity is used to set the download all buttton hide/visible

					if (oData.results.length === 0) {
						oModel.setProperty("/InvoiceDownloadAllBtnVis", false);

					}

					if (oData.results.length !== 0) {
						for (var b = 0; b <= oData.results.length; b++) {

							if (oData.results[b].Flag === "X") {
								oModel.setProperty("/InvoiceDownloadAllBtnVis", true);
								break;
							} else {

								oModel.setProperty("/InvoiceDownloadAllBtnVis", false);
							}
						}

					}

				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);
				}, this)
			};

			oServiceModel.read(sPath, mParameters);
		},

		//open invoices pop up
		onViewInvoices: function () {
			this._getInvoices();

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("som.ssv.fragments.Invoices", this);
			}

			this.getView().addDependent(this._oDialog);
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},

		//on Download Single Invoice
		onDownload: function (oEvent) {

			// TSINHADELOIT 5/4 - BOC
			// var sInvoice = oEvent.getSource().getBindingContext("viewData").getObject().Invoice;
			// TSINHADELOIT 5/4 - EOC
			//Line number 124 commented by SSAMRIDHI to accomodate INC0656338 changes
			var sInvoice = oEvent.getSource().getBindingContext("viewData").getObject().EncryptionKey; // ACHOPRADELOI RAMP-1007 2023/07/06
			var sPath = "/zcdoc-manager-billing/Ets_getInvoice(contract='',invoiceID='" + sInvoice + "',multi='Y')/$value"; // ACHOPRADELOI RAMP-1007 2023/07/06
			this.myWindow = window.open(sPath, "_blank");
		},

		//on Download All Invoices
		onDownloadAllInvoices: function (oEvent) {

			var ProviderContract = this.getView().getModel("viewData").getProperty("/ContractDetails/EncryptionKeyPC"); // ACHOPRADELOI RAMP-1007 2023/07/06
			var sPath = "/zcdoc-manager-billing/Ets_getInvoice(contract='" + ProviderContract + // ACHOPRADELOI RAMP-1007 2023/07/06
				"',multi='X',invoiceID='')/$value";
			this.myWindow = window.open(sPath, "_blank");
		},

		//on close
		onClose: function () {

			this._oDialog.close();
			this._oDialog.destroy();
			this._oDialog = null;

		},

		//Arjun R1.8 Phoenix SOME4028 - SSV Fiori App Part 3 START

		onPressUpgradeOrDowngrade: function (oEvent) {
			var processId = oEvent.getSource().getId(),
				ObjectID = this.getView().getModel("viewData").getProperty("/ProviderContract"),
				sUserEmailId = "",
				oResourceModel = this.getResourceBundle(),
				process;
			// _sURL = this.getView().getModel("viewData").getProperty("/ASQPunchOutURL");

			// Arjun: CPQE4302 start
			if (processId.includes("FundsAdittion")) {
				process = "FUNDS_ADDITION";
			} else if (processId.includes("idUpgradeBtn")) {
				process = "Upgrade";
			} else {
				process = "Downgrade";
			}
			// Arjun: CPQE4302 end

			//SOI jmezadeloitte SOME4302 " Add Funds Addition and remoe middle spaces"
			process = process.replace(/\s/g, "");
			//EOI jmezadeloitte SOME4302 " Add Funds Addition and remoe middle spaces"
			var f = [];
			//SOC kkalikapuram GLBP -1781 Upgrade Access issue
			var PartnerEmailId = this.getView().getModel("viewData").getProperty("/PunchOutData_Details/emailId");
			try {
				if (PartnerEmailId !== undefined && PartnerEmailId !== "" && PartnerEmailId !== null) {
					sUserEmailId = PartnerEmailId.split("|")[0];
				} else {
					if (sap.ushell !== undefined) {
						var sLoginUser = sap.ushell.Container.getUser();
						if (sLoginUser !== undefined) {
							sUserEmailId = sLoginUser.getEmail();
						}
					}

				}
			} catch (err) {}
			//EOC kkalikapuram GLBP -1781 Upgrade Access issue
			f.push(new sap.ui.model.Filter("Process", "EQ", process));
			f.push(new sap.ui.model.Filter("ObjectID", "EQ", ObjectID));
			f.push(new sap.ui.model.Filter("EmailID", "EQ", sUserEmailId));

			this.__openBusyDialog();

			var punchoutData = this.getView().getModel("viewData").getProperty("/PunchOutData");
			var oDataModel = this.getView().getModel("Z_SOM_CREATE_OPPORTUNITY_GP_SRV");
			oDataModel.read("/Ets_Details", {
				method: "GET",
				filters: f,
				success: function (oData) {
					this.__closeBusyDialog();
					var oppId = oData.results[0].OpportunityID,
						//var encodedOppId = btoa(oppId);
						//ACHOPRADELOI RAMP-1020 ASQ redirection URL adaptations 2023/09/08
						paramIdArr = btoa(oppId).split("").reverse();
					[paramIdArr[1], paramIdArr[11]] = [paramIdArr[11], paramIdArr[1]];
					[paramIdArr[2], paramIdArr[10]] = [paramIdArr[10], paramIdArr[2]];
					var encodedOppId = paramIdArr.join("");
					if (sap.ushell) {
						// var url = window.location.href;
						// url = url.substring(0, url.lastIndexOf("#"));
						// if (url.lastIndexOf("?") === -1) {
						// 	url = url + "?";
						// } else {
						// 	url = url + "&";
						// }
						// url = url + "i_opp=" + encodedOppId + "&punchoutType=SSV" + "#Sub-quote";
						// sap.m.URLHelper.redirect(url, true);

						// var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
						// 	hash = "";
						// hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
						// 	target: {
						// 		semanticObject: "ZLTS",
						// 		action: "manageSolQuote",
						// 	},
						// 	params: {
						// 		"o": encodedOppId,
						// 		"e": "CROSS_APP_SSV",
						// 		"punchoutType": "SSV"
						// 	}
						// })) || "";

						// oCrossAppNavigator.toExternal({
						// 	target: {
						// 		shellHash: hash + "&/Create/External"
						// 	}
						// });

						/*SOC kkalikapuram GLBP-1214 2024/06/03*/
						sap.m.MessageBox.confirm(
							oResourceModel.getText("xtxt.Main.Subscription.QuoteCreate", oppId), {
								title: oResourceModel.getText("xtxt.Main.Subscription.QuoteConfirm"),
								actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
								onClose: function (oAction) {
									if (oAction === sap.m.MessageBox.Action.OK) {
										// User clicked OK, proceed with the action
										var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
											hash = "";

										hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
											target: {
												semanticObject: "Sub",
												action: "quote",
											},
											params: {
												"o": encodedOppId,
												"e": "S",
												"b": punchoutData === "" || punchoutData === undefined || punchoutData ===
													null ? "" : punchoutData["Usertype"] === "" || punchoutData["Usertype"] === undefined || punchoutData["Usertype"] ===
													null ? "" : punchoutData["Usertype"].toUpperCase() === "INTERNAL" ?
													"so" : punchoutData["Usertype"].toUpperCase() === "PARTNER" ?
													punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("RS") ? "rs" :
													punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("DT") ? "dt" : "" : ""
											}
										})) || "";

										// var sTargetAppUrl =	oCrossAppNavigator.toExternal({
										// 		target: {
										// 			shellHash: hash + "&/Create/External"
										// 		}
										// 	});
										var sTargetAppUrl = window.location.href.split('#')[0] + hash + "&/Cr/Ex";
										sap.m.URLHelper.redirect(sTargetAppUrl, true);
										// window.open(sTargetAppUrl,'_blank');
									} else {
										// User clicked Cancel, do something else or just close the dialog
										// console.log("User clicked Cancel");
									}
								}
							}
						);
						/*EOC kkalikapuram GLBP-1214 2024/06/03*/

					} /*SOC BADH EAGLE-4243 2022/01/27*/
					else {
						// SOC kkalikapuram GLBP-1214 2024/06/19
						sap.m.MessageBox.confirm(
							oResourceModel.getText("xtxt.Main.Subscription.QuoteCreate", oppId), {
								title: oResourceModel.getText("xtxt.Main.Subscription.QuoteConfirm"),
								actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
								onClose: function (oAction) {
									if (oAction === sap.m.MessageBox.Action.OK) {

										var sProtocol = window.location.protocol,
											sHostName = window.location.hostname,
											baseurl = sProtocol + "//" + sHostName,
											_sURL = baseurl + "/go-hpe#Sub-quote?";

										// var _oViewModel = this.getView().getModel("viewData"),
										// 	_sURL = _oViewModel.getProperty("/ASQPunchOutURL");
										// if (_sURL === undefined || _sURL === "" || _sURL === null) {
										// 	_sURL = window.location.origin + "/z_manage_sol_q_pp/index.html?sap-ui-xx-fesr=false";
										// }

										// if (_sURL.lastIndexOf("?") === -1) {
										// 	_sURL = _sURL + "?";
										// } else {
										// 	_sURL = _sURL + "&";
										// }
										var __sLanguage = "";
										if (sap.ui.getCore().getConfiguration().getLanguage()) {
											__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
										} else {
											__sLanguage = "EN";
										}
										var b_parameter = punchoutData === "" || punchoutData === undefined || punchoutData ===
											null ? "" : punchoutData["Usertype"] === "" || punchoutData["Usertype"] === undefined || punchoutData["Usertype"] ===
											null ? "" :
											punchoutData["Usertype"].toUpperCase() === "INTERNAL" ?
											"so" : punchoutData["Usertype"].toUpperCase() === "PARTNER" ?
											punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("RS") ? "rs" :
											punchoutData["tierMapping"]["results"][0]["Brtypecode"].toUpperCase().includes("DT") ? "dt" : "" : "";
										_sURL = _sURL + "e=S" + "&b=" + b_parameter + "&o=" + encodedOppId + "&sap-language=" + __sLanguage +
											"#/Cr/Ex";
										sap.m.URLHelper.redirect(_sURL, true);
									} else {
										// User clicked Cancel, do something else or just close the dialog
										// console.log("User clicked Cancel");
									}
								}
							}
						);
						// EOC kkalikapuram GLBP-1214 2024/06/19
						//	this._fnOpenASQPunchOutUrl(encodedOppId, _sURL);
						//ACHOPRADELOI RAMP-1020 ASQ redirection URL adaptations 2023/09/08
					} /*EOC BADH EAGLE-4243 2022/01/27*/
				}.bind(this),
				error: function (oError) {
					this.__closeBusyDialog();
					var errorJson = JSON.parse(oError.responseText);
					var msgs = errorJson.error.innererror.errordetails;
					sap.m.MessageBox.show(
						msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					/*for(var i=0;i<msgs.lenght;i++){
						sap.ui.getCore().getMessageManager().addMessages(msgs[i].message);
					}*/
				}.bind(this)
			});
		},
		//Arjun R1.8 Phoenix SOME4028 - SSV Fiori App Part 3 END
		/*SOC BADH EAGLE-4243 2022/01/27*/
		_fnOpenASQPunchOutUrl: function (sEncodedOppId, sURL) {
			var __oDataModel = this.getView().getModel(),
				_oViewModel = this.getView().getModel("viewData"),
				/*SOC BADH OR-1948 2022/06/27*/
				__sUsrType = _oViewModel.getProperty("/PunchOutData/Usertype"),
				__sTier = _oViewModel.getProperty("/PunchOutData/tierMapping/results/0/Tier"),
				/*EOC BADH OR-1948 2022/06/27*/
				__sEmailId = _oViewModel.getProperty("/PunchOutData_Details/emailId").split("|"),
				__oPayload = {
					"emailId": __sEmailId[0],
					"persona": "SALES_REP"
				};

			/*SOC BADH OR-1948 2022/06/27*/
			if (__sUsrType.toUpperCase() === "PARTNER" && __sTier.toUpperCase() === "TIER1") {
				__oPayload["persona"] = "Distributor";
			} else if (__sUsrType.toUpperCase() === "PARTNER" && __sTier.toUpperCase() === "TIER2") {
				__oPayload["persona"] = "Reseller";
			} else if (__sUsrType.toUpperCase() === "CUSTOMER") {
				__oPayload["persona"] = "Reseller";
			}
			/*EOC BADH OR-1948 2022/06/27*/

			this.__openBusyDialog();
			__oDataModel.create("/Ets_ASQ_tokenBrim", __oPayload, {
				method: "POST",
				success: function (oData) {
					this.__closeBusyDialog();
					if (sURL.lastIndexOf("?") === -1) {
						sURL = sURL + "?";
					} else {
						sURL = sURL + "&";
					}
					var __sLanguage = "";
					if (sap.ui.getCore().getConfiguration().getLanguage()) {
						__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
					} else {
						__sLanguage = "EN";
					}
					sURL = sURL + "i_t=" + oData.token + "&i_opp=" + sEncodedOppId + "&sap-language=" + __sLanguage + "&punchoutType=SSV" +
						"#/Cr/Ex";
					sap.m.URLHelper.redirect(sURL, true);
				}.bind(this),
				error: function (oError) {
					this.__closeBusyDialog();
					var errorJson = JSON.parse(oError.responseText);
					var msgs = errorJson.error.innererror.errordetails;
					sap.m.MessageBox.show(
						msgs[0].message, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
					/*for(var i=0;i<msgs.lenght;i++){
						sap.ui.getCore().getMessageManager().addMessages(msgs[i].message);
					}*/
				}.bind(this)
			});
		},
		/*EOC BADH EAGLE-4243 2022/01/27*/

		/*SOC EAGLE-EGR2I001 BADH SSV CHANGES  2021/08/10*/
		onPressSubscriptionContractAction: function (oEvent) {
			var sURL = "",
				sURLParameter = "",
				_oViewModel = this.getView().getModel("viewData"),
				sBtnText = oEvent.getSource().getText(),
				oResourceModel = this.getResourceBundle(),
				bSFDCCaseCreation = false,
				_sProviderContract = _oViewModel.getProperty("/ContractDetails/providerContract"),
				__sLanguage = "";

			if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ExtendEval")) {
				var __bSP_Flag = _oViewModel.getProperty("/ContractDetails/SP_Flag"), //BADH SILVERPEAK-1213 2022/02/23
					startDate = _oViewModel.getProperty("/ContractDetails/conStartDate"),
					/*	endDate = _oViewModel.getProperty("/ContractDetails/conEndDate"),*/
					currDate = new Date(),
					diffDays = Math.round((currDate - startDate) / (1000 * 60 * 60 * 24));

				if (diffDays > 120 && __bSP_Flag !== "X") {
					bSFDCCaseCreation = true;
				} else {
					this.fnExtendEval(_sProviderContract, "C", sBtnText);
				}

			} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.AutoRenewSet") || sBtnText === oResourceModel.getText(
					"xbtn.Main.Subscription.AutoRenewRemove")) {
				this.fnAutoRenewContractAction(_sProviderContract, "B", sBtnText);
			} else {
				bSFDCCaseCreation = true;
			}

			if (bSFDCCaseCreation) {
				if (this.fnGetParamExistsInURI("i_t") || window.location.href.includes("index.html") === true) { // ACHOPRADELOI RAMP-1458 2023/10/17
					if (_oViewModel.getProperty("/SFDCCaseWebformURL") !== undefined && _oViewModel.getProperty("/SFDCCaseWebformURL") !== "") {
						sURL = _oViewModel.getProperty("/SFDCCaseWebformURL");
					} else {
						sURL = oResourceModel.getText("xurl.Main.Subscription.SFDCCaseWebform3");
					}
					/*SOC BADH EAGLE-2850 2021/12/11*/
					if (_oViewModel.getProperty("/PunchOutData_Details/emailId")) {

						/*SOC BADH INC0698341 2022/02/22*/
						var __userDetails = _oViewModel.getProperty("/PunchOutData_Details/emailId").split("|");
						if (__userDetails.length > 1) {
							sURLParameter += "&" + "Case_Requestor_Email__c=" + __userDetails[0];
							sURLParameter += "&" + "Case_Requestor__c=" + __userDetails[1];
							sURLParameter += "&" + "Requestor_Phone__c=" + __userDetails[2];
						} else {
							sURLParameter += "&" + "Case_Requestor_Email__c=" + __userDetails[0];
						}
						/*EOC BADH INC0698341 2022/02/22*/
					}

					/*EOC BADH EAGLE-2850 2021/12/11*/
				} else {
					if (_oViewModel.getProperty("/SFDCCaseWebformURL") !== undefined && _oViewModel.getProperty("/SFDCCaseWebformURL") !== "") {
						sURL = _oViewModel.getProperty("/SFDCCaseWebformURL");
					} else {
						sURL = oResourceModel.getText("xurl.Main.Subscription.SFDCCaseWebform3");
					}
				}

				try {
					if (sap.ushell !== undefined) {
						var sLoginUser = sap.ushell.Container.getUser();
						if (sLoginUser !== undefined) {
							//Your Name:
							sURLParameter += "Case_Requestor__c=" + sLoginUser.getFullName();
							//Email:
							sURLParameter += "&" + "Case_Requestor_Email__c=" + sLoginUser.getEmail();
							//Phone number:
							/*sURL += "Requestor_Phone__c=";*/
							__sLanguage = sLoginUser.getLanguage();
						} else {
							/*SOC BADH EAGLE-2850 2021/12/07*/
							if (sap.ui.getCore().getConfiguration().getLanguage()) {
								__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
							} else {
								__sLanguage = "EN";
							}
							/*EOC BADH EAGLE-2850 2021/12/07*/
						}
					} else {
						/*SOC BADH EAGLE-2850 2021/12/11*/
						if (sap.ui.getCore().getConfiguration().getLanguage()) {
							__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
						} else {
							__sLanguage = "EN";
						}
						/*EOC BADH EAGLE-2850 2021/12/11*/
					}

				} catch (err) {
					/*SOC BADH EAGLE-2850 2021/12/11*/
					if (sap.ui.getCore().getConfiguration().getLanguage()) {
						__sLanguage = sap.ui.getCore().getConfiguration().getLanguage();
					} else {
						__sLanguage = "EN";
					}
					/*EOC BADH EAGLE-2850 2021/12/11*/
				}

				/*SOC BADH EAGLE-3706 2021/12/15*/
				switch (__sLanguage.toUpperCase()) {
				case "EN": //English
					__sLanguage = "en_US";
					break;
				case "HE": //Hebrew
					__sLanguage = "iw";
					break;
				case "ID": //Indonesian
					__sLanguage = "in";
					break;
				case "PT": //Portuguese Brazil
					__sLanguage = "pt_BR";
					break;
				case "ZH": //Chinese (Simplified)
					__sLanguage = "zh_CN";
					break;
				case "ZH-HANS": //Chinese (Simplified)
					__sLanguage = "zh_CN";
					break;
				case "ZF": //Chinese (Traditional)
					__sLanguage = "zh_TW";
					break;
				case "ZH-HANT": //Chinese (Traditional)
					__sLanguage = "zh_TW";
					break;
				}
				/*EOC BADH EAGLE-3706 2021/12/15*/

				//Language:
				sURLParameter += "&" + "lang=" + __sLanguage.toUpperCase();

				//Region:
				sURLParameter += "&" + "Region__c=" + _oViewModel.getProperty("/AdressDetailsSoldTO/region");
				//Account Country:
				sURLParameter += "&" + "Country_of_Submitter__c=" + _oViewModel.getProperty("/AdressDetailsSoldTO/country");
				//Quote Number:
				sURLParameter += "&" + "CPQ_Quote_Number__c=" + _oViewModel.getProperty("/ContractDetails/quoteID");
				//Customer Purchase Order (PO) Number:
				sURLParameter += "&" + "PO_number__c=" + _oViewModel.getProperty("/ContractDetails/poNumber");
				//Party ID:
				sURLParameter += "&" + "Target_ID__c=" + _oViewModel.getProperty("/ContractDetails/customerID");
				//HPE Order Number:
				sURLParameter += "&" + "HP_Order_Number__c=" + _sProviderContract.trim();
				//Sold-to Party Name:
				sURLParameter += "&" + "Sold_to_Party__c=" + _oViewModel.getProperty("/ContractDetails/soldtoID");
				/*SOC BADH EAGLE-2631 2021/11/26*/
				//Business Group:
				sURLParameter += "&" + "Business_Group__c=" + _oViewModel.getProperty("/ContractDetails/SalesOff");
				/*EOC BADH EAGLE-2631 2021/11/26*/

				/*//Sales Order Amount:
				sURLParameter += "&" + "Sales_Order_Amount__c=";*/
				//Currency:
				sURLParameter += "&" + "CurrencyIsoCode=" + _oViewModel.getProperty("/ContractDetails/currency");
				if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ExtendEval")) {
					//Case reason:
					sURLParameter += "&" + "Reason=Subscription Changes";
					//Scenario:
					sURLParameter += "&" + "Scenario=Evaluation extension request";
				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqCancelation")) {
					//Case reason:
					sURLParameter += "&" + "Reason=Subscription Changes";
					//Scenario:
					sURLParameter += "&" + "Scenario=Subscription cancellation request";
				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.DisputeInvoice")) {
					//Case reason:
					sURLParameter += "&" + "Reason=Invoicing";
					//Scenario:
					sURLParameter += "&" + "Scenario=Invoice Correction Request"; /*BADH GLBP-1771 2024.06.24*/
				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqUpgrade")) { //SOC ACHOPRADELOI SOME-4028 2024/04/04
					//Case reason:
					sURLParameter += "&" + "Reason=Subscription Changes";
					//Scenario:
					sURLParameter += "&" + "Scenario=Upgrade request"; //kkalikapuram GLBP -1822 2024/06/19
				}
				//EOC ACHOPRADELOI SOME-4028 2024/04/04
				/*SOC EAGLE-1945 - BADH DEFECT 2021/09/24*/
				if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ExtendEval")) {
					//Subject:
					sURLParameter += "&" + "Subject=Subscription Changes/Evaluation extension request/10181-02";
				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqCancelation")) {
					//Subject:
					sURLParameter += "&" + "Subject=Subscription Changes/Subscription cancellation request/10181-02";
				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.DisputeInvoice")) {
					//Subject:
					sURLParameter += "&" + "Subject=Invoicing/Invoice Correction request/10181-02";
				} else if (sBtnText === oResourceModel.getText("xbtn.Main.Subscription.ReqUpgrade")) { //SOC ACHOPRADELOI SOME-4028 2024/04/04
					//Subject:
					sURLParameter += "&" + "Subject=Subscription Changes/Upgrade request/10181-02";
				}
				//EOC ACHOPRADELOI SOME-4028 2024/04/04
				/*EOC EAGLE-1945 - BADH DEFECT 2021/09/25*/

				/*//Description:
				sURLParameter += "&" + "Case_description__c=";
				//Additional email addresses to keep in copy:
				sURLParameter += "&" + "Cc_Contact_Email__c=" + _oViewModel.getProperty("/ContractDetails/customerID");*/

				sURL = sURL + "?" + sURLParameter;

				sap.m.URLHelper.redirect(sURL, true);
			}
		},

		fnExtendEval: function (_sProviderContract, _sAction, _sBtnText) {
			var _oRequestData = {
					"providerContract": _sProviderContract.trim(),
					"action": _sAction,
					"notes": "",
					"return": ""
				},

				oModel = this.getOwnerComponent().getModel();
			this.__openBusyDialog();
			oModel.create("/Ets_contractAction", _oRequestData, {
				method: "POST",
				success: function (oData, oResponse) {
					this.__closeBusyDialog();
					sap.m.MessageToast.show(oData.return);
					var _oViewModel = this.getView().getModel("viewData"),
						_sOrderNumber = _oViewModel.getProperty("/ContractDetailsOrderNumber");
					_sProviderContract = _oViewModel.getProperty("/ProviderContract");
					this.__fnGetProviderContractDetails(_sOrderNumber, _sProviderContract);
				}.bind(this),
				error: function (error) {
					this.__closeBusyDialog();
					sap.m.MessageBox.show(
						error.statusText, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Service Error",
							actions: [sap.m.MessageBox.Action.OK]
						});
				}.bind(this)
			});
		},

		fnAutoRenewContractAction: function (_sProviderContract, _sAction, _sBtnText) {
			var contractActionModel = new sap.ui.model.json.JSONModel();
			contractActionModel.setData({
				"providerContract": _sProviderContract.trim(),
				"action": _sAction,
				"notes": "",
				"return": ""
			});

			if (!this._oAutoRenewDialog) {
				this._oAutoRenewDialog = new sap.m.Dialog({
					type: sap.m.DialogType.Message,
					title: _sBtnText,
					content: [
						new sap.m.CheckBox({
							text: "{i18n>xtxt.Main.Subscription.AutoRenewAgree}",
							select: function (_oEvent) {
								var bSelected = _oEvent.getParameter("selected");
								this._oAutoRenewDialog.getBeginButton().setEnabled(bSelected);
							}.bind(this)
						}).addStyleClass("sapUiTinyMarginBeginEnd"),
						new sap.m.Link({
							text: "{i18n>xtxt.Main.Subscription.AutoRenewTerms}",
							textAlign: "Center",
							press: function (_oEvent) {}.bind(this)
						})
					],
					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "{i18n>xtxt.Main.Subscription.Submit}",
						enabled: false,
						press: function () {
							var _oRequestData = this._oAutoRenewDialog.getModel("contractActionModel").getData(),
								oModel = this.getOwnerComponent().getModel();

							this.__openBusyDialog();

							oModel.create("/Ets_contractAction", _oRequestData, {
								method: "POST",
								success: function (oData, oResponse) {
									this.__closeBusyDialog();
									sap.m.MessageToast.show(oData.return);
									var _oViewModel = this.getView().getModel("viewData"),
										_sOrderNumber = _oViewModel.getProperty("/ContractDetailsOrderNumber");
									_sProviderContract = _oViewModel.getProperty("/ProviderContract");
									this.__fnGetProviderContractDetails(_sOrderNumber, _sProviderContract);
								}.bind(this),
								error: function (error) {
									this.__closeBusyDialog();
									sap.m.MessageBox.show(
										error.statusText, {
											icon: sap.m.MessageBox.Icon.ERROR,
											title: "Service Error",
											actions: [sap.m.MessageBox.Action.OK]
										});
								}.bind(this)
							});

							this._oAutoRenewDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "{i18n>xbtn.Main.Subscription.Cancel}",
						press: function () {
							this._oAutoRenewDialog.close();
						}.bind(this)
					})
				});

				this.getView().addDependent(this._oAutoRenewDialog, this);
			}

			this._oAutoRenewDialog.setModel(contractActionModel, "contractActionModel");
			this._oAutoRenewDialog.setTitle(_sBtnText);
			this._oAutoRenewDialog.getContent()[0].setSelected(false);
			this._oAutoRenewDialog.getBeginButton().setEnabled(false);
			this._oAutoRenewDialog.open();
		},

		onContractActionBtnPress: function (oEvent) {
			var oButton = oEvent.getSource();
			this.byId("contractActionSheet").openBy(oButton);
		},
		/*EOC EAGLE-EGR2I001/EGR2I006 BADH SSV CHANGES 2021/08/10*/

		/*SOC EAGLE-EGR2E009 BADH CHANGES 2021/09/22*/
		onPressNotificationPrepaidDrawdown: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel(),
				_oViewModel = this.getView().getModel("viewData"),
				_sProviderContract = _oViewModel.getProperty("/ContractDetails/providerContract"),
				_sSoldToParty = _oViewModel.getProperty("/ContractDetails/soldtoID");

			this.__openBusyDialog();
			oModel.read("/Ets_OnDemand(Contract='" + _sProviderContract.trim() + "',Subscriber_Acc='" + _sSoldToParty.trim() + "')", {
				success: function (oData, oResponse) {
					this.__closeBusyDialog();
					sap.m.MessageToast.show("Details successfully sent to CCS");
				}.bind(this),
				error: function (error) {
					this.__closeBusyDialog();
					try {
						var errMsg = JSON.parse(error.responseText).error.message.value;
						sap.m.MessageBox.show(
							errMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Service Error",
								actions: [sap.m.MessageBox.Action.OK]
							});
					} catch (err) {
						sap.m.MessageBox.show(
							error.statusText, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Service Error",
								actions: [sap.m.MessageBox.Action.OK]
							});
					}
				}.bind(this)
			});
		},
		/*EOC EAGLE-EGR2E009 BADH CHANGES 2021/09/22*/
		/*SOC BADH ORION-SOME4028A 2022/04/27*/
		onPressCoterm: function (oEvent) {
			var _oViewModel = this.getView().getModel("viewData"),
				_sProviderContract = _oViewModel.getProperty("/ContractDetails/providerContract"),
				_sHPEEndCustomer = _oViewModel.getProperty("/PartnerFunction5/partnerNo");

			this.getRouter().navTo("CoTerm", {
				query: {
					punchoutType: "SSV",
					hpeEndCustomer: _sHPEEndCustomer.trim(),
					contractNo: _sProviderContract.trim()
				}
			});
		},
		/*EOC BADH ORION-SOME4028A 2022/04/27*/

		//SOC ACHOPRADELOI SOME-4028 2024/04/08
		__fnGetHistoricalTimeSlices: function (_sProviderContract) {
			var oModel = this.getView().getModel("viewData");
			this.getView().setBusy(true);
			var that = this;
			var f = [];
			f.push(new sap.ui.model.Filter("providerContract", "EQ", _sProviderContract));
			var oServiceModel = this._getODataModel();
			var sPath = "/Ets_contractTimeSlice";
			var mParameters = {
				method: "GET",
				filters: f,
				success: jQuery.proxy(function (oData) {
					var timeSliceStart, timeSliceEnd, timeSlice, historicalTimeSlice = [],
						timeSlicePayload, timeSliceStartPayload, timeSliceEndPayload, historicalForPayload = [];
					oData.results.forEach(function (data) {
						if (data.TimeSliceStartDate !== undefined && data.TimeSliceStartDate !== null && data.TimeSliceStartDate !== "") {
							var format = this.getView().getModel("viewData").getProperty("/DateFormat");
							timeSliceStart = formatter.dynamicFormatDate(data.TimeSliceStartDate, true, format);
							timeSliceStartPayload = formatter.dynamicFormatDate(data.TimeSliceStartDate, true, undefined, true);
						}

						if (data.TimeSliceEndDate !== undefined && data.TimeSliceEndDate !== null && data.TimeSliceEndDate !== "") {
							var format = this.getView().getModel("viewData").getProperty("/DateFormat");
							timeSliceEnd = formatter.dynamicFormatDate(data.TimeSliceEndDate, true, format);
							timeSliceEndPayload = formatter.dynamicFormatDate(data.TimeSliceEndDate, true, undefined, true);
						}

						timeSlice = timeSliceStart + " - " + timeSliceEnd;
						timeSlicePayload = timeSliceStartPayload + " - " + timeSliceEndPayload;

						historicalTimeSlice.push({
							"timeSlice": timeSlice
						});

						historicalForPayload.push({
							"timeSlice": timeSlicePayload
						});
					}.bind(that));
					oModel.setProperty("/historicalTimeSlice", historicalTimeSlice);
					oModel.setProperty("/historicalForPayload", historicalForPayload);

					that.getView().setBusy(false);
				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);
				}, this)
			};
			oServiceModel.read(sPath, mParameters);
		},

		onChangeHistoricalTimeSlice: function (oEvent) {
			var _oViewModel = this.getView().getModel("viewData"),
				_sOrderNumber = _oViewModel.getProperty("/ContractDetailsOrderNumber"),
				_sProviderContract = _oViewModel.getProperty("/ProviderContract"),
				timesliceStart, timeSliceEnd, timeSlice = [];
			timeSlice = oEvent.getSource().getSelectedKey().split(" - ");
			var timeSlicePayload = _oViewModel.getProperty("/historicalForPayload")[oEvent.getSource().getSelectedIndex()]["timeSlice"].split(
				" - ");
			timesliceStart = this.convertStringToTimestamp(timeSlicePayload[0]);
			timeSliceEnd = this.convertStringToTimestamp(timeSlicePayload[1]);
			this.__fnGetProviderContractDetails(_sOrderNumber, _sProviderContract, timesliceStart, timeSliceEnd);
			this.ChangeTimeSliceColor(false);
		},

		convertStringToTimestamp: function (dateTimeString) {
			// Split the string into date and time parts
			var parts = dateTimeString.split(' '),
				datePart = parts[0],
				timePart = parts[1],

				// Split the date into year, month, and day
				dateParts = datePart.split('-'),
				year = parseInt(dateParts[0], 10),
				month = parseInt(dateParts[1], 10) - 1, // Months are zero-based in JavaScript
				day = parseInt(dateParts[2], 10),

				// Split the time into hours, minutes, and seconds
				timeParts = timePart.split(':'),
				hours = parseInt(timeParts[0], 10),
				minutes = parseInt(timeParts[1], 10),
				seconds = parseInt(timeParts[2], 10),

				// Create a new Date object in UTC
				date = new Date(Date.UTC(year, month, day, hours, minutes, seconds));

			// Return the timestamp in milliseconds
			return date.getTime();
		},

		ChangeTimeSliceColor: function () {
				var id1, id2;
				id1 = this.getView().byId("IdtimeSlice").sId + '-labelText';
				id2 = this.getView().byId("IdsnapTimeSlice").sId + '-labelText';
				var current_span1 = document.getElementById(id1).innerHTML;
				var current_span2 = document.getElementById(id2).innerHTML;
				if (!current_span1.includes("zcustomHPEColours") && current_span1 !== "") {
					var arr = current_span1.split(" ");
					var highlightedText = arr[0] + " " + '<span class="zcustomHPEColours">' + arr[1] + '</span>' + " " + arr[2] + " " + arr[3] +
						" " +
						'<span class="zcustomHPEColours">' + arr[4] + '</span>';
					document.getElementById(id1).innerHTML = highlightedText;
				}
				if (!current_span2.includes("zcustomHPEColours") && current_span2 !== "") {
					var arr = current_span2.split(" ");
					var highlightedText = arr[0] + " " + '<span class="zcustomHPEColours">' + arr[1] + '</span>' + " " + arr[2] + " " + arr[3] +
						" " +
						'<span class="zcustomHPEColours">' + arr[4] + '</span>';
					document.getElementById(id2).innerHTML = highlightedText;
				}
			}
			//5100027029
			//EOC ACHOPRADELOI SOME-4028 2024/04/08
	});

});