sap.ui.define([
	"som/ssv/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/Tokenizer",
	"sap/ui/model/Filter",
	"sap/ui/export/Spreadsheet",
	"som/ssv/utils/formatter"
], function (BaseController, JSONModel, MessageToast, MessageBox, Token, Tokenizer, Filter, Spreadsheet, formatter) {
	"use strict";
	var checkFlag = false;
	var flagTier = 0;
	var TokenFlag = false;

	return BaseController.extend("som.ssv.controller.Main", {

		_formatter: formatter,

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		onInit: function () {

			this.flagPunchoutCall = '';
			this.selectedKey = "0";
			this.priceFlag = "";
			sap.ui.getCore().getModel("viewData").setProperty("/viewInvoicesVisibility", true);
			sap.ui.getCore().getModel("viewData").setProperty("/MHMGVisible", false);
			sap.ui.getCore().getModel("viewData").setProperty("/MGMGSelectKey", this.selectedKey);
			if(this.fnCheckOorQParamInHash()){
				sap.ui.getCore().getModel("viewData").setProperty("/showFilters", false);
			}
			sap.ui.core.UIComponent.getRouterFor(this).attachRoutePatternMatched(this.onRoutePatternMatched, this);
			this.getRouter().initialize();
			var oMultiInput = this.getView().byId("idPartyID");

			//validation for multiinput to make input a token
			oMultiInput.addValidator(function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			});

			var oMultiInpReport2 = this.getView().byId("idPartyIDIAB");

			//validation for multiinput to make input a token
			oMultiInpReport2.addValidator(function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			});

			var oMultiInpReport3 = this.getView().byId("idPartyIDUAR");

			//validation for multiinput to make input a token
			oMultiInpReport3.addValidator(function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			});

			var oMultiInpReport4 = this.getView().byId("idPartyIDDMI");

			//validation for multiinput to make input a token
			oMultiInpReport4.addValidator(function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			});

			/*SOC BADH EAGLE-SOME4028B 2021/11/08*/
			var oMultiInpReport5 = this.getView().byId("idPartyIDCCC");

			//validation for multiinput to make input a token
			oMultiInpReport5.addValidator(function (args) {
				var text = args.text;
				return new Token({
					key: text,
					text: text
				});
			});
			/*EOC BADH EAGLE-SOME4028B 2021/11/08*/

			/*SOC BADH EAGLE-2700 2021/11/17*/
			var oRptSchDate = this.getView().byId("idDateScheduleStartDateDMI");

			//validation for multiinput to make input a token
			oRptSchDate.setMinDate(new Date());
			/*EOC BADH EAGLE-2700 2021/11/17*/
		},

		//on Route match
		onRoutePatternMatched: function (oEvent) {

			var oJsonModel = this.getOwnerComponent().getModel("localJsonModel"),
				oModel = this.getModel("viewData");
			if (this.fnGetParamExistsInURI("i_t")||this.fnGetParamExistsInURI("s")) {
				this.dateFormat = this.fnGetParamIdFrmURI("dateFormat");
			} else {
				this.dateFormat = oModel.getProperty("/dateFormat");
			}
			this.partyId = "";
			this.visible = "";
			this.brimSolutionQuote = "";
			this.orderNo = "";

			if (oEvent.getParameter("name") === "main") {
				if (oModel.getProperty("/Flag") !== "Result") {
					if (this.fnGetParamExistsInURI("i_t")) {
						oModel.setProperty("/TokenValue", this.fnGetParamIdFrmURI("i_t"));
					}
					// this.getModel("viewData").setProperty("/TokenValue", "270050569346451EDB93CC5B5FC9150BE8");
					oModel.setProperty("/Flag", "Main");
					this._ChangeDateFormat();
					if (this.fnGetParamExistsInURI("i_t")) {
						oModel.setProperty("/HeaderPunchout", true);

						this.getView().byId("LineItemsSmartTable").setUseTablePersonalisation(true);  // kkalikapuram GLBP-3325 Sort issue for PRP external users
					} else {
						oModel.setProperty("/HeaderPunchout", false);
						if (this.fnGetParamIdFrmURI("i_t") === "") {
							TokenFlag = true;
							oJsonModel.setProperty("/bTokenFlag", TokenFlag);
							this.getRouter().navTo("AccessDenied");
						}

						if (window.location.href.includes("index.html") === true || this.fnGetParamIdFrmURI("i_t") === "") {
							TokenFlag = true;
							oJsonModel.setProperty("/bTokenFlag", TokenFlag);
							this.getRouter().navTo("AccessDenied");
						}

						if (window.location.href.includes("index.html") === true && window.location.href.includes("i_t") === !true && this.fnGetParamIdFrmURI(
							"i_t") === "") {
							TokenFlag = true;
							oJsonModel.setProperty("/bTokenFlag", TokenFlag);
							this.getRouter().navTo("AccessDenied");
						} else {
							this.getView().byId("LineItemsSmartTable").setUseVariantManagement(true);
							this.getView().byId("LineItemsSmartTable").setUseTablePersonalisation(true);
						}

						this.fnGetOsvUrlVal();
					}
				}
			}

		},
		// below function is used to get the OSV URL ( when app is launched from Fiori launchpad)
		/*SOC BADH EAGLE-4333 2022/02/14*/
		onFilterInitialized: function () {
			if (this.fnGetParamExistsInURI("i_t") || this.fnGetParamExistsInURI("s") || window.location.href.includes("ZSTC-subscriptionStatusVisibility") || window.location.href.includes("ZSTC-SSV") || window.location.href.includes("app-tile")) {   //kkalikapuram GLBP - 1643 2024/06/19
				this._getContractDetails();
			}
		},
		/*EOC BADH EAGLE-4333 2022/02/14*/

		fnGetOsvUrlVal: function () {

			var oModel = this.getView().getModel("viewData");
			var oServiceModel = this._getODataModel();

			var sPath = "/Ets_defaultUrls";

			var mParameters = {
				method: "GET",
				success: jQuery.proxy(function (oData) {

					try {
						oModel.setProperty("/OrderURL", oData.results[1].osvorderurl);
						oModel.setProperty("/PunchOutData_Details/osvorderurl", oData.results[1].osvorderurl); // ACHOPRADELOI RAMP-1458 2023/10/25
						oModel.setProperty("/PunchOutData_Full/results/0/osvorderurl", oData.results[1].osvorderurl); // ACHOPRADELOI RAMP-1458 2023/10/25
					} catch (e) {
						oModel.setProperty("/OrderURL", "");
					}

					try {
						oModel.setProperty("/DefaultURL", oData.results[0].osvdefaulturl);
						oModel.setProperty("/PunchOutData_Details/osvdefaulturl", oData.results[0].osvdefaulturl); // ACHOPRADELOI RAMP-1458 2023/10/25
						oModel.setProperty("/PunchOutData_Full/results/0/osvdefaulturl", oData.results[0].osvdefaulturl); // ACHOPRADELOI RAMP-1458 2023/10/25
					} catch (e) {
						oModel.setProperty("/DefaultURL", "");
					}

					/*SOC EAGLE BADH SOME4028A 2021/08/26*/
					try {
						oModel.setProperty("/SFDCCaseWebformURL", oData.results[2].sfdccaseurl);
						oModel.setProperty("/PunchOutData_Details/sfdccaseurl", oData.results[2].sfdccaseurl); // ACHOPRADELOI RAMP-1458 2023/10/25
						oModel.setProperty("/PunchOutData_Full/results/0/sfdccaseurl", oData.results[2].sfdccaseurl); // ACHOPRADELOI RAMP-1458 2023/10/25
					} catch (e) {
						oModel.setProperty("/SFDCCaseWebformURL", "");
					}
					/*EOC EAGLE BADH SOME4028A 2021/08/26*/

					/*SOC ACHOPRADELOI RAMP-1458 2023/10/17*/
					// try {
					// 	oModel.setProperty("/asqpunchouturl", oData.results[3].sfdccaseurl);
					// } catch (e) {
					// 	oModel.setProperty("/asqpunchouturl", "");
					// }
					/*EOC ACHOPRADELOI RAMP-1458 2023/10/17*/

				}, this),
				error: jQuery.proxy(function (oError) {

				}, this)
			};

			oServiceModel.read(sPath, mParameters);

		},

		// to validate the entered date range format  
		fnOnLivechangeDateVal: function () {
			if (!this.fnGetParamExistsInURI("dateFormat") ) {
				var dateString = this.getView().byId("idDateRange").mProperties.value;
				var dateVal = this.getView().byId("idDateRange");
				var regEx = /^(\d{1,2})-(\d{1,2})-(\d{4}) - (\d{1,2})-(\d{1,2})-(\d{4})/g;

				if (dateString.match(regEx) === null) {
					var oSelectedItem = "";
					dateVal.setValue(oSelectedItem);
					MessageBox.error("Please enter date in MM-DD-YYYY - MM-DD-YYYY format");

				} else {
					return dateString;
				}
			}
		},

		//get oData model
		_getODataModel: function () {
			return this.getOwnerComponent().getModel();
		},

		//format date function
		_ChangeDateFormat: function () {

			if (this.dateFormat) {
				this.getView().getModel("viewData").setProperty("/DateFormat", this.dateFormat);
			} else {
				this.getView().getModel("viewData").setProperty("/DateFormat", "MM-dd-yyyy");
			}
		},

		fnGetContractDetailsCall: function (groupFilter , value) {
			var that = this;
			var oJsonModel = this.getOwnerComponent().getModel("localJsonModel");
			oJsonModel.setProperty("/sSetValueState", "None");
			oJsonModel.setProperty("/sSetValStateSearch", "None");
			checkFlag = false;
			oJsonModel.setProperty("/sDateRangeSetValueState", "None");
			oJsonModel.setProperty("/sDateTypeSetValueState", "None");
			var oModel = this.getView().getModel("viewData");
			oModel.setProperty("/ContractDetails", []);
			// this.getView().setBusy(true);
			if ((this.fnGetParamExistsInURI("i_t")||this.fnGetParamExistsInURI("s") || window.location.href.includes("ZSTC-subscriptionStatusVisibility") || window.location.href.includes("ZSTC-SSV") || window.location.href.includes("app-tile") ) && this.flagPunchoutCall === '' ) {
			// if(true){
				this.getView().setBusy(true);
				this.flagPunchoutCall = 'X';
				var oServiceModel = this._getODataModel();
				var tPath = "";
				var partnerFilter = [];
				if(this.fnGetParamExistsInURI("i_t")){
					 tPath = "/Ets_Hdrtoken";
					 partnerFilter.push(new sap.ui.model.Filter("token", "EQ", this.getModel("viewData").getProperty("/TokenValue")));
				}
				else{
					tPath = "/Ets_GetEmail";
					if (this.fnGetParamExistsInURI("imp")) {
						var impValue = this.fnGetParamIdFrmURI("imp"),
						decryptedImpValue = this.fnGetDecryptedParamIDs(impValue);
						partnerFilter.push(new sap.ui.model.Filter("emailId", "EQ", decryptedImpValue)); 
				}
					else{
						var sEmail = sap.ushell.Container.getService("UserInfo").getUser().getEmail();
						if(sEmail === undefined){
							sEmail = "";
							// sEmail =  "capesgma.s4upgrademhmg_3region@yopmail.com" //"capesgma.s4upgrademhmg_3region@yopmail.com" // shsguser1@yopmail.com
							}
						partnerFilter.push(new sap.ui.model.Filter("emailId", "EQ", sEmail));
						if(groupFilter !==undefined && groupFilter==="group"){
						partnerFilter.push(new sap.ui.model.Filter("groupId", "EQ", value));
						}
						else if(groupFilter !==undefined && groupFilter==="party"){
						partnerFilter.push(new sap.ui.model.Filter("partyId", "EQ", value));
						}

					}
				}
				oServiceModel.metadataLoaded().then(function () {
					oServiceModel.read(tPath, {
						method: "GET",
						filters: partnerFilter,
						urlParameters: {
							"$expand": "userData,userData/tierMapping,userData/userDetails,userData/userDetails/brTypeSet",
							"$format": "json"
						},
						success: function (oDataPartnerInfo) {
							this.getView().setBusy(false);
							try {
								this.userType = oDataPartnerInfo.results[0].userData.results[0].Usertype;
								if(oDataPartnerInfo.results[0].userData.results[0].Persona==="SALES_OPS" || oDataPartnerInfo.results[0].userData.results[0].Usertype.toUpperCase() === "INTERNAL"){
									this.userType = "Internal";
								}
								if(oDataPartnerInfo.results[0].userData.results[0].Usertype.toUpperCase()==="PARTNER" || oDataPartnerInfo.results[0].userData.results[0].Usertype.toUpperCase()==="CUSTOMER" ){
								oModel = this.getView().getModel("viewData");
								oModel.setProperty("/PunchOutData_Details", oDataPartnerInfo.results[0]);
								oModel.setProperty("/PunchOutData", oDataPartnerInfo.results[0].userData.results[0]);
								try {
									oModel.setProperty("/DefaultURL", oDataPartnerInfo.results[0].osvdefaulturl);
								} catch (e) {
									oModel.setProperty("/DefaultURL", "");
								}
								try {
									oModel.setProperty("/OrderURL", oDataPartnerInfo.results[0].osvorderurl);
								} catch (e) {
									oModel.setProperty("/OrderURL", "");
								}
								try {
									oModel.setProperty("/SFDCCaseWebformURL", oDataPartnerInfo.results[0].sfdccaseurl);
								} catch (e) {
									oModel.setProperty("/SFDCCaseWebformURL", "");
								}
								try {
									oModel.setProperty("/ASQPunchOutURL", oDataPartnerInfo.results[0].asqpunchouturl);
								} catch (e) {
									oModel.setProperty("/ASQPunchOutURL", "");
								}
								this.partnerFilters = oDataPartnerInfo;
								// MMOHAN8 MHMG design BOC
								if(this.fnCheckOorQParamInHash()){
									this.partnerFilters.results[0].orderNumber = this.fnGetDecryptedParamIDs(this.fnGetOandQParamValuesFromHash().o);
									this.partnerFilters.results[0].brimSolutionQuote = this.fnGetDecryptedParamIDs(this.fnGetOandQParamValuesFromHash().q);
									this.partnerFilters.results[0].userData.results[0].Pricingvisibility = this.fnGetDecryptedParamIDs(this.fnGetOandQParamValuesFromHash().p)==="X"? true : false;
								}
								/* if(oDataPartnerInfo.results[0].userData.results[0].tierMapping.results.length>0 && !this.fnCheckOorQParamInHash() && oDataPartnerInfo.results[0].userData.results[0].Usertype.toUpperCase()==="PARTNER" && !this.fnGetParamExistsInURI("i_t")){
									oModel.setProperty("/MHMGVisible", true);
									var tierMapping = oDataPartnerInfo.results[0].userData.results[0].tierMapping.results;
									var userDetails = oDataPartnerInfo.results[0].userData.results[0].userDetails.results;
									var MHMGSelectArr=[];
									for(var i=0;i<tierMapping.length;i++){
										MHMGSelectArr.push({profileId : i, profileName : tierMapping[i].BrtypeDesc + " || "  + userDetails[i].CountryDesc+" || Price flag:" + userDetails[i].PricingVisibilityPerID })
									}
									if(this.fnGetParamExistsInURI("h")){
										var lrOrgId = this.fnGetDecryptedParamIDs(this.fnGetParamIdFrmURI("h"));
											for(var i=0 ; i<userDetails.length;i++){
												if(userDetails[i].LrOrgId === lrOrgId){
														this.selectedKey = i;
														break;
												}
											}
									}
									oModel.setProperty("/MHMGSelectArr", MHMGSelectArr);
									oModel.setProperty("/MHMGSelectKey", this.selectedKey);
									if(this.partnerFilters.results[0].userData.results[0].userDetails.results[this.selectedKey].PricingVisibilityPerID ===""){
									// to hide the two reports
									this.getView().byId("idReportIconTabBar").getItems()[1].setEnabled(false);
									this.getView().byId("idReportIconTabBar").getItems()[2].setEnabled(false);
									this.partnerFilters.results[0].userData.results[0].Pricingvisibility = false;
									this.getView().getModel("viewData").setProperty("/viewInvoicesVisibility", false);
								}
								} */
								// MMOHAN8 MHMG design EOC
								var __oSmartTable = this.getView().byId("LineItemsSmartTable");
								__oSmartTable.rebindTable(true);
							}
							else if(oDataPartnerInfo.results[0].userData.results[0].Usertype.toUpperCase() === "INTERNAL" || (oDataPartnerInfo.results[0].userData.results[0].Persona === "SALES_REP" || oDataPartnerInfo.results[0].userData.results[0].Persona==="SALES_OPS")){
								oModel.setProperty("/MHMGVisible", false);
								this.fnSetUrlDataInMdl();
								this.flagPunchoutCall = 'X';
								this.partnerFilters = oModel.getProperty("/PunchOutData_Full");
								if(this.fnCheckOorQParamInHash()){
									this.partnerFilters = oDataPartnerInfo;
									this.partnerFilters.results[0].orderNumber = this.fnGetDecryptedParamIDs(this.fnGetOandQParamValuesFromHash().o);
									this.partnerFilters.results[0].brimSolutionQuote = this.fnGetDecryptedParamIDs(this.fnGetOandQParamValuesFromHash().q);
									this.partnerFilters.results[0].userData.results[0].Pricingvisibility = this.fnGetDecryptedParamIDs(this.fnGetOandQParamValuesFromHash().p)==="X"? true : false;
									var __oSmartTable = this.getView().byId("LineItemsSmartTable");
									__oSmartTable.rebindTable(true);
								}
							}
							} catch (e) {
								MessageBox.error("Invalid response!");
							}
						}.bind(this),
						error: function (err) {
							var msg = JSON.parse(err.responseText).error.message.value;
							MessageBox.error(msg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								onClose: function (oAction) {
									TokenFlag = true;
									oJsonModel.setProperty("/bTokenFlag", TokenFlag);
									that.getRouter().navTo("AccessDenied");
								}
							});
							this.getView().setBusy(false);
						}.bind(this)
					});
				}.bind(this));
			}
			 else {
				var __oSmartTable = this.getView().byId("LineItemsSmartTable");
				__oSmartTable.rebindTable();
			}

		},

		//GET call to get Order URL and Default URL
		_getContractDetails: function () {
			//Arjun: to override checks in case of punchout
			if (this.flagPunchoutCall !== 'X') {
				this.fnGetContractDetailsCall();
				return;
			}
			// <!--SOC Raghav SOME4028 - Part 1 - 1/6 - for-"Search box - if only a solution quote is entered or any value is entered in search box without 'Search By' populated then the system will continue to search. Therefore, if the search box is populated, then the Search By should be mandatory and the user needs to have an indicator such as outlining the Search By box in red to know it is a mandatory field if the Search box is populated. "-> 
			var oJsonModel = this.getOwnerComponent().getModel("localJsonModel"),
				sSearchFieldVal = this.getView().byId("idSerachField").getValue(),
				sSelectedKeyVal = this.getView().byId("idsearchby").getSelectedKey();
			checkFlag = false;

			var search = this.getView().byId("idSerachField").getValue();
			var searchid = this.getView().byId("idsearchby").getSelectedKey();
			var dateID = this.getView().byId("idDateID").getSelectedKey();
			var regionID = this.getView().byId("idRegion").getSelectedKey();

			var idCountry = this.getView().byId("idCountry");
			var countryTokens = idCountry.getTokens(),
				countryTokensVal = countryTokens.length,
				billingmodel = this.getView().byId("idbillingmodel").getSelectedKey(),
				SubscriptionType = this.getView().byId("idsubscriptiontype").getSelectedKey(),
				ProviderContractStatus = this.getView().byId("idprovidercontractstatus").getSelectedKey(),
				dateValue = this.getView().byId("idDateRange").getDateValue(),
				/*sLabOffice = this.getView().byId("idLabOffice").getSelectedKey(),*/ //EAGLE BADH SOME4028A 2021/08/2;
				sSalesOrg = this.getView().byId("idSalesOrg").getValue(), //BADH EAGLE-2619 2021/11/12
				sSalesOffice = this.getView().byId("idSalesOffice").getSelectedKey(); //BADH EAGLE-3304 2021/12/06

			if (search === "" && searchid === "" && dateID === "" && regionID === "" && countryTokensVal === 0 && billingmodel === "" &&
				SubscriptionType === "" && ProviderContractStatus === "" && sSalesOrg === "" && sSalesOffice === "") {

				MessageToast.show("Please select at least one filter", {
					width: "550px"
				});

			}

			if (dateID !== "" && dateValue === null) {

				MessageToast.show("Please select Date Range Value", {
					width: "350px"
				});

				oJsonModel.setProperty("/sDateRangeSetValueState", "Error");
				oJsonModel.setProperty("/sSetDateRangeText", "Cannot Be Empty");
				checkFlag = true;
			}

			if (dateValue !== null && dateID === "") {
				MessageToast.show("Please select Date Type field value from the dropdown list", {
					width: "350px"
				});
				oJsonModel.setProperty("/sDateTypeSetValueState", "Error");
				oJsonModel.setProperty("/sSetDateTypeText", "Cannot Be Empty");
				checkFlag = true;
			}

			if (sSearchFieldVal !== "" && sSelectedKeyVal === "") {

				MessageToast.show("Please select search By field value from the dropdown list", {
					width: "350px"
				});

				oJsonModel.setProperty("/sSetValueState", "Error");
				oJsonModel.setProperty("/sSetValueStateText", "Cannot Be Empty");
				checkFlag = true;

			}

			if (sSearchFieldVal !== "" && sSelectedKeyVal === "") {
				MessageToast.show("Please select search By field value from the dropdown list", {
					width: "350px"
				});
				oJsonModel.setProperty("/sSetValueState", "Error");
				oJsonModel.setProperty("/sSetValueStateSearchText", "Cannot Be Empty");
				checkFlag = true;

			}

			if (sSelectedKeyVal !== "" && sSearchFieldVal === "") {
				MessageToast.show("Please fill the search value", {
					width: "350px"
				});
				oJsonModel.setProperty("/sSetValStateSearch", "Error");
				checkFlag = true;

			}

			if (sSelectedKeyVal !== "" && sSearchFieldVal !== "" && dateID === "" && dateValue === null) {
				this.fnGetContractDetailsCall();
				return;
			}

			if (sSelectedKeyVal === "" && sSearchFieldVal === "" && dateID !== "" && dateValue !== null) {
				this.fnGetContractDetailsCall();
				return;
			}
			if (sSelectedKeyVal !== "" && sSearchFieldVal !== "" && dateID !== "" && dateValue !== null) {
				this.fnGetContractDetailsCall();
				return;
			}

			if (sSelectedKeyVal !== "" && sSearchFieldVal !== "" && dateID !== "" && dateValue === null) {
				MessageToast.show("Please select Date Range Value", {
					width: "350px"
				});

				oJsonModel.setProperty("/sDateRangeSetValueState", "Error");
				oJsonModel.setProperty("/sSetDateRangeText", "Cannot Be Empty");
				checkFlag = true;

			}
			if (sSelectedKeyVal !== "" && sSearchFieldVal !== "" && dateID === "" && dateValue !== null) {
				MessageToast.show("Please select Date Type field value from the dropdown list", {
					width: "350px"
				});
				oJsonModel.setProperty("/sDateTypeSetValueState", "Error");
				oJsonModel.setProperty("/sSetDateTypeText", "Cannot Be Empty");
				checkFlag = true;

			}
			//
			if (sSelectedKeyVal !== "" && sSearchFieldVal === "" && dateID !== "" && dateValue !== null) {
				MessageToast.show("Please fill the search value", {
					width: "350px"
				});
				oJsonModel.setProperty("/sSetValStateSearch", "Error");
				checkFlag = true;

			}
			if (sSelectedKeyVal === "" && sSearchFieldVal !== "" && dateID !== "" && dateValue !== null) {

				MessageToast.show("Please select search By field value from the dropdown list", {
					width: "350px"
				});
				oJsonModel.setProperty("/sSetValueState", "Error");
				oJsonModel.setProperty("/sSetValueStateText", "Cannot Be Empty");
				checkFlag = true;

			}

			if (regionID !== "" || countryTokensVal !== 0 || billingmodel !== "" ||
				SubscriptionType !== "" || ProviderContractStatus !== "" || dateID !== "" || dateValue !== null || sSalesOrg !==
				"" || sSalesOffice !== "") {
				if (checkFlag === false) {
					this.fnGetContractDetailsCall();
					return;
				}
			}
		},

		//on Press of Filter Bar GO button
		onPressGo: function () {
			this._getContractDetails();
		},

		//Pass filters before table rebind
		onBeforeRebindTable: function (oEvent) {

			var oBindingParams = oEvent.getParameter("bindingParams");
			var search = this.getView().byId("idSerachField").getValue();
			var searchid = this.getView().byId("idsearchby").getSelectedKey();
			var dateID = this.getView().byId("idDateID").getSelectedKey();
			var regionID = this.getView().byId("idRegion").getSelectedKey();
			var idCountry = this.getView().byId("idCountry");
			var countryTokens = idCountry.getTokens();
			var emailId = "";
			var orderNumber = "";
			var brimSolutionQuote = "";
			var Pricingvisibility = "";
			var Usertype = "";
			var andFilters = [];
			var combinedFilters = [];
			var billingmodel = this.getView().byId("idbillingmodel").getSelectedKey(),
				SubscriptionType = this.getView().byId("idsubscriptiontype").getSelectedKey(),
				ProviderContractStatus = this.getView().byId("idprovidercontractstatus").getSelectedKey(),
				/*sLabOffice = this.getView().byId("idLabOffice").getSelectedKey(), */ //EAGLE BADH SOME4028A 2021/08/24
				sSalesOrg = this.getView().byId("idSalesOrg").getValue(), //BADH EAGLE-2619 2021/11/12
				sSalesOffice = this.getView().byId("idSalesOffice").getSelectedKey(); //BADH EAGLE-3304 2021/12/06

			if (this.partnerFilters.results[0].userData && this.partnerFilters.results[0].userData.results[0]) {
				try {
					emailId = this.partnerFilters.results[0].emailId;
					emailId = emailId.split("|")[0];
					andFilters.push(new sap.ui.model.Filter("emailId", sap.ui.model.FilterOperator.EQ, emailId));
				} catch (e) {
					emailId = "";
				}
				try {
					orderNumber = this.partnerFilters.results[0].orderNumber;
					andFilters.push(new sap.ui.model.Filter("orderNumber", sap.ui.model.FilterOperator.EQ, orderNumber));
				} catch (e) {
					orderNumber = "";
				}
				try {
					brimSolutionQuote = this.partnerFilters.results[0].brimSolutionQuote;
					andFilters.push(new sap.ui.model.Filter("solutionQuoteId", sap.ui.model.FilterOperator.EQ, brimSolutionQuote));
				} catch (e) {
					brimSolutionQuote = "";
				}
				try {
					if(this.getView().getModel("viewData").getProperty("/MHMGVisible")){
						Pricingvisibility = this.partnerFilters.results[0].userData.results[0].userDetails.results[this.selectedKey].PricingVisibilityPerID === "X" ? true : false ;
					}
					else{
						Pricingvisibility = this.partnerFilters.results[0].userData.results[0].Pricingvisibility;
					}
					andFilters.push(new sap.ui.model.Filter("pricingVisibility", sap.ui.model.FilterOperator.EQ, Pricingvisibility));
				} catch (e) {
					Pricingvisibility = "";
				}
				try {
					Usertype = this.partnerFilters.results[0].userData.results[0].Usertype;
					andFilters.push(new sap.ui.model.Filter("userType", sap.ui.model.FilterOperator.EQ, Usertype));
				} catch (e) {
					Usertype = "";
				}
			}

			if (search) {
				andFilters.push(new sap.ui.model.Filter("search", "EQ", search));
			}

			if (regionID) {
				andFilters.push(new sap.ui.model.Filter("region", "EQ", regionID));
			}

			if (countryTokens) {
				var aTokens = [];
				countryTokens.forEach(function (data) {
					var t = data.getKey();
					aTokens.push(t);
				});

				for (var i = 0; i < aTokens.length; i++) {
					andFilters.push(new sap.ui.model.Filter("country", "EQ", aTokens[i]));
				}

			}

			if (searchid) {
				andFilters.push(new sap.ui.model.Filter("searchId", "EQ", searchid));
			}

			if (billingmodel) {
				andFilters.push(new sap.ui.model.Filter("billModel", "EQ", billingmodel));
			}

			if (SubscriptionType) {
				andFilters.push(new sap.ui.model.Filter("subsType", "EQ", SubscriptionType));
			}
			if (ProviderContractStatus) {
				andFilters.push(new sap.ui.model.Filter("contractStatus", "EQ", ProviderContractStatus));
			}
			//SOC EAGLE BADH SOME4028A 2021/08/24
			/*if (sLabOffice) {
				andFilters.push(new sap.ui.model.Filter("labOffice", "EQ", sLabOffice));
			}*/
			//EOC EAGLE BADH SOME4028A 2021/08/24

			//SOC BADH EAGLE-2619 2021/08/24
			if (sSalesOrg) {
				andFilters.push(new sap.ui.model.Filter("salesOrg", "EQ", sSalesOrg));
			}
			//EOC BADH EAGLE-2619 2021/08/24

			//SOC EAGLE-3304 2021/12/06
			if (sSalesOffice) {
				andFilters.push(new sap.ui.model.Filter("salesOff", "EQ", sSalesOffice));
			}
			//EOC EAGLE-3304 2021/12/06

			if (dateID) {
				var lowDate = this.getView().byId("idDateRange").getDateValue();
				//BOC VSINGH for UTC date conversion
				lowDate = formatter.changeDateToUTC(lowDate);
				//EOC VSINGH
				var highDate = this.getView().byId("idDateRange").getSecondDateValue();
				highDate = formatter.changeDateToUTC(highDate);

				//	var lowDateUTC = oDateFormat.format(lowDate);
				andFilters.push(new sap.ui.model.Filter("dateId", "EQ", dateID));
				andFilters.push(new sap.ui.model.Filter("date", "BT", lowDate, highDate));
			}

			if (this.partnerFilters.results[0].userData && this.partnerFilters.results[0].userData.results[0]) {
				if(this.getView().getModel("viewData").getProperty("/MHMGVisible")){
					var tiereFilter = this.getTierMappingFilter(this.partnerFilters)[this.selectedKey];
					var userDetailFilter = this.getUserDetailsFilter(this.partnerFilters)[this.selectedKey];
				andFilters.push(new sap.ui.model.Filter(tiereFilter.sPath, tiereFilter.sOperator, tiereFilter.oValue1));
				andFilters.push(new sap.ui.model.Filter(userDetailFilter.sPath, userDetailFilter.sOperator,userDetailFilter.oValue1));
				}
				else{
					andFilters.push(new sap.ui.model.Filter(this.getTierMappingFilter(this.partnerFilters), false));
					andFilters.push(new sap.ui.model.Filter(this.getUserDetailsFilter(this.partnerFilters), false));
				}
			}

			combinedFilters = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter(andFilters, true)
				],
				and: true
			});
			oBindingParams.filters.push(combinedFilters);

			/*soc szanzaney 01/28 FUT issue - remove check on TIER for invoice visibilty*/

			if (Pricingvisibility === false || Pricingvisibility === "false") {
				this.getView().getModel("viewData").setProperty("/viewInvoicesVisibility", false);
			}

			/*eoc szanzaney 01/28 FUT issue - remove check on TIER invoice visibilty*/
		},

		onChangeMHMGProfile : function(e){
			this.selectedKey = e.mParameters.selectedItem.mProperties.key
			var __oSmartTable = this.getView().byId("LineItemsSmartTable");
				__oSmartTable.rebindTable(true);
			if(this.partnerFilters.results[0].userData.results[0].userDetails.results[this.selectedKey].PricingVisibilityPerID ===""){
					this.partnerFilters.results[0].userData.results[0].Pricingvisibility=false;
					this.getView().getModel("viewData").setProperty("/viewInvoicesVisibility", false);
					this.getView().byId("idReportIconTabBar").getItems()[1].setEnabled(false);
					this.getView().byId("idReportIconTabBar").getItems()[2].setEnabled(false);
			}
			else if(this.partnerFilters.results[0].userData.results[0].userDetails.results[this.selectedKey].PricingVisibilityPerID ==="X"){
					this.partnerFilters.results[0].userData.results[0].Pricingvisibility=true;
					this.getView().getModel("viewData").setProperty("/viewInvoicesVisibility", true);
					this.getView().byId("idReportIconTabBar").getItems()[1].setEnabled(true);
					this.getView().byId("idReportIconTabBar").getItems()[2].setEnabled(true);
			}
		},

		//on Provider Contract link press, get Contract Details and Partners
		onPress: function (oEvent) {
			var oTable = this.getView().byId("LineItemsSmartTable"),
				currentRowContext = oEvent.oSource.oPropagatedProperties.oBindingContexts.undefined,
				OrderNumber = oTable.getModel().getProperty("orderNumber", currentRowContext),
				providerContract = oEvent.getSource().mBindingInfos.text.binding.oValue;

			this.getView().getModel("viewData").setProperty("/ContractDetailsOrderNumber", OrderNumber);
			this.getView().getModel("viewData").setProperty("/ProviderContract", providerContract);

			this.getRouter().navTo("Results");
		},

		//OSV navigation
		onOsvPress: function (oEvent) {
			var osvUrl = this.getView().getModel("viewData").getProperty("/DefaultURL");
			window.open(osvUrl);
		},

		//Variant Navigation - Dummy Button
		onDummyPress: function () {

			var oServiceModel = this._getODataModel();

			var sPath = "/Ets_AVC";
			var mParameters = {
				method: "GET",
				success: jQuery.proxy(function (oData) {
					var sURLPath = oData.results[0].Url;
					this.myWindow = window.open(sURLPath, "_blank");
				}, this),
				error: jQuery.proxy(function (oError) {

				}, this)
			};

			oServiceModel.read(sPath, mParameters);

		},

		//Open Value help Box for Country
		handleValueHelpCountry: function (oEvent) {
			this.flagCountry = "S";

			if (!this._oCountry) {
				this._oCountry = sap.ui.xmlfragment("som.ssv.fragments.ValueHelpCountry", this);
				this.getView().addDependent(this._oCountry);
				// Remember selections if required
				this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
			}
			var region = this.getView().byId("idRegion").getSelectedKey();
			this._getCountry(region);
			this._oCountry.open();

		},

		//handle the search with the Value help of Country
		handleCountrySearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([new sap.ui.model.Filter([
				new sap.ui.model.Filter("countryID", sap.ui.model.FilterOperator.Contains, sValue),
				new sap.ui.model.Filter("countryName", sap.ui.model.FilterOperator.Contains, sValue)
			], false)]);
		},

		//close value help dialog box after selection
		handleCountryConfirm: function (oEvent) {
			var oModel = this.getModel("viewData");
			//	var region = oModel.setProperty("/EngineeringRecord", []);
			var aContexts = oEvent.getParameter("selectedContexts");
			var selection = aContexts.map(function (oContext) {
				return oContext.getObject().countryID;
			}).join(", ");

			var tokenselection = aContexts.map(function (oContext) {
				return {
					key: oContext.getObject().countryID,
					text: oContext.getObject().countryName
				};

			});
			var aTokens = [];
			tokenselection.forEach(function (data) {
				var t = new sap.m.Token(data);
				aTokens.push(t);
			});

			if (this.flagCountry === "S") {
				this.getView().byId("idCountry").setTokens(aTokens);
			} else if (this.flagCountry === "CS") {
				this.getView().byId("idCountryCS").setTokens(aTokens);
			} else if (this.flagCountry === "UAR") {
				this.getView().byId("idCountryUAR").setTokens(aTokens);
			} else if (this.flagCountry === "IAB") {
				this.getView().byId("idCountryIAB").setTokens(aTokens);
			}
			/*SOC BADH EAGLE-SOME4028B 2021/01/28*/
			else if (this.flagCountry === "CCC") {
				this.getView().byId("idCountryCCC").setTokens(aTokens);
			}
			/*EOC BADH EAGLE-SOME4028B 2021/01/28*/
			if (aContexts && aContexts.length) {
				MessageToast.show("You have chosen " + aContexts.map(function (oContext) {
					return oContext.getObject().countryName;
				}).join(", "));
			}

			oEvent.getSource().getBinding("items").filter([]);
		},

		//close value help dialog box
		handleClose: function (oEvent) {
			oEvent.getSource().getBinding("items").filter([]);

		},

		//for excel copy paste of Country
		onTokenUpdateCountry: function (oEvt) {
			var idCountry = this.getView().byId("idCountry");
			idCountry.addValidator(this._multiInputValidator);
		},

		/*Functions for Reports section*/

		//report type select
		onReportChange: function () {
			var _oView = this.getView(),
				reportType = _oView.byId("idReportIconTabBar").getSelectedKey();

			_oView.byId("idContractStatusF1").setVisible(false);
			_oView.byId("idIABF1").setVisible(false);
			_oView.byId("idUARF1").setVisible(false);
			_oView.byId("idUARF2").setVisible(false);
			_oView.byId("idUARF3").setVisible(false);
			_oView.byId("idUARF4").setVisible(false);
			_oView.byId("idUARF5").setVisible(false);
			_oView.byId("idDMIF1").setVisible(false);
			_oView.byId("idCCCF1").setVisible(false);
			_oView.byId("idCCCF2").setVisible(false);
			_oView.byId("idCCCF3").setVisible(false);
			_oView.byId("idCCCF4").setVisible(false);
			_oView.byId("idCCCF5").setVisible(false);

			var __oViewModel = sap.ui.getCore().getModel("viewData"); // Flag to identify internal users
			if (sap.ushell && sap.ushell.Container && this.userType.toUpperCase()==="INTERNAL") {
				__oViewModel.setProperty("/bInternal", true);
			} else {
				var __oPunchOutData = __oViewModel.getProperty("/PunchOutData"),
					__sUserType = __oPunchOutData.Usertype;
				if (__sUserType.toUpperCase() === "INTERNAL") {
					__oViewModel.setProperty("/bInternal", true);
				} else {
					__oViewModel.setProperty("/bInternal", false);
				}
			}

			/*EOC BADH EAGLE-SOME4028B 2021/01/28*/
			if (reportType === "1") {
				_oView.byId("idContractStatusF1").setVisible(true);
			} else if (reportType === "2") {
				_oView.byId("idIABF1").setVisible(true);
			} else if (reportType === "3") {
				_oView.byId("idUARF1").setVisible(true);
				_oView.byId("idUARF2").setVisible(true);
				_oView.byId("idUARF3").setVisible(true);
				_oView.byId("idUARF4").setVisible(true);
				_oView.byId("idUARF5").setVisible(true);
			} else if (reportType === "4") {
				_oView.byId("idDMIF1").setVisible(true);
			} else if (reportType === "5") {
				_oView.byId("idCCCF1").setVisible(true);
				_oView.byId("idCCCF2").setVisible(true);
				_oView.byId("idCCCF3").setVisible(true);
				_oView.byId("idCCCF4").setVisible(true);
				_oView.byId("idCCCF5").setVisible(true);
			}
		},

		//Run report
		onReportRun: function () {
			var reportType = this.getView().byId("idReportIconTabBar").getSelectedKey(),
				oModel = this.getView().getModel("viewData");
			// Begin defect 10555 GASINGHDELOI
			var bInternal = true; // Flag to identify internal users
			// if (!this.fnGetParamExistsInURI("i_t") || !this.fnGetParamExistsInURI("s")/**&& oModel.getProperty("/Persona") && oModel.getProperty("/Persona") === "SALES_OPS" **/) {
			// 	//Internal User FLP //Date Fields Mand Logic
			// 	if (reportType === "1") {
			// 		this._Report1(bInternal);
			// 	} else if (reportType === "2") {
			// 		this._Report2(bInternal);
			// 	} else if (reportType === "3") {
			// 		this._Report3(bInternal);
			// 	} else if (reportType === "4") {
			// 		this._Report4(bInternal);
			// 	} else if (reportType === "5") {
			// 		this._Report5(bInternal); //BADH EAGLE-SOME4028B 2021/11/08
			// 	}
			// } else {
				// var oLocalPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				// var sUserType = oLocalPunchoutData.Usertype;
				if (this.userType.toUpperCase() === "INTERNAL") {
					//Internal User Punchout //Date Fields Mand Logic
					if (reportType === "1") {
						this._Report1(bInternal);
					} else if (reportType === "2") {
						this._Report2(bInternal);
					} else if (reportType === "3") {
						this._Report3(bInternal);
					} else if (reportType === "4") {
						this._Report4(bInternal);
					} else if (reportType === "5") {
						this._Report5(bInternal); //BADH EAGLE-SOME4028B 2021/11/08
					}
				} else {
					//Party ID Mand Logic
					if (reportType === "1") {
						this._Report1(!bInternal);
					} else if (reportType === "2") {
						this._Report2(!bInternal);
					} else if (reportType === "3") {
						this._Report3(!bInternal);
					} else if (reportType === "4") {
						this._Report4(!bInternal);
					} else if (reportType === "5") {
						this._Report5(!bInternal); //BADH EAGLE-SOME4028B 2021/11/08
					}
				}
			// }
			// End defect 10555 GASINGHDELOI
		},

		// for Contract Status
		_Report1: function (bInternal) {

			var aPartyToken = this.getView().byId("idPartyID"),
				aPartyId = [],
				oModel = this.getView().getModel("viewData");
			for (var u = 0; u < aPartyToken.getTokens().length; u++) {
				var t1 = aPartyToken.getTokens()[u].getText();
				aPartyId.push(t1);
			}

			var partyType = this.getView().byId("idPartyType").getSelectedKey(),

				contractLowDate = this.getView().byId("idDateRangeContract").getDateValue(),
				contractHighDate = this.getView().byId("idDateRangeContract").getSecondDateValue(),
				activationLowDate = this.getView().byId("idDateRangeActivation").getDateValue(),
				activationHighDate = this.getView().byId("idDateRangeActivation").getSecondDateValue(),
				documentTypeSel = this.getView().byId("idsubscriptiontypeRepCS").getSelectedKey();
			if (documentTypeSel === "ST1") {
				var documentType = "ZQST";
			} else if (documentTypeSel === "ST2") {
				documentType = "ZQTR";
			} else {
				documentType = "";
			}
			var HPEQuotNo = this.getView().byId("idHPEQuotNo").getValue(),
				regionID = this.getView().byId("idRegionCS").getSelectedKey(),
				idCountry = this.getView().byId("idCountryCS"),
				countryTokens = idCountry.getTokens();

			contractLowDate = formatter.changeDateToUTC(contractLowDate);
			contractHighDate = formatter.changeDateToUTC(contractHighDate);
			activationLowDate = formatter.changeDateToUTC(activationLowDate);
			activationHighDate = formatter.changeDateToUTC(activationHighDate);

			var aTokens = [];
			countryTokens.forEach(function (data) {
				var t = data.getKey();
				aTokens.push(t);
			});
			var arr = [];
			var obj = {};
			var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// for Punchout Scenario 
			// if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/PunchOutData").Persona && (oModel.getProperty("/PunchOutData").Persona !== "SALES_OPS" || oModel.getProperty("/PunchOutData").Persona !== "SALES_REP"))) {
			if (this.userType.toUpperCase() === "PARTNER" ) {
				var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
				var l_pricingVisibility = localPunchoutData.Pricingvisibility,
					l_pricingVisibility = l_pricingVisibility.toString(),
					l_tierMapping = [],
					l_userDetails = [],
					l_userType = localPunchoutData.Usertype;
				if (localPunchoutData.tierMapping.results.length !== 0) {
					for(var i=0; i<localPunchoutData.tierMapping.results.length; i++){
						l_tierMapping.push({ "tierMapping" :  localPunchoutData.tierMapping.results[i].Tier + "," + localPunchoutData.tierMapping.results[i].Brtypecode})
					}
					// var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
				} else {
					l_tierMapping = [{"tierMapping" : ""}];
				}
				if (localPunchoutData.userDetails.results.length !== 0) {
					for(var i=0; i<localPunchoutData.userDetails.results.length; i++){
						l_userDetails.push({  "userDetails" :  localPunchoutData.userDetails.results[i].Groupid + "," + localPunchoutData.userDetails.results[i].Partyid +
						"," + localPunchoutData.userDetails.results[i].Visibilitytype +
						"," + localPunchoutData.userDetails.results[i].brTypeSet.results[0].Brtype})
					}

					/* var l_userDetails = localPunchoutData.userDetails.results[0].Groupid + "," + localPunchoutData.userDetails.results[0].Partyid +
						"," + localPunchoutData.userDetails.results[0].Visibilitytype +
						"," + localPunchoutData.userDetails.results[0].brTypeSet.results[0].Brtype; */

				} else {
					l_userDetails = [{"userDetails" : ""}];
				}

				var l_orderNumber = localPunchoutData_Details.orderNumber,
					l_emailId = localPunchoutData_Details.emailId,
					l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
				l_emailId = l_emailId.split("|")[0];
			}

			if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
				//Checks mandatory fields for Non-INTERNAL users
				MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
				this.getView().setBusy(false);

			} else if (((contractLowDate === null || contractHighDate === null) && (activationLowDate === null || activationHighDate === null)) &&
				bInternal) {
				//Checks mandatory fields for INTERNAL users
				MessageBox.error("Please fill the mandatory date fields.");
				this.getView().setBusy(false);
			} else {
				var _exeRpt1fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

					// Begin Defect 10555 GASINGHDELOI
					if (partyType === "") {
						//Begin jmezadeloitte defect 12427
						if (nLenOfPayload === undefined) {
							var data = {
								"emailId": l_emailId,
								"orderNumber": l_orderNumber,
								"HPEQuoteNo": l_brimSolQuote,
								"pricingVisibility": l_pricingVisibility,
								"userType": l_userType,
								"zcontractNo": "",
								"zcontractItem": "",
								"contractStatusReportNav": arr
							};

							obj = {
								"distributorID": "",
								"resellerID": "",
								"endCustID": "",
								"endCustName": "",
								"contractStartDateB": contractLowDate,
								"contractStartDateE": contractHighDate,
								"Country": "",
								"Region": regionID,
								"docType": documentType,
								"contractEndDateB": activationLowDate,
								"contractEndDateE": activationHighDate,
								"HPEQuoteNo": HPEQuotNo
							};
							data.contractStatusReportNav.push(obj);
						} else {
							//Begin jmezadeloitte defect 12427
							if (nLenOfPayload === 0 || nLenOfPayload === undefined) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"contractStatusReportNav": arr
								};
								obj = {
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};
								arr.push(obj);
								//End jmezadeloitte defect 12427
							} else {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"contractStatusReportNav": arr
									};
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}
									obj = {
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractStartDateB": contractLowDate,
										"contractStartDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"contractEndDateB": activationLowDate,
										"contractEndDateE": activationHighDate,
										"HPEQuoteNo": HPEQuotNo
									};
									arr.push(obj);
									//data.contractStatusReportNav.push(obj);
								}
							}
						}
						//END jmezadeloitte defect 12427
					}
					//if (partyType === "1") {
					else if (partyType === "1") {
						// End Defect 10555 GASINGHDELOI
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"contractStatusReportNav": arr
								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj = {
									"distributorID": nPartyIDVal,
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};
								arr.push(obj);

							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"contractStatusReportNav": arr,
									"tierMappingNav":  l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj = {
									"distributorID": nPartyIDVal,
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};
								arr.push(obj);
							}
						}

					} else if (partyType === "2") {

						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"contractStatusReportNav": arr
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj = {
									"distributorID": "",
									"resellerID": nPartyIDVal,
									"endCustID": "",
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};

								arr.push(obj);

							}

						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"contractStatusReportNav": arr,
									"tierMappingNav":  l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj = {
									"distributorID": "",
									"resellerID": nPartyIDVal,
									"endCustID": "",
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};
								arr.push(obj);

							}

						}

					} else if (partyType === "3") {
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"contractStatusReportNav": arr
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj = {
									"distributorID": "",
									"resellerID": "",
									"endCustID": nPartyIDVal,
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};

								arr.push(obj);

							}

						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"contractStatusReportNav": arr,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj = {
									"distributorID": "",
									"resellerID": "",
									"endCustID": nPartyIDVal,
									"endCustName": "",
									"contractStartDateB": contractLowDate,
									"contractStartDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"contractEndDateB": activationLowDate,
									"contractEndDateE": activationHighDate,
									"HPEQuoteNo": HPEQuotNo
								};
								arr.push(obj);

							}

						};

					}

					var oServiceModel = this._getODataModel();

					var sPath = "/Ets_ConStatRep";
					this.getView().setBusy(true);

					var mParameters = {
						method: "POST",
						success: jQuery.proxy(function (oData) {

							this.getView().setBusy(false);
							if (oData.errorMsg.length !== 0) {
								var errMasg = oData.errorMsg;
								MessageBox.error(errMasg);
							} else {
								var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_ContStatRepFile('" + oData.zguid22 + "')/$value";
								window.open(sUrl, "_blank");
							}

						}, this),

						error: jQuery.proxy(function (oError) {

							this.getView().setBusy(false);
							var oMessage = oError.headers.errorMsg;
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
							if (typeof oMessage !== "undefined") {
								oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
							} else if (oError.statusCode === "502") { // Timeout issue
								oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
							} else {
								oMessage = oError.message;
							}
							MessageBox.error(oMessage, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
							});
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
						}, this)
					};

					oServiceModel.create(sPath, data, mParameters);
					/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}.bind(this);

				var sMsgDateValidRpt1 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
					bMsgDateValidRpt1 = true;

				if (contractHighDate !== null && contractLowDate !== null) {
					if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
						bMsgDateValidRpt1 = false;
					}
				}

				if (activationHighDate !== null && activationLowDate !== null) {
					if (((activationHighDate.getTime() - activationLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
						bMsgDateValidRpt1 = false;
					}
				}

				if (!bMsgDateValidRpt1) {
					this.getView().setBusy(false);

					MessageBox.show(
						sMsgDateValidRpt1, {
						icon: MessageBox.Icon.WARNING,
						title: "Warning",
						actions: ["Proceed", MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.CANCEL,
						onClose: function (oAction) {
							if (oAction === "Proceed") {
								_exeRpt1fn();
							}
						}
					}
					);

				} else {
					_exeRpt1fn();
				}
				/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			}

		},

		// for Invoice Billing
		_Report2: function (bInternal) {

			var aPartyToken = this.getView().byId("idPartyIDIAB"),
				aPartyId = [],
				oModel = this.getView().getModel("viewData");
			for (var u = 0; u < aPartyToken.getTokens().length; u++) {
				var t1 = aPartyToken.getTokens()[u].getText();
				aPartyId.push(t1);
			}

			var partyType = this.getView().byId("idPartyTypeIAB").getSelectedKey(),
				contractLowDate = this.getView().byId("idDateRangeContractIAB").getDateValue(),
				contractHighDate = this.getView().byId("idDateRangeContractIAB").getSecondDateValue(),
				HPESolQuLowDate = this.getView().byId("idDateRangeHPESolQuIAB").getDateValue(),
				HPESolQuHighDate = this.getView().byId("idDateRangeHPESolQuIAB").getSecondDateValue(),
				HPEQuotLowDate = this.getView().byId("idDateRangeHPEQuoteIAB").getDateValue(),
				HPEQuotHighDate = this.getView().byId("idDateRangeHPEQuoteIAB").getSecondDateValue(),
				invoicingLowDate = this.getView().byId("idDateRangeInvoicingIAB").getDateValue(),
				invoicingHighDate = this.getView().byId("idDateRangeInvoicingIAB").getSecondDateValue();
			var documentTypeSel = this.getView().byId("idsubscriptiontypeRepIAB").getSelectedKey();
			if (documentTypeSel === "ST1") {
				var documentType = "ZQST";
			} else if (documentTypeSel === "ST2") {
				documentType = "ZQTR";
			} else {
				documentType = "";
			}
			var billingType = this.getView().byId("idBillingTypeIAB").getSelectedKey(),
				invoiceFreq = this.getView().byId("idInvoiceFreqIAB").getValue(),
				HPEQuotNo = this.getView().byId("idHPEQuotNoIAB").getValue(),
				ContractStatus = this.getView().byId("idContractStatusIAB").getSelectedKey(),
				regionID = this.getView().byId("idRegionIAB").getSelectedKey(),
				idCountry = this.getView().byId("idCountryIAB"),
				countryTokens = idCountry.getTokens();

			contractLowDate = formatter.changeDateToUTC(contractLowDate);
			contractHighDate = formatter.changeDateToUTC(contractHighDate);
			HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
			HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
			HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
			HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);
			invoicingLowDate = formatter.changeDateToUTC(invoicingLowDate);
			invoicingHighDate = formatter.changeDateToUTC(invoicingHighDate);

			var aTokens = [];
			countryTokens.forEach(function (data) {
				var t = data.getKey();
				aTokens.push(t);
			});
			var arr1 = [];
			var obj1 = {};
			var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/PunchOutData").Persona && (oModel.getProperty("/PunchOutData").Persona !== "SALES_OPS" || oModel.getProperty("/PunchOutData").Persona !== "SALES_REP"))) {
			if (this.userType.toUpperCase() === "PARTNER" ) {
				var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
				var l_pricingVisibility = localPunchoutData.Pricingvisibility,
					l_pricingVisibility = l_pricingVisibility.toString(),
					l_tierMapping = [],
					l_userDetails = [],
					l_userType = localPunchoutData.Usertype;
				if (localPunchoutData.tierMapping.results.length !== 0) {
					for(var i=0; i<localPunchoutData.tierMapping.results.length; i++){
						l_tierMapping.push({ "tierMapping" :  localPunchoutData.tierMapping.results[i].Tier + "," + localPunchoutData.tierMapping.results[i].Brtypecode})
					}
					// var l_tierMapping = localPunchoutData.tierMapping.results[0].Tier + "," + localPunchoutData.tierMapping.results[0].Brtypecode;
				} else {
					l_userDetails = [{"userDetails" : ""}];
				}
				if (localPunchoutData.userDetails.results.length !== 0) {
					for(var i=0; i<localPunchoutData.userDetails.results.length; i++){
						l_userDetails.push({  "userDetails" :  localPunchoutData.userDetails.results[i].Groupid + "," + localPunchoutData.userDetails.results[i].Partyid +
						"," + localPunchoutData.userDetails.results[i].Visibilitytype +
						"," + localPunchoutData.userDetails.results[i].brTypeSet.results[0].Brtype})
					}
				} else {
					l_userDetails = [{"userDetails" : ""}];
				}

				var l_orderNumber = localPunchoutData_Details.orderNumber,
					l_emailId = localPunchoutData_Details.emailId,
					l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
				l_emailId = l_emailId.split("|")[0];
			}

			if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
				//Checks mandatory fields for Non-INTERNAL users
				MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
				this.getView().setBusy(false);
			} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
				HPEQuotLowDate === null || HPEQuotHighDate === null) && (invoicingLowDate === null || invoicingHighDate === null)) && bInternal) {
				//Checks mandatory fields for INTERNAL users
				MessageBox.error("Please fill the mandatory date fields.");
				this.getView().setBusy(false);
			} else {

				var _exeRpt2fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
					// Begin Defect 10555 GASINGHDELOI
					if (partyType === "") {
						//BEGIN jmezadeloitte defect 12427
						if (nLenOfPayload === undefined) {
							var data = {
								"emailId": l_emailId,
								"orderNumber": l_orderNumber,
								"HPEQuoteNo": l_brimSolQuote,
								"pricingVisibility": l_pricingVisibility,
								"userType": l_userType,
								"zcontractNo": "",
								"zcontractItem": "",
								"invoiceBillReportNav": []
							};
							obj1 = {
								"creationStartDate": HPESolQuLowDate,
								"creationEndDate": HPESolQuHighDate,
								"contractStartDateB": HPEQuotLowDate,
								"contractStartDateE": HPEQuotHighDate,
								"contractSatus": ContractStatus,
								"distributorID": "",
								"resellerID": "",
								"endCustID": "",
								"endCustName": "",
								"contractEndDateB": contractLowDate,
								"contractEndDateE": contractHighDate,
								"Country": "",
								"Region": regionID,
								"docType": documentType,
								"invoiceStartDate": invoicingLowDate,
								"invoiceEndDate": invoicingHighDate,
								"billType": billingType,
								"frequency": invoiceFreq,
								"HPEQuoteNo": HPEQuotNo
							};
							data.invoiceBillReportNav.push(obj1);
						} else {
							//Begin jmezadeloitte defect 12427
							if (nLenOfPayload === 0) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"invoiceBillReportNav": arr1
								};
								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								arr1.push(obj1);
							} else {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"invoiceBillReportNav": arr1
									};
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}
									obj1 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"invoiceStartDate": invoicingLowDate,
										"invoiceEndDate": invoicingHighDate,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr1.push(obj1);
								}
							}
						} //END jmezadeloitte defect 12427
					}
					//if (partyType === "1") {
					else if (partyType === "1") {
						// End Defect 10555 GASINGHDELOI
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"invoiceBillReportNav": arr1
								};

								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}
								//if(jQuery.sap.getUriParameters().get("i_t")===null){

								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": nPartyIDVal,
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};

								arr1.push(obj1);

							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"invoiceBillReportNav": arr1,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": nPartyIDVal,
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};

								arr1.push(obj1);

							}

						}

					} else if (partyType === "2") {

						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"invoiceBillReportNav": arr1
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": nPartyIDVal,
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo

								};
								arr1.push(obj1);
							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"invoiceBillReportNav": arr1,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": nPartyIDVal,
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo

								};

								arr1.push(obj1);

							}

						}

					} else if (partyType === "3") {
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"invoiceBillReportNav": arr1
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": nPartyIDVal,
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo

								};
								arr1.push(obj1);
							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"invoiceBillReportNav": arr1,
									"tierMappingNav":  l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj1 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": nPartyIDVal,
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"invoiceStartDate": invoicingLowDate,
									"invoiceEndDate": invoicingHighDate,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo

								};

								arr1.push(obj1);

							}

						}
					}
					this.getView().setBusy(true);

					var oServiceModel = this._getODataModel();

					var sPath = "/Ets_InvBillRep";

					var mParameters = {
						method: "POST",
						success: jQuery.proxy(function (oData) {
							this.getView().setBusy(false);

							this.getView().setBusy(false);
							if (oData.errorMsg.length !== 0) {
								var errMasg = oData.errorMsg;
								MessageBox.error(errMasg);
							} else {

								var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_InvBillRepFile('" + oData.zguid22 + "')/$value";
								window.open(sUrl, "_blank");
							}

						}, this),

						error: jQuery.proxy(function (oError) {

							this.getView().setBusy(false);
							var oMessage = oError.headers.errorMsg;
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
							if (typeof oMessage !== "undefined") {
								oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
							} else if (oError.statusCode === "502") { // Timeout issue
								oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
							} else {
								oMessage = oError.message;
							}
							MessageBox.error(oMessage, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
							});
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
						}, this)
					};

					oServiceModel.create(sPath, data, mParameters);
					/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}.bind(this);

				var sMsgDateValidRpt2 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
					bMsgDateValidRpt2 = true;

				if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
					if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
						bMsgDateValidRpt2 = false;
					}
				}

				if (contractHighDate !== null && contractLowDate !== null) {
					if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
						bMsgDateValidRpt2 = false;
					}
				}

				if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
					if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
						bMsgDateValidRpt2 = false;
					}
				}

				if (invoicingHighDate !== null && invoicingLowDate !== null) {
					if (((invoicingHighDate.getTime() - invoicingLowDate.getTime()) / (1000 * 3600 * 24)) > 90) {
						bMsgDateValidRpt2 = false;
					}
				}

				if (!bMsgDateValidRpt2) {
					this.getView().setBusy(false);

					MessageBox.show(
						sMsgDateValidRpt2, {
						icon: MessageBox.Icon.WARNING,
						title: "Warning",
						actions: ["Proceed", MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.CANCEL,
						onClose: function (oAction) {
							if (oAction === "Proceed") {
								_exeRpt2fn();
							}
						}
					}
					);

				} else {
					_exeRpt2fn();
				}
				/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			}

		},

		// for Usage and Rate Report
		_Report3: function (bInternal) {

			var aPartyToken = this.getView().byId("idPartyIDUAR"),
				aPartyId = [],
				oModel = this.getView().getModel("viewData");
			for (var u = 0; u < aPartyToken.getTokens().length; u++) {
				var t1 = aPartyToken.getTokens()[u].getText();
				aPartyId.push(t1);
			}

			var partyType = this.getView().byId("idPartyTypeUAR").getSelectedKey(),
				partyID = this.getView().byId("idPartyIDUAR").getValue(),
				contractLowDate = this.getView().byId("idDateRangeContractUAR").getDateValue(),
				contractHighDate = this.getView().byId("idDateRangeContractUAR").getSecondDateValue(),
				HPESolQuLowDate = this.getView().byId("idDateRangeHPESolQuUAR").getDateValue(),
				HPESolQuHighDate = this.getView().byId("idDateRangeHPESolQuUAR").getSecondDateValue(),
				HPEQuotLowDate = this.getView().byId("idDateRangeHPEQuoteUAR").getDateValue(),
				HPEQuotHighDate = this.getView().byId("idDateRangeHPEQuoteUAR").getSecondDateValue();
			var documentTypeSel = this.getView().byId("idsubscriptiontypeRepUAR").getSelectedKey();
			if (documentTypeSel === "ST1") {
				var documentType = "ZQST";
			} else if (documentTypeSel === "ST2") {
				documentType = "ZQTR";
			} else {
				documentType = "";
			}
			var billingType = this.getView().byId("idBillingTypeUAR").getSelectedKey(),
				invoiceFreq = this.getView().byId("idInvoiceFreqUAR").getValue(),
				ContractStatus = this.getView().byId("idContractStatusUAR").getSelectedKey(),
				HPEQuotNo = this.getView().byId("idHPEQuotNoUAR").getValue(),
				regionID = this.getView().byId("idRegionUAR").getSelectedKey(),
				idCountry = this.getView().byId("idCountryUAR"),
				countryTokens = idCountry.getTokens();

			contractLowDate = formatter.changeDateToUTC(contractLowDate);
			contractHighDate = formatter.changeDateToUTC(contractHighDate);
			HPESolQuLowDate = formatter.changeDateToUTC(HPESolQuLowDate);
			HPESolQuHighDate = formatter.changeDateToUTC(HPESolQuHighDate);
			HPEQuotLowDate = formatter.changeDateToUTC(HPEQuotLowDate);
			HPEQuotHighDate = formatter.changeDateToUTC(HPEQuotHighDate);

			var aTokens = [];
			countryTokens.forEach(function (data) {
				var t = data.getKey();
				aTokens.push(t);
			});
			var arr2 = [];
			var obj2 = {};
			var nLenOfPayload = (aPartyId.length > aTokens.length) ? aPartyId.length : aTokens.length;

			// if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/PunchOutData").Persona && (oModel.getProperty("/PunchOutData").Persona !== "SALES_OPS" || oModel.getProperty("/PunchOutData").Persona !== "SALES_REP"))) {
			if (this.userType.toUpperCase() === "PARTNER" ) {
				var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
				var l_pricingVisibility = localPunchoutData.Pricingvisibility,
					l_pricingVisibility = l_pricingVisibility.toString(),
					l_tierMapping = [],
					l_userDetails = [],
					l_userType = localPunchoutData.Usertype;
				if (localPunchoutData.tierMapping.results.length !== 0) {
					for(var i=0; i<localPunchoutData.tierMapping.results.length; i++){
						l_tierMapping.push({ "tierMapping" :  localPunchoutData.tierMapping.results[i].Tier + "," + localPunchoutData.tierMapping.results[i].Brtypecode})
					}
				} else {
					l_tierMapping = [{"tierMapping" : ""}];
				}
				if (localPunchoutData.userDetails.results.length !== 0) {
					for(var i=0; i<localPunchoutData.userDetails.results.length; i++){
						l_userDetails.push({  "userDetails" :  localPunchoutData.userDetails.results[i].Groupid + "," + localPunchoutData.userDetails.results[i].Partyid +
						"," + localPunchoutData.userDetails.results[i].Visibilitytype +
						"," + localPunchoutData.userDetails.results[i].brTypeSet.results[0].Brtype})
					}

				} else {
					l_userDetails = [{"userDetails" : ""}];
				}

				var l_orderNumber = localPunchoutData_Details.orderNumber,
					l_emailId = localPunchoutData_Details.emailId,
					l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
				l_emailId = l_emailId.split("|")[0];
			}

			if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
				//Checks mandatory fields for Non-INTERNAL users
				MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
				this.getView().setBusy(false);
			} else if (((HPESolQuLowDate === null || HPESolQuHighDate === null) && (contractLowDate === null || contractHighDate === null) && (
				HPEQuotLowDate === null || HPEQuotHighDate === null)) && bInternal) {
				//Checks mandatory fields for INTERNAL users
				MessageBox.error("Please fill the mandatory date fields.");
				this.getView().setBusy(false);
			} else {
				var _exeRpt3fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days
					// Begin Defect 10555 GASINGHDELOI
					if (partyType === "") {
						//BEGIN jmezadeloitte defect 12427
						if (nLenOfPayload === undefined) {
							var data = {
								"emailId": l_emailId,
								"orderNumber": l_orderNumber,
								"HPEQuoteNo": l_brimSolQuote,
								"pricingVisibility": l_pricingVisibility,
								"userType": l_userType,
								"zcontractNo": "",
								"zcontractItem": "",
								"usageRatingReportNav": []
							};
							obj2 = {
								"creationStartDate": HPESolQuLowDate,
								"creationEndDate": HPESolQuHighDate,
								"contractStartDateB": HPEQuotLowDate,
								"contractStartDateE": HPEQuotHighDate,
								"contractSatus": ContractStatus,
								"distributorID": "",
								"resellerID": "",
								"endCustID": "",
								"endCustName": "",
								"contractEndDateB": contractLowDate,
								"contractEndDateE": contractHighDate,
								"Country": "",
								"Region": regionID,
								"docType": documentType,
								"billType": billingType,
								"frequency": invoiceFreq,
								"HPEQuoteNo": HPEQuotNo
							};
							data.usageRatingReportNav.push(obj2);
						} else {
							if (nLenOfPayload === 0) {
								var data = {
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"zcontractNo": "",
									"zcontractItem": "",
									"usageRatingReportNav": arr2
								};
								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": "",
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								arr2.push(obj2);
							} else {
								for (var i = 0; i < nLenOfPayload; i++) {
									var data = {
										"emailId": l_emailId,
										"orderNumber": l_orderNumber,
										"HPEQuoteNo": l_brimSolQuote,
										"pricingVisibility": l_pricingVisibility,
										"userType": l_userType,
										"zcontractNo": "",
										"zcontractItem": "",
										"usageRatingReportNav": arr2
									};
									if (aTokens[i] !== undefined) {
										var sCountryVal = aTokens[i];
									} else {
										sCountryVal = "";
									}
									obj2 = {
										"creationStartDate": HPESolQuLowDate,
										"creationEndDate": HPESolQuHighDate,
										"contractStartDateB": HPEQuotLowDate,
										"contractStartDateE": HPEQuotHighDate,
										"contractSatus": ContractStatus,
										"distributorID": "",
										"resellerID": "",
										"endCustID": "",
										"endCustName": "",
										"contractEndDateB": contractLowDate,
										"contractEndDateE": contractHighDate,
										"Country": sCountryVal,
										"Region": regionID,
										"docType": documentType,
										"billType": billingType,
										"frequency": invoiceFreq,
										"HPEQuoteNo": HPEQuotNo
									};
									arr2.push(obj2);
								}
							}
						} //END jmezadeloitte defect 12427
					}
					//if (partyType === "1") {
					else if (partyType === "1") {
						// End Defect 10555 GASINGHDELOI
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"usageRatingReportNav": arr2
								};

								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": nPartyIDVal,
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};

								arr2.push(obj2);

							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"usageRatingReportNav": arr2,
									"tierMappingNav":  l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									var sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								//if(jQuery.sap.getUriParameters().get("i_t")===null){

								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": nPartyIDVal,
									"resellerID": "",
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};

								arr2.push(obj2);

							}

						}

					} else if (partyType === "2") {
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"usageRatingReportNav": arr2
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": nPartyIDVal,
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								arr2.push(obj2);
							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"usageRatingReportNav": arr2,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": nPartyIDVal,
									"endCustID": "",
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								arr2.push(obj2);

							}

						}

					} else if (partyType === "3") {
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"usageRatingReportNav": arr2
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": nPartyIDVal,
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								arr2.push(obj2);
							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"usageRatingReportNav": arr2,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}
								if (aTokens[i] !== undefined) {
									sCountryVal = aTokens[i];
								} else {
									sCountryVal = "";
								}

								obj2 = {
									"creationStartDate": HPESolQuLowDate,
									"creationEndDate": HPESolQuHighDate,
									"contractStartDateB": HPEQuotLowDate,
									"contractStartDateE": HPEQuotHighDate,
									"contractSatus": ContractStatus,
									"distributorID": "",
									"resellerID": "",
									"endCustID": nPartyIDVal,
									"endCustName": "",
									"contractEndDateB": contractLowDate,
									"contractEndDateE": contractHighDate,
									"Country": sCountryVal,
									"Region": regionID,
									"docType": documentType,
									"billType": billingType,
									"frequency": invoiceFreq,
									"HPEQuoteNo": HPEQuotNo
								};
								arr2.push(obj2);

							}

						}
					}

					this.getView().setBusy(true);
					var oServiceModel = this._getODataModel();

					var sPath = "/Ets_UsaRatRep";

					var mParameters = {
						method: "POST",
						success: jQuery.proxy(function (oData) {
							this.getView().setBusy(false);

							if (oData.errorMsg.length !== 0) {
								var errMasg = oData.errorMsg;
								MessageBox.error(errMasg);
							} else {
								var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_UsaRatRepFile('" + oData.zguid22 + "')/$value";
								window.open(sUrl, "_blank");
							}

						}, this),

						error: jQuery.proxy(function (oError) {

							this.getView().setBusy(false);
							var oMessage = oError.headers.errorMsg;
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
							if (typeof oMessage !== "undefined") {
								oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
							} else if (oError.statusCode === "502") { // Timeout issue
								oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
							} else {
								oMessage = oError.message;
							}
							MessageBox.error(oMessage, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
							});
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
						}, this)
					};

					oServiceModel.create(sPath, data, mParameters);
					/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}.bind(this);

				var sMsgDateValidRpt3 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarning"),
					bMsgDateValidRpt3 = true;

				if (HPESolQuHighDate !== null && HPESolQuLowDate !== null) {
					if (((HPESolQuHighDate.getTime() - HPESolQuLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
						bMsgDateValidRpt3 = false;
					}
				}

				if (contractHighDate !== null && contractLowDate !== null) {
					if (((contractHighDate.getTime() - contractLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
						bMsgDateValidRpt3 = false;
					}
				}

				if (HPEQuotHighDate !== null && HPEQuotLowDate !== null) {
					if (((HPEQuotHighDate.getTime() - HPEQuotLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
						bMsgDateValidRpt3 = false;
					}
				}

				if (!bMsgDateValidRpt3) {

					this.getView().setBusy(false);

					MessageBox.show(
						sMsgDateValidRpt3, {
						icon: MessageBox.Icon.WARNING,
						title: "Warning",
						actions: ["Proceed", MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.CANCEL,
						onClose: function (oAction) {
							if (oAction === "Proceed") {
								_exeRpt3fn();
							}
						}
					}
					);

				} else {
					_exeRpt3fn();
				}

				/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			}

		},

		_Report4: function (bInternal) {

			var aPartyToken = this.getView().byId("idPartyIDDMI"),
				aPartyId = [],
				oModel = this.getView().getModel("viewData");
			for (var u = 0; u < aPartyToken.getTokens().length; u++) {
				var t1 = aPartyToken.getTokens()[u].getText();
				aPartyId.push(t1);
			}

			var partyType = this.getView().byId("idPartyTypeDMI").getSelectedKey(),

				invoiceLowDate = this.getView().byId("idDateRangeInvoicingDMI").getDateValue(),
				invoiceHighDate = this.getView().byId("idDateRangeInvoicingDMI").getSecondDateValue(),
				invoiceLowDate = formatter.changeDateToUTC(invoiceLowDate),
				invoiceHighDate = formatter.changeDateToUTC(invoiceHighDate),
				scheduleLowDate = this._formatter.formatDateForBackend(this.getView().byId("idDateRangeInvoicingDMI").getDateValue()),
				scheduleHighDate = this._formatter.formatDateForBackend(this.getView().byId("idDateRangeInvoicingDMI").getSecondDateValue()),
				dateOfMonth = this.getView().byId("idDOMDMI").getSelectedKey(),
				email = this.getView().byId("idEmailID").getValue;

			var arr3 = [];
			var obj3 = {};
			var nLenOfPayload = aPartyId.length;

			// if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/PunchOutData") && (oModel.getProperty("/PunchOutData").Persona !== "SALES_OPS" || oModel.getProperty("/PunchOutData").Persona !== "SALES_REP"))) {
			if (this.userType.toUpperCase() === "PARTNER" ) {
				var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
				var l_pricingVisibility = localPunchoutData.Pricingvisibility,
					l_pricingVisibility = l_pricingVisibility.toString(),
					l_tierMapping = [],
					l_userDetails = [],
					l_userType = localPunchoutData.Usertype;
				if (localPunchoutData.tierMapping.results.length !== 0) {
					for(var i=0; i<localPunchoutData.tierMapping.results.length; i++){
						l_tierMapping.push({ "tierMapping" :  localPunchoutData.tierMapping.results[i].Tier + "," + localPunchoutData.tierMapping.results[i].Brtypecode})
					}
				} else {
					l_tierMapping = [{"tierMapping" : ""}];
				}
				if (localPunchoutData.userDetails.results.length !== 0) {
					for(var i=0; i<localPunchoutData.userDetails.results.length; i++){
						l_userDetails.push({  "userDetails" :  localPunchoutData.userDetails.results[i].Groupid + "," + localPunchoutData.userDetails.results[i].Partyid +
						"," + localPunchoutData.userDetails.results[i].Visibilitytype +
						"," + localPunchoutData.userDetails.results[i].brTypeSet.results[0].Brtype})
					}
				} else {
					l_userDetails = [{"userDetails" : ""}];
				}

				var l_orderNumber = localPunchoutData_Details.orderNumber,
					l_emailId = localPunchoutData_Details.emailId,
					l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;
				l_emailId = l_emailId.split("|")[0];
			}

			if ((aPartyId.length === 0 || partyType === "") && !bInternal) {
				//Checks mandatory fields for Non-INTERNAL users
				MessageBox.error("Please fill the mandatory field Party Id & Select the dropdown value.");
				this.getView().setBusy(false);
			} else if ((invoiceLowDate === null || invoiceHighDate === null || scheduleLowDate === null || scheduleHighDate === null) &&
				bInternal) {
				//Checks mandatory fields for INTERNAL users
				MessageBox.error("Please fill the mandatory date fields.");
				this.getView().setBusy(false);
			} else {
				var _exeRpt4fn = function () { //BADH R1.8 - Validation for Date Range more than 30 days

					// Begin Defect 10555 GASINGHDELOI
					if (partyType === "") {
						var data = {
							"emailId": l_emailId,
							"orderNumber": l_orderNumber,
							"HPEQuoteNo": l_brimSolQuote,
							"pricingVisibility": l_pricingVisibility,
							"userType": l_userType,
							"zcontractNo": "",
							"zcontractItem": "",
							"monthlyInvoiceReportNav": []
						};
						obj3 = {
							"distrID": "",
							"partnerID": "",
							"endCustID": "",
							"invoicePeriodBegin": invoiceLowDate,
							"invoicePeriodEnd": invoiceHighDate
						};
						data.monthlyInvoiceReportNav.push(obj3);
					}
					//if (partyType === "1") {
					else if (partyType === "1") {
						// End Defect 10555 GASINGHDELOI
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"monthlyInvoiceReportNav": arr3
								};

								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}

								//if(jQuery.sap.getUriParameters().get("i_t")===null){

								obj3 = {
									"distrID": nPartyIDVal,
									"partnerID": "",
									"endCustID": "",
									"invoicePeriodBegin": invoiceLowDate,
									"invoicePeriodEnd": invoiceHighDate

								};

								arr3.push(obj3);

							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"monthlyInvoiceReportNav": arr3,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									var nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}

								obj3 = {
									"distrID": nPartyIDVal,
									"partnerID": "",
									"endCustID": "",
									"invoicePeriodBegin": invoiceLowDate,
									"invoicePeriodEnd": invoiceHighDate

								};

								arr3.push(obj3);

							}

						}

					} else if (partyType === "2") {
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"monthlyInvoiceReportNav": arr3
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}

								obj3 = {
									"distrID": "",
									"partnerID": nPartyIDVal,
									"endCustID": "",
									"invoicePeriodBegin": invoiceLowDate,
									"invoicePeriodEnd": invoiceHighDate

								};
								arr2.push(obj3);
							}
						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"monthlyInvoiceReportNav": arr3,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav": l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}

								obj3 = {
									"distrID": "",
									"partnerID": nPartyIDVal,
									"endCustID": "",
									"invoicePeriodBegin": invoiceLowDate,
									"invoicePeriodEnd": invoiceHighDate

								};
								arr3.push(obj3);

							}

						}

					}
					//SOC LEPRIYA INC1712496-SSV_MIissing customer search option in the account detail field for SSV Monthly Invoice Report-2022/09/13
					else if (partyType === "3") {
						if (!this.fnGetParamExistsInURI("i_t")  && this.userType.toUpperCase() !== "PARTNER") {
							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"monthlyInvoiceReportNav": arr3
								};

								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}

								obj3 = {
									"distrID": "",
									"partnerID": "",
									"endCustID": nPartyIDVal,
									"invoicePeriodBegin": invoiceLowDate,
									"invoicePeriodEnd": invoiceHighDate

								};
								arr3.push(obj3);

							}

						} else {

							for (var i = 0; i < nLenOfPayload; i++) {
								var data = {
									"zcontractNo": "",
									"zcontractItem": "",
									"emailId": l_emailId,
									"orderNumber": l_orderNumber,
									"HPEQuoteNo": l_brimSolQuote,
									"pricingVisibility": l_pricingVisibility,
									"userType": l_userType,
									"monthlyInvoiceReportNav": arr3,
									"tierMappingNav": l_tierMapping,
									"userDetailsNav":  l_userDetails

								};
								if (aPartyId[i] !== undefined) {
									nPartyIDVal = aPartyId[i];
								} else {
									nPartyIDVal = "";
								}

								obj3 = {
									"distrID": "",
									"partnerID": "",
									"endCustID": nPartyIDVal,
									"invoicePeriodBegin": invoiceLowDate,
									"invoicePeriodEnd": invoiceHighDate

								};
								arr3.push(obj3);

							}

						};

					}
					//EOC LEPRIYA INC1712496-SSV_MIissing customer search option in the account detail field for SSV Monthly Invoice Report-2022/09/13
					this.getView().setBusy(true);
					var oServiceModel = this._getODataModel();

					var sPath = "/Ets_MonthInvRep";

					var mParameters = {
						method: "POST",
						success: jQuery.proxy(function (oData) {
							this.getView().setBusy(false);

							if (oData.errorMsg.length !== 0) {
								var errMasg = oData.errorMsg;
								MessageBox.error(errMasg);
							} else {
								var sUrl = "/sap/opu/odata/sap/Z_SUBSTATUS_V_GP_SRV/Ets_MontInvRepFile('" + oData.zguid22 + "')/$value";
								window.open(sUrl, "_blank");
							}
						}, this),

						error: jQuery.proxy(function (oError) {

							this.getView().setBusy(false);
							var oMessage = oError.headers.errorMsg;
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout BOC
							if (typeof oMessage !== "undefined") {
								oMessage = JSON.parse(oError.responseText).error.message.value //(+)R1.5 BADHRAMRAJ DEFECT-11462 2021/05/04
							} else if (oError.statusCode === "502") { // Timeout issue
								oMessage = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.TimeoutError"); //  "Wait time exceed. Try with a different search criteria!"
							} else {
								oMessage = oError.message;
							}
							MessageBox.error(oMessage, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.FileDownloadFailed") //"File download failed"
							});
							// R1.8_TSINHADELOIT_16072021_ExceptionHandling on timeout EOC
						}, this)
					};

					oServiceModel.create(sPath, data, mParameters);
					/*SOC BADH R1.8 - Validation for Date Range more than 30 days*/
				}.bind(this);

				var sMsgDateValidRpt4 = this.getView().getModel("i18n").getResourceBundle().getText("xmsg.Main.Report.DateRangeWarningScheduleRpt"),
					bMsgDateValidRpt4 = true;

				if (invoiceHighDate !== null && invoiceLowDate !== null) {
					if (((invoiceHighDate.getTime() - invoiceLowDate.getTime()) / (1000 * 3600 * 24)) > 60) {
						bMsgDateValidRpt4 = false;
					}
				}

				if (!bMsgDateValidRpt4) {
					this.getView().setBusy(false);

					MessageBox.show(
						sMsgDateValidRpt4, {
						icon: MessageBox.Icon.WARNING,
						title: "Warning",
						actions: ["Proceed", MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.CANCEL,
						onClose: function (oAction) {
							if (oAction === "Proceed") {
								_exeRpt4fn();
							}
						}
					}
					);

				} else {
					_exeRpt4fn();
				}

				/*EOC BADH R1.8 - Validation for Date Range more than 30 days*/
			}
		},


		// this function will be called on click of "save as" button
		fnOnReport4SaveAs: function () {
			var aPartyToken = this.getView().byId("idPartyIDDMI"),
				partyType = this.getView().byId("idPartyTypeDMI").getSelectedKey(),
				partyID = [],
				ofilters = [],
				oModel = this.getView().getModel("viewData");

			for (var u = 0; u < aPartyToken.getTokens().length; u++) {
				var t1 = aPartyToken.getTokens()[u].getText();
				partyID.push(t1);
			}

			var invoiceLowDate = this.getView().byId("idDateRangeInvoicingDMI").getDateValue(),

				invoiceHighDate = this.getView().byId("idDateRangeInvoicingDMI").getSecondDateValue(),

				scheduleLowDate = this.getView().byId("idDateScheduleStartDateDMI").getDateValue(),

				scheduleHighDate = this.getView().byId("idDateScheduleStartDateDMI").getSecondDateValue(),

				dateOfMonth = this.getView().byId("idDOMDMI").getValue(),
				email = this.getView().byId("idEmailID").getValue();

			invoiceLowDate = formatter.changeDateToUTC(invoiceLowDate);
			invoiceHighDate = formatter.changeDateToUTC(invoiceHighDate);
			scheduleLowDate = formatter.changeDateToUTC(scheduleLowDate);
			scheduleHighDate = formatter.changeDateToUTC(scheduleHighDate);
			// if (this.fnGetParamExistsInURI("i_t") || (oModel.getProperty("/PunchOutData") && (oModel.getProperty("/PunchOutData").Persona !== "SALES_OPS" && oModel.getProperty("/PunchOutData").Persona !== "SALES_REP"))) {
			if (this.userType.toUpperCase() === "PARTNER" ) {
				var localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
				var localPunchoutData_Details = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData_Details");
				var l_pricingVisibility = localPunchoutData.Pricingvisibility,
					l_pricingVisibility = l_pricingVisibility.toString(),
					l_tierMapping = [],
					l_userDetails = [],
					l_userType = localPunchoutData.Usertype;
				if (localPunchoutData.tierMapping.results.length !== 0) {
					for(var i=0; i<localPunchoutData.tierMapping.results.length; i++){
						l_tierMapping.push({ "tierMapping" :  localPunchoutData.tierMapping.results[i].Tier + "," + localPunchoutData.tierMapping.results[i].Brtypecode})
					}
				} else {
					l_tierMapping = [{"tierMapping" : ""}];
				}
				if (localPunchoutData.userDetails.results.length !== 0) {
					for(var i=0; i<localPunchoutData.userDetails.results.length; i++){
						l_userDetails.push({  "userDetails" :  localPunchoutData.userDetails.results[i].Groupid + "," + localPunchoutData.userDetails.results[i].Partyid +
						"," + localPunchoutData.userDetails.results[i].Visibilitytype +
						"," + localPunchoutData.userDetails.results[i].brTypeSet.results[0].Brtype})
					}
				} else {
					l_userDetails = [{"userDetails" : ""}];
				}

				var l_orderNumber = localPunchoutData_Details.orderNumber,
					l_emailId = localPunchoutData_Details.emailId,
					l_brimSolQuote = localPunchoutData_Details.brimSolutionQuote;

				l_emailId = l_emailId.split("|")[0];

				ofilters.push(new sap.ui.model.Filter("orderNumber", "EQ", l_orderNumber));
				//Remove the hard code value
				ofilters.push(new sap.ui.model.Filter("solutionQuoteId", "EQ", l_brimSolQuote));
				ofilters.push(new sap.ui.model.Filter("pricingVisibility", "EQ", l_pricingVisibility));
				ofilters.push(new sap.ui.model.Filter("userType", "EQ", l_userType));
				// ofilters.push(new sap.ui.model.Filter("tierMapping", "EQ", l_tierMapping));
				// ofilters.push(new sap.ui.model.Filter("userDetails", "EQ", l_userDetails));
				ofilters.push(new sap.ui.model.Filter(this.getTierMappingFilter(this.partnerFilters), false));
				ofilters.push(new sap.ui.model.Filter(this.getUserDetailsFilter(this.partnerFilters), false));

			}

			this.getView().setBusy(true);
			/*SOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
			var _localPunchoutData = sap.ui.getCore().getModel("viewData").getProperty("/PunchOutData");
			if (_localPunchoutData === undefined || _localPunchoutData === null) {
				_localPunchoutData = {
					Usertype: ""
				};
			}
			var _bInternal = (_localPunchoutData.Usertype === "INTERNAL" || _localPunchoutData.Usertype ===
				"Internal" || _localPunchoutData.Usertype === "internal");
			var _bToken = (this.fnGetParamIdFrmURI("i_t") === null);

			if ((_bToken || _bInternal) && (scheduleLowDate === null || scheduleHighDate ===
				null || dateOfMonth === "" || email === "")) {
				MessageBox.error("Please fill all the form fields");
				this.getView().setBusy(false);
			} /*EOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
			else if (!_bToken && !_bInternal && (partyType === "" || scheduleLowDate === null || scheduleHighDate ===
				null || dateOfMonth === "" || email === "")) {
				MessageBox.error("Please fill all the form fields");
				this.getView().setBusy(false);
			} else {
				/*SOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
				if (partyID.length > 1) {
					var aPartyIDFilters = [];
					if (partyType === "1") {
						for (var sPartyID of partyID) {
							aPartyIDFilters.push(new sap.ui.model.Filter("distrID", "EQ", sPartyID));
						}
					} else if (partyType === "2") {
						for (var sPartyID of partyID) {
							aPartyIDFilters.push(new sap.ui.model.Filter("partnerID", "EQ", sPartyID));
						}
					}
					ofilters.push(new sap.ui.model.Filter(aPartyIDFilters, false));

				} else {
					if (partyType === "1") {
						ofilters.push(new sap.ui.model.Filter("distrID", "EQ", partyID));
					} else if (partyType === "2") {
						ofilters.push(new sap.ui.model.Filter("partnerID", "EQ", partyID));
					}
				}
				/*EOC BADHRAMRAJ DEFECT-11462 2021/04/28*/
				ofilters.push(new sap.ui.model.Filter("invoicePeriodBegin", "EQ", invoiceLowDate));
				ofilters.push(new sap.ui.model.Filter("invoicePeriodEnd", "EQ", invoiceHighDate));
				ofilters.push(new sap.ui.model.Filter("startDate", "EQ", scheduleLowDate));
				ofilters.push(new sap.ui.model.Filter("endDate", "EQ", scheduleHighDate));
				ofilters.push(new sap.ui.model.Filter("dateOfMonth", "EQ", dateOfMonth));
				ofilters.push(new sap.ui.model.Filter("emailID", "EQ", email));
				var oServiceModel = this._getODataModel();

				var sPath = "/Ets_MonthlyInvSch";

				var mParameters = {
					method: "GET",
					filters: ofilters,
					success: jQuery.proxy(function (oData) {

						this.getView().setBusy(false);

						if (oData.results[0].errorMsg.length !== 0) {
							var errMasg = oData.results[0].errorMsg;
							MessageBox.error(errMasg);
						} else {
							MessageBox.success("Monthly Invoicing Report has scheduled");

						}

					}, this),
					error: jQuery.proxy(function (oError) {
						this.getView().setBusy(false);
						var errMasg = oError.responseText;
						MessageBox.error(errMasg);
					}, this)
				};

				oServiceModel.read(sPath, mParameters);
			}

		},

		// to check the entered day of Month value for the 4th report
		fnCheckDayValue: function () {
			var enteredNo = this.getView().byId("idDOMDMI").getValue(),
				enterNoPar = this.getView().byId("idDOMDMI");
			if (isNaN(enteredNo) || enteredNo < 1 || enteredNo > 28) {
				var oEnteredVal = "";
				enterNoPar.setValue(oEnteredVal);
				MessageBox.error("Please Enter Number Between 1 to 28", {
					width: "550px"

				});
			} else {
				return enteredNo;
			}

		},

		fnCheckInvoiveDateReport4: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeInvoicingDMI");
				var dateString = this.getView().byId("idDateRangeInvoicingDMI").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}
		},

		fnCheckStartDateReport4: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER" ) {
				var dateVal = this.getView().byId("idDateScheduleStartDateDMI");
				var dateString = this.getView().byId("idDateScheduleStartDateDMI").mProperties.value;
				this.fnOnchangeDateValForReport4(dateVal, dateString);
			}
		},

		fnCheckContractDateReport1: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeContract");
				var dateString = this.getView().byId("idDateRangeContract").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}

		},

		fnCheckActivationDateReport1: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeActivation");
				var dateString = this.getView().byId("idDateRangeActivation").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}

		},

		fnCheckHPEDateReport2: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeHPEQuoteIAB");
				var dateString = this.getView().byId("idDateRangeHPEQuoteIAB").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}

		},
		fnCheckSolHPEDateReport2: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeHPESolQuIAB");
				var dateString = this.getView().byId("idDateRangeHPESolQuIAB").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}

		},
		fnCheckContractDateReport2: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeContractIAB");
				var dateString = this.getView().byId("idDateRangeContractIAB").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}

		},
		fnCheckInvoicetDateReport2: function () {
			if (!this.fnGetParamExistsInURI("i_t") && this.userType.toUpperCase() !== "PARTNER") {
				var dateVal = this.getView().byId("idDateRangeInvoicingIAB");
				var dateString = this.getView().byId("idDateRangeInvoicingIAB").mProperties.value;
				this.fnOnchangeDateValForReport(dateVal, dateString);
			}

		},

		// to validate the entered date range format for all the reports
		fnOnchangeDateValForReport: function (dateVal, dateString) {

			var regEx = /^(\d{1,2})-(\d{1,2})-(\d{4}) - (\d{1,2})-(\d{1,2})-(\d{4})/g;

			if (dateString.match(regEx) === null) {
				var oSelectedItem = "";

				dateVal.setValue(oSelectedItem);
				MessageBox.error("Enter date in MM-DD-YYYY - MM-DD-YYYY format");

			} else {
				return dateString;
			}
		},

		// to validate the entered date range format for 4th reports
		fnOnchangeDateValForReport4: function (dateVal, dateString) {

			var regEx = /^((0|1)\d{1})-((0|1|2)\d{1})-((19|20)\d{2}) - ((0|1)\d{1})-((0|1|2)\d{1})-((19|20)\d{2})/g;

			if (dateString.match(regEx) === null) {
				var oSelectedItem = "";

				dateVal.setValue(oSelectedItem);
				MessageBox.error("Enter date in MM-DD-YYYY - MM-DD-YYYY format");

			} else {
				return dateString;
			}
		},

		/*Value helps for country*/

		//Open Value help Box for Country
		handleValueHelpCountryCS: function (oEvent) {
			this.flagCountry = "CS";

			if (!this._oCountry) {
				this._oCountry = sap.ui.xmlfragment("som.ssv.fragments.ValueHelpCountry", this);
				this.getView().addDependent(this._oCountry);
				// Remember selections if required
				this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
			}

			var region = this.getView().byId("idRegionCS").getSelectedKey();
			this._getCountry(region);

			this._oCountry.open();
		},

		//get Values for country
		_getCountry: function (sRegion) {
			var oModel = this.getView().getModel("viewData");

			oModel.setProperty("/CountrySet", []);

			this.getView().setBusy(true);
			var f = [];
			f.push(new sap.ui.model.Filter("regionID", "EQ", sRegion));
			var oServiceModel = this._getODataModel();

			var sPath = "/Ets_getCountry";

			var mParameters = {
				method: "GET",
				filters: f,
				success: jQuery.proxy(function (oData) {
					this.getView().setBusy(false);
					oModel.setProperty("/CountrySet", oData.results);
				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);
				}, this)
			};

			oServiceModel.read(sPath, mParameters);
		},

		//for excel copy paste of Country
		onTokenUpdateCountryCS: function (oEvt) {
			var idCountry = this.getView().byId("idCountryCS");
			idCountry.addValidator(this._multiInputValidator);
		},

		

		//Open Value help Box for Country
		handleValueHelpCountryIAB: function (oEvent) {
			this.flagCountry = "IAB";

			if (!this._oCountry) {
				this._oCountry = sap.ui.xmlfragment("som.ssv.fragments.ValueHelpCountry", this);
				this.getView().addDependent(this._oCountry);
				// Remember selections if required
				this._oCountry.setRememberSelections(true); //BADH EAGLE-2776 2021/11/17
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCountry);
			}

			var region = this.getView().byId("idRegionIAB").getSelectedKey();
			this._getCountry(region);

			this._oCountry.open();

		},

		//for excel copy paste of Country
		onTokenUpdateCountryIAB: function (oEvt) {
			var idCountry = this.getView().byId("idCountryIAB");
			idCountry.addValidator(this._multiInputValidator);
		},


		getTierMappingFilter: function (oDataPartnerInfo) {
			try {
				var orFilters = [];
				var Tier = "";
				var Brtypecode = "";
				var tierMappingFilterValue = "";
				var tierMappingFilterArray = oDataPartnerInfo.results[0].userData.results[0].tierMapping.results;
				for (var i = 0; i < tierMappingFilterArray.length; i++) {
					try {
						Tier = tierMappingFilterArray[i].Tier;
						if (Tier === "Tier2") {
							flagTier++;
						}
					} catch (e) {
						Tier = "";
					}
					try {
						Brtypecode = tierMappingFilterArray[i].Brtypecode;
					} catch (e) {
						Brtypecode = "";
					}
					tierMappingFilterValue = Tier + "," + Brtypecode;
					orFilters.push(new sap.ui.model.Filter("tierMapping", sap.ui.model.FilterOperator.EQ, tierMappingFilterValue));
					tierMappingFilterValue = "";
					Brtypecode = "";
					Tier = "";

				}

				if (tierMappingFilterArray.length === 0) {
					orFilters.push(new sap.ui.model.Filter("tierMapping", sap.ui.model.FilterOperator.EQ, ""));

				}

				return orFilters;

			} catch (e) {
				return [];
			}
		},

		getUserDetailsFilter: function (oDataPartnerInfo) {
			try {
				var orFilters = [];
				var Groupid = "";
				var Partyid = "";
				var Visibilitytype = "";
				var Brtype = "";
				var userDetailsFilterValue = "";
				//arjun correction
				var userDetailsFilterArray = oDataPartnerInfo.results[0].userData.results[0].userDetails.results;
				for (var i = 0; i < userDetailsFilterArray.length; i++) {
					// arjun changes
					if (userDetailsFilterArray[i].brTypeSet.results.length === 0) {
						try {
							Groupid = userDetailsFilterArray[i].Groupid;
						} catch (e) {
							Groupid = "";
						}
						try {
							Partyid = userDetailsFilterArray[i].Partyid;
						} catch (e) {
							Partyid = "";
						}
						try {
							Visibilitytype = userDetailsFilterArray[i].Visibilitytype;
						} catch (e) {
							Visibilitytype = "";
						}
						Brtype = "";
						userDetailsFilterValue = Groupid + "," + Partyid + "," + Visibilitytype + "," + Brtype;
						orFilters.push(new sap.ui.model.Filter("userDetails", sap.ui.model.FilterOperator.EQ, userDetailsFilterValue));
						userDetailsFilterValue = "";
						Groupid = "";
						Partyid = "";
						Visibilitytype = "";
						Brtype = "";
						continue;
					}
					for (var j = 0; j < userDetailsFilterArray[i].brTypeSet.results.length; j++) {

						try {
							Groupid = userDetailsFilterArray[i].Groupid;
						} catch (e) {
							Groupid = "";
						}
						try {
							Partyid = userDetailsFilterArray[i].Partyid;
						} catch (e) {
							Partyid = "";
						}
						try {
							Visibilitytype = userDetailsFilterArray[i].Visibilitytype;
						} catch (e) {
							Visibilitytype = "";
						}
						try {
							Brtype = userDetailsFilterArray[i].brTypeSet.results[j].Brtype;
						} catch (e) {
							Brtype = "";
						}

						userDetailsFilterValue = Groupid + "," + Partyid + "," + Visibilitytype + "," + Brtype;
						orFilters.push(new sap.ui.model.Filter("userDetails", sap.ui.model.FilterOperator.EQ, userDetailsFilterValue));
						userDetailsFilterValue = "";
						Groupid = "";
						Partyid = "";
						Visibilitytype = "";
						Brtype = "";

					}
				}

				if (userDetailsFilterArray.length === 0) {
					orFilters.push(new sap.ui.model.Filter("userDetails", sap.ui.model.FilterOperator.EQ, ""));
				}

				return orFilters;

			} catch (e) {
				return [];
			}
		},

		// below function is used to validate the Party ID for 1st report

		// below function is used to validate the Party ID for the 4th report

		fnOnChanPartyDMIRep: function () {
			var oServiceModel = this._getODataModel();
			var sPath = "/Ets_validatePartner";
			this.getView().setBusy(true);
			var partyID = this.getView().byId("idPartyIDDMI").getValue();
			var oFilters = [];
			var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
			oFilters.push(CustID);

			var mParameters = {
				method: "GET",
				filters: oFilters,
				success: jQuery.proxy(function (oData) {
					this.getView().setBusy(false);
					//	MessageBox.success("Filter Pass");

				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);

					var msg = JSON.parse(oError.responseText).error.message.value;
					MessageBox.error(msg);
				}, this)
			};

			oServiceModel.read(sPath, mParameters);

		},

		// below function is used to validate the Party ID for the 2nd report

		fnOnChanPartyIABRep: function () {

			var oServiceModel = this._getODataModel();
			var sPath = "/Ets_validatePartner";
			this.getView().setBusy(true);
			var partyID = this.getView().byId("idPartyIDIAB").getValue();
			var oFilters = [];
			var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
			oFilters.push(CustID);

			var mParameters = {
				method: "GET",
				filters: oFilters,
				success: jQuery.proxy(function (oData) {
					this.getView().setBusy(false);
					//	MessageBox.success("Filter Pass");

				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);

					var msg = JSON.parse(oError.responseText).error.message.value;
					MessageBox.error(msg);
				}, this)
			};

			oServiceModel.read(sPath, mParameters);
		},


		// Common function to validate party id for all the report
		fnOnChanPartyCSRep_gg: function () {
			var oServiceModel = this._getODataModel();
			var sPath = "/Ets_validatePartner";
			this.getView().setBusy(true);
			var partyID = this.getView().byId("idPartyID").getValue();
			var oFilters = [];
			var CustID = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, partyID);
			oFilters.push(CustID);

			var mParameters = {
				method: "GET",
				filters: oFilters,
				success: jQuery.proxy(function (oData) {
					this.getView().setBusy(false);
					//	MessageBox.success("Filter Pass");

				}, this),
				error: jQuery.proxy(function (oError) {
					this.getView().setBusy(false);

					var msg = JSON.parse(oError.responseText).error.message.value;
					MessageBox.error(msg);
				}, this)
			};

			oServiceModel.read(sPath, mParameters);

		},

		//Begin jmezadeloitte phoenix 10811
		onChangeRegion: function (oEvent) {
			//this.Region = oEvent.getSource().getValue();
			var CountryMultiInput = this.getView().byId("idCountry");
			if (this._oCountry !== undefined) {
				this._oCountry._resetSelection(); //AVERMA4 Defect 10811 1/4
			}
			CountryMultiInput.removeAllTokens();

		},
		//End jmezadeloitte phoenix 10811
		

		/*SOC BADH EAGLE-2619 2021/11/12*/
		onSalesOrgValueHelpRequested: function (oEvent) {
			var aCols = [{
				"label": this.getResourceBundle().getText("xfld.Main.Subscriptions.SalesOrg"),
				"template": "SalesOrganization"
			}];

			sap.ui.core.Fragment.load({
				name: "som.ssv.fragments.salesOrgValueHelp",
				controller: this
			}).then(function name(oFragment) {
				this._salesOrgVHelpDialog = oFragment;
				this.getView().addDependent(this._salesOrgVHelpDialog);

				this._salesOrgVHelpDialog.getTableAsync().then(function (oTable) {
					oTable.setModel(this.getView().getModel("API_SALESORGANIZATION_SRV"));
					oTable.setModel(new sap.ui.model.json.JSONModel({
						"cols": aCols
					}), "columns");

					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/A_SalesOrganization");
					}

					if (oTable.bindItems) {
						oTable.bindAggregation("items", "/A_SalesOrganization", function () {
							return new ColumnListItem({
								cells: aCols.map(function (column) {
									return new Label({
										text: "{" + column.template + "}"
									});
								})
							});
						});
					}

					this._salesOrgVHelpDialog.update();
				}.bind(this));

				this._salesOrgVHelpDialog.open();
			}.bind(this));

		},

		onSalesOrgFilterBarSearch: function (oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new sap.ui.model.Filter({
						path: oControl.getName(),
						operator: sap.ui.model.FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterSalesOrgTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterSalesOrgTable: function (oFilter) {
			var oValueHelpDialog = this._salesOrgVHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},

		onSalesOrgValueHelpOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (aTokens.length > 0) {
				this.getView().byId("idSalesOrg").setValue(aTokens[0].getKey());
			}
			if (this._salesOrgVHelpDialog) {
				this._salesOrgVHelpDialog.close();
			}
		},

		onSalesOrgValueHelpCancelPress: function () {
			if (this._salesOrgVHelpDialog) {
				this._salesOrgVHelpDialog.close();
			}
		},

		onSalesOrgValueHelpAfterClose: function () {
			if (this._salesOrgVHelpDialog) {
				this._salesOrgVHelpDialog.destroy();
			}
		},
		/*EOC BADH EAGLE-2619 2021/11/12*/
		/*SOC BADH EAGLE-2776 2021/11/17*/
		_openCountryVHelpDialog: function () {
			var aCols = [{
				"label": this.getResourceBundle().getText("xfld.VHelp.Subscriptions.CountryID"),
				"template": "countryID"
			}, {
				"label": this.getResourceBundle().getText("xfld.VHelp.Subscriptions.CountryName"),
				"template": "countryName"
			}, {
				"label": this.getResourceBundle().getText("xfld.VHelp.Subscriptions.RegionID"),
				"template": "regionID"
			}];

			sap.ui.core.Fragment.load({
				name: "som.ssv.fragments.countryValueHelp",
				controller: this
			}).then(function name(oFragment) {
				this._countryVHelpDialog = oFragment;
				this.getView().addDependent(this._countryVHelpDialog);

				this._countryVHelpDialog.getTableAsync().then(function (oTable) {
					oTable.setModel(this.getView().getModel("viewData"));
					oTable.setModel(new sap.ui.model.json.JSONModel({
						"cols": aCols
					}), "columns");

					if (oTable.bindRows) {
						oTable.bindAggregation("rows", "/CountrySet");
					}

					if (oTable.bindItems) {
						oTable.bindAggregation("items", "/CountrySet", function () {
							return new ColumnListItem({
								cells: aCols.map(function (column) {
									return new Label({
										text: "{" + column.template + "}"
									});
								})
							});
						});
					}

					this._countryVHelpDialog.update();
				}.bind(this));

				var __aTokens = [],
					_oView = this.getView(),
					__aSelTokens = [];
				if (this.flagCountry === "S") {
					__aTokens = _oView.byId("idCountry").getTokens();
				} else if (this.flagCountry === "CS") {
					__aTokens = _oView.byId("idCountryCS").getTokens();
				} else if (this.flagCountry === "UAR") {
					__aTokens = _oView.byId("idCountryUAR").getTokens();
				} else if (this.flagCountry === "IAB") {
					__aTokens = _oView.byId("idCountryIAB").getTokens();
				} else if (this.flagCountry === "CCC") {
					__aTokens = _oView.byId("idCountryCCC").getTokens();
				}

				__aTokens.forEach(function (oToken) {
					var t = new sap.m.Token({
						key: oToken.getKey(),
						text: oToken.getText() + " (" + oToken.getKey() + ")"
					});
					oToken.getCustomData().forEach(function (cData) {
						t.addCustomData(new sap.ui.core.CustomData({
							key: cData.getKey(),
							value: cData.getValue()
						}));
					});
					__aSelTokens.push(t);
				});

				this._countryVHelpDialog.setTokens(__aSelTokens);
				this._countryVHelpDialog.open();
			}.bind(this));
		},

		onCountryFilterBarSearch: function (oEvent) {
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getMetadata().getElementName() === "sap.m.ComboBox") {
					if (oControl.getSelectedKey()) {
						aResult.push(new sap.ui.model.Filter({
							path: oControl.getName(),
							operator: sap.ui.model.FilterOperator.EQ,
							value1: oControl.getSelectedKey()
						}));
					}
				} else if (oControl.getValue()) {
					aResult.push(new sap.ui.model.Filter({
						path: oControl.getName(),
						operator: sap.ui.model.FilterOperator.EQ,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

			this._filterCountryTable(new sap.ui.model.Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterCountryTable: function (oFilter) {
			var oValueHelpDialog = this._countryVHelpDialog;

			oValueHelpDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},

		onCountryValueHelpOkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			if (aTokens.length > 0) {
				var aSelectedTokens = [],
					_oView = this.getView();
				aTokens.forEach(function (oToken) {
					var t = new sap.m.Token({
						key: oToken.getKey(),
						text: oToken.data("row").countryName
					});
					oToken.getCustomData().forEach(function (cData) {
						t.addCustomData(new sap.ui.core.CustomData({
							key: cData.getKey(),
							value: cData.getValue()
						}));
					});
					aSelectedTokens.push(t);
				});

				if (this.flagCountry === "S") {
					_oView.byId("idCountry").setTokens(aSelectedTokens);
				} else if (this.flagCountry === "CS") {
					_oView.byId("idCountryCS").setTokens(aSelectedTokens);
				} else if (this.flagCountry === "UAR") {
					_oView.byId("idCountryUAR").setTokens(aSelectedTokens);
				} else if (this.flagCountry === "IAB") {
					_oView.byId("idCountryIAB").setTokens(aSelectedTokens);
				}
				//SOC BADH EAGLE-SOME4028B 2021/01/28
				else if (this.flagCountry === "CCC") {
					_oView.byId("idCountryCCC").setTokens(aSelectedTokens);
				}
				//EOC BADH EAGLE-SOME4028B 2021/01/28
				if (aTokens && aTokens.length) {
					MessageToast.show("You have chosen " + aTokens.map(function (oContext) {
						return oContext.data("row").countryName;
					}).join(", "));
				}

				this._filterCountryTable([]);
			} else {
				if (this.flagCountry === "S") {
					_oView.byId("idCountry").removeAllTokens();
				} else if (this.flagCountry === "CS") {
					_oView.byId("idCountryCS").removeAllTokens();
				} else if (this.flagCountry === "UAR") {
					_oView.byId("idCountryUAR").removeAllTokens();
				} else if (this.flagCountry === "IAB") {
					_oView.byId("idCountryIAB").removeAllTokens();
				}
				//SOC BADH EAGLE-SOME4028B 2021/01/28
				else if (this.flagCountry === "CCC") {
					this.getView().byId("idCountryCCC").removeAllTokens();
				}
			}

			if (this._countryVHelpDialog) {
				this._countryVHelpDialog.close();
			}
		},

		onCountryValueHelpCancelPress: function () {
			if (this._countryVHelpDialog) {
				this._countryVHelpDialog.close();
			}
		},

		onCountryValueHelpAfterClose: function () {
			if (this._countryVHelpDialog) {
				this._countryVHelpDialog.destroy();
			}
		},
		/*EOC BADH EAGLE-2776 2021/11/17*/
		// SOC ACHOPRADELOI RAMP-1458 2023/10/17	
		onSelectIconTabBar1: function (oEvt) {
			if (oEvt.getSource().getSelectedKey() === "Reports") {
				var reportType = this.getView().byId("idReportIconTabBar").setSelectedKey("1");
				this.onReportChange();
			}
		}
		// EOC ACHOPRADELOI RAMP-1458 2023/10/17
	});
});