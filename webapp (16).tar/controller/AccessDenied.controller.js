
sap.ui.define(["sap/ui/core/mvc/Controller"
	], function (Controller) {
		"use strict";

		return Controller.extend("som.ssv.controller.AccessDenied", {

			/* =========================================================== */
			/* lifecycle methods                                           */
			/* =========================================================== */

			onInit : function () {
			sap.ui.core.UIComponent.getRouterFor(this).attachRoutePatternMatched(this.onRoutePatternMatchAccessDen, this);
			this.getRouter().initialize();
			},
				
		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
			
			onRoutePatternMatchAccessDen : function () {
				     var oJsonModel = this.getOwnerComponent().getModel("localJsonModel");
				var bTokenFlg = 	oJsonModel.getProperty("/bTokenFlag");
				
				if (bTokenFlg === true){
					
					this .getRouter().navTo("AccessDenied");
				}
				
			}
		});
	}
);