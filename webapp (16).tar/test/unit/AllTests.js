sap.ui.define([
	"som/ssv/test/unit/controller/Main.controller"
], function () {
	"use strict";
});