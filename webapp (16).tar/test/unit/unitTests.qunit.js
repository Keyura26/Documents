/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"som/ssv/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});