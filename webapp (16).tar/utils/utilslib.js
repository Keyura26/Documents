sap.ui.define([], function (DateFormat, MessageToast, NumberFormat) {
	"use strict";
	return {
		__fnGetDevOnlyEnabled: function (systemId) {
			var __bEnabled = false,
				__bLocal = true, //Only Enable for WEBIDE testing
				__sHost = window.location.host.toUpperCase();
			try {
				if (sap.ushell !== undefined) {
					var __oLogonSystem = sap.ushell.Container.getLogonSystem(),
						__sPlatform = __oLogonSystem.getPlatform(),
						__sName = __oLogonSystem.getName();
					if (__sPlatform === "local" && __bLocal === true) {
						__bEnabled = true;
					} else if (__sPlatform === "abap") {
						if (__sName === systemId) {
							__bEnabled = true;
						}
					}
				} else {
					if (__sHost.indexOf("WEBIDE") > -1 && __bLocal === true) {
						__bEnabled = true;
					} else if (__sHost.indexOf(systemId) > -1) {
						__bEnabled = true;
					}
				}
			} catch (err) {
				if (__sHost.indexOf("WEBIDE") > -1 && __bLocal === true) {
					__bEnabled = true;
				} else if (__sHost.indexOf(systemId) > -1) {
					__bEnabled = true;
				}
			}

			return __bEnabled;
		}
	};
});