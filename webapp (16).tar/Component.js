sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"som/ssv/model/models",
	"sap/base/util/UriParameters"
], function (UIComponent, Device, models, UriParameters) {
	"use strict";

	var oUriParameters = new UriParameters(window.location.href);
	return UIComponent.extend("som.ssv.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			var oModel = new sap.ui.model.json.JSONModel();
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			//initialize Model
			sap.ui.getCore().setModel(oModel, "viewData");
			this.setModel(oModel, "viewData");
			// enable routing

			if (!this.fnGetParamExistsInURI("i_t")) {
				var controller = this;
				//odeferred = $.Deferred();
				//	this.getEmailAndDefaultURLs(odeferred);

				//odeferred.done(function () {
				controller.getRouter().initialize();
				//});
			} else {
				this.getRouter().initialize();
			}

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			if (sap.ui.getCore()._appLoaded) {
				sap.ui.getCore()._appLoaded.resolve();
			}
		},

		getEmailAndDefaultURLs: function (odeferred) {
			var controller = this,
				aModel = this.getModel("viewData");

			if (aModel.getProperty("/Persona") && aModel.getProperty("/EmailId")) {
				odeferred.resolve();
				return;
			} else {
				var __sBatchGroupId__ = Math.random().toString(36).slice(2).toUpperCase(),
					oModel = this.getModel(),
					sPath1 = "/Ets_GetEmail",
					sPath2 = "/Ets_defaultUrls",
					aFilters = [];
				if (this.fnGetParamExistsInURI("imp")) {
					var impValue = this.fnGetParamIdFrmURI("imp"),
						decryptedImpValue = this.fnGetDecryptedParamIDs(impValue);
					aFilters.push(new sap.ui.model.Filter("Email", "EQ", decryptedImpValue));
				}

				var mParameters = {
					method: "GET",
					filters: aFilters,
					groupId: __sBatchGroupId__,
					urlParameters: {
						$expand: "userData/tierMapping,userData/userDetails,userData/userDetails/brTypeSet"
					},
					success: jQuery.proxy(function (oData) {

						try {
							aModel.setProperty("/Persona", oData.results[0].Persona);
							aModel.setProperty("/EmailId", oData.results[0].Email);
							aModel.setProperty("/dateFormat", oData.results[0].dateFormat);
							aModel.setProperty("/userData", oData.results[0].userData);
						} catch (e) {}

					}, this),
					error: jQuery.proxy(function (oError) {
						odeferred.reject();
					}, this)
				};

				oModel.read(sPath1, mParameters);

				var mParameters2 = {
					method: "GET",
					groupId: __sBatchGroupId__,
					success: jQuery.proxy(function (oData) {

						try {
							aModel.setProperty("/OrderURL", oData.results[1].osvorderurl);
							aModel.setProperty("/PunchOutData_Details/osvorderurl", oData.results[1].osvorderurl); // ACHOPRADELOI RAMP-1458 2023/10/25
							aModel.setProperty("/PunchOutData_Full/results/0/osvorderurl", oData.results[1].osvorderurl); // ACHOPRADELOI RAMP-1458 2023/10/25
						} catch (e) {
							aModel.setProperty("/OrderURL", "");
						}

						try {
							aModel.setProperty("/DefaultURL", oData.results[0].osvdefaulturl);
							aModel.setProperty("/PunchOutData_Details/osvdefaulturl", oData.results[0].osvdefaulturl); // ACHOPRADELOI RAMP-1458 2023/10/25
							aModel.setProperty("/PunchOutData_Full/results/0/osvdefaulturl", oData.results[0].osvdefaulturl); // ACHOPRADELOI RAMP-1458 2023/10/25
						} catch (e) {
							aModel.setProperty("/DefaultURL", "");
						}

						/*SOC EAGLE BADH SOME4028A 2021/08/26*/
						try {
							aModel.setProperty("/SFDCCaseWebformURL", oData.results[2].sfdccaseurl);
							aModel.setProperty("/PunchOutData_Details/sfdccaseurl", oData.results[2].sfdccaseurl); // ACHOPRADELOI RAMP-1458 2023/10/25
							aModel.setProperty("/PunchOutData_Full/results/0/sfdccaseurl", oData.results[2].sfdccaseurl); // ACHOPRADELOI RAMP-1458 2023/10/25
						} catch (e) {
							aModel.setProperty("/SFDCCaseWebformURL", "");
						}
						odeferred.resolve();
					}, this),
					error: jQuery.proxy(function (oError) {
						odeferred.reject();
					}, this)
				};

				oModel.read(sPath2, mParameters2);

				var mParameters3 = {
					groupId: __sBatchGroupId__,
					success: jQuery.proxy(function (oData) {}, this),
					error: jQuery.proxy(function (oError) {
						odeferred.reject();
					}, this)
				};
				oModel.submitChanges(mParameters3);
			}
		},

		fnGetParamExistsInURI: function (param) {
			var __bOpptyExistsInURI = false;
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null && __oURIParam.get(param) !== "") {
					__bOpptyExistsInURI = true;
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null && __aStartUpParameter[param] !== "") {
							__bOpptyExistsInURI = true;
						}
					}
				}
			} catch (err) {

			}
			return __bOpptyExistsInURI;
		},

		fnGetParamIdFrmURI: function (param) {
			var __sOpptyId = "";
			try {
				var __oURIParam = oUriParameters,
					__oComponentData = this.getComponentData();

				if (__oURIParam.get(param) !== undefined && __oURIParam.get(param) !== null) {
					__sOpptyId = __oURIParam.get(param);
				} else if (__oComponentData) {
					var __aStartUpParameter = __oComponentData["startupParameters"];
					if (__aStartUpParameter) {
						if (__aStartUpParameter[param] !== undefined && __aStartUpParameter[param] !== null) {
							__sOpptyId = decodeURIComponent(__aStartUpParameter[param][0]);
						}
					}
				}
			} catch (err) {

			}
			return __sOpptyId;
		},

		fnGetDecryptedParamIDs: function (param) {
			var paramArr = param.split("");
			//[optyIdArr[11], optyIdArr[1]] = [optyIdArr[1], optyIdArr[11]];
			//[optyIdArr[10], optyIdArr[2]] = [optyIdArr[2], optyIdArr[10]];
			return atob(paramArr.reverse().join(""));
			//return atob(param);
		},
	});
});