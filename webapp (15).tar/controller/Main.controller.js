sap.ui.define([
	"com/hpe/it/zsimulateasq/controller/BaseController",
	"sap/m/MessageBox"
], function (BaseController, MessageBox) {
	"use strict";

	return BaseController.extend("com.hpe.it.zsimulateasq.controller.Main", {

		extOnInit: function () {
			this.__fnGetAuthObjDtl();
			this.__fnGetOppObjDtl();
		},


		_handleRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") !== "MAIN") {
				return;
			} else {

				this.fnResetForm(true);
			}
		},

		fnResetForm: function (bInitial) {
			var __oView = this.getView();

			__oView.byId("quoteType_selId").setVisible(false);
			__oView.byId("opportunity_inpId").setVisible(false);
			__oView.byId("product_inpId").setVisible(false);
			__oView.byId("quoteNo_inpId").setVisible(false);
			__oView.byId("emailId_inpId").setVisible(false);

			if (bInitial) {
				__oView.byId("simulationType_segBtnId").setSelectedKey("punchOut");
				__oView.byId("quoteMode_segBtnId").setSelectedKey("create");
				__oView.byId("persona_selId").setSelectedKey("SALES_OPS");
				__oView.byId("language_selId").setSelectedKey("EN");
				__oView.byId("opportunity_inpId").setVisible(true);
				__oView.byId("product_inpId").setVisible(true);
				__oView.byId("emailId_inpId").setVisible(true);
			}

			var oOppModel = this.getModel("oppMdl");
			if (oOppModel && oOppModel.getProperty("/sDefOppId")) {
				__oView.byId("opportunity_inpId").setValue(oOppModel.getProperty("/sDefOppId"));
			} else {
				__oView.byId("opportunity_inpId").setValue();
			}
			__oView.byId("quoteType_selId").setSelectedKey("ZQST");
			__oView.byId("quoteNo_inpId").setValue();
			__oView.byId("emailId_inpId").setValue();
			if (sap.ushell !== undefined) {
				var sUserEmail = sap.ushell.Container.getUser().getEmail();
				if (sUserEmail) {
					__oView.byId("emailId_inpId").setValue(sUserEmail);
				}
			}

			if (__oView.byId("quoteMode_segBtnId").getSelectedKey() === "displayEdit") {
				__oView.byId("persona_selId").getItemByKey("Internal_Display").setEnabled(true);
			} else {
				if (__oView.byId("persona_selId").getSelectedKey() === "Internal_Display") {
					__oView.byId("persona_selId").setSelectedKey("SALES_OPS");
				}
				__oView.byId("persona_selId").getItemByKey("Internal_Display").setEnabled(false);
			}
		},

		fnOnSelectionChange: function () {
			var __oView = this.getView(),
				sSimulationType = __oView.byId("simulationType_segBtnId").getSelectedKey(),
				sQuoteMode = __oView.byId("quoteMode_segBtnId").getSelectedKey();

			this.fnResetForm(false);

			if (sSimulationType === "punchOut") {
				__oView.byId("emailId_inpId").setVisible(true);
				if (sQuoteMode === "create") {
					__oView.byId("opportunity_inpId").setVisible(true);
					__oView.byId("product_inpId").setVisible(true);
				} else {
					__oView.byId("quoteNo_inpId").setVisible(true);
				}
			} else {
				if (sQuoteMode === "displayEdit") {
					__oView.byId("quoteNo_inpId").setVisible(true);
				} else {
					__oView.byId("quoteType_selId").setVisible(true);
				}
			}
		},

		fnGetEncryptValue: function (param) {
			var paramIdArr = btoa(param).split("").reverse();
			[paramIdArr[1], paramIdArr[11]] = [paramIdArr[11], paramIdArr[1]];
			[paramIdArr[2], paramIdArr[10]] = [paramIdArr[10], paramIdArr[2]];
			return paramIdArr.join("");
		},

		fnGetEncryptValuePersona: function (sValue) {
			return btoa(sValue);
		},

		fnNavToASQExternal: function () {
			var __oView = this.getView(),
				sQuoteMode = __oView.byId("quoteMode_segBtnId").getSelectedKey(),
				sPersona = __oView.byId("persona_selId").getSelectedKey(),
				sLanguage = __oView.byId("language_selId").getSelectedKey(),
				sASQVersion = __oView.byId("asqrepo_selId").getSelectedKey(),
				sQuoteNo = __oView.byId("quoteNo_inpId").getValue().trim(),
				sOpportunityId = __oView.byId("opportunity_inpId").getValue().trim(),
				sProductId = __oView.byId("product_inpId").getValue().trim(),
				sEmailId = __oView.byId("emailId_inpId").getValue().trim(),
				oi18nBundle = this.getResourceBundle(),
				oSemanticObj,
				oAction,

				
				/*__oRequestPayload = {
					"emailId": sEmailId,
					"persona": sPersona,
					"token": "",
					"partnerAdminRole": "",
					"country": ""
				},
				_oCreateOptions = {},*/
				oAuthModel = this.getModel("authMdl");

			sPersona = this.fnGetEncryptValuePersona(sPersona);

			if(sASQVersion === "ASQ_NEW"){
				oSemanticObj = "Sub"
				oAction =  "quote"
			}
			else{
				oSemanticObj = "ZLTS"
				oAction =  "manageSolQuoteOld"
			}

			if (oAuthModel.getProperty("/bSimulateType")) {
				/*(-) SOC BADH  RAMP-1020 06.09.2023*/
				/*_oCreateOptions["oModel"] = this.getModel("Z_REGISTER_USERS_TOKEN_SRV");
				_oCreateOptions["sPath"] = "/Ets_tokenBRIM";
				_oCreateOptions["oRequestBody"] = __oRequestPayload;

				_oCreateOptions["fnSuccess"] = function (oData, oResponse) {
					if (oData.token) {
						var sURL = window.location.origin;

						if (sQuoteMode === "create") {
							sURL += oi18nBundle.getText("ASQCreateExtURL", [sLanguage, oData.token, this.fnGetEncryptValue(sOpportunityId)]);
						} else {
							sURL += oi18nBundle.getText("ASQDisplayEditExtURL", [sLanguage, oData.token, this.fnGetEncryptValue(sQuoteNo), sQuoteNo]);
						}

						sap.m.URLHelper.redirect(sURL, false);
					}
				}.bind(this);

				this.__createODataOperation(_oCreateOptions);*/
				/*(-) EOC BADH  RAMP-1020 06.09.2023*/
				/*(+) SOC BADH  RAMP-1020 06.09.2023*/
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
					hash = "";
				if (sQuoteMode === "create") {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
						var parameters = {
							"o": this.fnGetEncryptValue(sOpportunityId),
							"e": "CROSS_APP",
							"i": "ZLTS-simulateManageSolQuote",
							"i_pers": sPersona,
							"i_lang": sLanguage
						};

						if (sProductId !== "" && sProductId !== undefined && sProductId !== null) {
							parameters["p"] = this.fnGetEncryptValuePersona(sProductId);
						}

						oService.hrefForExternalAsync({
							target: {
								semanticObject: oSemanticObj,
								action: oAction
							},
							params: parameters
						}).then(function (sHref) {
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: sHref + "&/Cr/Ex"
								}
							});
						});
					}.bind(this));
				} else {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {

						oService.hrefForExternalAsync({
							target: {
								semanticObject: oSemanticObj,
								action: oAction
							},
							params: {
								"q": this.fnGetEncryptValue(sQuoteNo),
								"e": "CROSS_APP",
								"i": "ZLTS-simulateManageSolQuote",
								"i_pers": sPersona,
								"i_lang": sLanguage
							}
						}).then(function (sHref) {
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: sHref + "&/Display/" + sQuoteNo
								}
							});
						});
					}.bind(this));
				}
				/*(+) EOC BADH  RAMP-1020 06.09.2023*/
			} else {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
					hash = "";
				if (sQuoteMode === "create") {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
						var parameters = {
							"o": this.fnGetEncryptValue(sOpportunityId),
							"e": "CROSS_APP",
							"i": "ZLTS-simulateManageSolQuote",
							"i_pers": sPersona,
							"i_lang": sLanguage
						};

						if (sProductId !== "" && sProductId !== undefined && sProductId !== null) {
							parameters["p"] = this.fnGetEncryptValuePersona(sProductId);
						}
						oService.hrefForExternalAsync({
							target: {
								semanticObject: oSemanticObj,
								action: oAction
							},
							params: parameters
						}).then(function (sHref) {
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: sHref + "&/Cr/Ex"
								}
							});
						});
					}.bind(this));
				} else {
					sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {

						oService.hrefForExternalAsync({
							target: {
								semanticObject: oSemanticObj,
								action: oAction
							},
							params: {
								"q": this.fnGetEncryptValue(sQuoteNo),
								"e": "CROSS_APP",
								"i": "ZLTS-simulateManageSolQuote",
								"i_pers": sPersona,
								"i_lang": sLanguage
							}
						}).then(function (sHref) {
							oCrossAppNavigator.toExternal({
								target: {
									shellHash: sHref + "&/Display/" + sQuoteNo
								}
							});
						});
					}.bind(this));
				}

			}
		},

		fnNavToASQInternal: function (sQuoteNo) {
			var __oView = this.getView(),
				sLanguage = __oView.byId("language_selId").getSelectedKey(),
				sPersona = __oView.byId("persona_selId").getSelectedKey(),
				sQuoteMode = __oView.byId("quoteMode_segBtnId").getSelectedKey(),
				sASQVersion = __oView.byId("asqrepo_selId").getSelectedKey(),
				sQuoteNo = __oView.byId("quoteNo_inpId").getValue().trim(),
				sQuoteType = __oView.byId("quoteType_selId").getSelectedKey() ? __oView.byId("quoteType_selId").getSelectedItem().getText() : "",
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
				oSemanticObj,
				oAction;
        
			sPersona = this.fnGetEncryptValuePersona(sPersona);

			if(sASQVersion === "ASQ_NEW"){
				oSemanticObj = "Sub"
				oAction =  "quote"
			}
			else{
				oSemanticObj = "ZLTS"
				oAction =  "manageSolQuoteOld"
			}

			if (sQuoteMode === "create") {
				sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {

					oService.hrefForExternalAsync({
						target: {
							semanticObject: oSemanticObj,
							action: oAction
						},
						params: {
							"i_pers": sPersona,
							"i_lang": sLanguage
						}

					}).then(function (sHref) {
						oCrossAppNavigator.toExternal({
							target: {
								shellHash: sHref + "&/Cr/" + sQuoteType
							}
						});
					});
				});
			} else {
				sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {

					oService.hrefForExternalAsync({
						target: {
							semanticObject: oSemanticObj,
							action: oAction
						},
						params: {
							"i_pers": sPersona,
							"i_lang": sLanguage
						}

					}).then(function (sHref) {
						oCrossAppNavigator.toExternal({
							target: {
								shellHash: sHref + "&/Display/" + sQuoteNo
							}
						});
					});
				});
			}

		},

		//BOC by SMDELOITTE2 on 15-Feb-2023
		onQuoteIdValueHelpRequest: function (oEvent) {
			if (!this.oVHQuoteId) {
				//create dialog with fragment
				this.oVHQuoteId = sap.ui.xmlfragment("com.hpe.it.zsimulateasq.view.fragments.VHQuoteId",
					this);
				//adding dependent
				this.getView().addDependent(this.oVHQuoteId);
			}
			//open dialog
			this.oVHQuoteId.open();
		},
		onVHQuoteIdClose: function () {
			this.oVHQuoteId.close();
		},
		onSelectionChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem"),
				vSelectedID = oSelectedItem.getBindingContext().getObject("OBJECT_ID");
			this.getView().byId("quoteNo_inpId").setValue(vSelectedID);
			this.oVHQuoteId.close();
		},
		//EOC by SMDELOITTE2 on 15-Feb-2023

		onSimulateBtnPress: function (oEvent) {
			var __oView = this.getView(),
				sSimulationType = __oView.byId("simulationType_segBtnId").getSelectedKey(),
				sQuoteMode = __oView.byId("quoteMode_segBtnId").getSelectedKey(),
				sQuoteNo = __oView.byId("quoteNo_inpId").getValue().trim(),
				sOpportunityId = __oView.byId("opportunity_inpId").getValue().trim(),
				sEmailId = __oView.byId("emailId_inpId").getValue().trim(),
				sQuoteType = __oView.byId("quoteType_selId").getSelectedKey(),
				sMsg = this.getResourceBundle().getText("zmsg.mandatory");

			if (sSimulationType === "punchOut") {
				if (sQuoteMode === "create" && (sOpportunityId === "" || sEmailId === "")) {
					MessageBox.error(sMsg);
					return;
				} else if (sQuoteMode === "displayEdit" && (sQuoteNo === "" || sEmailId === "")) {
					MessageBox.error(sMsg);
					return;
				}
				this.fnNavToASQExternal();
			} else {
				if (sQuoteMode === "create" && sQuoteType === "") {
					MessageBox.error(sMsg);
					return;
				} else if (sQuoteMode === "displayEdit" && sQuoteNo === "") {
					MessageBox.error(sMsg);
					return;
				}
				this.fnNavToASQInternal();
			}
		},

		onResetBtnPress: function (oEvent) {
			this.fnResetForm(true);
		},

		__fnGetAuthObjDtl: function () {
			try {

				var sURL = "/sap/opu/odata4/sap/z_auth_obj_service_group/default/sap/zsid_auth_obj/0001/AuthObj";

				sURL += "?$filter=(AppId eq 'ASQSIM' and Operation eq 'SIMULATE' and (Field eq 'PERSONA' or Field eq 'SIMULATION_TYPE'))";
				$.ajax({
					type: "GET",
					contentType: "application/json",
					url: sURL,
					dataType: "json",
					async: false,
					success: function (oData, txtStatus, jqXHR) {
						if (txtStatus.toUpperCase() === "SUCCESS" && jqXHR["status"] === 200) {
							var bSimulateType = true,
								bPersonaVisible = true;

							for (var oVal of oData["value"]) {
								if (oVal.AppId === "ASQSIM" && oVal.Operation === "SIMULATE" && oVal.Field === "SIMULATION_TYPE" && oVal.BAuthorized ===
									"X") {
									bSimulateType = false;
								} else if (oVal.AppId === "ASQSIM" && oVal.Operation === "SIMULATE" && oVal.Field === "PERSONA" && oVal.BAuthorized ===
									"X") {
									bPersonaVisible = false;
								}
							}

							this.getView().setModel(new sap.ui.model.json.JSONModel({
								bSimulateType: bSimulateType,
								bPersonaVisible: bPersonaVisible
							}), "authMdl");
						}
					}.bind(this),
					error: function (oErr) {

					}.bind(this)
				});
			} catch (err) {
				this.getView().setModel(new sap.ui.model.json.JSONModel({
					bSimulateType: true,
					bPersonaVisible: true
				}), "authMdl");
			}
		},

		__fnGetOppObjDtl: function () {
			try {
				var sURL = "/sap/opu/odata4/sap/z_oppr_id_service_group/default/sap/zsid_oppr_id/0001/OppId";
				sURL += "?$filter=(AppId eq 'ASQSIM' and Operation eq 'SIMULATE' and Field eq 'OPPORTUNITYID')";
				$.ajax({
					type: "GET",
					contentType: "application/json",
					url: sURL,
					dataType: "json",
					async: false,
					success: function (oData, txtStatus, jqXHR) {
						if (txtStatus.toUpperCase() === "SUCCESS" && jqXHR["status"] === 200) {
							if (oData.value && oData.value[0]) {
								this.getView().setModel(new sap.ui.model.json.JSONModel({
									sDefOppId: oData.value[0].Value
								}), "oppMdl");
								this.byId("opportunity_inpId").setValue(oData.value[0].Value);
							}
						}
					}.bind(this),
					error: function (oErr) {

					}.bind(this)
				});
			} catch (err) {

			}
		}

	});

});