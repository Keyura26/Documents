sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";
	return Controller.extend("com.hpe.it.zsimulateasq.controller.BaseController", {

		onInit: function () {
			this.getRouter().attachRoutePatternMatched(this._handleRouteMatched, this);
			if(sap.ushell){
				var oJsonMdl =  new sap.ui.model.json.JSONModel({
					"userId": new sap.ushell.services.UserInfo().getId()
				});
				this.setJSONModel(oJsonMdl, "globalMdl", true);
			}
			this.extOnInit();
		},

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getModel: function (sName) {
			if (sName) {
				return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
			} else {
				return this.getView().getModel() || this.getOwnerComponent().getModel();
			}
		},
		setJSONModel: function (oData, sName, bGlobal) {
			if (bGlobal) {
				if (sName) {
					this.getOwnerComponent().setModel(oData, sName);
				} else {
					this.getOwnerComponent().setModel(oData);
				}
			} else {
				if (sName) {
					this.getView().setModel(oData, sName);
				} else {
					this.getView().setModel(oData);
				}
			}
		},
		__openBusyDialog: function () { //Global Method to  Open Busy Dialog
			if (!this.__oBusyDialog) {
				var _oBusyDialog = new sap.m.BusyDialog();
				_oBusyDialog.removeAllCustomData();
				_oBusyDialog.addCustomData(new sap.ui.core.CustomData({
					"key": "bOpened",
					"value": true
				}));
				this.__oBusyDialog = _oBusyDialog;
				jQuery.sap.delayedCall(0, this, function () {
					this.__oBusyDialog.open();
				});

			} else {
				if (this.__oBusyDialog.data("bOpened") !== undefined && this.__oBusyDialog.data("bOpened") !== true) {
					this.__oBusyDialog.removeAllCustomData();
					this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
						"key": "bOpened",
						"value": true
					}));
					jQuery.sap.delayedCall(0, this, function () {
						this.__oBusyDialog.open();
					});
				}
			}
		},

		__closeBusyDialog: function () { //Global Method to Close Busy Dialog
			if (this.__oBusyDialog) {
				this.__oBusyDialog.removeAllCustomData();
				this.__oBusyDialog.addCustomData(new sap.ui.core.CustomData({
					"key": "bOpened",
					"value": false
				}));
				this.__oBusyDialog.close();
			}
		},

		__isBusyDialogOpened: function () {
			if (this.__oBusyDialog) {
				if (this.__oBusyDialog.data("bOpened") !== undefined && this.__oBusyDialog.data("bOpened") === true) {
					return true;
				}
			}
			return false;
		},

		__readODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy()) {
							_options.oControl.setBusy(true);
						}
					}
				} else {
					this.__openBusyDialog();
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add Filter Parameters
				if (_options.oFilters) {
					_oParameters["filters"] = _options.oFilters;
				}

				/*SOC BADH PERFORMANCE FIXES 2022/09/07*/
				if (_options.oSorters) {
					_oParameters["sorters"] = _options.oSorters;
				}
				/*EOC BADH PERFORMANCE FIXES 2022/09/07*/

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				_oModel.read(_options.sPath, _oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog();
				}
			}
		},

		__deleteODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy()) {
							_options.oControl.setBusy(true);
						}
					}
				} else {
					this.__openBusyDialog();
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				_oModel.remove(_options.sPath, _oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog();
				}
			}
		},

		__updateODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy()) {
							_options.oControl.setBusy(true);
						}
					}
				} else {
					this.__openBusyDialog();
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//Add Merge flag
				if (_options.bMerge) {
					_oParameters["merge"] = _options.bMerge;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							if (!_options.oControl.getBusy()) {
								_options.oControl.setBusy(true);
							}
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				jQuery.sap.delayedCall(0, this, function () {
					_oModel.update(_options.sPath, _options.oRequestBody, _oParameters);
				});
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog();
				}
			}
		},

		__createODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy()) {
							_options.oControl.setBusy(true);
						}
					}
				} else {
					this.__openBusyDialog();
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				_oModel.create(_options.sPath, _options.oRequestBody, _oParameters);

			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog();
				}
			}
		},

		//SOC ACHOPRADELOI- OR-2477-IRIS File Upload 28/07/2022
		__callFunctionODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy()) {
							_options.oControl.setBusy(true);
						}
					}
				} else {
					this.__openBusyDialog();
				}

				var _oModel = _options.oModel,
					_oParameters = {},
					_oHeader = {
						'X-Requested-With': 'X',
						'Accept': 'application/json'
					};

				//Add Header Parameter
				if (_options.oHeaders) {
					Object.assign(_oHeader, _options.oHeaders);
				}
				_oModel.setHeaders(_oHeader);

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				if (_options.method) {
					_oParameters["method"] = _options.method;
				}

				//Add URL Parameters
				if (_options.oURIParameters) {
					_oParameters["urlParameters"] = _options.oURIParameters;
				}

				//Add Async flag
				if (_options.bAsync) {
					_oParameters["async"] = _options.bAsync;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				_oModel.callFunction(_options.sPath, _oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog();
				}
			}
		},
		//EOC ACHOPRADELOI- OR-2477-IRIS File Upload 28/07/2022

		__submitChangeODataOperation: function (_options) {
			var __bGlobalBusy = true;
			try {
				if (_options.bGlobalBusy !== undefined) {
					if (_options.bGlobalBusy === false) {
						__bGlobalBusy = false;
					}
				}

				if (__bGlobalBusy === false) {
					if (_options.oControl) {
						if (!_options.oControl.getBusy()) {
							_options.oControl.setBusy(true);
						}
					}
				} else {
					this.__openBusyDialog();
				}

				var _oModel = _options.oModel,
					_oParameters = {};

				//Add Header Parameter
				_oModel.setHeaders({
					'X-Requested-With': 'X',
					'Accept': 'application/json'
				});

				//Add Batch GroupId
				if (_options.sBatchGroupId) {
					_oModel.setDeferredGroups([_options.sBatchGroupId]);
					_oParameters["groupId"] = _options.sBatchGroupId;
				}

				//OData Success Handling
				_oParameters["success"] = function (oData, oResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnSuccess) {
						_options.fnSuccess(oData, oResponse);
					}
				}.bind(this);

				//OData Error Handling
				_oParameters["error"] = function (oErrResponse) {
					if (__bGlobalBusy === false) {
						if (_options.oControl) {
							_options.oControl.setBusy(false);
						}
					} else {
						this.__closeBusyDialog();
					}
					if (_options.fnError) {
						_options.fnError(oErrResponse);
					}
				}.bind(this);

				_oModel.submitChanges(_oParameters);
			} catch (err) {
				if (_options.oControl && __bGlobalBusy === false) {
					_options.oControl.setBusy(false);
				} else if (__bGlobalBusy === true) {
					this.__closeBusyDialog();
				}
			}
		}
	});
});