sap.ui.define([
	"com/hpe/it/zsimulateasq/test/unit/controller/App.controller"
], function () {
	"use strict";
});