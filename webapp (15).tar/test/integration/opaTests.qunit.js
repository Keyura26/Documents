/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"com/hpe/it/zsimulateasq/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});