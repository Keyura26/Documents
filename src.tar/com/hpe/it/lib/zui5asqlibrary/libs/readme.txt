******When PCE Config popup loads*******
fnSetInitialData - to fetch the data of the product added by user from Ets_product
__fnGetUUIDBatch - trigggers to fetch new draftuuid and simuationuuid the new PCE product
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnSetAVCTabs - This method will render AVC groups on UI
__fnUpdateStatusControlChar- This method will update CS_WORKLOADS_RELEASED
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnRenderWLTab - When user clicks on workload tab it gets rendered
__fnAddInstance - When user clicks on add Workload
__fnGetCharValueText - When add instance is load this function triggers to get the text
__fnGetWorkloadGroupChars - this method triggers when user needs to add level wise instance
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnSetAVCControls - This method will render AVC dynamic UI
fnSetPrdCartCharDetails - This method will be called to generate the configuration details, which are shown on Pick Product Cart screen
__fnGetCharTooltips - This method will be called when user select anything from Value Help Dialog of Multi Input
__fnSetCharGrpData - This method will fetch the latest AVC configuration details and update the characteristics values after changes in configuration
__fnValidateForPricing - This method will validate condition for pricing call
*********************************************************************************************************************************************************
*********************************************************************************************************************************************************
******When User enter the term*******
__fnUpdateCharValue - This method will update the characteristics values on changes in any characteristics and also fetch the latest AVC configuration details
__fnCallAVCUpdateSrvs - This method will fetch the latest AVC configuration details after changes in any characterictics
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnValidateForPricing - This method will validate condition for pricing call
fnSetPrdCartCharDetails - This method will be called to generate the configuration details, which are shown on Pick Product Cart screen
__fnGetCharTooltips - This method will be called when user select anything from Value Help Dialog of Multi Input
***************************************************************************************************************************************************************
***************************************************************************************************************************************************************
********When user click on workload tab***********
onAVCCharIconBarSelect - This method will be called when user changes from one tab to another tab in UI
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnRenderWLTab - This method will render workload tabs based on user selection
__fnGetCharValueText - This method will fetch descriptions for workload instances
__fnCheckInsBtn - This method will enable/disable Add Instance button
__fnSetReRenderExistingTabs - 
__fnSetAVCControls - This method will render AVC dynamic UI
fnSetPrdCartCharDetails - This method will be called to generate the configuration details, which are shown on Pick Product Cart screen
__fnGetCharTooltips - This method will be called when user select anything from Value Help Dialog of Multi Input
****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
**********When the user clicks on VM**********
onChildTabSelect - This method will be called when user changes from one tab to another tab in UI
__fnCheckInsBtn - This method will enable/disable Add Instance button
__fnSetReRenderExistingTabs
****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
*********When user clicks on add workload************
__fnAddInstance - This method will add instance of workload
__fnGenerateWL - This method will generate object for workload
__fnGetWorkloadUUIDBatch - This method will fetch the simulation and Draft UUID for new AVC configuration
__fnCheckInsBtn - This method will enable/disable Add Instance button
__fnGetWorkloadCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnRenderInstance - This method will render pre-existing Instance
__fnGetWorkloadGroups - This method will fetch the AVC Configuration status and Groups for configurable product
__fnUpdateStatus - This method will render workload status
__fnUpdateParentControlChar - This method will update parent product control char for overall config status
__fnUpdateStatusControlChar - This method will update CS_WORKLOADS_RELEASED
__fnGetClearChar - This method will clear characteristics value from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnSetCharGrpData - This method will fetch the latest AVC configuration details and update the characteristics values after changes in configuration
__fnValidateForPricing - This method will validate condition for pricing call
__fnLoadInstanceType - This method will load instance type for next group
__fnUpdateWorloadCharValue - This method will fetch the latest AVC configuration details after changes in any characterictics
__fnWorkloadCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnWorkloadCharAlterValue - This method will calculate the atlernate value of the characteristics from the AVC configuration
***************************************************************************************************************************************************************
***************************************************************************************************************************************************************
***********When User select VM instance characteristic type**************
__fnSelectedInstance - This method will load chars for selected instance type
__fnUpdateSelections - This method will update selections for workload
__fnLoadInstanceSizes - This method will load instance size
__fnSizeTypeChange - This method will update change size char and load chars
__fnUpdateWorloadCharValue - This method will fetch the latest AVC configuration details after changes in any characterictics
__fnWorkloadCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnWorkloadCharAlterValue - This method will calculate the atlernate value of the characteristics from the AVC configuration
__fnGetWorkloadCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetWorkloadGroupChars - This method will fetch the AVC Characteristics for configurable product
__fnSetCharGrpData - This method will fetch the latest AVC configuration details and update the characteristics values after changes in configuration
__fnValidateForPricing - This method will validate condition for pricing call
****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
***********When user provides char instance value in VM***********
__fnChangeSizeInput - This method will update size value char and load chars
__fnUpdateSelections - This method will update selections for workload
__fnUpdateWorloadCharValue - This method will fetch the latest AVC configuration details after changes in any characterictics
__fnWorkloadCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnWorkloadCharAlterValue - This method will calculate the atlernate value of the characteristics from the AVC configuration
__fnGetWorkloadCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetWorkloadGroupChars - This method will fetch the AVC Characteristics for configurable product
__fnUpdateStatus - This method will render workload status
__fnUpdateParentControlChar - This method will update parent product control char for overall config status
__fnUpdateStatusControlChar -This method will update CS_WORKLOADS_RELEASED
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnUpdateStatusControlChar - This method will update CS_WORKLOADS_RELEASED
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnLoadInstanceSizes - This method will load instance size
__fnValidateForPricing - This method will validate condition for pricing call
****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
************When user clicks on storage volumes tab*************
onChildTabSelect - This method will be called when user changes from one tab to another tab in UI
__fnSetReRenderExistingTabs - 
__fnInitiateStorageWL - This method will fetch the AVC Configuration storage workload
__fnGenerateWL - This method will generate object for workload
__fnGetWorkloadUUIDBatch - This method will fetch the simulation and Draft UUID for new AVC configuration
__fnGetWorkloadCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnRenderStorageInstance - This method will render storage instance
__fnGetWorkloadGroups - This method will fetch the AVC Configuration status and Groups for configurable product
__fnUpdateStatus - This method will render workload status
__fnUpdateParentControlChar - This method will update parent product control char for overall config status
__fnUpdateStatusControlChar - This method will update CS_WORKLOADS_RELEASED
__fnGetClearChar - This method will clear characteristics value from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnUpdateStatusControlChar - This method will update CS_WORKLOADS_RELEASED
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnGetWorkloadGroupChars - This method will fetch the AVC Characteristics for configurable product
__fnSetCharGrpData - This method will fetch the latest AVC configuration details and update the characteristics values after changes in configuration
__fnValidateForPricing - This method will validate condition for pricing call
__fnLoadStorageWL - This method will load storage worload
****************************************************************************************************************************************************************
****************************************************************************************************************************************************************
*******When user provides char value in in Storage Volumes*********
__fnChangeSizeInput - This method will update size value char and load chars
__fnUpdateSelections - This method will update selections for workload
__fnUpdateWorloadCharValue - This method will fetch the latest AVC configuration details after changes in any characterictics
__fnWorkloadCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnWorkloadCharAlterValue - This method will calculate the atlernate value of the characteristics from the AVC configuration
__fnGetWorkloadCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetWorkloadGroupChars - This method will fetch the AVC Characteristics for configurable product
__fnUpdateStatus - This method will render workload status
__fnUpdateParentControlChar - This method will update parent product control char for overall config status
__fnUpdateStatusControlChar - This method will update CS_WORKLOADS_RELEASED
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnUpdateStatusControlChar - This method will update CS_WORKLOADS_RELEASED
__fnSetCharValueAssign - This method will assign a value to the characteristics from the AVC configuration
__fnGetCharContext - This method will fetch the AVC Configuration status and Groups for configurable product
__fnGetCharGroup - This method will fetch the AVC Characteristics for configurable product
__fnValidateForPricing - This method will validate condition for pricing call
__fnSetCharGrpData - This method will fetch the latest AVC configuration details and update the characteristics values after changes in configuration
__fnValidateForPricing - This method will validate condition for pricing call
__fnPrepPricingPayload - This method will prepare payload for pricing call and update model with chars
__fnDetermineCharValueType - This method will determine char type (Technical or String)
__fnFetchPCEConfigPrice - This method will fetch price
