sap.ui.define([
	"Z_DOC_FLOW_CPQ/Z_DOC_FLOW_CPQ/test/unit/controller/ProcessFlow.controller"
], function () {
	"use strict";
});