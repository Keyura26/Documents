/*global QUnit*/

sap.ui.define([
	"Z_DOC_FLOW_CPQ/Z_DOC_FLOW_CPQ/controller/ProcessFlow.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ProcessFlow Controller");

	QUnit.test("I should test the ProcessFlow controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});