/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"Z_DOC_FLOW_CPQ/Z_DOC_FLOW_CPQ/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});