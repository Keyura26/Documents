sap.ui.define([
	"sap/ui/test/Opa5",
	"./arrangements/Startup",
	"./NavigationJourney"
], function (Opa5, Startup) {
	"use strict";

	Opa5.extendConfig({
		arrangements: new Startup(),
		viewNamespace: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.view.",
		autoWait: true
	});
});