sap.ui.define([
	'Z_DOC_FLOW_CPQ/Z_DOC_FLOW_CPQ/controller/BaseController',
	'jquery.sap.global',
	'sap/suite/ui/commons/library',
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/json/JSONModel',
	'sap/m/MessageToast',
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	"sap/ui/core/routing/HashChanger",
	'sap/ui/core/Fragment',
	"com/hpe/it/zui5odatautils/libs/zODataV2Utils",
	"com/hpe/it/zui5odatautils/libs/zODataV4Utils",
	'sap/ui/comp/smartvariants/PersonalizableInfo'
], function (BaseController, jQuery, SuiteLibrary, Controller, JSONModel, MessageToast, Filter, FilterOperator, Sorter, MessageBox,
	oHashChanger, Fragment, ODataV2Utils, ODataV4Utils, PersonalizableInfo) {
	"use strict";

	var __oPrevFilterData;

	return BaseController.extend("Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.controller.ProcessFlow", {
		extOnInit: function () {
			var oViewData = new JSONModel({
				bShowInvoicesBtn: false,
				bShowInvoicesBtnPressed: false
			}),
				oE2EDocFlow_SVMId = this.byId("e2eDocFlow_svmId"),
				oE2EDocFlowFilterBar = this.byId("e2eDocFlow_fbId"),
				oE2EDocFlowPersInfo;

			this.setJSONModel(oViewData, "viewDataMdl");

			oE2EDocFlowFilterBar.registerFetchData(this.fetchData.bind(this));
			oE2EDocFlowFilterBar.registerApplyData(this.applyData.bind(this));
			oE2EDocFlowFilterBar.registerGetFiltersWithValues(this.getFiltersWithValues.bind(this));

			oE2EDocFlowPersInfo = new PersonalizableInfo({
				type: "filterBar",
				keyName: "e2eDocFlowPersKey",
				dataSource: "",
				control: oE2EDocFlowFilterBar
			});

			oE2EDocFlow_SVMId.addPersonalizableControl(oE2EDocFlowPersInfo);
			oE2EDocFlow_SVMId.initialise(function () { }, oE2EDocFlowFilterBar);

			var oMessageManager = sap.ui.getCore().getMessageManager();
			this.setJSONModel(oMessageManager.getMessageModel(), "message");
			this.getModel("message").attachPropertyChange(function (oEvent) {
				debugger;
			}.bind(this));
			this.getModel("message").attachRequestCompleted(function (oEvent) {
				debugger;
			}.bind(this));

		},

		_handleRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "processFlow") {
				var sHash = oHashChanger.getInstance().getHash();
				if (sHash !== "undefined" && sHash !== "") {
					var sAppStateKeys = /(?:sap-iapp-state=)([^&=]+)/.exec(sHash);
					if (sAppStateKeys !== null) {
						var sAppStateKey = sAppStateKeys[1];
						sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
							oService.getAppState(this.getOwnerComponent(), sAppStateKey).then(function (oAppState) {
								var oAppStateData = oAppState.getData();
								if (oAppStateData) {
									__oPrevFilterData = oAppStateData;
								} else {
									__oPrevFilterData = [];
								}
							}.bind(this))
						}.bind(this));
					} /*(+)SOC BADH DEFAULT SOLQUOTE 2024.08.29*/else {
						this.__fnGetAuthObjDtl();
					}/*(+)EOC BADH DEFAULT SOLQUOTE 2024.08.29*/
				}/*(+)SOC BADH DEFAULT SOLQUOTE 2024.08.29*/else {
					this.__fnGetAuthObjDtl();
				}/*(+)EOC BADH DEFAULT SOLQUOTE 2024.08.29*/
			}
		},

		onMsgPopoverBtnPress: function (oEvent) {
			var oControl = oEvent.getSource();
			this.fnMsgManagerPopoverOpen(oControl);
		},

		fetchData: function () {
			var oE2EDocFlowFilterBar = this.byId("e2eDocFlow_fbId"),
				aData = oE2EDocFlowFilterBar.getAllFilterItems().reduce(function (aResult, oFilterItem) {
					aResult.push({
						groupName: oFilterItem.getGroupName(),
						fieldName: oFilterItem.getName(),
						fieldData: oFilterItem.getControl().getValue()
					});

					return aResult;
				}, []);

			return aData;
		},

		applyData: function (aData) {
			var oE2EDocFlowFilterBar = this.byId("e2eDocFlow_fbId");
			aData.forEach(function (oDataObject) {
				var oControl = oE2EDocFlowFilterBar.determineControlByName(oDataObject.fieldName, oDataObject.groupName);
				oControl.setValue(oDataObject.fieldData);
			}, this);
		},

		getFiltersWithValues: function () {
			var oE2EDocFlowFilterBar = this.byId("e2eDocFlow_fbId"),
				aFiltersWithValue = oE2EDocFlowFilterBar.getFilterGroupItems().reduce(function (aResult, oFilterGroupItem) {
					var oControl = oFilterGroupItem.getControl();

					if (oControl && oControl.getValue().length > 0) {
						aResult.push(oFilterGroupItem);
					}

					return aResult;
				}, []);

			return aFiltersWithValue;
		},

		//SOC PSENAPATI E2E New Design
		fnGetFilters: function () {
			var oView = this.getView(),
				oFilterBar = oView.byId("e2eDocFlow_fbId"),
				aFilters = oFilterBar.getFilterGroupItems().reduce(function (aResult, oFilterGroupItem) {
					var oControl = oFilterGroupItem.getControl(),
						sValues = oControl.getValue();

					if (sValues !== "" && sValues !== undefined && sValues !== null) {
						aResult.push(new Filter({
							path: oFilterGroupItem.getName(),
							operator: FilterOperator.EQ,
							value1: sValues.trim()
						}));
					}

					return aResult;
				}, []);
			return aFilters;
		},

		onInputLiveChanges: function (oEvent) {
			var _oInput = oEvent.getSource(),
				val = _oInput.getValue();
			val = val.replace(/[^\d]/g, '');
			_oInput.setValue(val);
			if (val) {
				this.byId("e2eDocFlow_svmId").currentVariantSetModified(true);
			} else {
				this.byId("e2eDocFlow_svmId").currentVariantSetModified(false);
			}
		},

		onPressSearch: function (oEvent, bShowAllInvoices) {
			var oView = this.getView(),
				aFilters = this.fnGetFilters(),
				oi18nModel = this.getResourceBundle(),
				oProcessFlow1 = oView.byId("processflow1");

			this.fnMsgManagerPopoverClose();
			if (typeof (oEvent) === 'string') {
				aFilters.push(new Filter("Quotenumber", FilterOperator.EQ, oEvent));
			}
			if (aFilters.length === 0) {
				MessageBox.error(oi18nModel.getText("ymsg.noFilters"));
				return;
			}

			if (!bShowAllInvoices) {
				aFilters.push(new Filter("Latestinvoice", FilterOperator.EQ, "X"));
			}

			var _oReadOptions = {};
			_oReadOptions["oModel"] = this.getModel();
			_oReadOptions["sPath"] = "/QuoteDetails";
			_oReadOptions["oFilters"] = [new Filter(aFilters, true)];
			_oReadOptions["oSorters"] = [new Sorter("Quotenumber")];
			_oReadOptions["isAbsolutePath"] = false;
			_oReadOptions["fnSuccess"] = function (oData, oResponse) {
				try {
					if (oData.length === 0) {
						MessageToast.show(oi18nModel.getText("ymsg.noQuotationFound"));

						var oProcessFlowMdl = new JSONModel({
							"nodes": [],
							"lanes": []
						}),
							oProcessFlow = oView.byId("processflow1");

						oProcessFlow.setModel(oProcessFlowMdl, "viewData");
						oProcessFlowMdl.attachRequestCompleted(oProcessFlow.updateModel.bind(oProcessFlow));
						oProcessFlow.updateNodesOnly();
						this.getModel("viewDataMdl").setProperty("/bShowInvoicesBtn", false);
					} else {
						/*SOC BADH SOME4406 2024.04.04*/
						this.getModel("viewDataMdl").setProperty("/bShowInvoicesBtn", true);
						if (bShowAllInvoices === undefined) {
							this.getModel("viewDataMdl").setProperty("/bShowInvoicesBtnPressed", false);
						}

						this.renderProcessFlow(oData);
					}
				} catch (err) {

				}
			}.bind(this);
			_oReadOptions["fnError"] = function (oError) {
				MessageToast.show(oi18nModel.getText("ymsg.serviceError"));
				this.fnMsgManagerPopoverOpen(this.byId("msgPopover_btnId"));
			}.bind(this);
			ODataV4Utils.__readODataOperation(_oReadOptions);

		},
		//EOC PSENAPATI E2E New Design
		/*SOC BADH RAMP-1513 2024.01.16*/
		fnGetLanes: function () {
			var aLanes,
				oi18nModel = this.getResourceBundle();

			aLanes = [{
				"id": "0",
				"icon": "sap-icon://decision",
				"label": oi18nModel.getText("masterAgreement"),
				"position": 0
			}, {
				"id": "1",
				"icon": "sap-icon://sales-quote",
				"label": oi18nModel.getText("hpeSolutionQuotation"),
				"position": 1
			}, {
				"id": "2",
				"icon": "sap-icon://my-sales-order",
				"label": oi18nModel.getText("internalOrder"),
				"position": 2
			}, {
				"id": "3",
				"icon": "sap-icon://sales-order-item",
				"label": oi18nModel.getText("subscriptionContract"),
				"position": 3
			}, {
				"id": "4",
				"icon": "sap-icon://customer-financial-fact-sheet",
				"label": oi18nModel.getText("providerContract"),
				"position": 4
			}, {
				"id": "5",
				"icon": "sap-icon://sales-order-item",
				"label": oi18nModel.getText("salesOrder"),
				"position": 5
			}, {
				"id": "6",
				"icon": "sap-icon://shipping-status",
				"label": oi18nModel.getText("delivery"),
				"position": 6
			}, {
				"id": "7",
				"icon": "sap-icon://monitor-payments",
				"label": oi18nModel.getText("invoices"),
				"position": 7
			}, /*SOC BADH SOME4406 2024.04.04*/ {
				"id": "8",
				"icon": "sap-icon://customer-order-entry",
				"label": oi18nModel.getText("revenueContract"),
				"position": 8
			} /*EOC BADH SOME4406 2024.04.04*/];

			return aLanes;
		},

		fnGetUniqueRecords: function (aData, aProperties) {
			var aUniqueArr = [];

			aUniqueArr = aData.filter(function (oItem, idx, arr) {
				return arr.findIndex(function (__aUniqArr) {
					var filterConditions = {};
					aProperties.forEach(function (__sProp) {
						filterConditions[__sProp] = __aUniqArr[__sProp];
					});
					return Object.entries(filterConditions).every(function ([key, value]) {
						return oItem[key] === value && oItem[key] !== undefined && oItem[key] !== null;
						//&& oItem[key] !== "" && oItem[key] !== "000000000000" /*(-)BADH GLBP-1249 2024.06.06*/
					});
				}) === idx;
			});

			return aUniqueArr;
		},

		renderProcessFlow: function (oData) {
			var oi18nModel = this.getResourceBundle(),
				aUniqueMasterAgreement = [],
				aUniqueSolQuotations = [],
				aUniqueInternalOrder = [],
				aUniqueSubsContract = [],
				aUniqueProviderContract = [],
				aUniqueRevenueContract = [],
				aUniqueSalesOrder = [],
				aUniqueDeliveryDoc = [],
				aUniqueInvoices = [],
				oProcessFlowData = {
					"nodes": [],
					"lanes": this.fnGetLanes()
				};

			//MasterAgreement
			this.fnGetUniqueRecords(oData, ["Masteragreement"]).forEach(function (arr, idx) {
				if (arr["Masteragreement"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					var startDate = this.fnGetDateFormat(arr["Magreementstartdt"]),
						endDate = this.fnGetDateFormat(arr["Magreementenddt"]), //ACHOPRADELOI GLBP-3518 2024/10/23
						aTexts = [];

					if (startDate) {
						aTexts.push(oi18nModel.getText("startDate") + ": " + startDate.toLocaleDateString());
					}
					if (endDate) {
						aTexts.push(oi18nModel.getText("endDate") + ": " + endDate.toLocaleDateString());
					}
					aUniqueMasterAgreement.push({
						"id": "0" + (1000 + (idx + 1)).toString(),
						"lane": "0",
						"uniqueKey": arr["Masteragreement"],
						"__key": "MASTER_AGREEMENT",
						"__value": arr["Masteragreement"],
						"title": oi18nModel.getText("masterAgreement") + " : " + (arr["Masteragreement"].startsWith("9") && arr["Masteragreement"].length === 10 ? "NA" : arr["Masteragreement"]),
						"titleAbbreviation": (arr["Masteragreement"].startsWith("9") && arr["Masteragreement"].length === 10 ? "NA" : arr["Masteragreement"]),
						"children": [],
						"state": "Positive",
						"focused": true,
						"highlighted": false,
						"texts": aTexts
					});
				}
			}.bind(this));

			//SolutionQuotation
			this.fnGetUniqueRecords(oData, ["Quotenumber"]).forEach(function (arr, idx) {
				if (arr["Quotenumber"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					var startDate = this.fnGetDateFormat(arr["Quotstartdt"]),
						endDate = this.fnGetDateFormat(arr["Quotenddt"]),
						aTexts = [],
						sOrderType = "";

					if (arr["Ordertype"]) {
						sOrderType = (arr["Ordertype"] === "INIT" ? oi18nModel.getText("orderTypeInitial") : oi18nModel.getText("orderTypeChange"))
						aTexts.push(sOrderType);
					}
					if (startDate) {
						aTexts.push(oi18nModel.getText("startDate") + ": " + startDate.toLocaleDateString());
					}
					if (endDate) {
						aTexts.push(oi18nModel.getText("endDate") + ": " + endDate.toLocaleDateString());
					}

					aUniqueSolQuotations.push({
						"id": "1" + (1000 + (idx + 1)).toString(),
						"lane": "1",
						"uniqueKey": arr["Quotenumber"],
						"__key": "SOLUTION_QUOTATION",
						"__value": arr["Quotenumber"],
						"__sFlag": arr["Flag"],
						"title": oi18nModel.getText("hpeQuotation") + " : " + (arr["Quotenumber"].startsWith("9") && arr["Quotenumber"].length === 10 ? "NA" : arr["Quotenumber"]),
						"titleAbbreviation": (arr["Quotenumber"].startsWith("9") && arr["Quotenumber"].length === 10 ? "NA" : arr["Quotenumber"]),
						"children": [],
						"state": "Positive",
						"stateText": arr["Quotetype"] === "UPG" ? oi18nModel.getText("upgradeQuoteType") : arr["Quotetype"] === "AUTO-RENEW" ? oi18nModel.getText("RenewQuoteType") : arr["Quotetype"] === "CANCEL" ? oi18nModel.getText("cancelQuoteType") : oi18nModel.getText("newQuoteType"),
						"focused": true,
						"highlighted": false,
						"texts": aTexts,
						"sOrderType": sOrderType,
						/*"sPurchaseOrder": arr["PurchaseOrder"],
						"soldToParty": {
							"soldTPContact": arr["soldTPContact"],
							"soldTPPartyId": arr["soldTPPartyId"],
							"soldTPEmail": arr["soldTPEmail"],
							"soldTPAdress": arr["soldTPAdress"]
						},
						"endCustomerContact": {
							"endCustContact": arr["endCustContact"],
							"endCustPartyId": arr["endCustPartyId"],
							"endCustEmail": arr["endCustEmail"],
							"endCustAdress": arr["endCustAdress"]
						},
						"resellerContact": {
							"reSellerContact": arr["reSellerContact"],
							"reSellerPartyId": arr["reSellerPartyId"],
							"reSellerEmail": arr["reSellerEmail"],
							"reSellerAdress": arr["reSellerAdress"]
						}*/
					});
				}
			}.bind(this));

			//InternalOrder
			this.fnGetUniqueRecords(oData, ["Internalorder"]).forEach(function (arr, idx) {
				if (arr["Internalorder"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					var startDate = this.fnGetDateFormat(arr["Internalorderstartdt"]),
						endDate = this.fnGetDateFormat(arr["Internalordeerenddt"]),
						aTexts = [];

					if (startDate) {
						aTexts.push(oi18nModel.getText("startDate") + ": " + startDate.toLocaleDateString());
					}
					if (endDate) {
						aTexts.push(oi18nModel.getText("endDate") + ": " + endDate.toLocaleDateString());
					}
					if (arr["Externalreference"]) {
						aTexts.push(oi18nModel.getText("extReferenceNumber") + " : " + arr["Externalreference"]);
					}

					aUniqueInternalOrder.push({
						"id": "2" + (1000 + (idx + 1)).toString(),
						"lane": "2",
						"uniqueKey": arr["Internalorder"],
						"__key": "INTERNAL_ORDER",
						"__value": arr["Internalorder"],
						"title": oi18nModel.getText("internalOrder") + " : " + arr["Internalorder"],
						"titleAbbreviation": arr["Internalorder"],
						"children": [],
						"state": "Positive",
						"focused": true,
						"highlighted": false,
						"texts": aTexts
					});
				}
			}.bind(this));

			//SubscriptionsContract
			this.fnGetUniqueRecords(oData, ["Subscriptioncontract", "Quotenumber"]).forEach(
				function (arr, idx) {
					if (arr["Subscriptioncontract"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
						var startTimeSlice = this.fnGetDateFormat(arr["Subscontractstarttimeslice"]),
							endTimeSlice = this.fnGetDateFormat(arr["Subscontractendtimeslice"]),
							startDate = this.fnGetDateFormat(arr["Subscriptioncontractstartdt"]),
							endDate = this.fnGetDateFormat(arr["Subscriptioncontractenddt"]),
							aTexts = [];

						/*if (startTimeSlice) {
							aTexts.push(oi18nModel.getText("startDate") + ": " + startTimeSlice.toLocaleDateString());
						} else*/
						if (startDate) {
							aTexts.push(oi18nModel.getText("startDate") + ": " + startDate.toLocaleDateString());
						}

						/*if (endTimeSlice && arr["SubsContractEndTimeSlice"] !== "99991231235959") {
							aTexts.push(oi18nModel.getText("endDate") + ": " + endTimeSlice.toLocaleDateString());
						} else*/
						if (endDate) {
							aTexts.push(oi18nModel.getText("endDate") + ": " + endDate.toLocaleDateString());
						}

						aUniqueSubsContract.push({
							"id": "3" + (1000 + (idx + 1)).toString(),
							"lane": "3",
							"uniqueKey": arr["Subscriptioncontract"] + "|" + arr["Quotenumber"],
							"__key": "SUBSCRIPTION_CONTRACT",
							"__value": arr["Subscriptioncontract"],
							"title": oi18nModel.getText("subscriptionContract") + " : " + arr["Subscriptioncontract"],
							"titleAbbreviation": arr["Subscriptioncontract"],
							"children": [],
							"state": "Positive",
							"focused": true,
							"highlighted": false
							//"texts": aTexts ///GLBP-1759 - MNJDELOITTE - hiding dates for subsciption contract
						});
					}
				}.bind(this));

			//ProviderContract
			this.fnGetUniqueRecords(oData, ["Providercontractno", "Contractstartdate", "Contractenddate"]).forEach(function (
				arr, idx) {
				if (arr["Providercontractno"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					var startDate = this.fnGetDateFormat(arr["Subscontractstarttimeslice"]), // ACHOPRADELOI GLBP-1249 2024/06/21
						endDate = this.fnGetDateFormat(arr["Subscontractendtimeslice"]), // ACHOPRADELOI GLBP-1249 2024/06/21
						subsConStartDate = this.fnGetDateFormat(arr["Subscriptioncontractstartdt"]),
						subsConEndDate = this.fnGetDateFormat(arr["Subscriptioncontractenddt"]),
						aTexts = [],
						sStatusText = "";
					// SOC ACHOPRADELOI GLBP-1941/2185 2024/07/10
					if (arr["Subscontractendtimeslice"] === "99991231235959") {
						endDate = this.fnGetDateFormat(arr["Subscriptioncontractenddt"]);
					}
					// EOC ACHOPRADELOI GLBP-1941/2185 2024/07/10
					if (startDate) {
						aTexts.push(oi18nModel.getText("startDate") + ": " + startDate.toLocaleDateString());
					}
					if (endDate) {
						aTexts.push(oi18nModel.getText("endDate") + ": " + endDate.toLocaleDateString());
					}

					if (subsConStartDate && subsConEndDate) {
						sStatusText = subsConStartDate.toLocaleDateString() + " - " + subsConEndDate.toLocaleDateString();
					}

					aUniqueProviderContract.push({
						"id": "4" + (1000 + (idx + 1)).toString(),
						"lane": "4",
						"uniqueKey": arr["Providercontractno"] + "|" + arr["Contractstartdate"] + "|" + arr["Contractenddate"],
						"__key": "PROVIDER_CONTRACT",
						"__value": arr["Providercontractno"],
						"title": oi18nModel.getText("providerContract") + " : " + arr["Providercontractno"],
						"titleAbbreviation": arr["Providercontractno"],
						"children": [],
						"state": "Positive",
						"stateText": sStatusText,
						"focused": true,
						"highlighted": false,
						"texts": aTexts
					});
				}
			}.bind(this));

			//SalesOrder
			this.fnGetUniqueRecords(oData, ["Salesordernumber"]).forEach(function (arr, idx) {
				if (arr["Salesordernumber"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					var aTexts = [];
					if (arr["Referenceorder"]) {
						aTexts.push(oi18nModel.getText("referenceOrder") + " : " + arr["Referenceorder"]);
					}

					aUniqueSalesOrder.push({
						"id": "5" + (1000 + (idx + 1)).toString(),
						"lane": "5",
						"uniqueKey": arr["Salesordernumber"],
						"__key": "SALES_ORDER",
						"__value": arr["Salesordernumber"],
						"title": oi18nModel.getText("salesOrder") + " : " + arr["Salesordernumber"],
						"titleAbbreviation": arr["Salesordernumber"],
						"children": [],
						"state": "Positive",
						"focused": true,
						"highlighted": false,
						"texts": aTexts
					});
				}
			}.bind(this));

			//DeliveryOrder
			this.fnGetUniqueRecords(oData, ["Deliveryordernumber"]).forEach(function (arr, idx) {
				if (arr["Deliveryordernumber"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					aUniqueDeliveryDoc.push({
						"id": "6" + (1000 + (idx + 1)).toString(),
						"lane": "6",
						"uniqueKey": arr["Deliveryordernumber"],
						"__key": "DELIVERY",
						"__value": arr["Deliveryordernumber"],
						"title": oi18nModel.getText("delivery") + " : " + arr["Deliveryordernumber"],
						"titleAbbreviation": arr["Deliveryordernumber"],
						"children": [],
						"state": "Positive",
						"focused": true,
						"highlighted": false,
						"texts": null
					});
				}
			}.bind(this));

			//Invoices
			this.fnGetUniqueRecords(oData, ["Invoicedocumentnumbersn"]).forEach(function (arr, idx) {
				if (arr["Invoicedocumentnumbersn"] !== "" && arr["Invoicedocumentnumbersn"] !== "000000000000") { /*(+)BADH GLBP-1249 2024.06.06*/
					var postingDate = this.fnGetDateFormat(arr["Invoicingpostingdate"]),
						aTexts = [],
						sTitle;
					if (arr["Amount"]) {
						aTexts.push(oi18nModel.getText("amount") + " : " + arr["Amount"] + " " + arr["Currency"]);
					}
					if (postingDate) {
						aTexts.push(oi18nModel.getText("postingDate") + " : " + postingDate.toLocaleDateString());
					}
					/*SOC BADH INC4877743 2024.03.06*/
					switch (arr["InvoiceType"]) {
						case "GC":
						case "ZM":
							sTitle = oi18nModel.getText("creditMemo");
							break;
						case "GD":
						case "ZD":
							sTitle = oi18nModel.getText("debitMemo");
							break;
						case "GR":
						case "ZR":
							sTitle = oi18nModel.getText("invoiceReversal");
							break;
						case "GS":
						case "ZS":
							sTitle = oi18nModel.getText("invoiceSimulation");
							break;
						default:
							sTitle = oi18nModel.getText("invoices");
					}
					/*EOC BADH INC4877743 2024.03.06*/
					aUniqueInvoices.push({
						"id": "7" + (1000 + (idx + 1)).toString(),
						"lane": "7",
						"uniqueKey": arr["Invoicedocumentnumbersn"],
						"__key": "INVOICE",
						"__value": arr["Invoicedocumentnumbersn"],
						"title": sTitle + " : " + arr["Invoicedocumentnumbersn"],
						"titleAbbreviation": arr["Invoicedocumentnumbersn"],
						"children": [],
						"state": "Positive",
						"stateText": arr["Orignalinvoice"] ? (oi18nModel.getText("invoices") + ": " + arr["Orignalinvoice"]) : "",
						"focused": true,
						"highlighted": false,
						"texts": aTexts
					});
				}
			}.bind(this));

			/*SOC BADH SOME4406 2024.04.04*/
			//RevenueContract
			this.fnGetUniqueRecords(oData, ["Revacc", "Refid"]).forEach(function (arr, idx) {
				if (arr["Revacc"] !== "") { /*(+)BADH GLBP-1249 2024.06.06*/
					/*(-)SOC BADH GLBP-1381 2024.06.06*/
					/*var startDate = this.fnGetDateFormat(arr["revAccStartDt"]),
						endDate = this.fnGetDateFormat(arr["revAccEndDt"]),
						aTexts = [];

					if (startDate) {
						aTexts.push(oi18nModel.getText("startDate") + ": " + startDate.toLocaleDateString());
					}
					if (endDate) {
						aTexts.push(oi18nModel.getText("endDate") + ": " + endDate.toLocaleDateString());
					}*/
					/*(-)EOC BADH GLBP-1381 2024.06.06*/
					aUniqueRevenueContract.push({
						"id": "8" + (1000 + (idx + 1)).toString(),
						"lane": "8",
						"uniqueKey": arr["Revacc"] + "|" + arr["Refid"] /*(+)BADH GLBP-1249 2024.06.06*/,
						"__key": "REVENUE_CONTRACT",
						"__value": arr["Revacc"],
						"title": oi18nModel.getText("revenueContract") + " : " + arr["Revacc"],
						"titleAbbreviation": arr["Revacc"],
						"children": [],
						"state": "Positive",
						"focused": true,
						"highlighted": false,
						"texts": [] //aTexts/*(-)BADH GLBP-1381 2024.06.06*/
					});
				}
			}.bind(this));
			/*EOC BADH SOME4406 2024.04.04*/

			if (aUniqueMasterAgreement.length > 0) {
				aUniqueMasterAgreement.forEach(function (obj) {
					oData.forEach(function (__obj) {
						if (__obj["Masteragreement"] === obj["uniqueKey"]) {
							if (__obj["Quotenumber"] !== "" && aUniqueSolQuotations.length > 0) {
								this.fnAssignChildrens(aUniqueSolQuotations, __obj["Quotenumber"], obj);
							}
						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueSolQuotations.length > 0) {
				aUniqueSolQuotations.forEach(function (obj) {
					oData.forEach(function (__obj) {
						if (__obj["Quotenumber"] === obj["uniqueKey"]) {
							if (__obj["Internalorder"] !== "" && aUniqueInternalOrder.length > 0) {
								this.fnAssignChildrens(aUniqueInternalOrder, __obj["Internalorder"], obj);
							}
							if (__obj["Internalorder"] === "" && __obj["Subscriptioncontract"] !== "" &&
								aUniqueSubsContract.length > 0) {
								var sUniqueKey = __obj["Subscriptioncontract"] + "|" + __obj["Quotenumber"];
								this.fnAssignChildrens(aUniqueSubsContract, sUniqueKey, obj);
							}
							if (__obj["Internalorder"] === "" && __obj["Subscriptioncontract"] === "" && __obj["Providercontractno"] !== "" &&
								aUniqueProviderContract.length > 0) {
								var sUniqueKey = __obj["Providercontractno"] + "|" + __obj["Contractstartdate"] + "|" + __obj[
									"Contractenddate"];
								this.fnAssignChildrens(aUniqueProviderContract, sUniqueKey, obj);
							}
							if (__obj["Subscriptioncontract"] === "" && __obj["Providercontractno"] === "" && __obj["Salesordernumber"] !== "" &&
								aUniqueSalesOrder.length > 0) {
								this.fnAssignChildrens(aUniqueSalesOrder, __obj["Salesordernumber"], obj);
							}
						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueInternalOrder.length > 0) {
				aUniqueInternalOrder.forEach(function (obj) {
					oData.forEach(function (__obj) {
						if (__obj["Internalorder"] === obj["uniqueKey"]) {
							if (__obj["Subscriptioncontract"] !== "" && __obj["Providercontractno"] !== "" && aUniqueSubsContract.length > 0) {
								var sUniqueKey = __obj["Subscriptioncontract"] + "|" + __obj["Quotenumber"];
								this.fnAssignChildrens(aUniqueSubsContract, sUniqueKey, obj);
							}
						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueSubsContract.length > 0) {
				aUniqueSubsContract.forEach(function (obj) {
					oData.forEach(function (__obj) {
						var sSubsContractUniqueKey = __obj["Subscriptioncontract"] + "|" + __obj["Quotenumber"];
						if (sSubsContractUniqueKey === obj["uniqueKey"]) {
							if (__obj["Providercontractno"] !== "" && aUniqueProviderContract.length > 0) {
								var sUniqueKey = __obj["Providercontractno"] + "|" + __obj["Contractstartdate"] + "|" + __obj[
									"Contractenddate"];
								this.fnAssignChildrens(aUniqueProviderContract, sUniqueKey, obj);
							}
						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueProviderContract.length > 0) {
				aUniqueProviderContract.forEach(function (obj) {
					oData.forEach(function (__obj) {
						var sProviderContractUniqueKey = __obj["Providercontractno"] + "|" + __obj["Contractstartdate"] + "|" + __obj[
							"Contractenddate"];
						if (sProviderContractUniqueKey === obj["uniqueKey"]) {
							if (__obj["Salesordernumber"] !== "" && aUniqueSalesOrder.length > 0) {
								this.fnAssignChildrens(aUniqueSalesOrder, __obj["Salesordernumber"], obj);
							}
							if (__obj["Salesordernumber"] === "" && __obj["Invoicedocumentnumbersn"] !== "" && __obj[
								"Invoicedocumentnumbersn"] !==
								"000000000000" && aUniqueInvoices.length >
								0) {
								this.fnAssignChildrens(aUniqueInvoices, __obj["Invoicedocumentnumbersn"], obj);
							}
							/*SOC BADH SOME4406 2024.04.04*/
							if (__obj["Providercontractno"] !== ""
								/*&& (__obj["Invoicedocumentnumbers_n"] ===
									"" || __obj["Invoicedocumentnumbers_n"] === "000000000000")*/
								&& __obj["Revacc"] !== "" && aUniqueRevenueContract.length >
								0) {
								/*(+)SOC BADH GLBP-1249 2024.06.06*/
								var sUniqueRevContractKey = __obj["Revacc"] + "|" + __obj["Refid"];
								this.fnAssignChildrens(aUniqueRevenueContract, sUniqueRevContractKey, obj);
								/*(+)EOC BADH GLBP-1249 2024.06.06*/
								/*(-)SOC BADH GLBP-1249 2024.06.06*/
								// this.fnAssignChildrens(aUniqueRevenueContract, __obj["revAcc"], obj);
								/*(-)EOC BADH GLBP-1249 2024.06.06*/
							}
							/*EOC BADH SOME4406 2024.04.04*/
						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueSalesOrder.length > 0) {
				aUniqueSalesOrder.forEach(function (obj) {
					oData.forEach(function (__obj) {
						if (__obj["Salesordernumber"] === obj["uniqueKey"]) {
							if (__obj["Deliveryordernumber"] !== "" && aUniqueDeliveryDoc.length > 0) {
								this.fnAssignChildrens(aUniqueDeliveryDoc, __obj["Deliveryordernumber"], obj);
							}
							if (__obj["Providercontractno"] !== "" && __obj["Deliveryordernumber"] === "" && __obj["Invoicedocumentnumbersn"] !== "" &&
								__obj["Invoicedocumentnumbersn"] !==
								"000000000000" && aUniqueInvoices.length > 0) {
								this.fnAssignChildrens(aUniqueInvoices, __obj["Invoicedocumentnumbersn"], obj);
							}

						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueDeliveryDoc.length > 0) {
				aUniqueDeliveryDoc.forEach(function (obj) {
					oData.forEach(function (__obj) {
						if (__obj["Deliveryordernumber"] === obj["uniqueKey"]) {
							if (__obj["Providercontractno"] !== "" && __obj["Salesordernumber"] !== "" && __obj["Invoicedocumentnumbersn"] !== "" &&
								__obj["Invoicedocumentnumbersn"] !== "000000000000" && aUniqueInvoices.length > 0) {
								this.fnAssignChildrens(aUniqueInvoices, __obj["Invoicedocumentnumbersn"], obj);
							}
							/*SOC BADH SOME4406 2024.04.04*/
							if (__obj["Providercontractno"] !== "" && __obj["Salesordernumber"] !== "" && (__obj["Invoicedocumentnumbersn"] ===
								"" || __obj["Invoicedocumentnumbersn"] === "000000000000") && __obj["Revacc"] !== "" && aUniqueRevenueContract.length >
								0) {
								/*(+)SOC BADH GLBP-1249 2024.06.06*/
								var sUniqueRevContractKey = __obj["Revacc"] + "|" + __obj["Refid"];
								this.fnAssignChildrens(aUniqueRevenueContract, sUniqueRevContractKey, obj);
								/*(+)EOC BADH GLBP-1249 2024.06.06*/
								/*(-)SOC BADH GLBP-1249 2024.06.06*/
								// this.fnAssignChildrens(aUniqueRevenueContract, __obj["revAcc"], obj);
								/*(-)EOC BADH GLBP-1249 2024.06.06*/
							}
							/*EOC BADH SOME4406 2024.04.04*/
						}
					}.bind(this));
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			if (aUniqueInvoices.length > 0) {
				aUniqueInvoices.forEach(function (obj) {
					/*SOC BADH SOME4406 2024.04.04*/
					oData.forEach(function (__obj) {
						if (__obj["Invoicedocumentnumbersn"] === obj["uniqueKey"]) {
							if (__obj["revAcc"] !== "" && aUniqueRevenueContract.length > 0) {
								/*(+)SOC BADH GLBP-1249 2024.06.06*/
								var sUniqueRevContractKey = __obj["Revacc"] + "|" + __obj["Refid"];
								this.fnAssignChildrens(aUniqueRevenueContract, sUniqueRevContractKey, obj);
								/*(+)EOC BADH GLBP-1249 2024.06.06*/
								/*(-)SOC BADH GLBP-1249 2024.06.06*/
								// this.fnAssignChildrens(aUniqueRevenueContract, __obj["revAcc"], obj);
								/*(-)EOC BADH GLBP-1249 2024.06.06*/
							}
						}
					}.bind(this));
					/*EOC BADH SOME4406 2024.04.04*/
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}

			/*SOC BADH SOME4406 2024.04.04*/
			if (aUniqueRevenueContract.length > 0) {
				aUniqueRevenueContract.forEach(function (obj) {
					oProcessFlowData.nodes.push(obj);
				}.bind(this));
			}
			/*EOC BADH SOME4406 2024.04.04*/

			var oProcessFlowMdl = new JSONModel(oProcessFlowData),
				oView = this.getView(),
				oProcessFlow = oView.byId("processflow1");
			/*SOC BADH GLBP-5348 2025.04.11 */
			if (oProcessFlowData.nodes.length > 100) {
				oProcessFlowMdl.setSizeLimit(oProcessFlowData.nodes.length);
			}
			/*EOC BADH GLBP-5348 2025.04.11 */
			oProcessFlow.setModel(oProcessFlowMdl, "viewData");
			oProcessFlowMdl.attachRequestCompleted(oProcessFlow.updateModel.bind(oProcessFlow));
			oProcessFlow.updateNodesOnly();
		},

		fnAssignChildrens: function (aUniqueArr, sValue, oParentObj) {
			aUniqueArr.forEach(function (oUniqueItem) {
				if (oUniqueItem["uniqueKey"] === sValue) {
					var iExistsIdx = oParentObj.children.findIndex(function (__child) {
						return __child === oUniqueItem["id"];
					});
					if (iExistsIdx < 0) {
						oParentObj.children.push(oUniqueItem["id"]);
					}
				}
			});
		},
		/*EOC BADH RAMP-1513 2024.01.16*/

		/*SOC BADH END2ENDDOCFLOW 2.0 2024.01.23*/
		fnGetDateFormat: function (sDate) {
			var _sDate = "";
			try {
				if (sDate) {
					_sDate = new Date(sDate.slice(0, 4), (sDate.slice(4, 6) - 1), sDate.slice(6, 8));
				}
			} catch (err) {

			}
			return _sDate;
		},

		//SOC PSENAPATI E2E New Design
		onNodePress: function (oEvent) {
			var oi18nModel = this.getResourceBundle(),
				sSemanticObject = "",
				sAction = "",
				oURLParams = {},
				sAddOnUrls = "",
				oNode = oEvent.getParameters(),
				sTitle = oNode.getTitle(),
				sTitleAbbreviation = oNode.getTitleAbbreviation(),
				__oBindObj = oNode.getBindingContext("viewData").getObject();

			if (sTitleAbbreviation === "") {
				var idx = sTitle.indexOf(":"),
					__sTitle = sTitle.substring(0, idx);
				MessageBox.error(oi18nModel.getText("ymsg", [__sTitle]));
				return;
			} else if (__oBindObj["__key"] === "MASTER_AGREEMENT" && sTitleAbbreviation !== "NA") {
				sSemanticObject = "CustMgmtMasterAgreement";
				sAction = "display";
				oURLParams = {
					"CustMgmtMasterAgreement": __oBindObj["__value"],
					"sap-ui-tech-hint": "WCF"
				};
			} else if (__oBindObj["__key"] === "SOLUTION_QUOTATION" && sTitleAbbreviation !== "NA") {
				if (__oBindObj["__sFlag"] === "D") {
					sSemanticObject = "BusinessSolutionQuotation";
					sAction = "manage";
					oURLParams = {
						"sap-ui-tech-hint": "WCF",
					};
				} else if (__oBindObj["__sFlag"] === "P") {
					if (this._pSolQuoteQuickView) {
						this._pSolQuoteQuickView.then(function (oQuickView) {
							if (!oQuickView.isOpen() || oQuickView.getModel("oSolQuoteMdl").getProperty("/solutionQutation") !== __oBindObj["__value"]) {
								this.fnOpenSolQuoteDialog(__oBindObj, oNode);
							}
						}.bind(this));
					} else {
						this.fnOpenSolQuoteDialog(__oBindObj, oNode);
					}
				}
			} else if (__oBindObj["__key"] === "INTERNAL_ORDER") {
				sSemanticObject = "InternalOrder";
				sAction = "displayFactSheet";
				sAddOnUrls = "&/C_InternalOrderTP(InternalOrder='" + __oBindObj["__value"] +
					"',InternalOrderDraftInternalUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)/?FCLLayout=MidColumnFullScreen";
			} else if (__oBindObj["__key"] === "SUBSCRIPTION_CONTRACT") {
				sSemanticObject = "SubscriptionContractDocument";
				sAction = "manage";
				sAddOnUrls = "&/SubscriptionContract('" + __oBindObj["__value"] + "')";
			} else if (__oBindObj["__key"] === "PROVIDER_CONTRACT") {
				sSemanticObject = "CAProviderContract";
				sAction = "display";
				oURLParams = {
					"sap-ui-tech-hint": "GUI"
				};
				sAddOnUrls = "&DFKK_VT_H-VTKEY=" + __oBindObj["__value"];
			} else if (__oBindObj["__key"] === "REVENUE_CONTRACT") {
				sSemanticObject = "RevenueAccountingContract";
				sAction = "manageContract";
				sAddOnUrls = "&/C_RAContrWithPostedBalanceTP(RevenueAccountingContract='" + __oBindObj["__value"] +
					"',DraftUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)";
			} else if (__oBindObj["__key"] === "SALES_ORDER") {
				sSemanticObject = "SalesOrder";
				sAction = "displayFactSheet";
				oURLParams = {
					"SalesOrder": __oBindObj["__value"]
				};
			} else if (__oBindObj["__key"] === "DELIVERY") {
				sSemanticObject = "OutboundDelivery";
				sAction = "displayFactSheet";
				sAddOnUrls = "&/C_OutboundDeliveryFs('" + __oBindObj["__value"] + "')";

			} else if (__oBindObj["__key"] === "INVOICE") {
				sSemanticObject = "CAInvoicingDocument";
				sAction = "display";
				sAddOnUrls = "&/C_CAInvcgDocDisp('" + __oBindObj["__value"] + "')";
			}

			if (sSemanticObject && sAction) {
				this.__fnSetCrossAppNavigation(sSemanticObject, sAction, oURLParams, sAddOnUrls);
			}

		},

		fnOpenSolQuoteDialog: function (__oBindObj, oNode) {
			this.fnMsgManagerPopoverClose();
			var _oReadOptions = {},
				oi18nModel = this.getResourceBundle();
			_oReadOptions["oModel"] = this.getModel();
			_oReadOptions["sPath"] = "/PartnerDet('" + __oBindObj["__value"] + "')";
			_oReadOptions["isAbsolutePath"] = true;
			_oReadOptions["fnSuccess"] = function (oData) {
				var oView = this.getView(),

					oModel = new JSONModel({
						"solutionQutation": __oBindObj["__value"],
						"sPurchaseOrder": oData["Purchaseorder"],
						"sOrderType": __oBindObj["sOrderType"],
						"partners": [{
							"heading": oi18nModel.getText("soldToParty"),
							"headingIcon": "sap-icon://customer",
							"bVisible": oData["Soldtppartyid"] ? true : false,
							"elements": [{
								"label": oi18nModel.getText("contact"),
								"value": oData["Soldtpcontact"]
							}, {
								"label": oi18nModel.getText("partyID"),
								"value": oData["Soldtppartyid"]
							}, {
								"label": oi18nModel.getText("email"),
								"value": oData["Soldtpemail"]
							}, {
								"label": oi18nModel.getText("address"),
								"value": oData["Soldtpadress"]
							}]
						}, {
							"heading": oi18nModel.getText("endCustomerContact"),
							"headingIcon": "sap-icon://person-placeholder",
							"bVisible": oData["Endcustpartyid"] ? true : false,
							"elements": [{
								"label": oi18nModel.getText("contact"),
								"value": oData["Endcustcontact"]
							}, {
								"label": oi18nModel.getText("partyID"),
								"value": oData["Endcustpartyid"]
							}, {
								"label": oi18nModel.getText("email"),
								"value": oData["Endcustemail"]
							}, {
								"label": oi18nModel.getText("address"),
								"value": oData["Endcustadress"]
							}]
						}, {
							"heading": oi18nModel.getText("resellerContact"),
							"headingIcon": "sap-icon://person-placeholder",
							"bVisible": oData["Resellerpartyid"] ? true : false,
							"elements": [{
								"label": oi18nModel.getText("contact"),
								"value": oData["Resellercontact"]
							}, {
								"label": oi18nModel.getText("partyID"),
								"value": oData["Resellerpartyid"]
							}, {
								"label": oi18nModel.getText("email"),
								"value": oData["Reselleremail"]
							}, {
								"label": oi18nModel.getText("address"),
								"value": oData["Reselleradress"]
							}]
						}]
					});
				if (!this._pSolQuoteQuickView) {
					this._pSolQuoteQuickView = Fragment.load({
						id: oView.getId(),
						name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.SolQuoteQuickView",
						controller: this
					}).then(function (oQuickView) {
						oView.addDependent(oQuickView, this);
						return oQuickView;
					}.bind(this));
				}
				this._pSolQuoteQuickView.then(function (oQuickView) {
					oQuickView.setModel(oModel, "oSolQuoteMdl");
					oQuickView.openBy(oNode);
				});
			}.bind(this);
			_oReadOptions["fnError"] = function (oError) {
				MessageToast.show(oi18nModel.getText("ymsg.serviceError"));
				this.fnMsgManagerPopoverOpen(this.byId("msgPopover_btnId"));
			}.bind(this)
			ODataV4Utils.__readODataOperation(_oReadOptions);
		},
		//EOC PSENAPATI E2E New Design

		// SOC MSHARMAINFO1 INC5253215 30/5/2024 OPENING TILES IN NEW TABS

		__fnSetCrossAppNavigation: function (sSemanticObject, sAction, oURLParams, sAddOnUrls) {
			var deviceDesktop = this.getModel("device").getData().system.desktop;
			var devicecombi = this.getModel("device").getData().system.combi;
			var devicephone = this.getModel("device").getData().system.phone;
			var devicetablet = this.getModel("device").getData().system.tablet;
			if (deviceDesktop === true && devicecombi === false && devicephone === false && devicetablet === false) {
				var navigationService = sap.ushell.Container.getService('CrossApplicationNavigation');
				var hashnew = navigationService.hrefForExternalAsync({
					target: {
						semanticObject: sSemanticObject,
						action: sAction
					},
					params: oURLParams
				}).then(function (sHref) {
					var url = window.location.href.split('#')[0];
					url = url + sHref + (sAddOnUrls != "" ? ((url.indexOf("?") < 0 ? "?" : "&") + sAddOnUrls) : "");
					sap.m.URLHelper.redirect(url, true);
				})
			} else {
				sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oService) {
					oService.createEmptyAppStateAsync(this.getOwnerComponent()).then(function (oAppState) {
						oAppState.setData(this.fnGetFilters());
						oAppState.save();

						var sAppStateKey = oAppState.getKey(),
							oHashChangerInstance = oHashChanger.getInstance(),
							sOldHash = oHashChangerInstance.getHash(),
							sNewHash = "",
							sAppStateKeys = /(?:sap-iapp-state=)([^&=]+)/.exec(sOldHash);

						if (sAppStateKeys !== null) {
							sOldHash = sOldHash.replace(sAppStateKeys[0], '');
						}
						sNewHash = sOldHash + (sOldHash.indexOf("?") < 0 ? "?" : "&") + "sap-iapp-state=" + sAppStateKey;
						oHashChangerInstance.replaceHash(sNewHash);

						oService.hrefForExternalAsync({
							target: {
								semanticObject: sSemanticObject,
								action: sAction
							},
							appStateKey: sAppStateKey,
							params: oURLParams
						}).then(function (sHref) {
							oService.toExternal({
								target: {
									shellHash: sHref + sAddOnUrls
								}
							});
						});
					}.bind(this));

				}.bind(this));

			}
		},

		// EOC MSHARMAINFO1 INC5253215 
		onFilterInitialized: function (oEvent) {
			if (__oPrevFilterData) {
				var oFilterBar = this.byId("e2eDocFlow_fbId");
				__oPrevFilterData.forEach(function (ofilterData) {
					if (ofilterData["sPath"]) {
						oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
							if (oFilterGroupItem.getName() === ofilterData["sPath"]) {
								var oControl = oFilterGroupItem.getControl();
								oControl.setValue(ofilterData["oValue1"]);
							}
						});
					}
				});
				oFilterBar.fireSearch();
			}
		},

		onSolQuoteTitlePress: function (oEvent) {
			var sTitle = oEvent.getSource().getTitle(),
				sSemanticObject = "Sub",
				sAction = "quote",
				oURLParams = {},
				sAddOnUrls = "&/Display/" + sTitle;

			if (sSemanticObject && sAction) {
				this.__fnSetCrossAppNavigation(sSemanticObject, sAction, oURLParams, sAddOnUrls);
			}
		},
		/*EOC BADH END2ENDDOCFLOW 2.0 2024.01.23*/

		onZoomInBtnPress: function () {
			var oi18nModel = this.getResourceBundle(),
				oView = this.getView(),
				oProcessFlow1 = oView.byId("processflow1");
			oProcessFlow1.zoomIn();
			MessageToast.show(oi18nModel.getText("ymsg.zoomLevel") + " " + oProcessFlow1.getZoomLevel());
		},

		onZoomOutBtnPress: function () {
			var oi18nModel = this.getResourceBundle(),
				oView = this.getView(),
				oProcessFlow1 = oView.byId("processflow1");
			oProcessFlow1.zoomOut();
			MessageToast.show(oi18nModel.getText("ymsg.zoomLevel") + " " + oProcessFlow1.getZoomLevel());
		},

		onDownloadReportBtnPress: function (oEvent) {
			var aFilters = this.fnGetFilters(),
				MasterAgreement = "",
				ContractNumber = "",
				ProviderContractNo = "",
				SalesOrderNumber = "",
				InternalOrder = "",
				Deliveryordernumber = "",
				Invoicedocumentnumbers = "";

			for (var oFilter of aFilters) {
				switch (oFilter["sPath"]) {
					case "Masteragreement":
						MasterAgreement = oFilter["oValue1"];
						break;
					case "Quotenumber":
						ContractNumber = oFilter["oValue1"];
						break;
					case "Internalorder": //SOC by MCHANDWANIDE
						InternalOrder = oFilter["oValue1"];
						break;
					case "Deliveryordernumber":
						Deliveryordernumber = oFilter["oValue1"];
						break; //EOC by MCHANDWANIDE
					case "Providercontractno":
						ProviderContractNo = oFilter["oValue1"];
						break;
					case "Salesordernumber":
						SalesOrderNumber = oFilter["oValue1"];
						break;
					case "Invoicedocumentnumbersn":
						Invoicedocumentnumbers = oFilter["oValue1"];
						break;
				}
			}

			if (MasterAgreement || ContractNumber || InternalOrder || ProviderContractNo || SalesOrderNumber || Deliveryordernumber ||
				Invoicedocumentnumbers) {
				var sPath = "/sap/opu/odata/sap/Z_END_DOC_FLOW_SRV/Ets_DocFlow(Contractnumber='" + ContractNumber + "',Providercontractno='" +
					ProviderContractNo +
					"',Invoicedocumentnumbers='" + Invoicedocumentnumbers + "',Masteragreement='" + MasterAgreement +
					"',Internalorder='" + InternalOrder + "',Deliveryordernumber='" + Deliveryordernumber +
					"',Salesordernumber='" + SalesOrderNumber + "')/$value";
				this.myWindow = window.open(sPath, "_blank");
			}

			//EOI jmezadeloitt E2E Report
		},

		onBtnPressInvoices: function (oEvent) {
			var bShowAllInvoices = oEvent.getParameter("pressed"),
				oBtnSrc = oEvent.getSource(),
				oi18nModel = this.getResourceBundle(),
				aFilters = this.fnGetFilters();
			if (aFilters.length > 0) {
				this.getModel("viewDataMdl").setProperty("/bShowInvoicesBtnPressed", bShowAllInvoices);
			} else {
				this.getModel("viewDataMdl").setProperty("/bShowInvoicesBtnPressed", !bShowAllInvoices);
			}
			this.onPressSearch(null, bShowAllInvoices);
		},

		// SOC kkalikapuram valuehelp for Quote Id 2024/08/28
		onQuoteIdValueHelpRequest: function (oEvent) {
			if (!this.oVHQuoteId) {
				//create dialog with fragment
				this.oVHQuoteId = sap.ui.xmlfragment("Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHQuoteId",
					this);
				//adding dependent
				this.getView().addDependent(this.oVHQuoteId);
				// this.getView().byId("idVHQuote").setModel(this.getView().getModel("MANAGE"));
				// this.oVHQuoteId.attachBeforeOpen(function(){
				// 		var oModel = this.getView().getModel("MANAGE");
				// 		oModel.metadataLoaded().then(function(){
				// 			this.oVHQuoteId.setModel(oModel);
				// 		}.bind(this));
				// 	}.bind(this));
				this.oVHQuoteId.attachBeforeOpen(function () {
					var oModel = this.getView().getModel("MANAGE");
					oModel.metadataLoaded().then(function () {
						var oFilter = sap.ui.getCore().byId("smartFilterBarId");
						oFilter.setModel(oModel);
						oFilter.setEntitySet("Z_MANAGE_SOL_QUOTE_CDS");
						var oTable = sap.ui.getCore().byId("idQuoteSmartTable");
						oTable.setModel(oModel);
						oTable.setEntitySet("Z_MANAGE_SOL_QUOTE_CDS");
					}.bind(this));
				}.bind(this));

			}
			//open dialog
			this.oVHQuoteId.open();
		},
		// SOC kkalikapuram remove default c-suite user 2024/09/09
		onSmartFilterBarInitialise: function () {
			var oFilter = sap.ui.getCore().byId("smartFilterBarId");
			var oUserId = this.getView().getModel("globalMdl").getData().userId;
			if (oUserId.toUpperCase() !== 'CSUITE') {
				var oFilterData = {
					CREATED_BY: {
						items: [
							{
								key: oUserId,
								text: "=" + oUserId
							}
						]

					}
				}
			}
			else {
				var oFilterData = {
					"CREATED_ON": {
						"conditionTypeInfo": {
							"name": "sap.ui.comp.config.condition.DateRangeType",
							"data": {
								"operation": "THISWEEK",
								"value1": null,
								"value2": null,
								"key": "CREATED_ON"
							}
						}
					}
				}

			}
			oFilter.setFilterData(oFilterData, true);

		},
		// EOC kkalikapuram remove default c-suite user 2024/09/09
		onVHQuoteIdClose: function () {
			this.oVHQuoteId.close();
		},
		onSelectionChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem"),
				vSelectedID = oSelectedItem.getBindingContext().getObject("OBJECT_ID");
			this.getView().byId("quoteNo_inpId").setValue(vSelectedID);
			this.oVHQuoteId.close();
		},

		// EOC kkalikapuram valuehelp for Quote Id 2024/08/28
		/*SOC BADH DEFAULT SOLQUOTE 2024.08.29*/
		__fnGetAuthObjDtl: function () {
			if (this.getOwnerComponent().getComponentData().startupParameters.i_quote) {
				var quote = this.getOwnerComponent().getComponentData().startupParameters.i_quote[0];
				var oFilterBar = this.byId("e2eDocFlow_fbId");
				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Quotenumber") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(quote);
					}
				});
				this.onPressSearch(quote, undefined);
			}
			else {
				try {
					var _oReadOptions = {},
						aFilters = [];
					aFilters.push(new Filter("AppId", FilterOperator.EQ, "E2EDOCFLOW"));
					aFilters.push(new Filter("Operation", FilterOperator.EQ, "DEFAULT"));
					aFilters.push(new Filter("Field", FilterOperator.EQ, "SOLQUOTE"));
					_oReadOptions["oModel"] = this.getModel("ZSID_AUTH_OBJ");
					_oReadOptions["sPath"] = "/AuthObj";
					_oReadOptions["oFilters"] = [new Filter(aFilters, true)];
					_oReadOptions["isAbsolutePath"] = false;
					_oReadOptions["fnSuccess"] = function (oData, oResponse) {
						if (oData.length > 0) {
							for (var oVal of oData) {
								if (oVal.AppId === "E2EDOCFLOW" && oVal.Operation === "DEFAULT" && oVal.Field === "SOLQUOTE" && oVal.BAuthorized ===
									"X") {
									this.__fnGetDefaultVal();
								}
							}
						}
					}.bind(this);
					ODataV4Utils.__readODataOperation(_oReadOptions);
				} catch (err) {

				}
			}
		},

		__fnGetDefaultVal: function () {
			try {
				var _oReadOptions = {},
					aFilters = [];
				aFilters.push(new Filter("AppId", FilterOperator.EQ, "E2EDOCFLOW"));
				aFilters.push(new Filter("Operation", FilterOperator.EQ, "DISPLAY"));
				aFilters.push(new Filter("Field", FilterOperator.EQ, "SOLUTIONQUOTE"));
				_oReadOptions["oModel"] = this.getModel("ZSID_OPPR_ID");
				_oReadOptions["sPath"] = "/OppId";
				_oReadOptions["oFilters"] = [new Filter(aFilters, true)];
				_oReadOptions["isAbsolutePath"] = false;
				_oReadOptions["fnSuccess"] = function (oData, oResponse) {
					if (oData.length > 0) {
						for (var oVal of oData) {
							if (oVal.AppId === "E2EDOCFLOW" && oVal.Operation === "DISPLAY" && oVal.Field === "SOLUTIONQUOTE" && oVal.Value !==
								"") {
								var oFilterBar = this.byId("e2eDocFlow_fbId");
								oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
									if (oFilterGroupItem.getName() === "Quotenumber") {
										var oControl = oFilterGroupItem.getControl();
										oControl.setValue(oVal.Value);
									}
								});
								oFilterBar.fireSearch();
							}
						}
					}
				}.bind(this);
				ODataV4Utils.__readODataOperation(_oReadOptions);
			} catch (err) {

			}
		},
		/*EOC BADH DEFAULT SOLQUOTE 2024.08.29*/
		/*SOC BADH PLAT-76 VALUEHELP DIALOG FOR SEARCH FIELDS 2025.03.28*/
		onMasterAgreementVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpMasterAgreementDialog) {
				this._vHelpMasterAgreementDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpMasterAgreement",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4MSTRAGRMNT");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4MSTRAGRMNT");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("MasterAgreementId", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpMasterAgreementDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpMasterAgreementClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("MasterAgreementId"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Masteragreement") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpMasterAgreementDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},
		onInternalOrderVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpInternalOrderDialog) {
				this._vHelpInternalOrderDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpInternalOrder",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4INTORDR");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4INTORDR");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("InternalOrder", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpInternalOrderDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpInternalOrderClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("InternalOrder"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Internalorder") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpInternalOrderDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},

		onSubscriptionContractVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpSubscriptionContractDialog) {
				this._vHelpSubscriptionContractDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpSubscriptionContract",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4SUBSCNTRCT");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4SUBSCNTRCT");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("SubscriptionContract", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpSubscriptionContractDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpSubscriptionContractClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("SubscriptionContract"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Subscriptioncontract") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpSubscriptionContractDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},

		onProviderContractVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpProviderContractDialog) {
				this._vHelpProviderContractDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpProviderContract",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4PROVCNTRCT");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4PROVCNTRCT");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("ProviderContract", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpProviderContractDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpProviderContractClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("ProviderContract"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Providercontractno") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpProviderContractDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},

		onSalesOrderVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpSalesOrderDialog) {
				this._vHelpSalesOrderDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpSalesOrder",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4SALSORDR");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4SALSORDR");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("SalesOrder", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpSalesOrderDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpSalesOrderClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("SalesOrder"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Salesordernumber") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpSalesOrderDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},

		onDeliveryVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpDeliveryDialog) {
				this._vHelpDeliveryDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpDelivery",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4CDELIVERY");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4CDELIVERY");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("DeliveryNo", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpDeliveryDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpDeliveryClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("DeliveryNo"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Deliveryordernumber") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpDeliveryDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},

		onInvoiceVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpInvoiceDialog) {
				this._vHelpInvoiceDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpInvoice",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4INVOICE");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4INVOICE");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("InvoiceDocument", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));

					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpInvoiceDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpInvoiceClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("InvoiceDocument"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Invoicedocumentnumbersn") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpInvoiceDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		},

		onRevenueContractVHelpDialog: function (oEvent) {
			var oView = this.getView();
			if (!this._vHelpRevenueContractDialog) {
				this._vHelpRevenueContractDialog = Fragment.load({
					id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.VHelpRevenueContract",
					controller: this
				}).then(function (oVHelpDialog) {
					oView.addDependent(oVHelpDialog, this);
					oVHelpDialog.attachBeforeOpen(function () {
						var oModel = this.getModel("Z_END_DOC_FLOW_SRV");
						oModel.metadataLoaded().then(function () {
							var oSmartFilter = oVHelpDialog.getContent()[0].getHeader().getContent()[0].getContent()[0],
								oSmartTable = oVHelpDialog.getContent()[0].getContent();
							oSmartFilter.setModel(oModel);
							oSmartFilter.setEntitySet("ZE2EDOCFLOW_V4REVCONTRACT");
							oSmartTable.setModel(oModel);
							oSmartTable.setEntitySet("ZE2EDOCFLOW_V4REVCONTRACT");
							oSmartTable.attachBeforeRebindTable(function (oEvent) {
								var oBindingParams = oEvent.getParameter("bindingParams");
								if (oBindingParams.sorter.length === 0)
									oBindingParams.sorter.push(new Sorter("RevenueContract", true));
							}.bind(this));
						}.bind(this));
					}.bind(this));
					return oVHelpDialog;
				}.bind(this));
			}
			this._vHelpRevenueContractDialog.then(function (oVHelpDialog) {
				oVHelpDialog.open();
			});
		},

		onVHelpRevenueContractClose: function (oEvent) {
			var bSelected = oEvent.getParameter("selected");
			if (bSelected) {
				var oSelListItem = oEvent.getParameter("listItem"),
					sValue = oSelListItem.getBindingContext().getProperty("RevenueContract"),
					oFilterBar = this.byId("e2eDocFlow_fbId");

				oFilterBar.getFilterGroupItems().forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getName() === "Revacc") {
						var oControl = oFilterGroupItem.getControl();
						oControl.setValue(sValue);
					}
				});
			}
			this._vHelpRevenueContractDialog.then(function (oVHelpDialog) {
				oVHelpDialog.close();
			});
		}
		/*EOC BADH PLAT-76 VALUEHELP DIALOG FOR SEARCH FIELDS 2025.03.28*/

	});
});