sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment"
], function (Controller, Fragment) {
	"use strict";
	return Controller.extend("Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.controller.BaseController", {

		onInit: function () {
			this.getRouter().attachRoutePatternMatched(this._handleRouteMatched, this);
			// SOC kkalikapuram valuehelp for Quote Id 2024/08/28
			if (sap.ushell) {
				var oJsonMdl = new sap.ui.model.json.JSONModel({
					"userId": new sap.ushell.services.UserInfo().getId()
				});
				this.setJSONModel(oJsonMdl, "globalMdl", true);
			}
			// EOC kkalikapuram valuehelp for Quote Id 2024/08/28
			this.extOnInit();
		},

		getRouter: function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getModel: function (sName) {
			if (sName) {
				return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
			} else {
				return this.getView().getModel() || this.getOwnerComponent().getModel();
			}
		},

		setJSONModel: function (oData, sName, bGlobal) {
			if (bGlobal) {
				if (sName) {
					this.getOwnerComponent().setModel(oData, sName);
				} else {
					this.getOwnerComponent().setModel(oData);
				}
			} else {
				if (sName) {
					this.getView().setModel(oData, sName);
				} else {
					this.getView().setModel(oData);
				}
			}
		},

		popUpIcon: function (message) {
			if (message.length > 0) {
				var typeErr;
				var typeWar;
				typeErr = message.find(msgData => msgData.type === "Error");
				typeWar = message.find(msgData => msgData.type === "Warning");

				if (typeErr) {
					return "sap-icon://error";
				} else if (typeWar) {
					return "sap-icon://alert";
				} else {
					return "sap-icon://information";
				}

			}
		},

		popUpBtnType: function (message) {
			if (message.length > 0) {
				var typeErr;
				var typeWar;
				typeErr = message.find(msgData => msgData.type === "Error");
				typeWar = message.find(msgData => msgData.type === "Warning");

				if (typeErr) {
					return "Reject";
				} else if (typeWar) {
					return "Critical";
				} else {
					return "Emphasized";
				}

			}
		},

		fnMsgManagerPopoverOpen: function (oControl) {
			var oView = this.getView();

			if (!this.oMsgManagerPopover) {
				this.oMsgManagerPopover = Fragment.load({
					// id: oView.getId(),
					name: "Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.fragments.MsgManagerPopover",
					controller: this
				}).then(function (oMsgPopover) {
					oView.addDependent(oMsgPopover, this);
					return oMsgPopover;
				}.bind(this));
			} 
			this.oMsgManagerPopover.then(function (oMsgPopover) {
				window.setTimeout(function () {
					if (oControl.getVisible()) {
						oMsgPopover.openBy(oControl);
					}
				}.bind(this), 0);
			}.bind(this));
		},

		fnMsgManagerPopoverClose: function () {
			if (this.oMsgManagerPopover) {
				this.oMsgManagerPopover.then(function (oMsgPopover) {
					if (oMsgPopover.isOpen()) {
						oMsgPopover.close()
					}
				}.bind(this));
			}
			sap.ui.getCore().getMessageManager().removeAllMessages();
		}
	});
});