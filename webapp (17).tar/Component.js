sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"Z_DOC_FLOW_CPQ/Z_DOC_FLOW_CPQ/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("Z_DOC_FLOW_CPQ.Z_DOC_FLOW_CPQ.Component", {

		metadata: {
			"async": true,
			"interfaces": ["sap.ui.core.IAsyncContentCreation"],
			"manifest": "json"
		},

		/**
		 * //Test Commit
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});