/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.hpe.it.zui5odatautils.
 */
sap.ui.define([
	"sap/ui/core/library"
], function () {
	"use strict";

	// delegate further initialization of this library to the Core
	// Hint: sap.ui.getCore() must still be used to support preload with sync bootstrap!
	sap.ui.getCore().initLibrary({
		name: "com.hpe.it.zui5odatautils",
		version: "${version}",
		dependencies: [ // keep in sync with the ui5.yaml and .library files
			"sap.ui.core"
		],
		controls: [
			"com.hpe.it.zui5odatautils.controls.ExtBusyDialog"
		],
		noLibraryCSS: true // if no CSS is provided, you can disable the library.css load here
	});

	/**
	 * Some description about <code>zui5odatautils</code>
	 *
	 * @namespace
	 * @name com.hpe.it.zui5odatautils
	 * @author Fiori tools
	 * @version ${version}
	 * @public
	 */
	/* eslint-disable */
	return com.hpe.it.zui5odatautils;
	/* eslint-enable */
});
